package com.example

import android.app.Application
import android.util.Log
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class RisingRoadsApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        // Safe uncaught exception logger to capture diagnostic logs for any crashes
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("RisingRoadsApp", "FATAL EXCEPTION in thread ${thread.name}: ${throwable.message}", throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // Pre-warm database safely in background
        applicationScope.launch {
            try {
                AppDatabase.getDatabase(this@RisingRoadsApp, this)
            } catch (t: Throwable) {
                Log.e("RisingRoadsApp", "Database initialization during app startup: ${t.message}", t)
            }
        }
    }
}
