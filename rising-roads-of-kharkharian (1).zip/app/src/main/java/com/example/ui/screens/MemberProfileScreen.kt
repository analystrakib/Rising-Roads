package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Deposit
import com.example.data.model.Member
import com.example.data.repository.AppRepository
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.MainViewModel
import com.example.util.CurrencyFormatter
import com.example.util.ImageCompressor
import com.example.ui.components.AppCardBorder
import com.example.ui.components.AppCardElevation
import com.example.ui.components.AppCardShape
import com.example.ui.components.AppInputShape
import com.example.ui.components.DepositReceiptDialog
import com.example.ui.components.MemberAvatar
import com.example.ui.components.MemberPaymentRequestItemCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.appInputTextStyle
import com.example.ui.components.appOutlinedTextFieldColors
import com.example.ui.components.appSolidButtonColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadWarning
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.TABULAR_NUMBERS

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberProfileScreen(
    memberId: Int,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val membersWithStats by viewModel.membersWithStats.collectAsStateWithLifecycle()
    val allDeposits by viewModel.deposits.collectAsStateWithLifecycle()
    val allPaymentRequests by viewModel.paymentRequests.collectAsStateWithLifecycle()
    val adminUsername by viewModel.adminUsername.collectAsStateWithLifecycle()
    val adminRole by viewModel.adminRole.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    var showPhotoDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var selectedDepositForReceipt by remember { mutableStateOf<Deposit?>(null) }
    var isMonthBreakdownExpanded by remember { mutableStateOf(false) }

    val stats = membersWithStats.find { it.member.id == memberId }

    if (stats == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NagadVeryLightBg),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Member profile not found",
                    color = NagadSecondaryText,
                    fontFamily = PoppinsFontFamily,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onBack,
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text(
                        text = "Back to Members",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
        return
    }

    val member = stats.member
    val memberCode = "RRK-${member.id.toString().padStart(3, '0')}"
    val memberDeposits = remember(allDeposits, memberId) {
        allDeposits.filter { it.memberId == memberId }.sortedByDescending { it.paymentDate }
    }
    val memberPaymentRequests = remember(allPaymentRequests, memberId) {
        allPaymentRequests.filter { it.memberId == memberId }
    }
    val allActiveMonths = remember { AppRepository.getActiveMonths() }

    val paidMonthsCount = stats.paidMonths.size
    val totalContributed = stats.totalPaidContribution
    val totalFinePaid = stats.totalFinePaid
    val totalDue = stats.totalDue
    val unpaidMonths = stats.consecutiveUnpaidMonths
    val compliancePct = remember(paidMonthsCount, unpaidMonths) {
        val totalExpected = (paidMonthsCount + unpaidMonths).coerceAtLeast(1)
        ((paidMonthsCount.toFloat() / totalExpected) * 100).toInt().coerceIn(0, 100)
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val compressedDataUri = ImageCompressor.compressUriToDataUri(
                context = context,
                uri = uri,
                maxDim = 180,
                quality = 65
            )
            if (compressedDataUri.isNotBlank()) {
                viewModel.updateMemberPhoto(member.id, compressedDataUri)
            }
            showPhotoDialog = false
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("member_profile_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to members",
                            tint = NagadPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = member.name,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp,
                            color = NagadMainText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$memberCode · Investment Member",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = NagadSecondaryText
                        )
                    }
                }

                if (isAdmin) {
                    OutlinedButton(
                        onClick = { showEditDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NagadPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("edit_member_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = NagadPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Edit",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = NagadPrimary
                        )
                    }
                }
            }
        }

        // Profile Identity & Details Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box {
                                MemberAvatar(
                                    name = member.name,
                                    id = member.id,
                                    size = 72,
                                    photoUri = member.photoUri
                                )
                                if (isAdmin) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(28.dp)
                                            .background(NagadPrimary, CircleShape)
                                            .clickable { showPhotoDialog = true },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddPhotoAlternate,
                                            contentDescription = "Change profile photo",
                                            tint = NagadWhite,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = member.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = NagadMainText,
                                    fontFamily = PoppinsFontFamily
                                )
                                Text(
                                    text = memberCode,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NagadPrimary,
                                    fontFamily = PoppinsFontFamily
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                StatusBadge(status = stats.status)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = NagadBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    ProfileDetailRow("Member Code", memberCode)
                    ProfileDetailRow("Phone", member.phone)
                    ProfileDetailRow("Join Date", member.joinDate)
                    ProfileDetailRow("Address", member.address)
                    ProfileDetailRow("Monthly Commitment", "৳1,000 / month")
                    ProfileDetailRow("Last Payment", stats.lastPaymentDate ?: "No payment yet")
                }
            }
        }

        // Financial Summary Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Financial Summary",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NagadMainText
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val pdfFile = PdfReceiptGenerator.generateMemberSummaryReceipt(context, stats)
                                    PdfReceiptGenerator.sharePdf(context, pdfFile, "Download Member Summary (.pdf)")
                                },
                                colors = appSolidButtonColors(NagadPrimary),
                                shape = RoundedCornerShape(14.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.height(38.dp),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Download PDF", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = InterFontFamily, maxLines = 1)
                            }

                            OutlinedButton(
                                onClick = {
                                    val pdfFile = PdfReceiptGenerator.generateMemberSummaryReceipt(context, stats)
                                    PdfReceiptGenerator.printPdf(context, pdfFile, pdfFile.nameWithoutExtension)
                                },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.45f)),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                                modifier = Modifier.height(38.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Print, contentDescription = "Print Member Summary PDF", modifier = Modifier.size(14.dp), tint = NagadPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SummaryTileCard(
                            title = "TIMELINE",
                            headline = "${allActiveMonths.size} Mos",
                            sub = "Since ${member.joinDate.take(7)}",
                            bg = NagadLightBg,
                            border = NagadBorder,
                            headlineColor = NagadMainText,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryTileCard(
                            title = "INVESTED",
                            headline = CurrencyFormatter.formatCurrency(totalContributed),
                            sub = "$paidMonthsCount Mos Verified",
                            bg = NagadLightBg,
                            border = NagadBorder,
                            headlineColor = NagadPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryTileCard(
                            title = "CURRENT DUE",
                            headline = CurrencyFormatter.formatCurrency(totalDue),
                            sub = "$unpaidMonths Unpaid Mos",
                            bg = if (totalDue > 0) Color(0xFFFDF0F0) else NagadLightBg,
                            border = if (totalDue > 0) Color(0xFFFCDADA) else NagadBorder,
                            headlineColor = if (totalDue > 0) NagadDanger else NagadPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FinancialMetricBox(
                            label = "Paid Months",
                            value = "$paidMonthsCount",
                            bg = NagadLightBg,
                            color = NagadMainText,
                            modifier = Modifier.weight(1f)
                        )
                        FinancialMetricBox(
                            label = "Fines Paid",
                            value = CurrencyFormatter.formatCurrency(totalFinePaid),
                            bg = Color(0xFFFEF7E6),
                            color = NagadWarning,
                            modifier = Modifier.weight(1f)
                        )
                        FinancialMetricBox(
                            label = "Overdue Mos",
                            value = "$unpaidMonths",
                            bg = if (unpaidMonths > 0) Color(0xFFFDF0F0) else NagadLightBg,
                            color = if (unpaidMonths > 0) NagadDanger else NagadPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Payment Compliance",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText
                        )
                        Text(
                            text = "$compliancePct%",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { compliancePct / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp),
                        color = NagadPrimary,
                        trackColor = NagadLightBg
                    )
                }
            }
        }

        // Collapsible Month Breakdown
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isMonthBreakdownExpanded = !isMonthBreakdownExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Month Breakdown (${allActiveMonths.size} Months)",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = NagadMainText
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isMonthBreakdownExpanded) "Hide" else "Show",
                                fontFamily = PoppinsFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NagadPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (isMonthBreakdownExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isMonthBreakdownExpanded) "Collapse" else "Expand",
                                tint = NagadPrimary
                            )
                        }
                    }

                    AnimatedVisibility(visible = isMonthBreakdownExpanded) {
                        Column {
                            Spacer(modifier = Modifier.height(12.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                allActiveMonths.forEach { month ->
                                    val isPaid = stats.paidMonths.contains(month)
                                    val isPending = stats.pendingMonths.contains(month)
                                    val dep = memberDeposits.find { it.month == month }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isPaid) NagadLightBg else if (isPending) Color(0xFFFDF0F0) else Color(0xFFF1F5F9),
                                        border = BorderStroke(
                                            1.dp,
                                            if (isPaid) NagadPrimary.copy(alpha = 0.35f) else if (isPending) NagadDanger.copy(alpha = 0.35f) else NagadBorder
                                        ),
                                        modifier = Modifier.clickable(enabled = isPaid && dep != null) {
                                            if (dep != null) selectedDepositForReceipt = dep
                                        }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = month,
                                                fontFamily = PoppinsFontFamily,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isPaid) NagadPrimary else if (isPending) NagadDanger else NagadSecondaryText
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = if (isPaid) Icons.Default.Check else Icons.Default.Close,
                                                contentDescription = null,
                                                tint = if (isPaid) NagadPrimary else if (isPending) NagadDanger else Color.Transparent,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Payment Requests & Verified Proofs Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Payment Requests & Verified Proofs (${memberPaymentRequests.size})",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Live verification status & downloadable proof receipts",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp,
                        color = NagadSecondaryText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (memberPaymentRequests.isEmpty()) {
                        Text(
                            text = "No manual payment proofs submitted by ${member.name} yet.",
                            color = NagadSecondaryText,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            memberPaymentRequests.forEach { req ->
                                MemberPaymentRequestItemCard(
                                    request = req,
                                    memberPhone = member.phone,
                                    adminFallbackName = adminUsername,
                                    showMemberIdentity = false,
                                    onProofDownloaded = { msg -> viewModel.showToast(msg) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Deposit History Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Deposit History (${memberDeposits.size})",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (memberDeposits.isEmpty()) {
                        Text(
                            text = "No deposit records found for ${member.name}.",
                            color = NagadSecondaryText,
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.5.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        memberDeposits.forEach { dep ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedDepositForReceipt = dep }
                                    .padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "RRK-${dep.id.toString().padStart(4, '0')} · ${dep.month}",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = NagadMainText
                                    )
                                    Text(
                                        text = "Date: ${dep.paymentDate} · Amount: ${CurrencyFormatter.formatCurrency(dep.amount)} (${dep.paymentMode})",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp,
                                        color = NagadSecondaryText
                                    )
                                    if (dep.fine > 0) {
                                        Text(
                                            text = "Late Fine: ${CurrencyFormatter.formatCurrency(dep.fine)}",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadDanger
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = CurrencyFormatter.formatCurrency(dep.amount + dep.fine),
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Bold,
                                        color = NagadPrimary,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = NagadLightBg
                                    ) {
                                        Text(
                                            text = "Receipt",
                                            fontFamily = PoppinsFontFamily,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadPrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = NagadBorder)
                        }
                    }
                }
            }
        }

        // Remove Member Action (Admin Only, with confirmation)
        if (isAdmin) {
            item {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadDanger),
                    border = BorderStroke(1.dp, NagadDanger.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Remove Member from Directory",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    if (selectedDepositForReceipt != null) {
        DepositReceiptDialog(
            deposit = selectedDepositForReceipt!!,
            member = member,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = { selectedDepositForReceipt = null }
        )
    }

    if (isAdmin && showPhotoDialog) {
        AlertDialog(
            onDismissRequest = { showPhotoDialog = false },
            containerColor = NagadWhite,
            title = {
                Text(
                    text = "Member Profile Photo",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    MemberAvatar(
                        name = member.name,
                        id = member.id,
                        size = 96,
                        photoUri = member.photoUri
                    )

                    Text(
                        text = "Choose a profile photo from your device for ${member.name}.",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = NagadSecondaryText
                    )

                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Choose Photo from Device", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    if (!member.photoUri.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = {
                                viewModel.updateMemberPhoto(member.id, null)
                                showPhotoDialog = false
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadDanger),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Remove Current Photo", fontFamily = PoppinsFontFamily, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPhotoDialog = false }) {
                    Text("Close", fontFamily = PoppinsFontFamily, color = NagadPrimary)
                }
            }
        )
    }

    if (isAdmin && showEditDialog) {
        EditMemberDialog(
            member = member,
            memberCode = memberCode,
            onDismiss = { showEditDialog = false },
            onSave = { updated ->
                viewModel.updateMember(updated)
                showEditDialog = false
            }
        )
    }

    if (isAdmin && showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = NagadWhite,
            title = {
                Text(
                    text = "Remove ${member.name}?",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Text(
                    text = "This permanently removes ${member.name} ($memberCode) and their deposits from the database.",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 13.sp,
                    color = NagadSecondaryText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMember(member.id, member.name)
                        showDeleteConfirm = false
                        onBack()
                    },
                    colors = appSolidButtonColors(NagadDanger),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("Remove", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }
}

@Composable
private fun SummaryTileCard(
    title: String,
    headline: String,
    sub: String,
    bg: Color = NagadWhite,
    border: Color = NagadBorder,
    headlineColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = AppCardShape,
        color = NagadWhite,
        border = AppCardBorder,
        shadowElevation = AppCardElevation,
        modifier = modifier.height(108.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                fontSize = 10.5.sp,
                color = NagadSecondaryText,
                fontWeight = FontWeight.SemiBold,
                fontFamily = PoppinsFontFamily,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = headline,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 15.5.sp,
                fontWeight = FontWeight.Bold,
                color = headlineColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = sub,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun EditMemberDialog(
    member: Member,
    memberCode: String,
    onDismiss: () -> Unit,
    onSave: (Member) -> Unit
) {
    var name by remember { mutableStateOf(member.name) }
    var phone by remember { mutableStateOf(member.phone) }
    var joinDate by remember { mutableStateOf(member.joinDate) }
    var address by remember { mutableStateOf(member.address) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        title = {
            Text(
                text = "Edit $memberCode Profile",
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                color = NagadMainText
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone *", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = joinDate,
                    onValueChange = { joinDate = it },
                    label = { Text("Join Date (YYYY-MM-DD)", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        member.copy(
                            name = name.trim(),
                            phone = phone.trim(),
                            joinDate = joinDate.trim().ifBlank { member.joinDate },
                            address = address.trim().ifBlank { "Kharkharian" }
                        )
                    )
                },
                enabled = name.isNotBlank() && phone.isNotBlank(),
                colors = appSolidButtonColors(NagadPrimary),
                modifier = Modifier.height(48.dp)
            ) {
                Text(
                    text = "Save Profile",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
            }
        }
    )
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            color = NagadSecondaryText
        )
        Text(
            text = value,
            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = NagadMainText
        )
    }
}

@Composable
private fun FinancialMetricBox(
    label: String,
    value: String,
    bg: Color,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, NagadBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontFamily = InterFontFamily,
                fontSize = 10.sp,
                color = NagadSecondaryText,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}
