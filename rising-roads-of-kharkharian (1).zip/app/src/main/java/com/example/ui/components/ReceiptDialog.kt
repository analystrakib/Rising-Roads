package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.remember
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.local.SessionManager
import com.example.data.model.Deposit
import com.example.data.model.Member
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DepositReceiptDialog(
    deposit: Deposit,
    member: Member,
    adminName: String,
    adminRole: String,
    dynamicDue: Int = 0,
    isAdmin: Boolean? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val resolvedIsAdmin = remember(isAdmin, context) {
        isAdmin ?: runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    }
    val total = deposit.amount + deposit.fine
    val rNo = "RRK-${deposit.id.toString().padStart(4, '0')}"
    val formattedTime = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date(deposit.inputTimestamp))

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp)
                .testTag("deposit_receipt_dialog"),
            shape = AppCardShape,
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = AppCardBorder,
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                // Header with Compact Official RRK Logo, Centered Title & Top-Right Close Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF064E3B),
                                    Color(0xFF059669),
                                    Color(0xFF10B981)
                                )
                            )
                        )
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                ) {
                    // Centered Header Content with generous right clearance from the X button
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 22.dp, end = 32.dp)
                            .align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color.White, CircleShape)
                                    .border(1.2.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.logo),
                                    contentDescription = "Rising Roads of Kharkharian Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Rising Roads Of Kharkharian",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.5.sp,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Joint Capital Investment Platform",
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 10.5.sp,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "RECEIPT: $rNo",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Absolute Top-Right Close Button
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.TopEnd)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                // Body Info
                Column(modifier = Modifier.padding(16.dp)) {
                    ReceiptRow(label = "Member Name", value = member.name, isBold = true)
                    ReceiptRow(label = "Member ID", value = "RRK-${member.id.toString().padStart(3, '0')}")
                    ReceiptRow(label = "Payment Month", value = deposit.month)
                    ReceiptRow(label = "Payment Date", value = deposit.paymentDate)
                    ReceiptRow(label = "Paid Amount", value = com.example.util.CurrencyFormatter.formatCurrency(deposit.amount), isBold = true)

                    if (deposit.fine > 0) {
                        ReceiptRow(
                            label = "Late Fine (after 15th)",
                            value = com.example.util.CurrencyFormatter.formatCurrency(deposit.fine),
                            isDanger = true,
                            isBold = true
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Total Collected Highlighted Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFECFDF5),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF6EE7B7)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total Collected",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46),
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = com.example.util.CurrencyFormatter.formatCurrency(total),
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldGreen,
                                fontSize = 17.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Single-Line Issued Timestamp & Role-Aware Signature / System Verified Receipt Area
                    val displayName = adminName.trim().ifBlank { "Admin" }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Issued: $formattedTime",
                            fontSize = 9.5.sp,
                            color = NagadSecondaryText,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        if (resolvedIsAdmin) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                HorizontalDivider(
                                    color = Color(0xFF064E3B),
                                    thickness = 1.dp,
                                    modifier = Modifier.width(120.dp)
                                )
                                Text(
                                    text = "Generated by: $displayName",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NagadMainText,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(top = 3.dp)
                                )
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFECFDF5),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6EE7B7))
                            ) {
                                Text(
                                    text = "System Verified Receipt",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF065F46),
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Buttons Above Final Footer
                    Button(
                        onClick = {
                            val (imageFile, savedToGallery) = PdfReceiptGenerator.generateDepositReceiptImage(
                                context = context,
                                deposit = deposit,
                                member = member,
                                adminName = displayName,
                                isAdmin = resolvedIsAdmin
                            )
                            val toastText = if (savedToGallery) {
                                "Receipt ${imageFile.name} saved to Pictures/RisingRoads"
                            } else {
                                "Receipt image ready to save or share"
                            }
                            Toast.makeText(context, toastText, Toast.LENGTH_SHORT).show()
                            PdfReceiptGenerator.shareImage(context, imageFile, "Save / Share Receipt $rNo (.png)")
                        },
                        colors = appSolidButtonColors(EmeraldGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("download_receipt_image_button")
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download Image (.png)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val pdfFile = PdfReceiptGenerator.generateDepositReceipt(
                                    context = context,
                                    deposit = deposit,
                                    member = member,
                                    adminName = displayName,
                                    isAdmin = resolvedIsAdmin
                                )
                                PdfReceiptGenerator.sharePdf(context, pdfFile, "Download Receipt $rNo (.pdf)")
                            },
                            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1.25f)
                                .testTag("download_receipt_pdf_button")
                        ) {
                            Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp), tint = EmeraldGreen)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download PDF", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = EmeraldGreen, maxLines = 1, softWrap = false)
                        }

                        OutlinedButton(
                            onClick = {
                                val pdfFile = PdfReceiptGenerator.generateDepositReceipt(
                                    context = context,
                                    deposit = deposit,
                                    member = member,
                                    adminName = displayName,
                                    isAdmin = resolvedIsAdmin
                                )
                                PdfReceiptGenerator.printPdf(context, pdfFile, "RRK_Receipt_$rNo")
                            },
                            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(0.85f)
                                .testTag("print_receipt_pdf_button")
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = "Print PDF", modifier = Modifier.size(14.dp), tint = EmeraldGreen)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Print", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = EmeraldGreen, maxLines = 1, softWrap = false)
                        }

                        OutlinedButton(
                            onClick = onDismiss,
                            border = androidx.compose.foundation.BorderStroke(1.dp, InputBorder),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                            modifier = Modifier.weight(0.75f)
                        ) {
                            Text("Close", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = NagadSecondaryText, maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Minimalist Bottom Footer Line below subtle thin top border (1px solid #E5E7EB)
                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = PdfReceiptGenerator.UNIFIED_BOTTOM_FOOTER,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        modifier = Modifier
                            .padding(top = 8.dp, bottom = 2.dp)
                            .fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    isDanger: Boolean = false
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText
            )
            Text(
                text = value,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 12.5.sp,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                color = if (isDanger) RedAlert else NagadMainText
            )
        }
        HorizontalDivider(color = NagadBorder, thickness = 1.dp)
    }
}
