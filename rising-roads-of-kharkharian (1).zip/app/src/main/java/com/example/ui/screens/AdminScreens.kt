package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.AdminAlertEmailSettings
import com.example.data.model.AdminUser
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberAccount
import com.example.data.model.MemberSettlement
import com.example.data.model.MemberWithStats
import com.example.data.model.OfficialPaymentAccounts
import com.example.data.model.PaymentRequest
import com.example.data.model.CustomPage
import com.example.data.model.ExitedMember
import com.example.data.model.FinancialKpi
import com.example.data.repository.AppRepository
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.MainViewModel
import com.example.util.AdminNotificationHelper
import com.example.util.CurrencyFormatter
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminLoginScreen(
    viewModel: MainViewModel,
    onLoginSuccess: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .padding(20.dp)
            .testTag("admin_login_screen"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = AppCardShape,
            colors = CardDefaults.cardColors(containerColor = NagadWhite),
            border = AppCardBorder,
            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(NagadLightBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = NagadPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Admin Access",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = NagadMainText
                    )
                )
                Text(
                    text = "Rising Roads Control Panel",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username", fontFamily = InterFontFamily) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = NagadPrimary) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Ascii
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_username_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password", fontFamily = InterFontFamily) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = NagadPrimary) },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Password
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_password_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = NagadDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = InterFontFamily,
                            modifier = Modifier.padding(10.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        viewModel.login(username.trim(), password.trim()) { success, msg ->
                            if (success) {
                                errorMessage = null
                                onLoginSuccess()
                            } else {
                                errorMessage = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_login_submit_button")
                ) {
                    Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, fontFamily = InterFontFamily)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    viewModel: MainViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToDeposits: () -> Unit,
    onNavigateToExpenses: () -> Unit,
    onNavigateToInvestments: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToCustomPage: (CustomPage) -> Unit = {}
) {
    val context = LocalContext.current
    val adminUsername by viewModel.adminUsername.collectAsState()
    val adminRole by viewModel.adminRole.collectAsState()
    val kpi by viewModel.financialKpi.collectAsState()
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val deposits by viewModel.deposits.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val settlements by viewModel.settlements.collectAsState()
    val admins by viewModel.admins.collectAsState()
    val memberAccounts by viewModel.memberAccounts.collectAsState()
    val activityLogs by viewModel.activityLogs.collectAsState()
    val paymentRequests by viewModel.paymentRequests.collectAsState()
    val pendingPaymentRequestsCount by viewModel.pendingPaymentRequestsCount.collectAsState()
    val officialAccounts by viewModel.officialPaymentAccounts.collectAsState()
    val adminAlertEmailSettings by viewModel.adminAlertEmailSettings.collectAsState()
    val simulatedReminderDay by viewModel.simulatedReminderDay.collectAsState()
    val exitedMembers by viewModel.exitedMembers.collectAsState()
    val customPages by viewModel.customPages.collectAsState()
    val isCloudConnected by viewModel.isCloudConnected.collectAsState()
    val syncState by viewModel.syncState.collectAsState()

    val pendingPaymentRequests = remember(paymentRequests) {
        paymentRequests.filter { it.status == "PENDING" }
    }
    val processedPaymentRequests = remember(paymentRequests) {
        paymentRequests.filter { it.status != "PENDING" }
    }

    var requestToReject by remember { mutableStateOf<PaymentRequest?>(null) }
    var showEditOfficialAccountsDialog by remember { mutableStateOf(false) }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val adminDrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()

    val tabs = listOf(
        "Overview",
        "Members",
        "Deposits",
        "Expenses",
        "Investments",
        "Org Settings",
        "Return Ledger",
        "Voucher",
        "Restore",
        "Admin Users",
        "Settings",
        "Activity Log",
        "Exited Members",
        "Custom Pages"
    )

    val adminDrawerSections = remember {
        listOf(
            "MANAGEMENT" to listOf(
                Triple(0, "Overview", Icons.Default.Home),
                Triple(1, "Members", Icons.Default.Groups),
                Triple(2, "Deposits", Icons.Default.Payments),
                Triple(3, "Expenses", Icons.Default.MoneyOff),
                Triple(4, "Investments", Icons.AutoMirrored.Filled.TrendingUp)
            ),
            "GOVERNANCE & LEDGERS" to listOf(
                Triple(5, "Org Settings", Icons.Default.Apartment),
                Triple(6, "Return Ledger", Icons.AutoMirrored.Filled.ReceiptLong),
                Triple(7, "Voucher", Icons.Default.Receipt),
                Triple(12, "Exited Members", Icons.Default.Person)
            ),
            "SYSTEM & SECURITY" to listOf(
                Triple(8, "Restore", Icons.Default.Restore),
                Triple(9, "Admin Users", Icons.Default.AdminPanelSettings),
                Triple(10, "Settings", Icons.Default.Settings),
                Triple(11, "Activity Log", Icons.Default.History),
                Triple(13, "Custom Pages", Icons.Default.Tune)
            )
        )
    }

    BackHandler(enabled = adminDrawerState.isOpen) {
        drawerScope.launch { adminDrawerState.close() }
    }

    var searchQuery by remember { mutableStateOf("") }

    // Dialog States for Member CRUD
    var showAddMemberDialog by remember { mutableStateOf(false) }
    var memberToEdit by remember { mutableStateOf<Member?>(null) }
    var memberToDelete by remember { mutableStateOf<Member?>(null) }

    // Dialog States for Deposit CRUD & Bulk
    var showAddDepositDialog by remember { mutableStateOf(false) }
    var showBulkDepositDialog by remember { mutableStateOf(false) }
    var depositToEdit by remember { mutableStateOf<Deposit?>(null) }
    var depositToDelete by remember { mutableStateOf<Deposit?>(null) }
    var selectedDepositForReceipt by remember { mutableStateOf<Deposit?>(null) }
    var selectedMemberForReceipt by remember { mutableStateOf<Member?>(null) }

    // Dialog States for Expense CRUD & Bulk
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showBulkExpenseDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<Expense?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }

    // Dialog States for Investment CRUD & Bulk
    var showAddInvestmentDialog by remember { mutableStateOf(false) }
    var showBulkInvestmentDialog by remember { mutableStateOf(false) }
    var investmentToEdit by remember { mutableStateOf<Investment?>(null) }
    var investmentToDelete by remember { mutableStateOf<Investment?>(null) }

    // Dialog States for Member Settlement
    var showAddSettlementDialog by remember { mutableStateOf(false) }
    var settlementToDelete by remember { mutableStateOf<MemberSettlement?>(null) }

    // Dialog States for Admin Management & Settings
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showAddAdminDialog by remember { mutableStateOf(false) }

    // Dialog States for Backup & Restore
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showResetDefaultsConfirm by remember { mutableStateOf(false) }
    var exportedJsonPreview by remember { mutableStateOf<String?>(null) }

    // Dialog States for Exited Members
    var showAddExitedMemberDialog by remember { mutableStateOf(false) }
    var showMarkActiveExitedDialog by remember { mutableStateOf(false) }
    var exitedMemberToEdit by remember { mutableStateOf<ExitedMember?>(null) }
    var exitedMemberToDelete by remember { mutableStateOf<ExitedMember?>(null) }

    // Dialog States for Custom Pages
    var showAddCustomPageDialog by remember { mutableStateOf(false) }
    var customPageToEdit by remember { mutableStateOf<CustomPage?>(null) }
    var customPageToDelete by remember { mutableStateOf<CustomPage?>(null) }

    val membersMap = remember(membersWithStats) {
        membersWithStats.associate { it.member.id to it.member }
    }

    ModalNavigationDrawer(
        drawerState = adminDrawerState,
        gesturesEnabled = adminDrawerState.isOpen,
        scrimColor = Color.Black.copy(alpha = 0.35f),
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(284.dp)
                    .testTag("admin_sections_drawer"),
                drawerContainerColor = NagadWhite,
                drawerContentColor = NagadMainText
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NagadLightBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = NagadPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Admin Sections",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.5.sp,
                                color = NagadMainText
                            )
                            Text(
                                text = "$adminUsername ($adminRole)",
                                fontFamily = InterFontFamily,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadSecondaryText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    adminDrawerSections.forEachIndexed { groupIndex, (groupTitle, itemsList) ->
                        Text(
                            text = groupTitle,
                            fontFamily = InterFontFamily,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadSecondaryText,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )

                        itemsList.forEach { (tabIdx, title, icon) ->
                            val isSelected = selectedTabIndex == tabIdx
                            NavigationDrawerItem(
                                label = {
                                    Text(
                                        text = title,
                                        fontFamily = InterFontFamily,
                                        color = if (isSelected) NagadPrimary else NagadMainText,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isSelected) NagadPrimary else NagadSecondaryText,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                badge = if (isSelected) {
                                    {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(NagadPrimary)
                                        )
                                    }
                                } else null,
                                selected = isSelected,
                                onClick = {
                                    selectedTabIndex = tabIdx
                                    drawerScope.launch { adminDrawerState.close() }
                                },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = NagadLightBg,
                                    unselectedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .testTag("admin_drawer_item_$tabIdx")
                            )
                        }

                        if (groupIndex < adminDrawerSections.lastIndex) {
                            HorizontalDivider(
                                color = NagadBorder,
                                thickness = 1.dp,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    ) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("admin_panel_screen")
    ) {
        // Top Header with Secondary Admin Sections Drawer Button (no horizontal scrollable tabs)
        Surface(
            color = NagadWhite,
            shadowElevation = AppCardElevation,
            border = BorderStroke(1.5.dp, NagadBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = { drawerScope.launch { adminDrawerState.open() } },
                        shape = RoundedCornerShape(12.dp),
                        color = NagadLightBg,
                        border = BorderStroke(1.dp, NagadBorder),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("admin_sections_drawer_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Open Admin Sections Drawer",
                                tint = NagadPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Admin Control Panel",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = InterFontFamily,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NagadMainText
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NagadLightBg,
                                border = BorderStroke(1.dp, NagadBorder)
                            ) {
                                Text(
                                    text = tabs[selectedTabIndex],
                                    fontFamily = InterFontFamily,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NagadPrimary,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "$adminUsername ($adminRole)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadSecondaryText,
                                fontFamily = InterFontFamily,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                if (pendingPaymentRequestsCount > 0) {
                    Surface(
                        onClick = { selectedTabIndex = 0 },
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .testTag("admin_panel_notification_bell")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Pending Payment Notifications",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$pendingPaymentRequestsCount",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { viewModel.logout() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadDanger),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                ) {
                    Text("Logout", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = InterFontFamily)
                }
            }
        }

        if (pendingPaymentRequestsCount > 0) {
            Surface(
                onClick = { selectedTabIndex = 0 },
                color = Color(0xFFFFFBEB),
                border = BorderStroke(1.2.dp, Color(0xFFF59E0B)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("admin_pending_payment_alert_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🔔 New Payment Proof Pending Verification — Review Now",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = "$pendingPaymentRequestsCount pending payment proof(s) awaiting Admin verification",
                            fontFamily = InterFontFamily,
                            fontSize = 10.5.sp,
                            color = Color(0xFFB45309)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Review ($pendingPaymentRequestsCount) →",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = NagadPrimary
                    )
                }
            }
        }

        // Search bar for filtering deposits, expenses, or investments by category or member name
        if (selectedTabIndex in listOf(2, 3, 4)) {
            Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { 
                        val tabName = when(selectedTabIndex) {
                            2 -> "Search deposits by member, month, mode..."
                            3 -> "Search expenses by category, description..."
                            4 -> "Search investments by name, type..."
                            else -> "Search..."
                        }
                        Text(tabName, fontSize = 12.sp, color = NagadSecondaryText, fontFamily = PoppinsFontFamily)
                    },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = NagadPrimary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = NagadSecondaryText)
                            }
                        }
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(13.5.sp),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("admin_search_bar")
                )
            }
        }

        // Tab Content
        when (selectedTabIndex) {
            0 -> {
                // 1. OVERVIEW TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Admin Payment Approval Queue (Top of Admin Panel)
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = BorderStroke(
                                1.5.dp,
                                if (pendingPaymentRequests.isNotEmpty()) Color(0xFFFCD34D) else NagadBorder
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_payment_approval_queue")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = "Payment Approval Queue",
                                            fontFamily = PoppinsFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.5.sp,
                                            color = NagadMainText
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (pendingPaymentRequests.isNotEmpty()) Color(0xFFFFFBEB) else NagadLightBg,
                                            border = BorderStroke(
                                                1.dp,
                                                if (pendingPaymentRequests.isNotEmpty()) Color(0xFFFCD34D) else NagadBorder
                                            )
                                        ) {
                                            Text(
                                                text = "${pendingPaymentRequests.size} Pending",
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = if (pendingPaymentRequests.isNotEmpty()) Color(0xFFB45309) else NagadPrimary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    TextButton(
                                        onClick = { showEditOfficialAccountsDialog = true },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            tint = NagadPrimary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Accounts",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = NagadPrimary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Approving automatically posts the verified deposit, recalculates Cash/Bank/Liquid Capital, and unlocks the member's PNG proof receipt.",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 11.5.sp,
                                    color = NagadSecondaryText
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                if (pendingPaymentRequests.isEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = NagadLightBg,
                                        border = BorderStroke(1.dp, NagadBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "All caught up! No pending manual payment requests right now.",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 12.sp,
                                            color = NagadPrimary,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        pendingPaymentRequests.forEach { req ->
                                            val reqTotal = req.amount + req.fine
                                            val memberPhone = membersMap[req.memberId]?.phone.orEmpty()
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = Color(0xFFFFFBEB),
                                                border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("pending_request_item_${req.id}")
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = "${req.memberName} (RRK-${req.memberId.toString().padStart(3, '0')})",
                                                                fontFamily = InterFontFamily,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 13.5.sp,
                                                                color = NagadMainText
                                                            )
                                                            Text(
                                                                text = "${req.month} · ${req.paymentMethod} · TrxID: ${req.trxId.ifBlank { "Cash" }}",
                                                                fontFamily = InterFontFamily,
                                                                fontSize = 11.5.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = NagadSecondaryText
                                                            )
                                                            if (memberPhone.isNotBlank()) {
                                                                Text(
                                                                    text = "Date: ${req.paymentDate} · Phone: $memberPhone",
                                                                    fontFamily = InterFontFamily,
                                                                    fontWeight = FontWeight.Medium,
                                                                    fontSize = 10.5.sp,
                                                                    color = NagadSecondaryText
                                                                )
                                                            }
                                                        }

                                                        Column(horizontalAlignment = Alignment.End) {
                                                            Text(
                                                                text = CurrencyFormatter.formatCurrency(reqTotal),
                                                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                                fontWeight = FontWeight.ExtraBold,
                                                                fontSize = 16.sp,
                                                                color = NagadPrimary
                                                            )
                                                            if (req.fine > 0) {
                                                                Text(
                                                                    text = "Base ${CurrencyFormatter.formatCurrency(req.amount)} + Fine ${CurrencyFormatter.formatCurrency(req.fine)}",
                                                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    fontSize = 10.sp,
                                                                    color = NagadDanger
                                                                )
                                                            }
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(10.dp))

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        OutlinedButton(
                                                            onClick = { requestToReject = req },
                                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadDanger),
                                                            border = BorderStroke(1.dp, NagadDanger.copy(alpha = 0.55f)),
                                                            shape = RoundedCornerShape(10.dp),
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .height(48.dp)
                                                                .testTag("reject_request_btn_${req.id}")
                                                        ) {
                                                            Text(
                                                                text = "Reject",
                                                                fontFamily = InterFontFamily,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 12.5.sp
                                                            )
                                                        }

                                                        Button(
                                                            onClick = { viewModel.approvePaymentRequest(req.id) },
                                                            colors = appSolidButtonColors(NagadPrimary),
                                                            shape = RoundedCornerShape(10.dp),
                                                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                                                            modifier = Modifier
                                                                .weight(1.3f)
                                                                .height(48.dp)
                                                                .testTag("approve_request_btn_${req.id}")
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Check,
                                                                contentDescription = null,
                                                                tint = Color.White,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = "Approve & Sync",
                                                                fontFamily = InterFontFamily,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 12.5.sp,
                                                                color = Color.White
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (processedPaymentRequests.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    HorizontalDivider(color = NagadBorder)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Recent Verified / Processed Proofs (${processedPaymentRequests.size})",
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = NagadMainText
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        processedPaymentRequests.take(5).forEach { req ->
                                            MemberPaymentRequestItemCard(
                                                request = req,
                                                memberPhone = membersMap[req.memberId]?.phone.orEmpty(),
                                                adminFallbackName = adminUsername,
                                                showMemberIdentity = true,
                                                onProofDownloaded = { msg -> viewModel.showToast(msg) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Quick Action Buttons
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Quick Management Actions", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText, fontFamily = PoppinsFontFamily)
                                Spacer(modifier = Modifier.height(12.dp))

                                // 2x2 Grid for Quick Actions
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Card 1: + Add Member
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(52.dp)
                                                .clickable { showAddMemberDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            color = NagadWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NagadBorder)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = NagadPrimary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "+ Add Member",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NagadMainText,
                                                    fontFamily = PoppinsFontFamily,
                                                    maxLines = 1
                                                )
                                            }
                                        }

                                        // Card 2: + Add Deposit
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(52.dp)
                                                .clickable { showAddDepositDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            color = NagadWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NagadBorder)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.AttachMoney,
                                                    contentDescription = null,
                                                    tint = NagadPrimary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "+ Add Deposit",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NagadMainText,
                                                    fontFamily = PoppinsFontFamily,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Card 3: + Add Expense
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(52.dp)
                                                .clickable { showAddExpenseDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            color = NagadWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NagadBorder)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.MoneyOff,
                                                    contentDescription = null,
                                                    tint = NagadPrimary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "+ Add Expense",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NagadMainText,
                                                    fontFamily = PoppinsFontFamily,
                                                    maxLines = 1
                                                )
                                            }
                                        }

                                        // Card 4: + Add Investment
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(52.dp)
                                                .clickable { showAddInvestmentDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            color = NagadWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NagadBorder)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.TrendingUp,
                                                    contentDescription = null,
                                                    tint = NagadPrimary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "+ Add Investment",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = NagadMainText,
                                                    fontFamily = PoppinsFontFamily,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Sleek secondary export backup button
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .clickable {
                                            viewModel.exportDatabaseBackup(context) { file, json ->
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "application/json"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    putExtra(Intent.EXTRA_SUBJECT, file.name)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Share Database Backup JSON"))
                                            }
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = NagadVeryLightBg,
                                    border = AppCardBorder
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 14.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Backup,
                                            contentDescription = null,
                                            tint = NagadMainText,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Export Full Database Backup (JSON)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadMainText,
                                            fontFamily = InterFontFamily,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Official Payment Accounts Settings (bKash / Nagad / Bank)
                    item {
                        OfficialPaymentAccountsSettingsCard(
                            officialAccounts = officialAccounts,
                            onSave = { bkash, nagad, bank ->
                                viewModel.updateOfficialPaymentAccounts(bkash, nagad, bank)
                            }
                        )
                    }

                    // Admin Alert Email & EmailJS Settings
                    item {
                        AdminAlertEmailSettingsCard(
                            settings = adminAlertEmailSettings,
                            onSave = { email, serviceId, templateId, publicKey ->
                                viewModel.updateAdminAlertEmailSettings(
                                    adminAlertEmail = email,
                                    emailJsServiceId = serviceId,
                                    emailJsTemplateId = templateId,
                                    emailJsPublicKey = publicKey
                                )
                            }
                        )
                    }

                    // Scheduled Monthly Due Reminders (1st / 8th / 14th) Preview & Test
                    item {
                        AdminScheduledDueRemindersTestCard(
                            membersWithStats = membersWithStats,
                            simulatedReminderDay = simulatedReminderDay,
                            onTriggerTest = { day, memberId ->
                                viewModel.triggerTestDueReminders(day, memberId)
                            }
                        )
                    }

                    // System Operational Rules Status
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("System Automation Rules", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Spacer(modifier = Modifier.height(10.dp))

                                val rules = listOf(
                                    "11 Founding Members Contribution (৳1,000/mo)" to "Active",
                                    "Deadline 15th of month" to "Active",
                                    "Late Fine ৳100 auto-applied after 15th" to "Active",
                                    "Fine funds redirected to Company Capital" to "Active",
                                    "RED ALERT on 3 consecutive unpaid months" to "Active",
                                    "JSON Database Backup & Restore Engine" to "Active",
                                    "Native PDF Receipt Vector Generator" to "Active",
                                    "Room Database Local Persistence" to "Active"
                                )

                                rules.forEach { (rule, status) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(rule, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadMainText)
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = Color(0xFFECFDF5)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(status, color = EmeraldGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    HorizontalDivider(color = NagadBorder)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // 2. MEMBERS TAB (FULL CRUD)
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("All Members (${membersWithStats.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NagadMainText)
                            Button(
                                onClick = { showAddMemberDialog = true },
                                colors = appSolidButtonColors(RoyalBlue),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Member", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    items(membersWithStats, key = { it.member.id }) { item ->
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            "RRK-${item.member.id.toString().padStart(3, '0')}",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontSize = 11.sp,
                                            color = RoyalBlue,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(item.member.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadMainText)
                                    }
                                    Text("Phone: ${item.member.phone} · Joined: ${item.member.joinDate}", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                    Text("Address: ${item.member.address}", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                    Text(
                                        "Paid: ${CurrencyFormatter.formatCurrency(item.totalPaidContribution)} (${item.paidMonths.size} mos) · Due: ${CurrencyFormatter.formatCurrency(item.totalDue)}",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { memberToEdit = item.member }) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Member", tint = RoyalBlue, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(onClick = { memberToDelete = item.member }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Member", tint = RedAlert, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // 3. DEPOSITS TAB (FULL CRUD)
                var depositsExpanded by remember { mutableStateOf(false) }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "All Deposit Records",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NagadMainText,
                                maxLines = 1
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { depositsExpanded = !depositsExpanded },
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(36.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, RoyalBlue)
                                ) {
                                    Text(if (depositsExpanded) "Hide" else "Show", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        imageVector = if (depositsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = RoyalBlue
                                    )
                                }
                                Button(
                                    onClick = { showAddDepositDialog = true },
                                    colors = appSolidButtonColors(RoyalBlue),
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Entry", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                                }
                            }
                        }
                    }

                    item {
                        AnimatedVisibility(visible = depositsExpanded) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                val filteredDeposits = remember(deposits, searchQuery, membersMap) {
                                    if (searchQuery.isBlank()) deposits else {
                                        deposits.filter { dep ->
                                            val m = membersMap[dep.memberId]
                                            val mName = m?.name ?: ""
                                            mName.contains(searchQuery, true) ||
                                            dep.month.contains(searchQuery, true) ||
                                            dep.paymentMode.contains(searchQuery, true) ||
                                            dep.id.toString().contains(searchQuery)
                                        }
                                    }
                                }
                                filteredDeposits.forEach { dep ->
                                    val m = membersMap[dep.memberId]
                                    val rNo = "RRK-${dep.id.toString().padStart(4, '0')}"
                                    val mName = m?.name ?: "Member #${dep.memberId}"

                                    Card(
                                        shape = AppCardShape,
                                        colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                        border = AppCardBorder,
                                        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "$rNo • $mName",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = NagadMainText
                                                )
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Text(
                                                    text = "Month: ${dep.month} · Date: ${dep.paymentDate}",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = NagadSecondaryText
                                                )
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "Total: ${CurrencyFormatter.formatCurrency(dep.amount + dep.fine)}",
                                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = FintechPrimary
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "(Base: ${CurrencyFormatter.formatCurrency(dep.amount)}",
                                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                        fontSize = 11.5.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = NagadSecondaryText
                                                    )
                                                    if (dep.fine > 0) {
                                                        Text(
                                                            text = ", Fine: ${CurrencyFormatter.formatCurrency(dep.fine)}",
                                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                            fontSize = 11.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = FintechDuesRed
                                                        )
                                                    }
                                                    Text(
                                                        text = ")",
                                                        fontSize = 11.5.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = NagadSecondaryText
                                                    )
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        if (m != null) {
                                                            selectedDepositForReceipt = dep
                                                            selectedMemberForReceipt = m
                                                        }
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Visibility,
                                                        contentDescription = "Receipt",
                                                        tint = RoyalBlue,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { depositToEdit = dep },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "Edit Deposit",
                                                        tint = Gold,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { depositToDelete = dep },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete Deposit",
                                                        tint = RedAlert,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // 4. EXPENSES TAB (FULL CRUD)
                var expensesExpanded by remember { mutableStateOf(false) }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Operational Expenses",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NagadMainText,
                                maxLines = 1
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { expensesExpanded = !expensesExpanded },
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(36.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, RoyalBlue)
                                ) {
                                    Text(if (expensesExpanded) "Hide" else "Show", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        imageVector = if (expensesExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = RoyalBlue
                                    )
                                }
                                Button(
                                    onClick = { showAddExpenseDialog = true },
                                    colors = appSolidButtonColors(RoyalBlue),
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Expense", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                                }
                            }
                        }
                    }

                    item {
                        AnimatedVisibility(visible = expensesExpanded) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                val filteredExpenses = remember(expenses, searchQuery) {
                                    if (searchQuery.isBlank()) expenses else {
                                        expenses.filter { exp ->
                                            exp.category.contains(searchQuery, true) ||
                                            exp.description.contains(searchQuery, true) ||
                                            exp.paidBy.contains(searchQuery, true)
                                        }
                                    }
                                }
                                filteredExpenses.forEach { exp ->
                                    Card(
                                        shape = AppCardShape,
                                        colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                        border = AppCardBorder,
                                        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(exp.description, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadMainText)
                                                Text("Category: ${exp.category} · Date: ${exp.date}", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                                Text(
                                                    "Amount: ${CurrencyFormatter.formatCurrency(exp.amount)}",
                                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = RedAlert
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(onClick = { expenseToEdit = exp }) {
                                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Expense", tint = RoyalBlue, modifier = Modifier.size(18.dp))
                                                }
                                                IconButton(onClick = { expenseToDelete = exp }) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Expense", tint = RedAlert, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            4 -> {
                // 5. INVESTMENTS TAB (FULL CRUD)
                var investmentsExpanded by remember { mutableStateOf(false) }
                val runningInvestments = remember(investments) {
                    investments.filter { it.status.equals("Active", true) || it.status.equals("Running", true) }
                }
                val totalRunningCapital = runningInvestments.sumOf { if (it.activeCapital > 0) it.activeCapital else it.amount }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Commercial Investments",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NagadMainText,
                                maxLines = 1
                            )
                            Button(
                                onClick = { showAddInvestmentDialog = true },
                                colors = appSolidButtonColors(RoyalBlue),
                                shape = RoundedCornerShape(18.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Investment", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                            }
                        }
                    }

                    // Running Investments Summary Card
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🚀", fontSize = 18.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Running Investments", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = FintechMintTint,
                                        modifier = Modifier.wrapContentWidth()
                                    ) {
                                        Text(
                                            text = "${runningInvestments.size} Active",
                                            color = FintechPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Total Running Capital Deployed: ${CurrencyFormatter.formatCurrency(totalRunningCapital)}",
                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FintechPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Active commercial trade cycles currently in progress and generating returns.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NagadSecondaryText
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "All Investment Records",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NagadMainText,
                                maxLines = 1
                            )
                            OutlinedButton(
                                onClick = { investmentsExpanded = !investmentsExpanded },
                                shape = RoundedCornerShape(18.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(36.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, FintechPrimary)
                            ) {
                                Text(if (investmentsExpanded) "Hide" else "Show", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FintechPrimary)
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = if (investmentsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = FintechPrimary
                                )
                            }
                        }
                    }

                    item {
                        AnimatedVisibility(visible = investmentsExpanded) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                val filteredInvestments = remember(investments, searchQuery) {
                                    if (searchQuery.isBlank()) investments else {
                                        investments.filter { inv ->
                                            inv.name.contains(searchQuery, true) ||
                                            inv.type.contains(searchQuery, true) ||
                                            inv.supervisor.contains(searchQuery, true) ||
                                            inv.status.contains(searchQuery, true)
                                        }
                                    }
                                }
                                filteredInvestments.forEach { inv ->
                                    val isRunning = inv.status.uppercase() == "RUNNING" || inv.status.uppercase() == "ACTIVE"
                                    val badgeText = if (isRunning) "RUNNING" else "CLOSED"

                                    Card(
                                        shape = AppCardShape,
                                        colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                        border = AppCardBorder,
                                        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = inv.name,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = NagadMainText,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = if (isRunning) Color(0xFFE8F5E9) else NagadVeryLightBg,
                                                        border = androidx.compose.foundation.BorderStroke(1.5.dp, if (isRunning) FintechPrimary else NagadBorder),
                                                        modifier = Modifier.wrapContentWidth()
                                                    ) {
                                                        Text(
                                                            text = badgeText,
                                                            fontSize = 10.sp,
                                                            color = if (isRunning) FintechPrimary else NagadSecondaryText,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1,
                                                            softWrap = false,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Text(
                                                    text = "Type: ${inv.type} · Capital Deployed: ${CurrencyFormatter.formatCurrency(inv.amount)}",
                                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = NagadSecondaryText
                                                )
                                                if (inv.purchasedQuantity.isNotBlank() || inv.supervisor.isNotBlank()) {
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = "Qty: ${inv.purchasedQuantity} | Supervisor: ${inv.supervisor}",
                                                        fontSize = 11.5.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = NagadSecondaryText
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (isRunning) {
                                                    Text(
                                                        text = "P&L: Ongoing / In Progress",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = FintechAmber
                                                    )
                                                } else {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = "P&L: ${CurrencyFormatter.formatSignedCurrency(inv.profitLoss)}",
                                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (inv.profitLoss >= 0) FintechPrimary else FintechDuesRed
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text(
                                                            text = "Revenue: ${CurrencyFormatter.formatCurrency(inv.saleRevenue)}",
                                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Medium,
                                                            color = NagadSecondaryText
                                                        )
                                                    }
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                IconButton(
                                                    onClick = { investmentToEdit = inv },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "Edit Investment",
                                                        tint = Gold,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { investmentToDelete = inv },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete Investment",
                                                        tint = RedAlert,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            5 -> {
                // ORGANIZATION SETTINGS TAB
                OrganizationSettingsTab(viewModel = viewModel)
            }

            6 -> {
                // MEMBER SETTLEMENT & RETURN LEDGER TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Member Settlement & Return Ledger (${settlements.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Text("Formula: Total Deposit - (Legal/Stamp ৳ + Shared Losses ৳)", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                            }
                            Button(
                                onClick = { showAddSettlementDialog = true },
                                colors = appSolidButtonColors(RedAlert),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Settlement", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    if (settlements.isEmpty()) {
                        item {
                            Card(
                                shape = AppCardShape,
                                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                border = AppCardBorder,
                                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🤝 No Resigned / Settled Members Yet", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadMainText)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("All 11 active founding members are currently active in good standing.", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                    } else {
                        items(settlements, key = { it.id }) { s ->
                            Card(
                                shape = AppCardShape,
                                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                border = AppCardBorder,
                                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(s.memberName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                            Text("Resigned: ${s.resignationDate} · Mode: ${s.paymentMode}", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (s.settlementStatus == "Done") EmeraldGreen.copy(alpha = 0.15f) else Gold.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = s.settlementStatus,
                                                color = if (s.settlementStatus == "Done") EmeraldGreen else DeepNavy,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Total Deposits: ${CurrencyFormatter.formatCurrency(s.totalDepositPaid)} · Legal Charge: ${CurrencyFormatter.formatCurrency(s.legalCharge)} · Shared Loss: ${CurrencyFormatter.formatCurrency(s.sharedLosses)}",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText
                                    )
                                    Text(
                                        "Net Return Amount: ${CurrencyFormatter.formatCurrency(s.netReturnAmount)}",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = RoyalBlue
                                    )
                                    if (s.notes.isNotBlank()) {
                                        Text("Notes: ${s.notes}", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                        if (s.settlementStatus != "Done") {
                                            TextButton(onClick = { viewModel.updateSettlement(s.copy(settlementStatus = "Done")) }) {
                                                Text("Mark as Done", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        IconButton(onClick = { settlementToDelete = s }) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = RedAlert, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            7 -> {
                // HEAD OFFICE RRK VOUCHER TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        HeadOfficeVoucherCard(kpi = kpi, context = context, adminName = adminUsername)
                    }
                }
            }

            8 -> {
                // 9. BACKUP & RESTORE TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Firebase Cloud Firestore & Storage",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = NagadMainText
                                        )
                                        Text(
                                            text = "Real-time bidirectional synchronization with Cloud Firestore and Firebase Storage. Offline persistence is active with automatic first-launch seeding.",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = NagadSecondaryText,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                    Surface(
                                        color = if (isCloudConnected) Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(start = 8.dp)
                                    ) {
                                        Text(
                                            text = if (isCloudConnected) "● Cloud Active" else "● Offline Mode",
                                            color = if (isCloudConnected) EmeraldGreen else Color(0xFFD97706),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            drawerScope.launch {
                                                viewModel.firebaseRepository.pushAllLocalDataToFirestore()
                                            }
                                        },
                                        colors = appSolidButtonColors(EmeraldGreen),
                                        shape = AppInputShape,
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Push to Cloud", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            drawerScope.launch {
                                                viewModel.firebaseRepository.pullRemoteDataFromFirestore()
                                            }
                                        },
                                        shape = AppInputShape,
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldGreen)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Pull from Cloud", fontWeight = FontWeight.Bold, color = EmeraldGreen, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Export Database to JSON", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NagadMainText)
                                Text(
                                    text = "Creates a complete snapshot of all 11 founding members, deposits, expenses, investments, settlements, settings, and activity logs. You can share or store this file safely to ensure member financial history is never lost.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NagadSecondaryText,
                                    modifier = Modifier.padding(top = 4.dp)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        viewModel.exportDatabaseBackup(context) { file, json ->
                                            exportedJsonPreview = json
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/json"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                putExtra(Intent.EXTRA_SUBJECT, file.name)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Database Backup JSON"))
                                        }
                                    },
                                    colors = appSolidButtonColors(EmeraldGreen),
                                    shape = AppInputShape,
                                    modifier = Modifier.fillMaxWidth().height(46.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Export & Share JSON Backup File", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Restore Database from JSON", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NagadMainText)
                                Text(
                                    text = "Paste or load a valid Rising Roads backup JSON file to restore all tables and history.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NagadSecondaryText,
                                    modifier = Modifier.padding(top = 4.dp)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = { showRestoreDialog = true },
                                    colors = appSolidButtonColors(RoyalBlue),
                                    shape = AppInputShape,
                                    modifier = Modifier.fillMaxWidth().height(46.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Restore Database from JSON...", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                            border = BorderStroke(1.5.dp, Color(0xFFFCA5A5)),
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Reset to Verified 11 Founding Members", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = RedAlert)
                                Text(
                                    text = "Restores the verified database with 11 founding members and the exact 2025-2026 month-by-month deposit matrix (৳1,79,000 deposits + ৳2,900 fines).",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF991B1B),
                                    modifier = Modifier.padding(top = 4.dp)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { showResetDefaultsConfirm = true },
                                    colors = appSolidButtonColors(RedAlert),
                                    shape = AppInputShape,
                                    modifier = Modifier.fillMaxWidth().height(46.dp)
                                ) {
                                    Text("Reset Database to Official 11 Founding Members", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            9 -> {
                // 10. ADMIN USERS TAB
                AdminUsersTabContent(
                    viewModel = viewModel,
                    adminUsername = adminUsername,
                    admins = admins,
                    memberAccounts = memberAccounts
                )
            }

            10 -> {
                // 11. SETTINGS TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Security & Password", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Update password for administrator \"$adminUsername\"", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { showChangePasswordDialog = true },
                                    colors = appSolidButtonColors(NagadPrimary),
                                    shape = AppInputShape,
                                    modifier = Modifier.height(46.dp)
                                ) {
                                    Text("Change Password", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            var bankInput by remember { mutableStateOf(kpi.bankBalance.toString()) }
                            var reserveInput by remember { mutableStateOf(kpi.reservedAmount.toString()) }
                            val derivedCashPreview = kpi.mainLiquidCapital - (bankInput.toIntOrNull() ?: kpi.bankBalance)

                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Financial Balances Adjustment", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Modify corporate bank balance and reserved funds (Cash in Hand derives automatically)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = bankInput,
                                    onValueChange = { bankInput = it },
                                    label = { Text("Bank Balance (৳)") },
                                    singleLine = true,
                                    textStyle = appInputTextStyle(),
                                    shape = AppInputShape,
                                    colors = appOutlinedTextFieldColors(),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = CurrencyFormatter.formatCurrency(derivedCashPreview),
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Cash In Hand (Derived: Liquid − Bank)") },
                                    singleLine = true,
                                    textStyle = appInputTextStyle(),
                                    shape = AppInputShape,
                                    colors = appOutlinedTextFieldColors(),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = reserveInput,
                                    onValueChange = { reserveInput = it },
                                    label = { Text("Reserved Amount (৳)") },
                                    singleLine = true,
                                    textStyle = appInputTextStyle(),
                                    shape = AppInputShape,
                                    colors = appOutlinedTextFieldColors(),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        val b = bankInput.toIntOrNull() ?: 0
                                        val r = reserveInput.toIntOrNull() ?: 0
                                        viewModel.updateFinancialSettings(b, r)
                                    },
                                    colors = appSolidButtonColors(NagadPrimary),
                                    shape = AppInputShape,
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Text("Save Financial Settings", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }

                    item {
                        OfficialPaymentAccountsSettingsCard(
                            officialAccounts = officialAccounts,
                            onSave = { bkash, nagad, bank ->
                                viewModel.updateOfficialPaymentAccounts(bkash, nagad, bank)
                            }
                        )
                    }

                    item {
                        AdminAlertEmailSettingsCard(
                            settings = adminAlertEmailSettings,
                            onSave = { email, serviceId, templateId, publicKey ->
                                viewModel.updateAdminAlertEmailSettings(
                                    adminAlertEmail = email,
                                    emailJsServiceId = serviceId,
                                    emailJsTemplateId = templateId,
                                    emailJsPublicKey = publicKey
                                )
                            }
                        )
                    }

                    item {
                        AdminScheduledDueRemindersTestCard(
                            membersWithStats = membersWithStats,
                            simulatedReminderDay = simulatedReminderDay,
                            onTriggerTest = { day, memberId ->
                                viewModel.triggerTestDueReminders(day, memberId)
                            }
                        )
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Organization Content Manager", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Edit About Us story, Mission & Vision, Contact Us, and Footer Credit", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { selectedTabIndex = 5 },
                                    colors = appSolidButtonColors(RoyalBlue),
                                    shape = AppInputShape,
                                    modifier = Modifier.fillMaxWidth().height(46.dp)
                                ) {
                                    Text("Edit Organization Info & Brand Settings...", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Platform Governance", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Governance: 11 Active Founding Members", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                Text("Platform: Rising Roads Of Kharkharian (RRK) Joint Investment Platform", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                Text("Official Launch: May 1, 2025 · Head Office Audit: November 2026", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                            }
                        }
                    }
                }
            }

            11 -> {
                // 12. ACTIVITY LOG TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Activity Log (${activityLogs.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                            if (activityLogs.isNotEmpty()) {
                                TextButton(onClick = { viewModel.clearLogs() }) {
                                    Text("Clear Log", color = RedAlert, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (activityLogs.isEmpty()) {
                        item {
                            Text("No activity logged yet", color = NagadSecondaryText, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                    } else {
                        items(activityLogs, key = { it.id }) { log ->
                            val icon = when (log.type) {
                                "deposit" -> "💰"
                                "member" -> "👤"
                                "cost" -> "💸"
                                "investment" -> "📈"
                                "login" -> "🔐"
                                "logout" -> "🚪"
                                "delete" -> "🗑️"
                                "update" -> "✏️"
                                else -> "⚙️"
                            }
                            val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(log.timestamp))

                            Card(
                                shape = AppCardShape,
                                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                                border = AppCardBorder,
                                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(icon, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(log.message, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NagadMainText)
                                        Text("${log.username} · $dateStr", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            12 -> {
                // 13. EXITED MEMBERS & LOSS OFFSET LEDGER
                AdminExitedMembersTabContent(
                    exitedMembers = exitedMembers,
                    kpi = kpi,
                    onAddExitedMember = { showAddExitedMemberDialog = true },
                    onMarkActiveExited = { showMarkActiveExitedDialog = true },
                    onEditExitedMember = { exitedMemberToEdit = it },
                    onDeleteExitedMember = { exitedMemberToDelete = it }
                )
            }

            13 -> {
                // 14. DYNAMIC CUSTOM PAGE BUILDER
                AdminCustomPagesTabContent(
                    viewModel = viewModel,
                    customPages = customPages,
                    onCreatePage = { showAddCustomPageDialog = true },
                    onPreviewPage = { onNavigateToCustomPage(it) },
                    onEditPage = { customPageToEdit = it },
                    onDeletePage = { customPageToDelete = it }
                )
            }
        }
    }
    }

    // --- ALL CRUD DIALOGS ---

    // 1. Add Member Dialog
    if (showAddMemberDialog) {
        var nameInput by remember { mutableStateOf("") }
        var phoneInput by remember { mutableStateOf("") }
        var addressInput by remember { mutableStateOf("Kharkharian") }
        var joinDateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }

        AlertDialog(
            onDismissRequest = { showAddMemberDialog = false },
            title = { Text("Add New Member", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Full Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        label = { Text("Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = joinDateInput,
                        onValueChange = { joinDateInput = it },
                        label = { Text("Join Date (YYYY-MM-DD)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isNotBlank() && phoneInput.isNotBlank()) {
                            viewModel.addMember(nameInput, phoneInput, joinDateInput, addressInput)
                            showAddMemberDialog = false
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Add Member", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMemberDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 2. Edit Member Dialog
    if (memberToEdit != null) {
        val m = memberToEdit!!
        var eName by remember { mutableStateOf(m.name) }
        var ePhone by remember { mutableStateOf(m.phone) }
        var eAddr by remember { mutableStateOf(m.address) }
        var eJoin by remember { mutableStateOf(m.joinDate) }

        AlertDialog(
            onDismissRequest = { memberToEdit = null },
            title = { Text("Edit Member #${m.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = eName,
                        onValueChange = { eName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = ePhone,
                        onValueChange = { ePhone = it },
                        label = { Text("Phone") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eAddr,
                        onValueChange = { eAddr = it },
                        label = { Text("Address") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eJoin,
                        onValueChange = { eJoin = it },
                        label = { Text("Join Date") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateMember(m.copy(name = eName.trim(), phone = ePhone.trim(), address = eAddr.trim(), joinDate = eJoin.trim()))
                        memberToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { memberToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 3. Delete Member Dialog
    if (memberToDelete != null) {
        AlertDialog(
            onDismissRequest = { memberToDelete = null },
            title = { Text("Delete Member?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to remove \"${memberToDelete?.name}\" (RRK-${memberToDelete?.id?.toString()?.padStart(3, '0')})? This will remove the member from active lists.", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        memberToDelete?.let { viewModel.deleteMember(it.id, it.name) }
                        memberToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete Member", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { memberToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 4. Add Deposit Dialog
    if (showAddDepositDialog) {
        var selectedMemberId by remember { mutableStateOf(membersWithStats.firstOrNull()?.member?.id ?: 1) }
        val activeMonthsList = remember { AppRepository.getActiveMonths() }
        var selectedMonthInput by remember { mutableStateOf(activeMonthsList.lastOrNull() ?: "May 2025") }
        var paymentDateInput by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val day = remember { SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1 }
        val autoFine = if (day > 15) 100 else 0
        var fineInput by remember { mutableStateOf(autoFine.toString()) }

        val alreadyPaid = remember(selectedMemberId, selectedMonthInput, deposits) {
            deposits.any { it.memberId == selectedMemberId && it.month == selectedMonthInput }
        }

        AlertDialog(
            onDismissRequest = { showAddDepositDialog = false },
            title = { Text("Record New Deposit", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (alreadyPaid) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF2F2),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ This member already paid for $selectedMonthInput!",
                                color = RedAlert,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    // Member selector
                    Text("Select Member:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    var memberDropdownOpen by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = memberDropdownOpen,
                        onExpandedChange = { memberDropdownOpen = !memberDropdownOpen }
                    ) {
                        val currentSelectedMember = membersMap[selectedMemberId]
                        OutlinedTextField(
                            value = currentSelectedMember?.name ?: "Select",
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = memberDropdownOpen,
                            onDismissRequest = { memberDropdownOpen = false }
                        ) {
                            membersWithStats.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text("${m.member.id}. ${m.member.name}") },
                                    onClick = {
                                        selectedMemberId = m.member.id
                                        memberDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // Month selector
                    Text("Month:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    var monthDropdownOpen by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = monthDropdownOpen,
                        onExpandedChange = { monthDropdownOpen = !monthDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = selectedMonthInput,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = monthDropdownOpen,
                            onDismissRequest = { monthDropdownOpen = false }
                        ) {
                            activeMonthsList.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m) },
                                    onClick = {
                                        selectedMonthInput = m
                                        monthDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = paymentDateInput,
                        onValueChange = { paymentDateInput = it },
                        label = { Text("Payment Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = fineInput,
                        onValueChange = { fineInput = it },
                        label = { Text("Late Fine (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fine = fineInput.toIntOrNull() ?: 0
                        viewModel.recordDeposit(
                            memberId = selectedMemberId,
                            month = selectedMonthInput,
                            paymentDate = paymentDateInput,
                            amount = 1000,
                            fine = fine
                        ) { newId ->
                            showAddDepositDialog = false
                        }
                    },
                    colors = appSolidButtonColors(EmeraldGreen),
                    enabled = !alreadyPaid
                ) {
                    Text("Record Deposit", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDepositDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 5. Edit Deposit Dialog
    if (depositToEdit != null) {
        val d = depositToEdit!!
        val m = membersMap[d.memberId]
        var eDate by remember { mutableStateOf(d.paymentDate) }
        var eFine by remember { mutableStateOf(d.fine.toString()) }
        var eAmt by remember { mutableStateOf(d.amount.toString()) }

        AlertDialog(
            onDismissRequest = { depositToEdit = null },
            title = { Text("Edit Deposit RRK-${d.id.toString().padStart(4, '0')}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Member: ${m?.name ?: "ID ${d.memberId}"} (${d.month})", fontWeight = FontWeight.Bold, color = NagadMainText)
                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Payment Date") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eAmt,
                        onValueChange = { eAmt = it },
                        label = { Text("Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eFine,
                        onValueChange = { eFine = it },
                        label = { Text("Fine (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val a = eAmt.toIntOrNull() ?: 1000
                        val f = eFine.toIntOrNull() ?: 0
                        viewModel.updateDeposit(d.copy(paymentDate = eDate.trim(), amount = a, fine = f))
                        depositToEdit = null
                    },
                    colors = appSolidButtonColors(EmeraldGreen)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { depositToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 6. Delete Deposit Dialog
    if (depositToDelete != null) {
        AlertDialog(
            onDismissRequest = { depositToDelete = null },
            title = { Text("Delete Deposit Record?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete deposit RRK-${depositToDelete?.id?.toString()?.padStart(4, '0')}?", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        depositToDelete?.let { viewModel.deleteDeposit(it.id) }
                        depositToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { depositToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 7. Add Expense Dialog
    if (showAddExpenseDialog) {
        val categories = listOf("Office Expenses", "Transport", "Marketing", "Investment", "Emergency", "Business Expenses", "Miscellaneous")
        var descInput by remember { mutableStateOf("") }
        var categoryInput by remember { mutableStateOf(categories.first()) }
        var amountInput by remember { mutableStateOf("") }
        var dateInput by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        var catDropdownOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddExpenseDialog = false },
            title = { Text("Log New Expense", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Description *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    ExposedDropdownMenuBox(
                        expanded = catDropdownOpen,
                        onExpandedChange = { catDropdownOpen = !catDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = categoryInput,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = catDropdownOpen,
                            onDismissRequest = { catDropdownOpen = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        categoryInput = cat
                                        catDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount (৳) *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = dateInput,
                        onValueChange = { dateInput = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toIntOrNull() ?: 0
                        if (descInput.isNotBlank() && amt > 0) {
                            viewModel.addExpense(descInput, categoryInput, amt, dateInput)
                            showAddExpenseDialog = false
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Add Expense", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddExpenseDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 8. Edit Expense Dialog
    if (expenseToEdit != null) {
        val exp = expenseToEdit!!
        var eDesc by remember { mutableStateOf(exp.description) }
        var eCat by remember { mutableStateOf(exp.category) }
        var eAmt by remember { mutableStateOf(exp.amount.toString()) }
        var eDate by remember { mutableStateOf(exp.date) }

        AlertDialog(
            onDismissRequest = { expenseToEdit = null },
            title = { Text("Edit Expense #${exp.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = eDesc,
                        onValueChange = { eDesc = it },
                        label = { Text("Description") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eCat,
                        onValueChange = { eCat = it },
                        label = { Text("Category") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eAmt,
                        onValueChange = { eAmt = it },
                        label = { Text("Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Date") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val a = eAmt.toIntOrNull() ?: exp.amount
                        viewModel.updateExpense(exp.copy(description = eDesc.trim(), category = eCat.trim(), amount = a, date = eDate.trim()))
                        expenseToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 9. Delete Expense Dialog
    if (expenseToDelete != null) {
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text("Delete Expense?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete \"${expenseToDelete?.description}\" (৳${expenseToDelete?.amount})?", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        expenseToDelete?.let { viewModel.deleteExpense(it.id) }
                        expenseToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 10. Add Investment Dialog
    if (showAddInvestmentDialog) {
        val statusOptions = listOf("RUNNING", "CLOSED")
        val sourceOptions = listOf("Cash", "Bank")
        var nameInput by remember { mutableStateOf("") }
        var amountInput by remember { mutableStateOf("") }
        var revenueInput by remember { mutableStateOf("") }
        var plInput by remember { mutableStateOf("0") }
        var statusInput by remember { mutableStateOf("RUNNING") }
        var sourceInput by remember { mutableStateOf("Cash") }
        var returnSourceInput by remember { mutableStateOf("Cash") }
        var dateInput by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        var descInput by remember { mutableStateOf("") }
        var statusDropdownOpen by remember { mutableStateOf(false) }
        var sourceDropdownOpen by remember { mutableStateOf(false) }
        var returnDropdownOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddInvestmentDialog = false },
            containerColor = NagadWhite,
            title = { Text("Add Investment", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Investment Name *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { newAmtStr ->
                            amountInput = newAmtStr
                            val amt = newAmtStr.toIntOrNull() ?: 0
                            val rev = revenueInput.toIntOrNull()
                            if (statusInput == "CLOSED" && rev != null) {
                                plInput = (rev - amt).toString()
                            }
                        },
                        label = { Text("Amount (৳) *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ExposedDropdownMenuBox(
                        expanded = sourceDropdownOpen,
                        onExpandedChange = { sourceDropdownOpen = !sourceDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (sourceInput == "Bank") {
                                "Bank Balance (${CurrencyFormatter.formatCurrency(kpi.bankBalance)})"
                            } else {
                                "Cash in Hand (${CurrencyFormatter.formatCurrency(kpi.cashInHand)})"
                            },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Source") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceDropdownOpen,
                            onDismissRequest = { sourceDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            sourceOptions.forEach { src ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (src == "Bank") {
                                                "Bank Balance (${CurrencyFormatter.formatCurrency(kpi.bankBalance)})"
                                            } else {
                                                "Cash in Hand (${CurrencyFormatter.formatCurrency(kpi.cashInHand)})"
                                            },
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        sourceInput = src
                                        returnSourceInput = src
                                        sourceDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    ExposedDropdownMenuBox(
                        expanded = statusDropdownOpen,
                        onExpandedChange = { statusDropdownOpen = !statusDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (statusInput == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Status") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusDropdownOpen,
                            onDismissRequest = { statusDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            statusOptions.forEach { opt ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (opt == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        statusInput = opt
                                        if (opt == "CLOSED" && revenueInput.isBlank()) {
                                            val amt = amountInput.toIntOrNull() ?: 0
                                            val pl = plInput.toIntOrNull() ?: 0
                                            revenueInput = (amt + pl).toString()
                                        }
                                        statusDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    if (statusInput == "CLOSED") {
                        OutlinedTextField(
                            value = revenueInput,
                            onValueChange = { newRevStr ->
                                revenueInput = newRevStr
                                val amt = amountInput.toIntOrNull() ?: 0
                                val rev = newRevStr.toIntOrNull()
                                if (rev != null) {
                                    plInput = (rev - amt).toString()
                                }
                            },
                            label = { Text("Sale / Return Revenue (৳)") },
                            singleLine = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = plInput,
                            onValueChange = { newPlStr ->
                                plInput = newPlStr
                                val amt = amountInput.toIntOrNull() ?: 0
                                val pl = newPlStr.toIntOrNull()
                                if (pl != null) {
                                    revenueInput = (amt + pl).toString()
                                }
                            },
                            label = { Text("Realized Profit / Loss (৳)") },
                            singleLine = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        ExposedDropdownMenuBox(
                            expanded = returnDropdownOpen,
                            onExpandedChange = { returnDropdownOpen = !returnDropdownOpen }
                        ) {
                            OutlinedTextField(
                                value = if (returnSourceInput == "Bank") "Bank Balance" else "Cash in Hand",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Return Proceeds To") },
                                textStyle = appInputTextStyle(),
                                shape = AppInputShape,
                                colors = appOutlinedTextFieldColors(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = returnDropdownOpen) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = returnDropdownOpen,
                                onDismissRequest = { returnDropdownOpen = false },
                                containerColor = NagadWhite
                            ) {
                                sourceOptions.forEach { dst ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (dst == "Bank") "Bank Balance" else "Cash in Hand",
                                                color = NagadMainText
                                            )
                                        },
                                        onClick = {
                                            returnSourceInput = dst
                                            returnDropdownOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = dateInput,
                        onValueChange = { dateInput = it },
                        label = { Text("Date") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Description") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toIntOrNull() ?: 0
                        val rev = if (statusInput == "CLOSED") {
                            revenueInput.toIntOrNull() ?: (amt + (plInput.toIntOrNull() ?: 0))
                        } else 0
                        val pl = if (statusInput == "CLOSED") {
                            plInput.toIntOrNull() ?: (rev - amt)
                        } else 0
                        if (nameInput.isNotBlank() && amt > 0) {
                            viewModel.addInvestment(
                                Investment(
                                    name = nameInput.trim(),
                                    amount = amt,
                                    activeCapital = if (statusInput == "RUNNING") amt else 0,
                                    saleRevenue = rev,
                                    saleDate = if (statusInput == "CLOSED") dateInput.trim() else "",
                                    profitLoss = pl,
                                    status = statusInput,
                                    stockStatus = if (statusInput == "RUNNING") "In Stock" else "Closed",
                                    date = dateInput.trim(),
                                    description = descInput.trim(),
                                    paymentSource = sourceInput,
                                    returnSource = if (statusInput == "CLOSED") returnSourceInput else ""
                                )
                            )
                            showAddInvestmentDialog = false
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Add Investment", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddInvestmentDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 11. Edit Investment Dialog
    if (investmentToEdit != null) {
        val inv = investmentToEdit!!
        val statusOptions = listOf("RUNNING", "CLOSED")
        val sourceOptions = listOf("Cash", "Bank")
        var eName by remember { mutableStateOf(inv.name) }
        var eAmt by remember { mutableStateOf(inv.amount.toString()) }
        var eRev by remember {
            mutableStateOf(
                if (inv.saleRevenue > 0) inv.saleRevenue.toString() else (inv.amount + inv.profitLoss).toString()
            )
        }
        var ePl by remember { mutableStateOf(inv.profitLoss.toString()) }
        var eSt by remember {
            mutableStateOf(
                if (inv.status.uppercase() in setOf("RUNNING", "ACTIVE")) "RUNNING" else "CLOSED"
            )
        }
        var eSource by remember {
            mutableStateOf(if (inv.paymentSource.equals("Bank", true)) "Bank" else "Cash")
        }
        var eReturnSource by remember {
            mutableStateOf(
                inv.returnSource.ifBlank { if (inv.paymentSource.equals("Bank", true)) "Bank" else "Cash" }
            )
        }
        var eDate by remember { mutableStateOf(inv.date) }
        var eDesc by remember { mutableStateOf(inv.description) }
        var statusDropdownOpen by remember { mutableStateOf(false) }
        var sourceDropdownOpen by remember { mutableStateOf(false) }
        var returnDropdownOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { investmentToEdit = null },
            containerColor = NagadWhite,
            title = { Text("Edit / Close Investment #${inv.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = eName, onValueChange = { eName = it }, label = { Text("Name") }, textStyle = appInputTextStyle(), shape = AppInputShape, colors = appOutlinedTextFieldColors(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = eAmt,
                        onValueChange = { newAmtStr ->
                            eAmt = newAmtStr
                            val amt = newAmtStr.toIntOrNull() ?: 0
                            val rev = eRev.toIntOrNull()
                            if (eSt == "CLOSED" && rev != null) {
                                ePl = (rev - amt).toString()
                            }
                        },
                        label = { Text("Amount (৳)") },
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ExposedDropdownMenuBox(
                        expanded = sourceDropdownOpen,
                        onExpandedChange = { sourceDropdownOpen = !sourceDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (eSource == "Bank") "Bank Balance" else "Cash in Hand",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Source") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceDropdownOpen,
                            onDismissRequest = { sourceDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            sourceOptions.forEach { src ->
                                DropdownMenuItem(
                                    text = { Text(if (src == "Bank") "Bank Balance" else "Cash in Hand", color = NagadMainText) },
                                    onClick = {
                                        eSource = src
                                        sourceDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    ExposedDropdownMenuBox(
                        expanded = statusDropdownOpen,
                        onExpandedChange = { statusDropdownOpen = !statusDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (eSt == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Status") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusDropdownOpen,
                            onDismissRequest = { statusDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            statusOptions.forEach { opt ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (opt == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        eSt = opt
                                        if (opt == "CLOSED") {
                                            val amt = eAmt.toIntOrNull() ?: inv.amount
                                            val curPl = ePl.toIntOrNull() ?: inv.profitLoss
                                            eRev = (amt + curPl).toString()
                                            if (eReturnSource.isBlank()) eReturnSource = eSource
                                        }
                                        statusDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    if (eSt == "CLOSED") {
                        OutlinedTextField(
                            value = eRev,
                            onValueChange = { newRevStr ->
                                eRev = newRevStr
                                val amt = eAmt.toIntOrNull() ?: inv.amount
                                val rev = newRevStr.toIntOrNull()
                                if (rev != null) {
                                    ePl = (rev - amt).toString()
                                }
                            },
                            label = { Text("Sale / Return Revenue (৳)") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = ePl,
                            onValueChange = { newPlStr ->
                                ePl = newPlStr
                                val amt = eAmt.toIntOrNull() ?: inv.amount
                                val pl = newPlStr.toIntOrNull()
                                if (pl != null) {
                                    eRev = (amt + pl).toString()
                                }
                            },
                            label = { Text("Realized Profit / Loss (৳)") },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        ExposedDropdownMenuBox(
                            expanded = returnDropdownOpen,
                            onExpandedChange = { returnDropdownOpen = !returnDropdownOpen }
                        ) {
                            OutlinedTextField(
                                value = if (eReturnSource == "Bank") "Bank Balance" else "Cash in Hand",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Return Proceeds To") },
                                textStyle = appInputTextStyle(),
                                shape = AppInputShape,
                                colors = appOutlinedTextFieldColors(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = returnDropdownOpen) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = returnDropdownOpen,
                                onDismissRequest = { returnDropdownOpen = false },
                                containerColor = NagadWhite
                            ) {
                                sourceOptions.forEach { dst ->
                                    DropdownMenuItem(
                                        text = { Text(if (dst == "Bank") "Bank Balance" else "Cash in Hand", color = NagadMainText) },
                                        onClick = {
                                            eReturnSource = dst
                                            returnDropdownOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    OutlinedTextField(value = eDate, onValueChange = { eDate = it }, label = { Text("Date") }, textStyle = appInputTextStyle(), shape = AppInputShape, colors = appOutlinedTextFieldColors(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = eDesc, onValueChange = { eDesc = it }, label = { Text("Description") }, textStyle = appInputTextStyle(), shape = AppInputShape, colors = appOutlinedTextFieldColors(), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val a = eAmt.toIntOrNull() ?: inv.amount
                        val rev = if (eSt == "CLOSED") {
                            eRev.toIntOrNull() ?: (a + (ePl.toIntOrNull() ?: inv.profitLoss))
                        } else 0
                        val p = if (eSt == "CLOSED") {
                            ePl.toIntOrNull() ?: (rev - a)
                        } else 0
                        val finalSaleDate = if (eSt == "CLOSED") {
                            inv.saleDate.ifBlank { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
                        } else ""
                        viewModel.updateInvestment(
                            inv.copy(
                                name = eName.trim(),
                                amount = a,
                                activeCapital = if (eSt == "RUNNING") a else 0,
                                saleRevenue = rev,
                                saleDate = finalSaleDate,
                                profitLoss = p,
                                status = eSt,
                                stockStatus = if (eSt == "RUNNING") "In Stock" else "Closed",
                                date = eDate.trim(),
                                description = eDesc.trim(),
                                paymentSource = eSource,
                                returnSource = if (eSt == "CLOSED") eReturnSource else ""
                            )
                        )
                        investmentToEdit = null
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Save", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { investmentToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 12. Delete Investment Dialog
    if (investmentToDelete != null) {
        AlertDialog(
            onDismissRequest = { investmentToDelete = null },
            title = { Text("Delete Investment?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete \"${investmentToDelete?.name}\"?", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        investmentToDelete?.let { viewModel.deleteInvestment(it.id) }
                        investmentToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { investmentToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 13. Restore Database Dialog
    if (showRestoreDialog) {
        var jsonInput by remember { mutableStateOf("") }
        var restoreStatus by remember { mutableStateOf<String?>(null) }
        var isProcessing by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Database from JSON", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Paste the contents of your backup JSON file below:", fontSize = 12.sp, color = NagadSecondaryText)
                    OutlinedTextField(
                        value = jsonInput,
                        onValueChange = { jsonInput = it },
                        label = { Text("Backup JSON Content") },
                        minLines = 6,
                        maxLines = 10,
                        textStyle = appInputTextStyle(13.sp),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (restoreStatus != null) {
                        Text(restoreStatus ?: "", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (restoreStatus?.contains("✅") == true) EmeraldGreen else RedAlert)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (jsonInput.isNotBlank()) {
                            isProcessing = true
                            viewModel.restoreDatabaseBackup(jsonInput) { success, msg ->
                                isProcessing = false
                                restoreStatus = if (success) msg else "Error: $msg"
                                if (success) {
                                    showRestoreDialog = false
                                }
                            }
                        }
                    },
                    enabled = jsonInput.isNotBlank() && !isProcessing,
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Restore Database", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 14. Reset to Factory Defaults Confirm Dialog
    if (showResetDefaultsConfirm) {
        AlertDialog(
            onDismissRequest = { showResetDefaultsConfirm = false },
            title = { Text("Reset to 11 Founding Members?", fontWeight = FontWeight.Bold, color = RedAlert) },
            text = { Text("Are you sure? This will restore the verified 11 founding members with the exact 2025-2026 month-by-month deposit matrix (৳1,79,000 deposits + ৳2,900 fines).", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToOfficial11Data {
                            showResetDefaultsConfirm = false
                        }
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Reset to 11 Members", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDefaultsConfirm = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 15. Change Password Dialog
    if (showChangePasswordDialog) {
        var curPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Change Password", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = curPass,
                        onValueChange = { curPass = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password (min 6 chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("Confirm New Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (err != null) {
                        Text(err ?: "", color = RedAlert, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass != confirmPass) {
                            err = "Passwords do not match"
                            return@Button
                        }
                        viewModel.changePassword(curPass, newPass) { success, msg ->
                            if (success) {
                                showChangePasswordDialog = false
                            } else {
                                err = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Update", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 16. Add Admin Dialog
    if (showAddAdminDialog) {
        val roles = listOf("Admin", "Moderator", "Viewer", "Super Admin")
        var newAdminU by remember { mutableStateOf("") }
        var newAdminP by remember { mutableStateOf("") }
        var selectedRole by remember { mutableStateOf(roles.first()) }
        var roleDropdownOpen by remember { mutableStateOf(false) }
        var addAdminErr by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showAddAdminDialog = false },
            title = { Text("Add New Administrator", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newAdminU,
                        onValueChange = { newAdminU = it },
                        label = { Text("Username *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newAdminP,
                        onValueChange = { newAdminP = it },
                        label = { Text("Password (min 6 chars) *") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Role:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    ExposedDropdownMenuBox(
                        expanded = roleDropdownOpen,
                        onExpandedChange = { roleDropdownOpen = !roleDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = selectedRole,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = roleDropdownOpen,
                            onDismissRequest = { roleDropdownOpen = false }
                        ) {
                            roles.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text(r) },
                                    onClick = {
                                        selectedRole = r
                                        roleDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                    if (addAdminErr != null) {
                        Text(addAdminErr ?: "", color = RedAlert, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addNewAdmin(newAdminU, newAdminP, selectedRole) { success, msg ->
                            if (success) {
                                showAddAdminDialog = false
                            } else {
                                addAdminErr = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Add Admin", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAdminDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // 17. Deposit Receipt Preview Dialog
    if (selectedDepositForReceipt != null && selectedMemberForReceipt != null) {
        DepositReceiptDialog(
            deposit = selectedDepositForReceipt!!,
            member = selectedMemberForReceipt!!,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = {
                selectedDepositForReceipt = null
                selectedMemberForReceipt = null
            }
        )
    }

    // 18. Bulk Deposit Entry Dialog (Admin Only)
    if (showBulkDepositDialog) {
        BulkDepositEntryDialog(
            members = membersWithStats.map { it.member },
            onDismiss = { showBulkDepositDialog = false },
            onSaveAll = { bulkList ->
                viewModel.recordBulkDeposits(bulkList) {
                    showBulkDepositDialog = false
                }
            }
        )
    }

    // 19. Bulk Expense Entry Dialog (Admin Only)
    if (showBulkExpenseDialog) {
        BulkExpenseEntryDialog(
            onDismiss = { showBulkExpenseDialog = false },
            onSaveAll = { bulkList ->
                viewModel.recordBulkExpenses(bulkList) {
                    showBulkExpenseDialog = false
                }
            }
        )
    }

    // 20. Bulk Investment Entry Dialog (Admin Only)
    if (showBulkInvestmentDialog) {
        BulkInvestmentEntryDialog(
            onDismiss = { showBulkInvestmentDialog = false },
            onSaveAll = { bulkList ->
                viewModel.recordBulkInvestments(bulkList) {
                    showBulkInvestmentDialog = false
                }
            }
        )
    }

    // 21. Member Settlement Dialog (Admin Only)
    if (showAddSettlementDialog) {
        MemberSettlementDialog(
            members = membersWithStats.map { it.member },
            deposits = deposits,
            onDismiss = { showAddSettlementDialog = false },
            onSave = { settlement ->
                viewModel.addSettlement(settlement) {
                    showAddSettlementDialog = false
                }
            }
        )
    }

    // Settlement Deletion Confirm
    if (settlementToDelete != null) {
        AlertDialog(
            onDismissRequest = { settlementToDelete = null },
            title = { Text("Delete Settlement Record?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete the settlement record for ${settlementToDelete?.memberName}?") },
            confirmButton = {
                Button(
                    onClick = {
                        settlementToDelete?.id?.let { viewModel.deleteSettlement(it) }
                        settlementToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { settlementToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Reject Manual Payment Request Dialog
    if (requestToReject != null) {
        val targetReq = requestToReject!!
        var rejectionReasonInput by remember(targetReq.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { requestToReject = null },
            containerColor = NagadWhite,
            title = {
                Text(
                    text = "Reject Payment Proof?",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Rejecting ${targetReq.memberName}'s request for ${targetReq.month} (${CurrencyFormatter.formatCurrency(targetReq.amount + targetReq.fine)}, TrxID: ${targetReq.trxId.ifBlank { "Cash" }}). Financial totals will not be changed.",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText
                    )
                    OutlinedTextField(
                        value = rejectionReasonInput,
                        onValueChange = { rejectionReasonInput = it },
                        label = { Text("Reason (optional)", fontFamily = InterFontFamily) },
                        placeholder = { Text("e.g., TrxID not matched in statement", fontFamily = InterFontFamily) },
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.rejectPaymentRequest(targetReq.id, rejectionReasonInput)
                        requestToReject = null
                    },
                    colors = appSolidButtonColors(RedAlert),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("Reject Request", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { requestToReject = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }

    // Edit Official Payment Accounts Dialog (Admin)
    if (showEditOfficialAccountsDialog) {
        EditOfficialPaymentAccountsDialog(
            currentAccounts = officialAccounts,
            onDismiss = { showEditOfficialAccountsDialog = false },
            onSave = { bkash, nagad, bank ->
                viewModel.updateOfficialPaymentAccounts(bkash, nagad, bank)
                showEditOfficialAccountsDialog = false
            }
        )
    }

    // Exited Members: Add Dialog
    if (showAddExitedMemberDialog) {
        var nameInput by remember { mutableStateOf("") }
        var phoneInput by remember { mutableStateOf("") }
        var resignationDateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        var lossShareInput by remember { mutableStateOf("14") }
        var notesInput by remember { mutableStateOf("Settled & departed; loss share retained") }

        AlertDialog(
            onDismissRequest = { showAddExitedMemberDialog = false },
            title = { Text("Add Exited Member", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Member Name *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_exited_member_name_input")
                    )
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_exited_member_phone_input")
                    )
                    OutlinedTextField(
                        value = resignationDateInput,
                        onValueChange = { resignationDateInput = it },
                        label = { Text("Resignation Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_exited_member_date_input")
                    )
                    OutlinedTextField(
                        value = lossShareInput,
                        onValueChange = { lossShareInput = it },
                        label = { Text("Retained Loss Share (৳) *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_exited_member_loss_input")
                    )
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notes / Settlement Details") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lossAmt = lossShareInput.toIntOrNull() ?: 14
                        if (nameInput.isNotBlank()) {
                            viewModel.addExitedMember(
                                name = nameInput.trim(),
                                phone = phoneInput.trim(),
                                resignationDate = resignationDateInput.trim(),
                                lossShareAmount = lossAmt,
                                notes = notesInput.trim()
                            )
                            showAddExitedMemberDialog = false
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Exited Member", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddExitedMemberDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Exited Members: Mark Active as Exited Dialog
    if (showMarkActiveExitedDialog) {
        var selectedMemberId by remember {
            mutableIntStateOf(membersWithStats.firstOrNull()?.member?.id ?: 1)
        }
        val targetMember = membersMap[selectedMemberId]
        var resignationDateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        var lossShareInput by remember { mutableStateOf("14") }
        var notesInput by remember { mutableStateOf("Marked as exited by admin; loss share retained") }
        var memberDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showMarkActiveExitedDialog = false },
            title = { Text("Mark Active Member as Exited", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Active Member to mark as Exited:", fontSize = 12.sp, color = NagadSecondaryText)
                    ExposedDropdownMenuBox(
                        expanded = memberDropdownExpanded,
                        onExpandedChange = { memberDropdownExpanded = !memberDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = "${targetMember?.name.orEmpty()} (RRK-${targetMember?.id?.toString()?.padStart(3, '0') ?: ""})",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownExpanded) },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = memberDropdownExpanded,
                            onDismissRequest = { memberDropdownExpanded = false }
                        ) {
                            membersWithStats.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text("${m.member.id}. ${m.member.name}") },
                                    onClick = {
                                        selectedMemberId = m.member.id
                                        memberDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = resignationDateInput,
                        onValueChange = { resignationDateInput = it },
                        label = { Text("Resignation Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = lossShareInput,
                        onValueChange = { lossShareInput = it },
                        label = { Text("Retained Loss Share (৳)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notes") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lossAmt = lossShareInput.toIntOrNull() ?: 14
                        if (targetMember != null) {
                            viewModel.addExitedMember(
                                name = targetMember.name,
                                phone = targetMember.phone,
                                resignationDate = resignationDateInput.trim(),
                                lossShareAmount = lossAmt,
                                notes = notesInput.trim()
                            )
                            showMarkActiveExitedDialog = false
                        }
                    },
                    colors = appSolidButtonColors(FintechAmber)
                ) {
                    Text("Confirm Exited", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showMarkActiveExitedDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Exited Members: Edit Dialog
    if (exitedMemberToEdit != null) {
        val em = exitedMemberToEdit!!
        var eName by remember { mutableStateOf(em.name) }
        var ePhone by remember { mutableStateOf(em.phone) }
        var eDate by remember { mutableStateOf(em.resignationDate) }
        var eLoss by remember { mutableStateOf(em.lossShareAmount.toString()) }
        var eNotes by remember { mutableStateOf(em.notes) }

        AlertDialog(
            onDismissRequest = { exitedMemberToEdit = null },
            title = { Text("Edit Exited Member #${em.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = eName,
                        onValueChange = { eName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = ePhone,
                        onValueChange = { ePhone = it },
                        label = { Text("Phone") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Resignation Date") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eLoss,
                        onValueChange = { eLoss = it },
                        label = { Text("Retained Loss Share (৳)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eNotes,
                        onValueChange = { eNotes = it },
                        label = { Text("Notes") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lossAmt = eLoss.toIntOrNull() ?: em.lossShareAmount
                        viewModel.updateExitedMember(
                            em.copy(
                                name = eName.trim(),
                                phone = ePhone.trim(),
                                resignationDate = eDate.trim(),
                                lossShareAmount = lossAmt,
                                notes = eNotes.trim()
                            )
                        )
                        exitedMemberToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { exitedMemberToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Exited Members: Delete Dialog
    if (exitedMemberToDelete != null) {
        val em = exitedMemberToDelete!!
        AlertDialog(
            onDismissRequest = { exitedMemberToDelete = null },
            title = { Text("Delete Exited Member Record?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Text(
                    "Are you sure you want to delete exited member \"${em.name}\"? Their ${CurrencyFormatter.formatCurrency(em.lossShareAmount)} loss share offset will be removed and Net Business P/L will automatically recalculate.",
                    fontWeight = FontWeight.Medium,
                    color = NagadSecondaryText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteExitedMember(em.id)
                        exitedMemberToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { exitedMemberToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Custom Pages: Add Dialog
    if (showAddCustomPageDialog) {
        var titleInput by remember { mutableStateOf("") }
        var iconInput by remember { mutableStateOf("Description") }
        var coverUrlInput by remember { mutableStateOf("") }
        var contentInput by remember { mutableStateOf("") }
        var isVisibleInput by remember { mutableStateOf(true) }
        var orderInput by remember { mutableStateOf((customPages.size + 1).toString()) }

        AlertDialog(
            onDismissRequest = { showAddCustomPageDialog = false },
            title = { Text("Create New Custom Page", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Page Title *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_custom_page_title_input")
                    )
                    OutlinedTextField(
                        value = iconInput,
                        onValueChange = { iconInput = it },
                        label = { Text("Icon Name (e.g., Description, Article, Info, Star)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = coverUrlInput,
                        onValueChange = { coverUrlInput = it },
                        label = { Text("Cover Image URL (Optional)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = contentInput,
                        onValueChange = { contentInput = it },
                        label = { Text("Page Content / Body Text *") },
                        minLines = 4,
                        maxLines = 8,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_custom_page_content_input")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show in Sidebar Menu", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                        androidx.compose.material3.Switch(
                            checked = isVisibleInput,
                            onCheckedChange = { isVisibleInput = it }
                        )
                    }
                    OutlinedTextField(
                        value = orderInput,
                        onValueChange = { orderInput = it },
                        label = { Text("Display Order") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ord = orderInput.toIntOrNull() ?: (customPages.size + 1)
                        if (titleInput.isNotBlank()) {
                            viewModel.addCustomPage(
                                title = titleInput.trim(),
                                iconName = iconInput.trim().ifBlank { "Description" },
                                coverImageUrl = coverUrlInput.trim(),
                                content = contentInput.trim(),
                                isVisible = isVisibleInput,
                                displayOrder = ord
                            )
                            showAddCustomPageDialog = false
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Publish Page", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCustomPageDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Custom Pages: Edit Dialog
    if (customPageToEdit != null) {
        val cp = customPageToEdit!!
        var eTitle by remember { mutableStateOf(cp.title) }
        var eIcon by remember { mutableStateOf(cp.iconName) }
        var eCover by remember { mutableStateOf(cp.coverImageUrl) }
        var eContent by remember { mutableStateOf(cp.content) }
        var eVisible by remember { mutableStateOf(cp.isVisible) }
        var eOrder by remember { mutableStateOf(cp.displayOrder.toString()) }

        AlertDialog(
            onDismissRequest = { customPageToEdit = null },
            title = { Text("Edit Custom Page #${cp.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = eTitle,
                        onValueChange = { eTitle = it },
                        label = { Text("Page Title") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eIcon,
                        onValueChange = { eIcon = it },
                        label = { Text("Icon Name") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eCover,
                        onValueChange = { eCover = it },
                        label = { Text("Cover Image URL") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eContent,
                        onValueChange = { eContent = it },
                        label = { Text("Page Content") },
                        minLines = 4,
                        maxLines = 8,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show in Sidebar Menu", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                        androidx.compose.material3.Switch(
                            checked = eVisible,
                            onCheckedChange = { eVisible = it }
                        )
                    }
                    OutlinedTextField(
                        value = eOrder,
                        onValueChange = { eOrder = it },
                        label = { Text("Display Order") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ord = eOrder.toIntOrNull() ?: cp.displayOrder
                        viewModel.updateCustomPage(
                            cp.copy(
                                title = eTitle.trim(),
                                iconName = eIcon.trim(),
                                coverImageUrl = eCover.trim(),
                                content = eContent.trim(),
                                isVisible = eVisible,
                                displayOrder = ord
                            )
                        )
                        customPageToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { customPageToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Custom Pages: Delete Dialog
    if (customPageToDelete != null) {
        val cp = customPageToDelete!!
        AlertDialog(
            onDismissRequest = { customPageToDelete = null },
            title = { Text("Delete Custom Page?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete \"${cp.title}\"? It will be removed from the sidebar menu immediately.", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomPage(cp.id)
                        customPageToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete Page", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { customPageToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }
}

@Composable
fun OrganizationSettingsTab(viewModel: MainViewModel) {
    val configsState by viewModel.configs.collectAsState()

    var aboutUsStoryInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "about_us_story" }?.value ?: "Rising Roads Of Kharkharian was founded in May 2025 by 11 committed individuals from the Kharkharian community. Small consistent contributions build something extraordinary. Each member pledges ৳1,000 monthly.")
    }
    var missionInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "mission_statement" }?.value ?: configsState.find { it.key == "mission_vision" }?.value ?: "Build financial discipline, encourage regular monthly savings, create long-term commercial business growth, and build a strong member-based investment system that serves all 11 founders equally.")
    }
    var visionInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "vision_statement" }?.value ?: "Establish Rising Roads as a full registered business enterprise. Create commercial shops, agro-livestock farms, and sustainable trade projects that benefit all 11 founding partners and the Kharkharian community.")
    }
    var contactPhoneInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "contact_phone" }?.value ?: "+880 1700-000000")
    }
    var contactEmailInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "contact_email" }?.value ?: "risingroads@gmail.com")
    }
    var contactAddressInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "contact_address" }?.value ?: "Kharkharian, Bangladesh")
    }
    var developerCreditInput by remember(configsState) {
        mutableStateOf(configsState.find { it.key == "developer_credit" }?.value ?: "Developed by Rakib")
    }
    var isSavedSuccessfully by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(NagadVeryLightBg),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Organization Content & Brand Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NagadMainText)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Edit public organization information displayed in About Us, Mission & Vision, Contact Us, and sidebar/about footer credit", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("1. About Us Story & Description", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = aboutUsStoryInput,
                        onValueChange = { aboutUsStoryInput = it },
                        label = { Text("About Us Story") },
                        minLines = 4,
                        maxLines = 8,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("about_us_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("2. Mission Statement", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = missionInput,
                        onValueChange = { missionInput = it },
                        label = { Text("Core Mission Statement") },
                        minLines = 3,
                        maxLines = 6,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("mission_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("3. Vision Statement", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = visionInput,
                        onValueChange = { visionInput = it },
                        label = { Text("Future Vision Statement") },
                        minLines = 3,
                        maxLines = 6,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("vision_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("4. Official Contact Details", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = contactPhoneInput,
                        onValueChange = { contactPhoneInput = it },
                        label = { Text("Official Phone") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("contact_phone_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = contactEmailInput,
                        onValueChange = { contactEmailInput = it },
                        label = { Text("Official Email") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("contact_email_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = contactAddressInput,
                        onValueChange = { contactAddressInput = it },
                        label = { Text("Office Address") },
                        minLines = 2,
                        maxLines = 4,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("contact_address_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("5. Brand & Footer Credit", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoyalBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = developerCreditInput,
                        onValueChange = { developerCreditInput = it },
                        label = { Text("Footer / Developer Credit") },
                        placeholder = { Text("Developed by Rakib", color = NagadSecondaryText) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("developer_credit_input")
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    if (isSavedSuccessfully) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFECFDF5),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✓ Organization info saved and updated in real-time across public views!",
                                color = EmeraldGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Button(
                        onClick = {
                            viewModel.updateConfig("about_us_story", aboutUsStoryInput)
                            viewModel.updateConfig("mission_statement", missionInput)
                            viewModel.updateConfig("mission_vision", missionInput)
                            viewModel.updateConfig("vision_statement", visionInput)
                            viewModel.updateConfig("contact_phone", contactPhoneInput)
                            viewModel.updateConfig("contact_email", contactEmailInput)
                            viewModel.updateConfig("contact_address", contactAddressInput)
                            viewModel.updateConfig("developer_credit", developerCreditInput.trim().ifBlank { "Developed by Rakib" })
                            isSavedSuccessfully = true
                        },
                        colors = appSolidButtonColors(RoyalBlue),
                        shape = AppInputShape,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_organization_info_button")
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUsersTabContent(
    viewModel: MainViewModel,
    adminUsername: String,
    admins: List<AdminUser>,
    memberAccounts: List<MemberAccount>
) {
    var fullNameInput by remember { mutableStateOf("") }
    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var selectedRole by remember { mutableStateOf("Super Admin") }
    var roleDropdownOpen by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var formSuccess by remember { mutableStateOf<String?>(null) }
    var memberToResetPassword by remember { mutableStateOf<MemberAccount?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(NagadVeryLightBg).testTag("admin_users_lazy_column"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Create New Admin Form Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Create New Admin",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = fullNameInput,
                        onValueChange = { fullNameInput = it },
                        label = { Text("Admin Full Name", color = NagadSecondaryText) },
                        placeholder = { Text("e.g. Md Rakib Hossain", color = NagadSecondaryText) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_fullname_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text("Username / Login ID", color = NagadSecondaryText) },
                        placeholder = { Text("e.g. rakib_admin", color = NagadSecondaryText) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_username_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Password", color = NagadSecondaryText) },
                        placeholder = { Text("Set Password", color = NagadSecondaryText) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = NagadSecondaryText
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("admin_new_password_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Role Selection:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadSecondaryText)
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(
                        expanded = roleDropdownOpen,
                        onExpandedChange = { roleDropdownOpen = !roleDropdownOpen },
                        modifier = Modifier.testTag("admin_role_dropdown")
                    ) {
                        OutlinedTextField(
                            value = selectedRole,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = roleDropdownOpen,
                            onDismissRequest = { roleDropdownOpen = false }
                        ) {
                            listOf("Super Admin", "Finance Admin").forEach { roleOption ->
                                DropdownMenuItem(
                                    text = { Text(roleOption) },
                                    onClick = {
                                        selectedRole = roleOption
                                        roleDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    if (formError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(formError ?: "", color = RedAlert, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (formSuccess != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(formSuccess ?: "", color = EmeraldGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.addNewAdmin(usernameInput, passwordInput, selectedRole) { success, msg ->
                                if (success) {
                                    formError = null
                                    formSuccess = "Admin account created successfully! ✅"
                                    usernameInput = ""
                                    passwordInput = ""
                                    fullNameInput = ""
                                } else {
                                    formError = msg
                                    formSuccess = null
                                }
                            }
                        },
                        colors = appSolidButtonColors(FintechPrimary),
                        shape = AppInputShape,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_admin_button")
                    ) {
                        Text("Save Admin", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    }
                }
            }
        }

        // 2. Registered Admins Section Header
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Registered Admins",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = NagadMainText
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // 3. LazyColumn items for each admin
        items(admins, key = { it.username }) { admin ->
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("admin_item_${admin.username}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(FintechMintTint),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = admin.username.take(1).uppercase(),
                                color = FintechPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = admin.username,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = NagadMainText
                                )
                                if (admin.username == adminUsername) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = RoyalBlue.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "You",
                                            color = RoyalBlue,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (admin.role == "Super Admin") EmeraldGreen.copy(alpha = 0.15f) else RoyalBlue.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = admin.role,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (admin.role == "Super Admin") EmeraldGreen else RoyalBlue,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    if (admin.username != "admin" && admin.username != adminUsername) {
                        IconButton(
                            onClick = { viewModel.deleteAdminUser(admin.username) },
                            modifier = Modifier.testTag("delete_admin_${admin.username}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Admin",
                                tint = RedAlert,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "Protected",
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 3b. Member Accounts Backup Password Reset Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Member Password Reset (Backup)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = NagadMainText
            )
            Text(
                text = "Reset a registered member's login password if they cannot recover it themselves",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (memberAccounts.isEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No member portal accounts have signed up yet. Once members register via Sign Up, they will appear here for backup password resets.",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(memberAccounts, key = { "member_acc_${it.rrkMemberId}" }) { account ->
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .testTag("member_account_item_${account.rrkMemberId}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NagadLightBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = account.fullName.take(1).uppercase(),
                                    color = NagadPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = account.fullName,
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = NagadMainText
                                )
                                Text(
                                    text = "${account.rrkMemberId} · ${account.contact}",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 11.5.sp,
                                    color = NagadSecondaryText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedButton(
                            onClick = { memberToResetPassword = account },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, NagadPrimary),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("reset_member_password_${account.rrkMemberId}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockReset,
                                contentDescription = null,
                                tint = NagadPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Reset",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = NagadPrimary
                            )
                        }
                    }
                }
            }
        }

        // 4. Financial Balances Adjustment Card below
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                val currentKpi by viewModel.financialKpi.collectAsState()
                var bankInput by remember { mutableStateOf(currentKpi.bankBalance.toString()) }
                var reserveInput by remember { mutableStateOf(currentKpi.reservedAmount.toString()) }
                val derivedCashPreview = currentKpi.mainLiquidCapital - (bankInput.toIntOrNull() ?: currentKpi.bankBalance)

                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Financial Balances Adjustment", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Modify corporate bank balance and reserved funds (Cash in Hand derives automatically)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = bankInput,
                        onValueChange = { bankInput = it },
                        label = { Text("Bank Balance (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = CurrencyFormatter.formatCurrency(derivedCashPreview),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Cash In Hand (Derived: Liquid − Bank)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reserveInput,
                        onValueChange = { reserveInput = it },
                        label = { Text("Reserved Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val b = bankInput.toIntOrNull() ?: 0
                            val r = reserveInput.toIntOrNull() ?: 0
                            viewModel.updateFinancialSettings(b, r)
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = AppInputShape,
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("Save Financial Settings", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }

    val targetAccount = memberToResetPassword
    if (targetAccount != null) {
        var newPass by remember(targetAccount.rrkMemberId) { mutableStateOf("") }
        var confirmPass by remember(targetAccount.rrkMemberId) { mutableStateOf("") }
        var resetPassVisible by remember(targetAccount.rrkMemberId) { mutableStateOf(false) }
        var resetError by remember(targetAccount.rrkMemberId) { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { memberToResetPassword = null },
            containerColor = NagadWhite,
            shape = AppCardShape,
            title = {
                Text(
                    text = "Reset Member Password",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Setting a backup password for ${targetAccount.fullName} (${targetAccount.rrkMemberId}).",
                        fontFamily = InterFontFamily,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText
                    )
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password (min 6 chars)", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { resetPassVisible = !resetPassVisible }) {
                                Icon(
                                    imageVector = if (resetPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = NagadSecondaryText
                                )
                            }
                        },
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_reset_member_pass_input")
                    )
                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("Confirm New Password", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("admin_reset_member_confirm_input")
                    )
                    if (resetError != null) {
                        Text(
                            text = resetError ?: "",
                            fontFamily = InterFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NagadDanger
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass != confirmPass) {
                            resetError = "Passwords do not match."
                            return@Button
                        }
                        viewModel.adminResetMemberPassword(targetAccount.rrkMemberId, newPass) { success, msg ->
                            if (success) {
                                memberToResetPassword = null
                            } else {
                                resetError = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier.testTag("admin_reset_member_submit")
                ) {
                    Text("Save Password", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { memberToResetPassword = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }
}

@Composable
private fun OfficialPaymentAccountsSettingsCard(
    officialAccounts: OfficialPaymentAccounts,
    onSave: (bkash: String, nagad: String, bank: String) -> Unit
) {
    var bkashInput by remember(officialAccounts.bkash) { mutableStateOf(officialAccounts.bkash) }
    var nagadInput by remember(officialAccounts.nagad) { mutableStateOf(officialAccounts.nagad) }
    var bankInput by remember(officialAccounts.bank) { mutableStateOf(officialAccounts.bank) }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_official_payment_accounts_settings_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = null,
                    tint = NagadPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Official Payment Accounts Settings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = NagadMainText,
                    fontFamily = PoppinsFontFamily
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Edit Personal bKash, Personal Nagad, and Bank Account details synced to Contributions → Pay / Submit",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText,
                fontFamily = InterFontFamily
            )
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = bkashInput,
                onValueChange = { bkashInput = it },
                label = { Text("Personal bKash Number & Label", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., 01711-000111 (Personal)", fontFamily = InterFontFamily) },
                singleLine = true,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_bkash_account_input")
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = nagadInput,
                onValueChange = { nagadInput = it },
                label = { Text("Personal Nagad Number & Label", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., 01711-000222 (Personal)", fontFamily = InterFontFamily) },
                singleLine = true,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_nagad_account_input")
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = bankInput,
                onValueChange = { bankInput = it },
                label = { Text("Bank Account Details", fontFamily = InterFontFamily) },
                placeholder = { Text("Bank Name, A/C No, Branch", fontFamily = InterFontFamily) },
                minLines = 2,
                maxLines = 4,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_bank_account_input")
            )
            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    onSave(
                        bkashInput.trim().ifBlank { officialAccounts.bkash },
                        nagadInput.trim().ifBlank { officialAccounts.nagad },
                        bankInput.trim().ifBlank { officialAccounts.bank }
                    )
                },
                colors = appSolidButtonColors(NagadPrimary),
                shape = AppInputShape,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_official_payment_accounts_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save Payment Accounts",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun AdminAlertEmailSettingsCard(
    settings: AdminAlertEmailSettings,
    onSave: (
        adminAlertEmail: String,
        emailJsServiceId: String,
        emailJsTemplateId: String,
        emailJsPublicKey: String
    ) -> Unit
) {
    var emailInput by remember(settings.adminAlertEmail) { mutableStateOf(settings.adminAlertEmail) }
    var serviceIdInput by remember(settings.emailJsServiceId) { mutableStateOf(settings.emailJsServiceId) }
    var templateIdInput by remember(settings.emailJsTemplateId) { mutableStateOf(settings.emailJsTemplateId) }
    var publicKeyInput by remember(settings.emailJsPublicKey) { mutableStateOf(settings.emailJsPublicKey) }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_alert_email_settings_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        tint = NagadPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Admin Alert Email Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText,
                        fontFamily = PoppinsFontFamily
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (settings.isEmailJsConfigured) Color(0xFFECFDF5) else Color(0xFFFFFBEB),
                    border = BorderStroke(
                        1.dp,
                        if (settings.isEmailJsConfigured) Color(0xFF6EE7B7) else Color(0xFFFCD34D)
                    )
                ) {
                    Text(
                        text = if (settings.isEmailJsConfigured) "EmailJS Active" else "mailto: Fallback Ready",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (settings.isEmailJsConfigured) Color(0xFF059669) else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Receive instant payment proof alerts via EmailJS (automatic) and pre-filled Notify Admin via Email (mailto:) fallback.",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText,
                fontFamily = InterFontFamily
            )
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text("Admin Alert Email", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., rakibother01@gmail.com", fontFamily = InterFontFamily) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_alert_email_input")
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = serviceIdInput,
                onValueChange = { serviceIdInput = it },
                label = { Text("EmailJS Service ID (Optional)", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., service_xxxxxxx", fontFamily = InterFontFamily) },
                singleLine = true,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_emailjs_service_id_input")
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = templateIdInput,
                onValueChange = { templateIdInput = it },
                label = { Text("EmailJS Template ID (Optional)", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., template_xxxxxxx", fontFamily = InterFontFamily) },
                singleLine = true,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_emailjs_template_id_input")
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = publicKeyInput,
                onValueChange = { publicKeyInput = it },
                label = { Text("EmailJS Public Key (Optional)", fontFamily = InterFontFamily) },
                placeholder = { Text("e.g., user_xxxxxxxxxxxxx", fontFamily = InterFontFamily) },
                singleLine = true,
                textStyle = appInputTextStyle(),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_emailjs_public_key_input")
            )
            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    onSave(
                        emailInput.trim().ifBlank { AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL },
                        serviceIdInput.trim(),
                        templateIdInput.trim(),
                        publicKeyInput.trim()
                    )
                },
                colors = appSolidButtonColors(NagadPrimary),
                shape = AppInputShape,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_admin_alert_email_settings_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save Alert Email Settings",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminScheduledDueRemindersTestCard(
    membersWithStats: List<MemberWithStats>,
    simulatedReminderDay: Int?,
    onTriggerTest: (dayOfMonth: Int?, targetMemberId: Int?) -> Unit
) {
    var selectedMemberId by remember(membersWithStats) {
        mutableIntStateOf(
            membersWithStats.firstOrNull { it.totalDue > 0 }?.member?.id
                ?: membersWithStats.firstOrNull()?.member?.id
                ?: 1
        )
    }
    var memberDropdownExpanded by remember { mutableStateOf(false) }
    var showInlinePreview by remember { mutableStateOf(true) }

    val selectedStats = membersWithStats.find { it.member.id == selectedMemberId }
        ?: membersWithStats.firstOrNull()
    val activeMonths = remember { AppRepository.getActiveMonths() }
    val billingMonth = remember(selectedStats, activeMonths) {
        selectedStats?.pendingMonths?.firstOrNull()
            ?: activeMonths.lastOrNull()
            ?: SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
    }
    val todayDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    val previewReminders = remember(selectedStats, billingMonth, todayDate) {
        listOf(1, 8, 14).mapNotNull { day ->
            AdminNotificationHelper.buildReminderForDay(
                stats = selectedStats,
                dayOfMonth = day,
                billingMonth = billingMonth,
                paymentDate = todayDate,
                isTestPreview = true
            )
        }
    }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_scheduled_due_reminders_test_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = NagadPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Scheduled Due Reminders (1st / 8th / 14th)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = NagadMainText,
                        fontFamily = PoppinsFontFamily
                    )
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (simulatedReminderDay != null) Color(0xFFFFFBEB) else Color(0xFFECFDF5),
                    border = BorderStroke(
                        1.dp,
                        if (simulatedReminderDay != null) Color(0xFFFCD34D) else Color(0xFF6EE7B7)
                    )
                ) {
                    Text(
                        text = when (simulatedReminderDay) {
                            0 -> "Testing All 3"
                            1 -> "Testing 1st"
                            8 -> "Testing 8th"
                            14 -> "Testing 14th"
                            else -> "Auto Schedule"
                        },
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (simulatedReminderDay != null) Color(0xFFB45309) else Color(0xFF059669),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Automated monthly due reminders run on the 1st, 8th, and 14th for members with totalPayable > ৳0 (৳0 due shows zero alerts).",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText,
                fontFamily = InterFontFamily
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Member Selector for Preview/Testing
            if (membersWithStats.isNotEmpty() && selectedStats != null) {
                ExposedDropdownMenuBox(
                    expanded = memberDropdownExpanded,
                    onExpandedChange = { memberDropdownExpanded = !memberDropdownExpanded }
                ) {
                    val rrkId = "RRK-${selectedStats.member.id.toString().padStart(3, '0')}"
                    OutlinedTextField(
                        value = "$rrkId · ${selectedStats.member.name} (Due: ${CurrencyFormatter.formatCurrency(selectedStats.totalDue)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Preview Target Member", fontFamily = InterFontFamily) },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownExpanded)
                        },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = memberDropdownExpanded,
                        onDismissRequest = { memberDropdownExpanded = false },
                        containerColor = NagadWhite
                    ) {
                        membersWithStats.forEach { st ->
                            val idStr = "RRK-${st.member.id.toString().padStart(3, '0')}"
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "$idStr · ${st.member.name} (Capital Due: ${CurrencyFormatter.formatCurrency(st.totalDue)})",
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 12.5.sp,
                                        color = NagadMainText
                                    )
                                },
                                onClick = {
                                    selectedMemberId = st.member.id
                                    memberDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Primary required action button: 'Preview / Test Due Reminders (1st / 8th / 14th)'
            Button(
                onClick = {
                    showInlinePreview = true
                    onTriggerTest(0, selectedStats?.member?.id)
                },
                colors = appSolidButtonColors(NagadPrimary),
                shape = AppInputShape,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("preview_test_due_reminders_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Preview / Test Due Reminders (1st / 8th / 14th)",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Individual day test buttons (1st, 8th, 14th, Reset)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    1 to "Test 1st",
                    8 to "Test 8th",
                    14 to "Test 14th"
                ).forEach { (day, label) ->
                    val isSelected = simulatedReminderDay == day
                    OutlinedButton(
                        onClick = {
                            showInlinePreview = true
                            onTriggerTest(day, selectedStats?.member?.id)
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) NagadPrimary else NagadBorder
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) NagadLightBg else NagadWhite,
                            contentColor = if (isSelected) NagadPrimary else NagadMainText
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .testTag("test_due_reminder_day_$day")
                    ) {
                        Text(
                            text = label,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                if (simulatedReminderDay != null) {
                    OutlinedButton(
                        onClick = { onTriggerTest(null, null) },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0xFFFEF2F2),
                            contentColor = NagadDanger
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .height(38.dp)
                            .testTag("reset_due_reminder_test_btn")
                    ) {
                        Text(
                            text = "Reset",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (showInlinePreview) {
                Spacer(modifier = Modifier.height(12.dp))
                if (previewReminders.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NagadVeryLightBg,
                        border = AppCardBorder,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "0 Due Alerts — ${selectedStats?.member?.name ?: "Member"} has ৳0 pending due for this billing cycle.",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        previewReminders.forEach { rem ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = when (rem.dayOfMonth) {
                                    14 -> Color(0xFFFEF2F2)
                                    8 -> Color(0xFFFFFBEB)
                                    else -> Color(0xFFECFDF5)
                                },
                                border = BorderStroke(
                                    1.dp,
                                    when (rem.dayOfMonth) {
                                        14 -> Color(0xFFFCA5A5)
                                        8 -> Color(0xFFFCD34D)
                                        else -> Color(0xFF6EE7B7)
                                    }
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = rem.stageLabel,
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = NagadMainText
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = rem.message,
                                        fontFamily = InterFontFamily,
                                        fontSize = 11.5.sp,
                                        lineHeight = 16.sp,
                                        color = NagadMainText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminExitedMembersTabContent(
    exitedMembers: List<ExitedMember>,
    kpi: FinancialKpi,
    onAddExitedMember: () -> Unit,
    onMarkActiveExited: () -> Unit,
    onEditExitedMember: (ExitedMember) -> Unit,
    onDeleteExitedMember: (ExitedMember) -> Unit
) {
    val totalLossShare = remember(exitedMembers) { exitedMembers.sumOf { it.lossShareAmount } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(NagadVeryLightBg).testTag("admin_exited_members_tab"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Exited Members & Loss Offset",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        )
                    )
                    Text(
                        text = "${exitedMembers.size} Exited Members · Total ${CurrencyFormatter.formatCurrency(totalLossShare)} Loss Share Retained",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = InterFontFamily,
                        color = NagadSecondaryText
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onAddExitedMember,
                        colors = appSolidButtonColors(RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Exited", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onMarkActiveExited,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, FintechAmber),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = FintechAmber),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text("Mark Active", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Summary KPI Banner
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚖️ Business Loss Offset Mechanism",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = NagadMainText
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = FintechMintTint
                        ) {
                            Text(
                                text = "Active: ${kpi.activeMembersCount} · Exited: ${kpi.exitedMembersCount}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = FintechPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Gross Business P/L: -৳600 · Retained Exited Share: +${CurrencyFormatter.formatCurrency(totalLossShare)} · Net Active Business P/L: ${kpi.formattedNetBusinessPL}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (kpi.netBusinessProfitLoss < 0) FintechDuesRed else FintechPrimary,
                        fontFamily = InterFontFamily
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "When founding members resign, their allocated business loss share (৳14 per member) is retained from their capital settlement so that active members do not bear an unfair loss. Adding, editing, or deleting exited members updates this offset in real-time.",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = InterFontFamily,
                        color = NagadSecondaryText,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Exited Members list
        if (exitedMembers.isEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No Exited Members Recorded", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadMainText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "All founding members are currently active. Click 'Add Exited' or 'Mark Active' to record a departure.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(exitedMembers, key = { it.id }) { em ->
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth().testTag("exited_member_item_${em.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = em.name,
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.5.sp,
                                    color = NagadMainText
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFFEF2F2),
                                    border = BorderStroke(1.dp, Color(0xFFFECACA))
                                ) {
                                    Text(
                                        text = "EXITED",
                                        fontFamily = InterFontFamily,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = RedAlert,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (em.phone.isNotBlank()) {
                                Text(
                                    text = "Phone: ${em.phone}",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NagadSecondaryText,
                                    fontFamily = InterFontFamily
                                )
                            }

                            Text(
                                text = "Resigned: ${em.resignationDate}",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadSecondaryText,
                                fontFamily = InterFontFamily
                            )

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = "Retained Loss Offset: ${CurrencyFormatter.formatCurrency(em.lossShareAmount)}",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = NagadPrimary
                            )

                            if (em.notes.isNotBlank()) {
                                Text(
                                    text = em.notes,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = InterFontFamily,
                                    color = NagadSecondaryText,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(onClick = { onEditExitedMember(em) }) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Exited Member",
                                    tint = RoyalBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = { onDeleteExitedMember(em) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Exited Member",
                                    tint = RedAlert,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCustomPagesTabContent(
    viewModel: MainViewModel,
    customPages: List<CustomPage>,
    onCreatePage: () -> Unit,
    onPreviewPage: (CustomPage) -> Unit,
    onEditPage: (CustomPage) -> Unit,
    onDeletePage: (CustomPage) -> Unit
) {
    val sortedPages = remember(customPages) { customPages.sortedBy { it.displayOrder } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(NagadVeryLightBg).testTag("admin_custom_pages_tab"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Dynamic Custom Page Builder",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        )
                    )
                    Text(
                        text = "${customPages.size} Custom Pages Created · Published pages appear in Sidebar",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = InterFontFamily,
                        color = NagadSecondaryText
                    )
                }

                Button(
                    onClick = onCreatePage,
                    colors = appSolidButtonColors(RoyalBlue),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("admin_create_custom_page_btn")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Create Page", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // Info card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💡", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Dynamic Sidebar Integration",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = NagadMainText
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Pages created here are immediately saved in Room database and rendered in the main sidebar drawer. You can toggle visibility on/off, change ordering, and format rich guidelines or project announcements.",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = InterFontFamily,
                        color = NagadSecondaryText,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        if (sortedPages.isEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No Custom Pages Yet", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadMainText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Click 'Create Page' to add your first custom page (e.g., Organization Bylaws, Investment Criteria, FAQ).",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(sortedPages, key = { it.id }) { page ->
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth().testTag("custom_page_item_${page.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = NagadLightBg,
                                    border = BorderStroke(1.dp, NagadBorder),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "#${page.displayOrder}",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = NagadPrimary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column {
                                    Text(
                                        text = page.title,
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = NagadMainText
                                    )
                                    Text(
                                        text = "Icon: ${page.iconName} · Order: #${page.displayOrder}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        fontFamily = InterFontFamily,
                                        color = NagadSecondaryText
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (page.isVisible) Color(0xFFECFDF5) else NagadVeryLightBg,
                                border = BorderStroke(1.5.dp, if (page.isVisible) Color(0xFF6EE7B7) else NagadBorder)
                            ) {
                                Text(
                                    text = if (page.isVisible) "PUBLISHED" else "HIDDEN",
                                    fontFamily = InterFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (page.isVisible) Color(0xFF059669) else NagadSecondaryText,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        if (page.content.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = page.content.take(120) + if (page.content.length > 120) "..." else "",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                fontFamily = InterFontFamily,
                                color = NagadSecondaryText,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = { onPreviewPage(page) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp), tint = RoyalBlue)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("View Page", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
                                }

                                TextButton(
                                    onClick = { viewModel.updateCustomPage(page.copy(isVisible = !page.isVisible)) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = if (page.isVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = if (page.isVisible) FintechAmber else Color(0xFF059669)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (page.isVisible) "Hide" else "Publish",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (page.isVisible) FintechAmber else Color(0xFF059669)
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onEditPage(page) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = RoyalBlue, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { onDeletePage(page) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = RedAlert, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


