package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.ActivityLog
import com.example.data.model.AdminUser
import com.example.data.model.AppConfig
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.IdeaComment
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberAccount
import com.example.data.model.MemberIdea
import com.example.data.model.CustomPage
import com.example.data.model.ExitedMember
import com.example.data.model.MemberSettlement
import com.example.data.model.MemberWithCapitalContributions
import com.example.data.model.PaymentRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- Members ---
    @Query("SELECT COUNT(*) FROM members")
    suspend fun getMemberCount(): Int

    @Query("SELECT * FROM members ORDER BY id ASC")
    fun getAllMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: Int): Member?

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    fun observeMemberById(id: Int): Flow<Member?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<Member>)

    @Update
    suspend fun updateMember(member: Member)

    @Delete
    suspend fun deleteMember(member: Member)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteMemberById(id: Int)

    // --- Member & Capital Contributions 1-to-Many Relation ---
    @Transaction
    @Query("SELECT * FROM members WHERE id = :memberId")
    fun getMemberWithCapitalContributions(memberId: Int): Flow<MemberWithCapitalContributions?>

    @Transaction
    @Query("SELECT * FROM members ORDER BY id ASC")
    fun getAllMembersWithCapitalContributions(): Flow<List<MemberWithCapitalContributions>>

    // --- Deposits ---
    @Query("SELECT * FROM deposits ORDER BY paymentDate DESC, id DESC")
    fun getAllDeposits(): Flow<List<Deposit>>

    @Query("SELECT * FROM deposits WHERE memberId = :memberId ORDER BY paymentDate DESC, id DESC")
    fun getDepositsForMember(memberId: Int): Flow<List<Deposit>>

    @Query("SELECT * FROM deposits WHERE id = :id LIMIT 1")
    suspend fun getDepositById(id: Int): Deposit?

    @Query("SELECT * FROM deposits WHERE memberId = :memberId AND month = :month LIMIT 1")
    suspend fun getDepositForMemberMonth(memberId: Int, month: String): Deposit?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeposit(deposit: Deposit): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeposits(deposits: List<Deposit>)

    @Update
    suspend fun updateDeposit(deposit: Deposit)

    @Query("DELETE FROM deposits WHERE id = :id")
    suspend fun deleteDepositById(id: Int)

    @Query("DELETE FROM deposits WHERE memberId = :memberId")
    suspend fun deleteDepositsForMember(memberId: Int)

    // --- Expenses ---
    @Query("SELECT * FROM expenses ORDER BY date DESC, id DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<Expense>)

    @Update
    suspend fun updateExpense(expense: Expense)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Int)

    // --- Investments ---
    @Query("SELECT * FROM investments ORDER BY date DESC, id DESC")
    fun getAllInvestments(): Flow<List<Investment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestment(investment: Investment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestments(investments: List<Investment>)

    @Update
    suspend fun updateInvestment(investment: Investment)

    @Query("DELETE FROM investments WHERE id = :id")
    suspend fun deleteInvestmentById(id: Int)

    // --- Admin Users ---
    @Query("SELECT * FROM admin_users ORDER BY username ASC")
    fun getAllAdmins(): Flow<List<AdminUser>>

    @Query("SELECT * FROM admin_users WHERE LOWER(TRIM(username)) = LOWER(TRIM(:username)) LIMIT 1")
    suspend fun getAdminByUsername(username: String): AdminUser?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(admin: AdminUser)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmins(admins: List<AdminUser>)

    @Query("DELETE FROM admin_users WHERE username = :username")
    suspend fun deleteAdmin(username: String)

    // --- Activity Logs ---
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC, id DESC LIMIT 100")
    fun getAllLogs(): Flow<List<ActivityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLog)

    @Query("DELETE FROM activity_logs")
    suspend fun clearLogs()

    @Query("UPDATE members SET photoUri = :photoUri WHERE id = :id")
    suspend fun updateMemberPhoto(id: Int, photoUri: String?)

    // --- Member Settlements & Returns ---
    @Query("SELECT * FROM member_settlements ORDER BY resignationDate DESC, id DESC")
    fun getAllSettlements(): Flow<List<MemberSettlement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: MemberSettlement): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlements(settlements: List<MemberSettlement>)

    @Update
    suspend fun updateSettlement(settlement: MemberSettlement)

    @Query("DELETE FROM member_settlements WHERE id = :id")
    suspend fun deleteSettlementById(id: Int)

    @Query("SELECT * FROM member_settlements ORDER BY resignationDate DESC, id DESC")
    suspend fun getAllSettlementsSync(): List<MemberSettlement>

    @Query("DELETE FROM member_settlements")
    suspend fun clearSettlements()

    // --- App Config / Settings ---
    @Query("SELECT * FROM app_config")
    fun getAllConfigs(): Flow<List<AppConfig>>

    @Query("SELECT value FROM app_config WHERE `key` = :key LIMIT 1")
    suspend fun getConfig(key: String): String?

    // --- Sync queries for Backup & Restore ---
    @Query("SELECT * FROM members ORDER BY id ASC")
    suspend fun getAllMembersSync(): List<Member>

    @Query("SELECT * FROM deposits ORDER BY paymentDate DESC, id DESC")
    suspend fun getAllDepositsSync(): List<Deposit>

    @Query("SELECT * FROM expenses ORDER BY date DESC, id DESC")
    suspend fun getAllExpensesSync(): List<Expense>

    @Query("SELECT * FROM investments ORDER BY date DESC, id DESC")
    suspend fun getAllInvestmentsSync(): List<Investment>

    @Query("SELECT * FROM admin_users ORDER BY username ASC")
    suspend fun getAllAdminsSync(): List<AdminUser>

    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC, id DESC")
    suspend fun getAllLogsSync(): List<ActivityLog>

    @Query("SELECT * FROM app_config")
    suspend fun getAllConfigsSync(): List<AppConfig>

    // --- Table Clear Methods for Clean Restore ---
    @Query("DELETE FROM members")
    suspend fun clearMembers()

    @Query("DELETE FROM deposits")
    suspend fun clearDeposits()

    @Query("DELETE FROM expenses")
    suspend fun clearExpenses()

    @Query("DELETE FROM investments")
    suspend fun clearInvestments()

    @Query("DELETE FROM app_config")
    suspend fun clearConfigs()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setConfig(config: AppConfig)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfigs(configs: List<AppConfig>)

    // --- Member Accounts (Sign Up / Sign In / Password Reset) ---
    @Query("SELECT * FROM member_accounts ORDER BY createdAt DESC")
    fun getAllMemberAccounts(): Flow<List<MemberAccount>>

    @Query("SELECT * FROM member_accounts WHERE rrkMemberId = :rrkMemberId LIMIT 1")
    suspend fun getMemberAccountById(rrkMemberId: String): MemberAccount?

    @Query("SELECT * FROM member_accounts WHERE normalizedContact = :normalizedContact LIMIT 1")
    suspend fun getMemberAccountByContact(normalizedContact: String): MemberAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberAccount(account: MemberAccount)

    @Query("UPDATE member_accounts SET passwordHash = :passwordHash WHERE rrkMemberId = :rrkMemberId")
    suspend fun updateMemberAccountPassword(rrkMemberId: String, passwordHash: String)

    @Query("DELETE FROM member_accounts WHERE rrkMemberId = :rrkMemberId")
    suspend fun deleteMemberAccount(rrkMemberId: String)

    // --- Member Ideas & Comments ---
    @Query("SELECT * FROM member_ideas ORDER BY createdAt DESC, id DESC")
    fun getAllMemberIdeas(): Flow<List<MemberIdea>>

    @Query("SELECT * FROM member_ideas WHERE id = :id LIMIT 1")
    suspend fun getMemberIdeaById(id: Int): MemberIdea?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberIdea(idea: MemberIdea): Long

    @Update
    suspend fun updateMemberIdea(idea: MemberIdea)

    @Query("DELETE FROM member_ideas WHERE id = :id")
    suspend fun deleteMemberIdeaById(id: Int)

    @Query("SELECT * FROM idea_comments ORDER BY createdAt ASC, id ASC")
    fun getAllIdeaComments(): Flow<List<IdeaComment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdeaComment(comment: IdeaComment): Long

    @Query("DELETE FROM idea_comments WHERE ideaId = :ideaId")
    suspend fun deleteCommentsForIdea(ideaId: Int)

    // --- Manual Payment Requests & Verification Queue ---
    @Query("SELECT * FROM payment_requests ORDER BY createdAt DESC, id DESC")
    fun getAllPaymentRequests(): Flow<List<PaymentRequest>>

    @Query("SELECT * FROM payment_requests WHERE memberId = :memberId ORDER BY createdAt DESC, id DESC")
    fun getPaymentRequestsForMember(memberId: Int): Flow<List<PaymentRequest>>

    @Query("SELECT * FROM payment_requests WHERE id = :id LIMIT 1")
    suspend fun getPaymentRequestById(id: Int): PaymentRequest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentRequest(request: PaymentRequest): Long

    @Update
    suspend fun updatePaymentRequest(request: PaymentRequest)

    @Query("DELETE FROM payment_requests")
    suspend fun clearPaymentRequests()

    // --- Exited Members ---
    @Query("SELECT * FROM exited_members ORDER BY id ASC")
    fun getAllExitedMembers(): Flow<List<ExitedMember>>

    @Query("SELECT * FROM exited_members ORDER BY id ASC")
    suspend fun getAllExitedMembersSync(): List<ExitedMember>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExitedMember(member: ExitedMember): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExitedMembers(members: List<ExitedMember>)

    @Update
    suspend fun updateExitedMember(member: ExitedMember)

    @Query("DELETE FROM exited_members WHERE id = :id")
    suspend fun deleteExitedMember(id: Int)

    @Query("DELETE FROM exited_members")
    suspend fun clearExitedMembers()

    // --- Custom Pages ---
    @Query("SELECT * FROM custom_pages ORDER BY displayOrder ASC, id ASC")
    fun getAllCustomPages(): Flow<List<CustomPage>>

    @Query("SELECT * FROM custom_pages ORDER BY displayOrder ASC, id ASC")
    suspend fun getAllCustomPagesSync(): List<CustomPage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomPage(page: CustomPage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomPages(pages: List<CustomPage>)

    @Update
    suspend fun updateCustomPage(page: CustomPage)

    @Query("DELETE FROM custom_pages WHERE id = :id")
    suspend fun deleteCustomPage(id: Int)

    @Query("DELETE FROM custom_pages")
    suspend fun clearCustomPages()
}
