package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ai.AiTaskState
import com.example.data.model.Investment
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import com.example.util.ImageCompressor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvestmentsScreen(
    viewModel: MainViewModel
) {
    val investments by viewModel.investments.collectAsState()
    val kpi by viewModel.financialKpi.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val aiSummaryState by viewModel.investmentSummaryState.collectAsState()
    val context = LocalContext.current

    var showAddInvestmentDialog by remember { mutableStateOf(false) }
    var investmentToEdit by remember { mutableStateOf<Investment?>(null) }
    var investmentToDelete by remember { mutableStateOf<Investment?>(null) }
    var previewPhotoUri by remember { mutableStateOf<String?>(null) }

    val totalInvested = remember(investments) { investments.sumOf { it.amount } }
    val grossProfitLoss = remember(investments) {
        investments.filter { isInvestmentClosedStatus(it.status) }.sumOf { it.profitLoss }
    }
    val totalProfit = remember(investments) {
        investments.filter { isInvestmentClosedStatus(it.status) && it.profitLoss > 0 }.sumOf { it.profitLoss }
    }
    val totalLoss = remember(investments) {
        investments.filter { isInvestmentClosedStatus(it.status) && it.profitLoss < 0 }.sumOf { -it.profitLoss }
    }
    val exitedLossRecovery = kpi.exitedMembersLossRecovery
    val totalProfitLoss = grossProfitLoss + exitedLossRecovery
    val activeCount = remember(investments) {
        investments.count { isInvestmentRunningStatus(it.status) }
    }

    val investmentBarItems = remember(investments) {
        investments.map { inv ->
            BarItem(
                label = inv.name.take(8) + if (inv.name.length > 8) "…" else "",
                value = inv.amount.toFloat(),
                color = NagadPrimary
            )
        }
    }

    val roiBarItems = remember(investments) {
        investments.map { inv ->
            val roiPct = if (inv.amount > 0) (inv.profitLoss.toFloat() / inv.amount) * 100f else 0f
            BarItem(
                label = inv.name.take(8) + if (inv.name.length > 8) "…" else "",
                value = roiPct.coerceAtLeast(0f),
                color = if (inv.profitLoss >= 0) NagadPrimary else NagadDanger
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("investments_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 20.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Investments",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = NagadMainText
                        )
                    )
                    Text(
                        text = "Commercial portfolio & ROI tracking",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier.height(40.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    AiSummaryButton(
                        isLoading = aiSummaryState is AiTaskState.Loading || aiSummaryState is AiTaskState.Streaming,
                        onClick = { viewModel.generateInvestmentAiSummary() }
                    )
                }
            }
        }

        if (aiSummaryState !is AiTaskState.Idle) {
            item {
                AiSummaryPanel(
                    title = "Portfolio AI Summary",
                    state = aiSummaryState,
                    onDismiss = { viewModel.clearInvestmentAiSummary() },
                    onRetry = { viewModel.generateInvestmentAiSummary() }
                )
            }
        }

        // 4 Stat Cards (Equal width 50/50 & Equal height per row)
        item {
            val grossStr = CurrencyFormatter.formatSignedCurrency(grossProfitLoss)
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Total Projects",
                        value = "${investments.size}",
                        subtitle = "Portfolio ventures",
                        icon = Icons.Default.BarChart,
                        iconBgColor = RoyalBlue.copy(alpha = 0.12f),
                        iconColor = RoyalBlue,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                    StatCard(
                        title = "Total Invested",
                        value = CurrencyFormatter.formatCurrency(totalInvested),
                        subtitle = "Disbursed capital",
                        icon = Icons.Default.Diamond,
                        iconBgColor = Gold.copy(alpha = 0.15f),
                        iconColor = Gold,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Business P&L",
                        value = CurrencyFormatter.formatSignedCurrency(totalProfitLoss),
                        subtitle = "Gross $grossStr + ${CurrencyFormatter.formatCurrency(exitedLossRecovery)} exited share",
                        icon = Icons.Default.TrendingUp,
                        iconBgColor = if (totalProfitLoss >= 0) EmeraldGreen.copy(alpha = 0.12f) else RedAlert.copy(alpha = 0.12f),
                        iconColor = if (totalProfitLoss >= 0) EmeraldGreen else RedAlert,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        trendText = if (totalProfitLoss >= 0) "Profit" else "Loss",
                        isPositiveTrend = totalProfitLoss >= 0
                    )
                    StatCard(
                        title = "Active Projects",
                        value = "$activeCount",
                        subtitle = "Ongoing operations",
                        icon = Icons.Default.CheckCircle,
                        iconBgColor = EmeraldGreen.copy(alpha = 0.12f),
                        iconColor = EmeraldGreen,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
            }
        }

        // Business P/L & Exited Members' Loss Offset Reconciliation Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Business P/L & Exited Members' Loss Offset",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Total Profit: ${CurrencyFormatter.formatCurrency(totalProfit)} | Total Loss: ${CurrencyFormatter.formatCurrency(totalLoss)} → Gross Business P/L: ${CurrencyFormatter.formatSignedCurrency(grossProfitLoss)}",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = NagadSecondaryText,
                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                    )
                    Text(
                        text = "Exited Members' Loss Share Retained (3 Exited Members × ৳14/person): +${CurrencyFormatter.formatCurrency(exitedLossRecovery)}",
                        fontFamily = InterFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NagadPrimary,
                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                    )
                    HorizontalDivider(color = NagadBorder)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "Net Active Business P/L (11 Active Members)",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = NagadMainText
                        )
                        Text(
                            text = "${CurrencyFormatter.formatSignedCurrency(totalProfitLoss)} (${CurrencyFormatter.formatSignedCurrency(grossProfitLoss)} + ${CurrencyFormatter.formatCurrency(exitedLossRecovery)})",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.5.sp,
                            color = if (totalProfitLoss >= 0) NagadPrimary else NagadDanger,
                            style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                        )
                    }
                }
            }
        }

        // Investment Cards
        item {
            Text(
                text = "Active & Historical Portfolios (${investments.size})",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = NagadMainText
            )
        }

        if (investments.isEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            "No investment projects registered yet",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    }
                }
            }
        } else {
            items(investments, key = { it.id }) { inv ->
                val isRunning = isInvestmentRunningStatus(inv.status)
                val isClosed = isInvestmentClosedStatus(inv.status)
                val (statusBg, statusTextColor) = when {
                    isRunning -> Pair(NagadLightBg, NagadPrimary)
                    isClosed -> Pair(Color(0xFFF1F5F9), NagadSecondaryText)
                    else -> Pair(Color(0xFFFEF7E6), NagadWarning)
                }
                val statusLabel = when {
                    isRunning -> "Running"
                    isClosed -> "Closed"
                    else -> inv.status
                }
                val pnlLabel = when {
                    inv.profitLoss > 0 -> "Profit: ${CurrencyFormatter.formatSignedCurrency(inv.profitLoss)}"
                    inv.profitLoss < 0 -> "Loss: ${CurrencyFormatter.formatSignedCurrency(inv.profitLoss)}"
                    else -> "Equal: ৳0"
                }

                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f).padding(end = 8.dp)
                            ) {
                                if (inv.photoUri.isNotBlank()) {
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(NagadLightBg)
                                            .clickable { previewPhotoUri = inv.photoUri },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AsyncImage(
                                            model = inv.photoUri,
                                            contentDescription = inv.name,
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(NagadLightBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (inv.type.lowercase()) {
                                                "stock", "commodities" -> Icons.Default.BarChart
                                                else -> Icons.Default.TrendingUp
                                            },
                                            contentDescription = null,
                                            tint = NagadPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                }

                                Column {
                                    Text(
                                        text = inv.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.5.sp,
                                        color = NagadMainText,
                                        fontFamily = InterFontFamily
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = statusBg
                            ) {
                                Text(
                                    text = "Status: $statusLabel",
                                    color = statusTextColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = InterFontFamily,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = NagadBorder)
                        Spacer(modifier = Modifier.height(10.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Invested (${inv.date})",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText,
                                        fontFamily = InterFontFamily
                                    )
                                    Text(
                                        text = CurrencyFormatter.formatCurrency(inv.amount),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.5.sp,
                                        color = NagadPrimary,
                                        fontFamily = InterFontFamily,
                                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    val soldDateStr = if (inv.saleDate.isNotBlank()) " (${inv.saleDate})" else ""
                                    Text(
                                        text = "Sold$soldDateStr",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText,
                                        fontFamily = InterFontFamily
                                    )
                                    Text(
                                        text = CurrencyFormatter.formatCurrency(inv.saleRevenue),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = NagadMainText,
                                        fontFamily = InterFontFamily,
                                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Net Result",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText,
                                        fontFamily = InterFontFamily
                                    )
                                    Text(
                                        text = pnlLabel,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = when {
                                            inv.profitLoss > 0 -> NagadPrimary
                                            inv.profitLoss < 0 -> NagadDanger
                                            else -> NagadSecondaryText
                                        },
                                        fontFamily = InterFontFamily,
                                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Supervision",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText,
                                        fontFamily = InterFontFamily
                                    )
                                    Text(
                                        text = inv.supervisor.ifBlank { "—" },
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = NagadMainText,
                                        fontFamily = InterFontFamily
                                    )
                                }
                            }
                        }

                        if (isAdmin) {
                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = NagadBorder)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { investmentToEdit = inv },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                TextButton(
                                    onClick = { investmentToDelete = inv },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = RedAlert, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Delete", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RedAlert)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Charts
        if (investmentBarItems.isNotEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Investment Capital Distribution",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = NagadMainText
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        BarChartComposable(items = investmentBarItems)
                    }
                }
            }

            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Return on Investment (ROI %)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = NagadMainText
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        BarChartComposable(items = roiBarItems, valuePrefix = "")
                    }
                }
            }
        }
    }

    // Add Investment Dialog
    if (showAddInvestmentDialog) {
        val sourceOptions = listOf("Cash", "Bank")
        var nameInput by remember { mutableStateOf("") }
        var amountInput by remember { mutableStateOf("") }
        var plInput by remember { mutableStateOf("0") }
        var revenueInput by remember { mutableStateOf("") }
        var statusInput by remember { mutableStateOf("RUNNING") }
        var sourceInput by remember { mutableStateOf("Cash") }
        var returnSourceInput by remember { mutableStateOf("Cash") }
        var dateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        var descInput by remember { mutableStateOf("") }
        var photoUriInput by remember { mutableStateOf("") }
        var statusDropdownOpen by remember { mutableStateOf(false) }
        var sourceDropdownOpen by remember { mutableStateOf(false) }
        var returnDropdownOpen by remember { mutableStateOf(false) }

        val addPhotoLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia()
        ) { uri: Uri? ->
            if (uri != null) {
                val compressed = ImageCompressor.compressUriToDataUri(context, uri, maxDim = 180, quality = 65)
                if (compressed.isNotBlank()) {
                    photoUriInput = compressed
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showAddInvestmentDialog = false },
            containerColor = NagadWhite,
            title = {
                Text(
                    "Record New Investment",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Asset Photo Upload Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NagadLightBg)
                                .clickable {
                                    if (photoUriInput.isNotBlank()) previewPhotoUri = photoUriInput
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (photoUriInput.isNotBlank()) {
                                AsyncImage(
                                    model = photoUriInput,
                                    contentDescription = "Asset Photo Preview",
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = NagadSecondaryText, modifier = Modifier.size(24.dp))
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Product / Asset Photo", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NagadMainText)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = {
                                    addPhotoLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.2.dp, NagadPrimary),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Upload Photo", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Investment Name *", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { newAmtStr ->
                            amountInput = newAmtStr
                            val amt = newAmtStr.toIntOrNull() ?: 0
                            val rev = revenueInput.toIntOrNull()
                            if (statusInput == "CLOSED" && rev != null) {
                                plInput = (rev - amt).toString()
                            }
                        },
                        label = { Text("Capital Amount (৳) *", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    ExposedDropdownMenuBox(
                        expanded = sourceDropdownOpen,
                        onExpandedChange = { sourceDropdownOpen = !sourceDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (sourceInput == "Bank") {
                                "Bank Balance (${CurrencyFormatter.formatCurrency(kpi.bankBalance)})"
                            } else {
                                "Cash in Hand (${CurrencyFormatter.formatCurrency(kpi.cashInHand)})"
                            },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Source", fontFamily = InterFontFamily) },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceDropdownOpen,
                            onDismissRequest = { sourceDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            sourceOptions.forEach { src ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (src == "Bank") {
                                                "Bank Balance (${CurrencyFormatter.formatCurrency(kpi.bankBalance)})"
                                            } else {
                                                "Cash in Hand (${CurrencyFormatter.formatCurrency(kpi.cashInHand)})"
                                            },
                                            fontFamily = InterFontFamily,
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        sourceInput = src
                                        returnSourceInput = src
                                        sourceDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Text("Status:", fontFamily = InterFontFamily, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    ExposedDropdownMenuBox(
                        expanded = statusDropdownOpen,
                        onExpandedChange = { statusDropdownOpen = !statusDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (statusInput == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusDropdownOpen,
                            onDismissRequest = { statusDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            listOf("RUNNING", "CLOSED").forEach { opt ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (opt == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                                            fontFamily = InterFontFamily,
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        statusInput = opt
                                        if (opt == "CLOSED" && revenueInput.isBlank()) {
                                            val amt = amountInput.toIntOrNull() ?: 0
                                            val pl = plInput.toIntOrNull() ?: 0
                                            revenueInput = (amt + pl).toString()
                                        }
                                        statusDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    if (statusInput == "CLOSED") {
                        OutlinedTextField(
                            value = revenueInput,
                            onValueChange = { newRevStr ->
                                revenueInput = newRevStr
                                val amt = amountInput.toIntOrNull() ?: 0
                                val rev = newRevStr.toIntOrNull()
                                if (rev != null) {
                                    plInput = (rev - amt).toString()
                                }
                            },
                            label = { Text("Final Sale / Return Revenue (৳)", fontFamily = InterFontFamily) },
                            singleLine = true,
                            textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        )
                        OutlinedTextField(
                            value = plInput,
                            onValueChange = { newPlStr ->
                                plInput = newPlStr
                                val amt = amountInput.toIntOrNull() ?: 0
                                val pl = newPlStr.toIntOrNull()
                                if (pl != null) {
                                    revenueInput = (amt + pl).toString()
                                }
                            },
                            label = { Text("Realized Profit / Loss (৳)", fontFamily = InterFontFamily) },
                            singleLine = true,
                            textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        )
                        ExposedDropdownMenuBox(
                            expanded = returnDropdownOpen,
                            onExpandedChange = { returnDropdownOpen = !returnDropdownOpen }
                        ) {
                            OutlinedTextField(
                                value = if (returnSourceInput == "Bank") "Bank Balance" else "Cash in Hand",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Return Proceeds To", fontFamily = InterFontFamily) },
                                textStyle = appInputTextStyle(),
                                shape = AppInputShape,
                                colors = appOutlinedTextFieldColors(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = returnDropdownOpen) },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = returnDropdownOpen,
                                onDismissRequest = { returnDropdownOpen = false },
                                containerColor = NagadWhite
                            ) {
                                sourceOptions.forEach { dst ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (dst == "Bank") "Bank Balance" else "Cash in Hand",
                                                fontFamily = InterFontFamily,
                                                color = NagadMainText
                                            )
                                        },
                                        onClick = {
                                            returnSourceInput = dst
                                            returnDropdownOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = dateInput,
                        onValueChange = { dateInput = it },
                        label = { Text("Date (YYYY-MM-DD)", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Brief Description", fontFamily = InterFontFamily) },
                        singleLine = false,
                        maxLines = 3,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toIntOrNull() ?: 0
                        val rev = if (statusInput == "CLOSED") {
                            revenueInput.toIntOrNull() ?: (amt + (plInput.toIntOrNull() ?: 0))
                        } else 0
                        val pl = if (statusInput == "CLOSED") {
                            plInput.toIntOrNull() ?: (rev - amt)
                        } else 0
                        if (nameInput.isNotBlank() && amt > 0) {
                            viewModel.addInvestment(
                                Investment(
                                    name = nameInput.trim(),
                                    amount = amt,
                                    activeCapital = if (statusInput == "RUNNING") amt else 0,
                                    profitLoss = pl,
                                    saleRevenue = rev,
                                    saleDate = if (statusInput == "CLOSED") dateInput.trim() else "",
                                    status = statusInput,
                                    stockStatus = if (statusInput == "RUNNING") "In Stock" else "Closed",
                                    date = dateInput.trim(),
                                    description = descInput.trim(),
                                    photoUri = photoUriInput,
                                    paymentSource = sourceInput,
                                    returnSource = if (statusInput == "CLOSED") returnSourceInput else ""
                                )
                            )
                            showAddInvestmentDialog = false
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Add Investment", fontFamily = InterFontFamily, color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddInvestmentDialog = false }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }

    // Delete Confirmation
    if (investmentToDelete != null) {
        AlertDialog(
            onDismissRequest = { investmentToDelete = null },
            containerColor = NagadWhite,
            title = {
                Text(
                    "Delete Investment Project?",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Text(
                    "Are you sure you want to delete \"${investmentToDelete?.name}\"?",
                    fontFamily = InterFontFamily,
                    color = NagadSecondaryText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        investmentToDelete?.id?.let { viewModel.deleteInvestment(it) }
                        investmentToDelete = null
                    },
                    colors = appSolidButtonColors(NagadDanger)
                ) {
                    Text("Delete", fontFamily = InterFontFamily, color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { investmentToDelete = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }

    // Edit Investment Dialog
    if (investmentToEdit != null) {
        val inv = investmentToEdit!!
        val statusOptions = listOf("RUNNING", "CLOSED")
        val sourceOptions = listOf("Cash", "Bank")
        var eName by remember { mutableStateOf(inv.name) }
        var eAmount by remember { mutableStateOf(inv.amount.toString()) }
        var eRevenue by remember {
            mutableStateOf(
                if (inv.saleRevenue > 0) inv.saleRevenue.toString() else (inv.amount + inv.profitLoss).toString()
            )
        }
        var ePl by remember { mutableStateOf(inv.profitLoss.toString()) }
        var eStatus by remember {
            mutableStateOf(if (isInvestmentRunningStatus(inv.status)) "RUNNING" else "CLOSED")
        }
        var eSource by remember {
            mutableStateOf(if (inv.paymentSource.equals("Bank", true)) "Bank" else "Cash")
        }
        var eReturnSource by remember {
            mutableStateOf(
                inv.returnSource.ifBlank { if (inv.paymentSource.equals("Bank", true)) "Bank" else "Cash" }
            )
        }
        var eDate by remember { mutableStateOf(inv.date) }
        var eDesc by remember { mutableStateOf(inv.description) }
        var ePhotoUri by remember { mutableStateOf(inv.photoUri) }
        var statusDropdownOpen by remember { mutableStateOf(false) }
        var sourceDropdownOpen by remember { mutableStateOf(false) }
        var returnDropdownOpen by remember { mutableStateOf(false) }

        val editPhotoLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia()
        ) { uri: Uri? ->
            if (uri != null) {
                val compressed = ImageCompressor.compressUriToDataUri(context, uri, maxDim = 180, quality = 65)
                if (compressed.isNotBlank()) {
                    ePhotoUri = compressed
                }
            }
        }

        AlertDialog(
            onDismissRequest = { investmentToEdit = null },
            containerColor = NagadWhite,
            title = {
                Text(
                    "Edit / Close Investment #${inv.id}",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Asset Photo Upload Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NagadLightBg)
                                .clickable {
                                    if (ePhotoUri.isNotBlank()) previewPhotoUri = ePhotoUri
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (ePhotoUri.isNotBlank()) {
                                AsyncImage(
                                    model = ePhotoUri,
                                    contentDescription = "Asset Photo Preview",
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = NagadSecondaryText, modifier = Modifier.size(24.dp))
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Product / Asset Photo", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NagadMainText)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = {
                                    editPhotoLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.2.dp, NagadPrimary),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Upload Photo", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = eName,
                        onValueChange = { eName = it },
                        label = { Text("Investment Name *", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    OutlinedTextField(
                        value = eAmount,
                        onValueChange = { newAmtStr ->
                            eAmount = newAmtStr
                            val amt = newAmtStr.toIntOrNull() ?: 0
                            val rev = eRevenue.toIntOrNull()
                            if (eStatus == "CLOSED" && rev != null) {
                                ePl = (rev - amt).toString()
                            }
                        },
                        label = { Text("Capital Amount (৳) *", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    ExposedDropdownMenuBox(
                        expanded = sourceDropdownOpen,
                        onExpandedChange = { sourceDropdownOpen = !sourceDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (eSource == "Bank") "Bank Balance" else "Cash in Hand",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Source", fontFamily = InterFontFamily) },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceDropdownOpen,
                            onDismissRequest = { sourceDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            sourceOptions.forEach { src ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (src == "Bank") "Bank Balance" else "Cash in Hand",
                                            fontFamily = InterFontFamily,
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        eSource = src
                                        sourceDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Text("Status:", fontFamily = InterFontFamily, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    ExposedDropdownMenuBox(
                        expanded = statusDropdownOpen,
                        onExpandedChange = { statusDropdownOpen = !statusDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = if (eStatus == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownOpen) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusDropdownOpen,
                            onDismissRequest = { statusDropdownOpen = false },
                            containerColor = NagadWhite
                        ) {
                            statusOptions.forEach { opt ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (opt == "RUNNING") "Running (Active Venture)" else "Closed (Liquidated/Completed)",
                                            fontFamily = InterFontFamily,
                                            color = NagadMainText
                                        )
                                    },
                                    onClick = {
                                        eStatus = opt
                                        if (opt == "CLOSED") {
                                            val amt = eAmount.toIntOrNull() ?: inv.amount
                                            val curPl = ePl.toIntOrNull() ?: inv.profitLoss
                                            eRevenue = (amt + curPl).toString()
                                            if (eReturnSource.isBlank()) eReturnSource = eSource
                                        }
                                        statusDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    if (eStatus == "CLOSED") {
                        OutlinedTextField(
                            value = eRevenue,
                            onValueChange = { newRevStr ->
                                eRevenue = newRevStr
                                val amt = eAmount.toIntOrNull() ?: inv.amount
                                val rev = newRevStr.toIntOrNull()
                                if (rev != null) {
                                    ePl = (rev - amt).toString()
                                }
                            },
                            label = { Text("Sale / Return Revenue (৳)", fontFamily = InterFontFamily) },
                            singleLine = true,
                            textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        )
                        OutlinedTextField(
                            value = ePl,
                            onValueChange = { newPlStr ->
                                ePl = newPlStr
                                val amt = eAmount.toIntOrNull() ?: inv.amount
                                val pl = newPlStr.toIntOrNull()
                                if (pl != null) {
                                    eRevenue = (amt + pl).toString()
                                }
                            },
                            label = { Text("Realized Profit / Loss (৳)", fontFamily = InterFontFamily) },
                            singleLine = true,
                            textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        )
                        ExposedDropdownMenuBox(
                            expanded = returnDropdownOpen,
                            onExpandedChange = { returnDropdownOpen = !returnDropdownOpen }
                        ) {
                            OutlinedTextField(
                                value = if (eReturnSource == "Bank") "Bank Balance" else "Cash in Hand",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Return Proceeds To", fontFamily = InterFontFamily) },
                                textStyle = appInputTextStyle(),
                                shape = AppInputShape,
                                colors = appOutlinedTextFieldColors(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = returnDropdownOpen) },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = returnDropdownOpen,
                                onDismissRequest = { returnDropdownOpen = false },
                                containerColor = NagadWhite
                            ) {
                                sourceOptions.forEach { dst ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (dst == "Bank") "Bank Balance" else "Cash in Hand",
                                                fontFamily = InterFontFamily,
                                                color = NagadMainText
                                            )
                                        },
                                        onClick = {
                                            eReturnSource = dst
                                            returnDropdownOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Date (YYYY-MM-DD)", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle().copy(fontFeatureSettings = TABULAR_NUMBERS),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    OutlinedTextField(
                        value = eDesc,
                        onValueChange = { eDesc = it },
                        label = { Text("Brief Description", fontFamily = InterFontFamily) },
                        singleLine = false,
                        maxLines = 3,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = eAmount.toIntOrNull() ?: inv.amount
                        val rev = if (eStatus == "CLOSED") {
                            eRevenue.toIntOrNull() ?: (amt + (ePl.toIntOrNull() ?: inv.profitLoss))
                        } else 0
                        val pl = if (eStatus == "CLOSED") {
                            ePl.toIntOrNull() ?: (rev - amt)
                        } else 0
                        val finalSaleDate = if (eStatus == "CLOSED") {
                            inv.saleDate.ifBlank { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
                        } else ""
                        if (eName.isNotBlank() && amt > 0) {
                            viewModel.updateInvestment(
                                inv.copy(
                                    name = eName.trim(),
                                    amount = amt,
                                    activeCapital = if (eStatus == "RUNNING") amt else 0,
                                    saleRevenue = rev,
                                    saleDate = finalSaleDate,
                                    profitLoss = pl,
                                    status = eStatus,
                                    stockStatus = if (eStatus == "RUNNING") "In Stock" else "Closed",
                                    date = eDate.trim(),
                                    description = eDesc.trim(),
                                    photoUri = ePhotoUri,
                                    paymentSource = eSource,
                                    returnSource = if (eStatus == "CLOSED") eReturnSource else ""
                                )
                            )
                            investmentToEdit = null
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Save Changes", fontFamily = InterFontFamily, color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { investmentToEdit = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }

    // Full-size Photo Preview Modal
    if (previewPhotoUri != null) {
        AlertDialog(
            onDismissRequest = { previewPhotoUri = null },
            containerColor = NagadWhite,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Asset Photo Preview",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = NagadMainText
                    )
                    IconButton(onClick = { previewPhotoUri = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = NagadMainText)
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NagadLightBg),
                    contentAlignment = Alignment.Center
                ) {
                    coil.compose.AsyncImage(
                        model = previewPhotoUri,
                        contentDescription = "Full Size Asset Photo",
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { previewPhotoUri = null },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Close", fontFamily = InterFontFamily, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

private fun isInvestmentRunningStatus(status: String): Boolean =
    status.uppercase() in setOf("RUNNING", "ACTIVE")

private fun isInvestmentClosedStatus(status: String): Boolean =
    status.uppercase() in setOf("CLOSED", "COMPLETED", "LIQUIDATED")

