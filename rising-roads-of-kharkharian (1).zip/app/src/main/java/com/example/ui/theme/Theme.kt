package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val FintechColorScheme = lightColorScheme(
    primary = FintechPrimary,
    onPrimary = Color.White,
    primaryContainer = FintechMintTint,
    onPrimaryContainer = FintechDeepGreen,
    secondary = FintechPrimary,
    onSecondary = Color.White,
    secondaryContainer = FintechMintTint,
    onSecondaryContainer = FintechDeepGreen,
    tertiary = FintechAmber,
    onTertiary = Color.White,
    background = FintechBackground,
    onBackground = FintechTextPrimary,
    surface = FintechSurface,
    onSurface = FintechTextPrimary,
    surfaceVariant = FintechSurface,
    onSurfaceVariant = FintechTextSecondary,
    outline = InputBorder,
    outlineVariant = FintechBorder,
    error = FintechDuesRed,
    onError = Color.White
)

private val FintechShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(16.dp)
)

@Composable
fun RisingRoadsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FintechColorScheme,
        typography = Typography,
        shapes = FintechShapes,
        content = content
    )
}
