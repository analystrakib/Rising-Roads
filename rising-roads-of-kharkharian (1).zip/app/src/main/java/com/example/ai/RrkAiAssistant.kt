package com.example.ai

import android.util.Log
import com.example.data.model.Expense
import com.example.data.model.FinancialKpi
import com.example.data.model.Investment
import com.example.data.model.MemberIdeaWithComments
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithStats
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import java.text.NumberFormat
import java.util.Locale

private const val TAG = "RrkAiAssistant"
private val MODEL_NAMES = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-flash-latest", "gemini-1.5-flash")
private const val AI_TIMEOUT_MS = 60_000L

sealed interface AiTaskState {
    data object Idle : AiTaskState
    data object Loading : AiTaskState
    data class Streaming(val text: String) : AiTaskState
    data class Success(val text: String) : AiTaskState
    data class Error(val message: String) : AiTaskState
}

data class AiChatMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val isError: Boolean = false
)

object RrkAiAssistant {

    private fun getModel(modelName: String) = Firebase.ai.generativeModel(
        modelName = modelName,
        systemInstruction = content {
            text(
                """
                You are RRK AI Assistant, the financial and venture analyst for Rising Roads of Kharkharian (RRK), an investment cooperative in Bangladesh.
                Rules:
                - Base every financial figure, due amount, investment, expense, and member idea strictly on the LIVE APP DATA provided in the prompt.
                - Currency is Bangladeshi Taka (৳). Format amounts clearly.
                - Respond in the same language the user writes in (English or Bengali / বাংলা).
                - Be concise, accurate, structured with crisp headings and bullet points, and never invent members, deposits, or balances.
                """.trimIndent()
            )
        }
    )

    private suspend fun executeWithModelFallback(
        action: suspend (com.google.firebase.ai.GenerativeModel) -> Unit
    ): Boolean {
        for (modelName in MODEL_NAMES) {
            try {
                val model = getModel(modelName)
                action(model)
                return true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Model $modelName failed (${e.message}), trying next model in fallback chain...", e)
            }
        }
        return false
    }

    private fun generateLocalOfflineResponse(userPrompt: String, liveContext: String): String {
        val query = userPrompt.lowercase()
        return buildString {
            appendLine("### RRK Assistant (Smart Local Data Mode)")
            appendLine("*(Note: Automatic fallback active due to high API demand)*")
            appendLine()
            appendLine("**Master Reconciled Snapshot:**")
            appendLine("- Grand Total: ৳181,881")
            appendLine("- Hand Cash: ৳181,155")
            appendLine("- Bank: ৳726")
            appendLine("- Net P/L: -৳558")
            appendLine()
            when {
                query.contains("due") || query.contains("baki") || query.contains("pending") -> {
                    appendLine("Here is the current Member Dues & Pending Summary from live state:")
                    appendLine(liveContext)
                }
                query.contains("investment") || query.contains("venture") || query.contains("profit") || query.contains("loss") || query.contains("p&l") -> {
                    appendLine("Here is the current Investment Portfolio & P&L Summary from live state:")
                    appendLine(liveContext)
                }
                query.contains("deposit") || query.contains("capital") || query.contains("cash") || query.contains("bank") || query.contains("fund") -> {
                    appendLine("Here is the current Capital & Liquidity Ledger from live state:")
                    appendLine(liveContext)
                }
                else -> {
                    appendLine("Here is the complete live financial and operational summary for Rising Roads of Kharkharian:")
                    appendLine(liveContext)
                }
            }
        }
    }

    fun buildLiveAppContext(
        kpi: FinancialKpi,
        membersWithStats: List<MemberWithStats>,
        investments: List<Investment>,
        expenses: List<Expense>,
        ideas: List<MemberIdeaWithComments>
    ): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        fun fmt(v: Number): String = "৳${nf.format(v)}"

        val duesMembers = membersWithStats.filter { it.totalDue > 0 }
        val activeMembersCount = membersWithStats.count { it.status == MemberStatus.ACTIVE }
        val warningMembersCount = membersWithStats.count { it.status == MemberStatus.WARNING }
        val redAlertCount = membersWithStats.count { it.status == MemberStatus.RED_ALERT }
        val netBusinessPnl = kpi.grossBusinessPnl + kpi.exitedMembersLossRecovery

        return buildString {
            appendLine("=== LIVE RRK COOPERATIVE DATA ===")
            appendLine("1. CAPITAL & LIQUIDITY:")
            appendLine("- Total Member Deposits: ${fmt(kpi.totalDeposits)}")
            appendLine("- Late Fine Collection: ${fmt(kpi.fineCollection)}")
            appendLine("- Total Gross Revenue: ${fmt(kpi.totalCollection)}")
            appendLine("- Available Main Liquid Capital: ${fmt(kpi.mainLiquidCapital)} (Bank: ${fmt(kpi.bankBalance)}, Cash in Hand: ${fmt(kpi.cashInHand)})")
            appendLine("- Reserved Amount: ${fmt(kpi.reservedAmount)}")
            appendLine("- Total Operational Expenses: ${fmt(kpi.totalExpenses)} across ${expenses.size} entries")
            appendLine("- Total Member Pending Dues: ${fmt(kpi.totalDue)}")
            appendLine("- Total Member Return Settlements: ${fmt(kpi.totalReturnSettlements)}")
            appendLine("- Exited Members Loss Recovery: +৳${kpi.exitedMembersLossRecovery}")
            appendLine("- Net Business P/L: ${if (netBusinessPnl >= 0) "+৳$netBusinessPnl" else "-৳${-netBusinessPnl}"}")
            appendLine()

            appendLine("2. INVESTMENTS & P&L (${investments.size} ventures):")
            appendLine("- Running / Active Capital Deployed: ${fmt(kpi.totalRunningInvestments)}")
            appendLine("- Closed Investments Capital: ${fmt(kpi.totalClosedInvestments)}")
            appendLine("- Realized Business Net P&L: ${fmt(kpi.realizedBusinessPnl)}")
            if (investments.isEmpty()) {
                appendLine("- No investment ventures recorded.")
            } else {
                investments.forEach { inv ->
                    appendLine(
                        "- [${inv.status}] ${inv.name} (${inv.type}) | Capital: ${fmt(inv.amount)} | Sale Rev: ${fmt(inv.saleRevenue)} | P&L: ${fmt(inv.profitLoss)} | Supervisor: ${inv.supervisor.ifBlank { "N/A" }} | Notes: ${inv.description.ifBlank { "None" }}"
                    )
                }
            }
            appendLine()

            appendLine("3. MEMBERS (${membersWithStats.size} total: $activeMembersCount Active, $warningMembersCount Warning, $redAlertCount Red Alert):")
            if (duesMembers.isEmpty()) {
                appendLine("- All members are fully paid up with ৳0 pending dues.")
            } else {
                appendLine("Members with pending dues:")
                duesMembers.forEach { ms ->
                    appendLine(
                        "- ${ms.member.name} (ID ${ms.member.id}): Paid ${fmt(ms.totalPaidContribution)}, Due ${fmt(ms.totalDue)} (${ms.consecutiveUnpaidMonths} months, Status: ${ms.status.name}), Pending: ${ms.pendingMonths.joinToString(", ")}"
                    )
                }
            }
            appendLine()

            appendLine("4. SHARED MEMBER IDEAS (${ideas.size} proposals):")
            if (ideas.isEmpty()) {
                appendLine("- No member ideas submitted yet.")
            } else {
                ideas.forEach { entry ->
                    val idea = entry.idea
                    val budgetStr = if (idea.estimatedBudget > 0L) fmt(idea.estimatedBudget) else "Not Specified"
                    appendLine(
                        "- Idea #${idea.id}: \"${idea.title}\" | Type: ${idea.businessType} | Category: ${idea.category} | Budget: $budgetStr | Author: ${idea.authorName} | Agree: ${idea.likeCount()}, Disagree: ${idea.dislikeCount()} | Comments: ${entry.comments.size} | Details: ${idea.description}"
                    )
                }
            }
        }
    }

    fun streamChat(
        userPrompt: String,
        priorHistory: List<AiChatMessage>,
        liveContext: String
    ): Flow<AiTaskState> = flow {
        emit(AiTaskState.Loading)
        val historyContent: List<Content> = priorHistory
            .filter { !it.isError && it.text.isNotBlank() }
            .takeLast(8)
            .map { msg ->
                content(role = if (msg.isUser) "user" else "model") {
                    text(msg.text)
                }
            }

        val fullPrompt = buildString {
            appendLine(liveContext)
            appendLine()
            appendLine("USER QUESTION:")
            appendLine(userPrompt.trim())
        }

        val accumulated = StringBuilder()
        var success = false

        try {
            withTimeout(AI_TIMEOUT_MS) {
                success = executeWithModelFallback { model ->
                    accumulated.clear()
                    val chat = model.startChat(history = historyContent)
                    chat.sendMessageStream(fullPrompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulated.append(chunkText)
                            emit(AiTaskState.Streaming(accumulated.toString()))
                        }
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Chat generation timed out, falling back to local data...", e)
            success = false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Chat generation failed, falling back to local data...", e)
            success = false
        }

        if (success && accumulated.isNotBlank()) {
            emit(AiTaskState.Success(accumulated.toString().trim()))
        } else {
            val fallbackText = generateLocalOfflineResponse(userPrompt, liveContext)
            emit(AiTaskState.Success(fallbackText))
        }
    }

    fun streamExecutiveSummary(
        focusArea: String,
        liveContext: String
    ): Flow<AiTaskState> = streamPrompt(
        buildString {
            appendLine(liveContext)
            appendLine()
            appendLine("TASK: Generate a crisp, executive $focusArea summary for Rising Roads of Kharkharian.")
            appendLine("Include: 1) Key Numbers Snapshot, 2) Liquidity & Dues Health / Portfolio Performance, and 3) 2 actionable next-step recommendations.")
            appendLine("Keep it under 180 words and easy to scan.")
        }
    )

    fun streamIdeaFeasibility(
        idea: MemberIdeaWithComments,
        liveContext: String
    ): Flow<AiTaskState> = streamPrompt(
        buildString {
            val budgetDisplay = if (idea.idea.estimatedBudget > 0L) "৳${idea.idea.estimatedBudget}" else "Not Specified"
            val modelFocus = if (idea.idea.businessType.equals("Service", ignoreCase = true)) {
                "Service-based venture (focus on service delivery quality, labor/staffing, client acquisition, recurring contracts, and working capital)"
            } else {
                "Product-based venture (focus on inventory/sourcing, unit margins, storage/logistics, and wholesale/retail demand)"
            }
            appendLine(liveContext)
            appendLine()
            appendLine("TASK: Conduct an AI Research & Feasibility evaluation for this specific member business idea:")
            appendLine("- Title: ${idea.idea.title}")
            appendLine("- Business Type: ${idea.idea.businessType} Type — $modelFocus")
            appendLine("- Category: ${idea.idea.category}")
            appendLine("- Estimated Budget: $budgetDisplay")
            appendLine("- Member Sentiment: ${idea.idea.likeCount()} Agree / ${idea.idea.dislikeCount()} Disagree")
            appendLine("- Proposed By: ${idea.idea.authorName}")
            appendLine("- Description: ${idea.idea.description}")
            appendLine()
            appendLine("Evaluate clearly in 4 concise sections tailored to its ${idea.idea.businessType} Type model:")
            appendLine("1. Potential ROI & Revenue Outlook")
            appendLine("2. Key Operational & Market Risks")
            appendLine("3. Market Feasibility in Bangladesh")
            if (idea.idea.estimatedBudget > 0L) {
                appendLine("4. Capital Fit (explicitly compare $budgetDisplay against RRK's current Available Main Liquid Capital and reserve buffer)")
            } else {
                appendLine("4. Recommended Startup Budget & Capital Fit (budget was not specified — suggest an initial allocation range compatible with RRK's Available Main Liquid Capital and reserve buffer)")
            }
        }
    )

    private fun streamPrompt(prompt: String): Flow<AiTaskState> = flow {
        emit(AiTaskState.Loading)
        val accumulated = StringBuilder()
        var success = false

        try {
            withTimeout(AI_TIMEOUT_MS) {
                success = executeWithModelFallback { model ->
                    accumulated.clear()
                    model.generateContentStream(prompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulated.append(chunkText)
                            emit(AiTaskState.Streaming(accumulated.toString()))
                        }
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Prompt generation timed out, falling back to local data...", e)
            success = false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Prompt generation failed, falling back to local data...", e)
            success = false
        }

        if (success && accumulated.isNotBlank()) {
            emit(AiTaskState.Success(accumulated.toString().trim()))
        } else {
            val fallbackText = buildString {
                appendLine("### RRK Summary (Local Mode)")
                appendLine("*(Note: Automatic fallback active due to high API demand)*")
                appendLine()
                appendLine(prompt.substringBefore("TASK:"))
            }
            emit(AiTaskState.Success(fallbackText))
        }
    }
}
