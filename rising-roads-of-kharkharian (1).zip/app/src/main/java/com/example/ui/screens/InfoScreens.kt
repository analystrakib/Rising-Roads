package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.IconButton
import coil.compose.AsyncImage
import com.example.data.model.CustomPage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun AboutScreen(viewModel: MainViewModel? = null) {
    val configsState = viewModel?.configs?.collectAsState()
    val configs = configsState?.value ?: emptyList()
    val customStory = configs.find { it.key == "about_us_story" }?.value
    val developerCredit = configs.find { it.key == "developer_credit" }?.value?.trim()?.takeIf { it.isNotEmpty() }
        ?: "Developed by Rakib"
    val storyContent = if (!customStory.isNullOrBlank()) customStory else "Rising Roads Of Kharkharian was founded in May 2025 by 11 committed individuals from the Kharkharian community. Small consistent contributions build something extraordinary. Each member pledges ৳1,000 monthly."
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("about_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card (Rich Green Gradient Card)
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(NagadDeepGreen, NagadPrimary)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NagadWhite.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, NagadWhite.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "EST. MAY 2025 · KHARKHARIAN, BD",
                            color = NagadWhite,
                            fontFamily = InterFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Rising Roads\nOf Kharkharian",
                        fontFamily = InterFontFamily,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NagadWhite,
                        lineHeight = 30.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "A member-owned joint investment platform dedicated to building financial discipline and long-term wealth for all 11 founding members.",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = NagadWhite.copy(alpha = 0.92f),
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Section: How We Started
        item {
            InfoSectionCard(
                title = "How We Started",
                icon = "🚀",
                content = storyContent
            )
        }

        // Section: Future Goals
        item {
            InfoSectionCard(
                title = "Future Goals",
                icon = "🎯",
                content = "Within 3 years, Rising Roads aims to launch its first registered commercial business enterprise. By Year 5, we envision a diversified portfolio of active investments generating consistent returns for all 11 partners."
            )
        }

        // Section: Member Unity
        item {
            InfoSectionCard(
                title = "Member Unity & Governance",
                icon = "🤝",
                content = "Our 11 members are partners, decision-makers, and stakeholders in every venture. We operate on principles of transparency, equal voting rights, and mutual accountability."
            )
        }

        // Section: Investment Strategy
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📊 Phased Investment Strategy",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Phase 1 (2025): Strict fund discipline & reserve building\n• Phase 2 (2026): Launch first commercial retail/wholesale venture\n• Phase 3 (2027+): Diversify across local industries & assets\n• Phase 4 (2028+): Formal corporate company incorporation",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // About Page Footer with Editable Developer Credit
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "RISING ROADS OF KHARKHARIAN",
                        color = NagadPrimary,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = developerCredit,
                        color = NagadMainText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.testTag("about_developer_credit")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Custom engineered for Rising Roads Of Kharkharian with real-time reactive financial reconciliation, zero-loss capital auditing, and native vector statement generation.",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = NagadSecondaryText,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MissionScreen(viewModel: MainViewModel? = null) {
    val configsState = viewModel?.configs?.collectAsState()
    val configs = configsState?.value ?: emptyList()
    val customMission = configs.find { it.key == "mission_statement" }?.value ?: configs.find { it.key == "mission_vision" }?.value
    val customVision = configs.find { it.key == "vision_statement" }?.value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("mission_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Mission & Vision",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                color = NagadMainText
            )
            Text(
                text = "Principles and aspirations guiding every decision at Rising Roads",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = NagadSecondaryText
            )
        }

        // Mission Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NagadLightBg,
                        border = BorderStroke(1.5.dp, NagadBorder)
                    ) {
                        Text(
                            text = "🎯 OUR MISSION",
                            color = NagadPrimary,
                            fontFamily = InterFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Building Financial Discipline",
                        color = NagadMainText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (!customMission.isNullOrBlank()) customMission else "Build financial discipline, encourage regular monthly savings, create long-term commercial business growth, and build a strong member-based investment system that serves all 11 founders equally.",
                        color = NagadSecondaryText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        lineHeight = 21.sp
                    )
                }
            }
        }

        // Vision Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFEF7E6),
                        border = BorderStroke(1.5.dp, Color(0xFFFDE68A))
                    ) {
                        Text(
                            text = "🔭 OUR VISION",
                            color = NagadWarning,
                            fontFamily = InterFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Becoming a Full Enterprise",
                        color = NagadMainText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (!customVision.isNullOrBlank()) customVision else "Establish Rising Roads as a full registered business enterprise. Create commercial shops, agro-livestock farms, and sustainable trade projects that benefit all 11 founding partners and the Kharkharian community.",
                        color = NagadSecondaryText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        lineHeight = 21.sp
                    )
                }
            }
        }

        // Core Values
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Core Values",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        CoreValuePill("⚡", "Discipline", "Monthly habit")
                        CoreValuePill("🔍", "Transparency", "Open ledgers")
                        CoreValuePill("🤝", "Unity", "11 Partners")
                        CoreValuePill("📈", "Growth", "Wealth creation")
                    }
                }
            }
        }
    }
}

@Composable
fun ContactScreen(viewModel: MainViewModel? = null) {
    val configsState = viewModel?.configs?.collectAsState()
    val configs = configsState?.value ?: emptyList()
    val cEmail = configs.find { it.key == "contact_email" }?.value ?: "risingroads@gmail.com"
    val cAddress = configs.find { it.key == "contact_address" }?.value ?: "Kharkharian, Bangladesh"
    val cPhone = configs.find { it.key == "contact_phone" }?.value

    var senderName by remember { mutableStateOf("") }
    var senderEmail by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var isSent by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("contact_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Contact Us",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                color = NagadMainText
            )
            Text(
                text = "Get in touch with Rising Roads Of Kharkharian administration",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = NagadSecondaryText
            )
        }

        // Contact Information Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Contact Information",
                        color = NagadMainText,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    ContactItemRow(Icons.Default.Email, "Email", cEmail)
                    ContactItemRow(Icons.Default.LocationOn, "Location", cAddress)
                    if (!cPhone.isNullOrBlank()) {
                        ContactItemRow(Icons.Default.Groups, "Phone", cPhone)
                    }
                    ContactItemRow(Icons.Default.Groups, "Founding Members", "11 Founding Partners")
                    ContactItemRow(Icons.Default.CalendarMonth, "Established", "May 2025")

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = NagadBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "⚡ Payment deadline: 15th of each month · ৳100 late fine auto-applied after deadline",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp,
                        color = NagadPrimary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Send a Message Form
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Send an Inquiry or Message",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = senderName,
                        onValueChange = { senderName = it },
                        label = { Text("Your Name", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = senderEmail,
                        onValueChange = { senderEmail = it },
                        label = { Text("Your Email", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message", fontFamily = InterFontFamily) },
                        minLines = 3,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (isSent) {
                        Surface(
                            shape = AppInputShape,
                            color = NagadLightBg,
                            border = BorderStroke(1.5.dp, NagadBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✓ Message sent successfully! The administration will respond soon.",
                                color = NagadPrimary,
                                fontFamily = InterFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                if (senderName.isNotBlank() && message.isNotBlank()) {
                                    isSent = true
                                }
                            },
                            colors = appSolidButtonColors(NagadPrimary),
                            shape = AppInputShape,
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Send Message", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InfoSectionCard(title: String, icon: String, content: String) {
    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 20.sp)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = NagadMainText
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                color = NagadSecondaryText,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun CoreValuePill(icon: String, title: String, subtitle: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 22.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = NagadMainText
        )
        Text(
            text = subtitle,
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 10.5.sp,
            color = NagadSecondaryText
        )
    }
}

@Composable
fun ContactItemRow(icon: ImageVector, title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NagadLightBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = NagadPrimary, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, fontFamily = InterFontFamily, fontWeight = FontWeight.Medium, fontSize = 11.sp, color = NagadSecondaryText)
            Text(value, fontFamily = InterFontFamily, fontSize = 13.sp, color = NagadMainText, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun CustomPageDetailScreen(page: CustomPage, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NagadMainText)
                }
                Text(
                    text = page.title,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = NagadMainText
                )
                Spacer(modifier = Modifier.width(48.dp))
            }
        }
        if (page.coverImageUrl.isNotBlank()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                ) {
                    AsyncImage(
                        model = page.coverImageUrl,
                        contentDescription = page.title,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = page.content,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        color = NagadMainText,
                        lineHeight = 22.sp
                    )
                }
            }
        }
    }
}

