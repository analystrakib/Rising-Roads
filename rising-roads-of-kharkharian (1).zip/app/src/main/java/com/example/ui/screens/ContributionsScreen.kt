package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.LaunchedEffect
import com.example.data.model.Deposit
import com.example.data.model.Member
import com.example.data.repository.AppRepository
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContributionsScreen(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit,
    initialTab: Int = 0
) {
    var selectedTab by remember { mutableIntStateOf(initialTab) } // 0 = 11 Investor Portfolios, 1 = Monthly Sheet, 2 = Pay / Submit
    val pendingRequestsCount by viewModel.pendingPaymentRequestsCount.collectAsState()
    val activeMemberDueReminders by viewModel.activeMemberDueReminders.collectAsState()

    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }

    Column(modifier = Modifier.fillMaxSize().background(NagadVeryLightBg).testTag("contributions_screen")) {
        if (activeMemberDueReminders.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                activeMemberDueReminders.forEach { reminder ->
                    MemberDueReminderBanner(
                        reminder = reminder,
                        onPayNow = { selectedTab = 2 },
                        onDismiss = { viewModel.dismissDueReminder(reminder.id) }
                    )
                }
            }
        }

        // Tab switcher (Nagad Green & White Pill Container)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NagadWhite, shape = RoundedCornerShape(12.dp))
                    .border(BorderStroke(1.5.dp, NagadBorder), RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selectedTab == 0) NagadPrimary else Color.Transparent,
                    modifier = Modifier
                        .weight(1.18f)
                        .clickable { selectedTab = 0 }
                        .padding(vertical = 8.dp, horizontal = 2.dp)
                ) {
                    Text(
                        text = "11 Investor Portfolios",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 0) NagadWhite else NagadSecondaryText,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selectedTab == 1) NagadPrimary else Color.Transparent,
                    modifier = Modifier
                        .weight(0.95f)
                        .clickable { selectedTab = 1 }
                        .padding(vertical = 8.dp, horizontal = 2.dp)
                ) {
                    Text(
                        text = "Monthly Sheet",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 1) NagadWhite else NagadSecondaryText,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selectedTab == 2) NagadPrimary else Color.Transparent,
                    modifier = Modifier
                        .weight(0.87f)
                        .clickable { selectedTab = 2 }
                        .padding(vertical = 8.dp, horizontal = 2.dp)
                        .testTag("pay_submit_tab_pill")
                ) {
                    val tabText = if (pendingRequestsCount > 0 && selectedTab != 2) {
                        "Pay / Submit ($pendingRequestsCount)"
                    } else {
                        "Pay / Submit"
                    }
                    Text(
                        text = tabText,
                        fontFamily = PoppinsFontFamily,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 2) NagadWhite else NagadSecondaryText,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                CapitalContributionsScreen(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = onNavigateToMemberProfile,
                    onPayNowClick = { selectedTab = 2 }
                )
            }
            1 -> {
                MonthlyContributionsView(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = onNavigateToMemberProfile
                )
            }
            else -> {
                PaySubmitTab(
                    viewModel = viewModel,
                    onNavigateToMemberProfile = onNavigateToMemberProfile
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyContributionsView(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit
) {
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val allDeposits by viewModel.deposits.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val adminRole by viewModel.adminRole.collectAsState()

    val activeMonths = remember { AppRepository.getActiveMonths() }
    var selectedMonth by remember { mutableStateOf(activeMonths.lastOrNull() ?: "May 2025") }
    var isMonthDropdownExpanded by remember { mutableStateOf(false) }

    var selectedReceiptDeposit by remember { mutableStateOf<Deposit?>(null) }
    var selectedReceiptMember by remember { mutableStateOf<Member?>(null) }
    var recordDepositForMember by remember { mutableStateOf<Member?>(null) }

    val currentDayOfMonth = remember {
        SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1
    }
    val isAfterDeadline = currentDayOfMonth > 15

    // Month stats
    val monthDeposits = remember(allDeposits, selectedMonth) {
        allDeposits.filter { it.month == selectedMonth }
    }
    val paidMemberIds = remember(monthDeposits) {
        monthDeposits.map { it.memberId }.toSet()
    }
    val paidCount = paidMemberIds.size
    val dueCount = (membersWithStats.size - paidCount).coerceAtLeast(0)
    val collectedAmount = monthDeposits.sumOf { it.amount }
    val totalFineForMonth = monthDeposits.sumOf { it.fine }

    // Chart data for monthly collections
    val barItems = remember(allDeposits) {
        activeMonths.takeLast(6).map { m ->
            val sum = allDeposits.filter { it.month == m }.sumOf { it.amount }.toFloat()
            BarItem(label = m.split(" ").firstOrNull() ?: m, value = sum, color = NagadPrimary)
        }
    }

    val donutSlices = remember(paidCount, dueCount) {
        listOf(
            DonutSlice("Paid", paidCount.toFloat(), NagadPrimary),
            DonutSlice("Due", dueCount.toFloat(), NagadDanger)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("monthly_contributions_view"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Title & Month Selector Dropdown
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Monthly Status Sheet",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = NagadMainText
                        )
                        Text(
                            text = "Monthly contribution tracking",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = NagadSecondaryText
                        )
                    }

                    // Month Selector Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isMonthDropdownExpanded,
                        onExpandedChange = { isMonthDropdownExpanded = !isMonthDropdownExpanded }
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = NagadWhite,
                            border = AppCardBorder,
                            modifier = Modifier
                                .menuAnchor()
                                .clickable { isMonthDropdownExpanded = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedMonth,
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = NagadPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = isMonthDropdownExpanded)
                            }
                        }

                        ExposedDropdownMenu(
                            expanded = isMonthDropdownExpanded,
                            onDismissRequest = { isMonthDropdownExpanded = false }
                        ) {
                            activeMonths.forEach { m ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = m,
                                            fontFamily = PoppinsFontFamily,
                                            fontWeight = if (m == selectedMonth) FontWeight.Bold else FontWeight.Normal,
                                            color = if (m == selectedMonth) NagadPrimary else NagadMainText
                                        )
                                    },
                                    onClick = {
                                        selectedMonth = m
                                        isMonthDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4 KPI Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Paid This Month",
                        value = "$paidCount / ${membersWithStats.size}",
                        subtitle = "Members completed",
                        icon = Icons.Default.CheckCircle,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Due This Month",
                        value = "$dueCount",
                        subtitle = "Pending contributions",
                        icon = Icons.Default.HourglassBottom,
                        iconBgColor = Color(0xFFFDF0F0),
                        iconColor = NagadDanger,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Collected (Base)",
                        value = "৳${collectedAmount.toLocaleString()}",
                        subtitle = "৳1,000 / member",
                        icon = Icons.Default.AttachMoney,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Fines Collected",
                        value = "৳${totalFineForMonth.toLocaleString()}",
                        subtitle = "After 15th deadline",
                        icon = Icons.Default.Warning,
                        iconBgColor = Color(0xFFFEF7E6),
                        iconColor = NagadWarning,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        }

        // Monthly Status Table
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Payment Status for $selectedMonth",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Deadline: 15th · Automatic ৳100 late fine applied after deadline",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        color = NagadSecondaryText
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    membersWithStats.forEachIndexed { index, item ->
                        val dep = monthDeposits.find { it.memberId == item.member.id }
                        val isPaid = dep != null
                        val fine = if (isPaid) dep.fine else if (isAfterDeadline) 100 else 0

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToMemberProfile(item.member.id) }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "${index + 1}.",
                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NagadSecondaryText,
                                    modifier = Modifier.width(26.dp)
                                )
                                Column {
                                    Text(
                                        text = item.member.name,
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = NagadMainText
                                    )
                                    Text(
                                        text = "Base: ৳1,000" + if (fine > 0) " + Fine: ${CurrencyFormatter.formatCurrency(fine)}" else "",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp,
                                        color = if (fine > 0) NagadDanger else NagadSecondaryText
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isPaid) NagadLightBg else Color(0xFFFDF0F0),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isPaid) NagadBorder else Color(0xFFFBD5D5)
                                    )
                                ) {
                                    Text(
                                        text = if (isPaid) "Paid" else "Due",
                                        color = if (isPaid) NagadPrimary else NagadDanger,
                                        fontFamily = PoppinsFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                if (isPaid && dep != null) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = NagadLightBg,
                                        border = BorderStroke(1.dp, NagadBorder),
                                        modifier = Modifier.clickable {
                                            selectedReceiptDeposit = dep
                                            selectedReceiptMember = item.member
                                        }
                                    ) {
                                        Text(
                                            text = "Receipt",
                                            fontFamily = PoppinsFontFamily,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadPrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFFDF0F0),
                                        border = BorderStroke(1.dp, Color(0xFFFBD5D5))
                                    ) {
                                        Text(
                                            text = "Unpaid",
                                            fontFamily = PoppinsFontFamily,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadDanger,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                        HorizontalDivider(color = NagadBorder.copy(alpha = 0.5f))
                    }
                }
            }
        }

        // Charts Section
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Monthly Collections Comparison",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    BarChartComposable(items = barItems)
                }
            }
        }

        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "$selectedMonth Payment Distribution",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DonutChartComposable(
                        slices = donutSlices,
                        centerLabel = "Total",
                        centerValue = "${membersWithStats.size}"
                    )
                }
            }
        }
    }

    // Receipt Dialog
    if (selectedReceiptDeposit != null && selectedReceiptMember != null) {
        val memberDue = membersWithStats.find { it.member.id == selectedReceiptMember?.id }?.totalDue ?: 0
        DepositReceiptDialog(
            deposit = selectedReceiptDeposit!!,
            member = selectedReceiptMember!!,
            dynamicDue = memberDue,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = {
                selectedReceiptDeposit = null
                selectedReceiptMember = null
            }
        )
    }

    // Quick Record Dialog for Member
    if (recordDepositForMember != null) {
        val targetMember = recordDepositForMember!!
        val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
        val day = remember { SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1 }
        val defFine = if (day > 15) 100 else 0
        var pDate by remember { mutableStateOf(todayStr) }
        var fineVal by remember { mutableStateOf(defFine.toString()) }

        AlertDialog(
            onDismissRequest = { recordDepositForMember = null },
            containerColor = NagadWhite,
            title = {
                Text(
                    text = "Record ${targetMember.name} — $selectedMonth",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Contribution Amount: ৳1,000",
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        color = NagadPrimary
                    )
                    OutlinedTextField(
                        value = pDate,
                        onValueChange = { pDate = it },
                        label = { Text("Payment Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    OutlinedTextField(
                        value = fineVal,
                        onValueChange = { fineVal = it },
                        label = { Text("Fine Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    if (fineVal.toIntOrNull() ?: 0 > 0) {
                        Text(
                            text = "Total Payment: ${CurrencyFormatter.formatCurrency(1000 + (fineVal.toIntOrNull() ?: 0))}",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontWeight = FontWeight.ExtraBold,
                            color = NagadPrimary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fine = fineVal.toIntOrNull() ?: 0
                        viewModel.recordDeposit(
                            memberId = targetMember.id,
                            month = selectedMonth,
                            paymentDate = pDate,
                            amount = 1000,
                            fine = fine
                        ) { newId ->
                            val newDep = Deposit(
                                id = newId.toInt(),
                                memberId = targetMember.id,
                                month = selectedMonth,
                                paymentDate = pDate,
                                amount = 1000,
                                fine = fine
                            )
                            selectedReceiptDeposit = newDep
                            selectedReceiptMember = targetMember
                            recordDepositForMember = null
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Record Payment", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordDepositForMember = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }
}

private fun Int.toLocaleString(): String {
    return CurrencyFormatter.formatNumber(this)
}
