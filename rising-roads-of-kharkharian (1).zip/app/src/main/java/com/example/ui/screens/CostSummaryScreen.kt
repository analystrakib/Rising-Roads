package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Expense
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CostSummaryScreen(
    viewModel: MainViewModel
) {
    val expenses by viewModel.expenses.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()

    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<Expense?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }

    val totalExpenses = remember(expenses) { expenses.sumOf { it.amount } }

    val categoriesMap = remember(expenses) {
        expenses.groupBy { it.category }.mapValues { it.value.sumOf { exp -> exp.amount } }
    }

    val officeCost = categoriesMap["Office Expenses"] ?: 0
    val transportCost = categoriesMap["Transport"] ?: 0
    val marketingCost = categoriesMap["Marketing"] ?: 0

    val categoryColors = listOf(
        NagadPrimary,
        NagadDeepGreen,
        NagadWarning,
        NagadDanger,
        Color(0xFF7C3AED),
        Color(0xFF059669),
        NagadSecondaryText
    )

    val donutSlices = remember(categoriesMap) {
        categoriesMap.entries.mapIndexed { idx, entry ->
            DonutSlice(entry.key, entry.value.toFloat(), categoryColors[idx % categoryColors.size])
        }
    }

    val trendPoints = remember(expenses) {
        val sdf = SimpleDateFormat("MMM yyyy", Locale.US)
        val parseFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        expenses.groupBy { exp ->
            try {
                val d = parseFormat.parse(exp.date)
                if (d != null) sdf.format(d) else exp.date
            } catch (e: Exception) {
                exp.date
            }
        }.map { (month, list) ->
            Pair(month.split(" ").firstOrNull() ?: month, list.sumOf { it.amount }.toFloat())
        }.takeLast(6)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("cost_summary_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Cost Summary",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = NagadMainText
                        )
                    )
                    Text(
                        text = "Detailed operational expense ledger",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    )
                }
            }
        }

        // 4 Stat Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Total Expenses",
                        value = CurrencyFormatter.formatCurrency(totalExpenses),
                        subtitle = "${expenses.size} records",
                        valueColor = NagadDanger,
                        icon = Icons.Default.MoneyOff,
                        iconBgColor = Color(0xFFFDF0F0),
                        iconColor = NagadDanger,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Office & Supplies",
                        value = CurrencyFormatter.formatCurrency(officeCost),
                        subtitle = "Venues & stationery",
                        valueColor = NagadMainText,
                        icon = Icons.Default.BusinessCenter,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Transport Costs",
                        value = CurrencyFormatter.formatCurrency(transportCost),
                        subtitle = "Site visits & travel",
                        valueColor = NagadMainText,
                        icon = Icons.Default.DirectionsCar,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Marketing & Print",
                        value = CurrencyFormatter.formatCurrency(marketingCost),
                        subtitle = "Flyers & campaign",
                        valueColor = NagadMainText,
                        icon = Icons.Default.Campaign,
                        iconBgColor = Color(0xFFFEF7E6),
                        iconColor = NagadWarning,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        }

        // Expense Records Table
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Expense Records (${expenses.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (expenses.isEmpty()) {
                        Text(
                            text = "No expenses recorded yet",
                            color = NagadSecondaryText,
                            fontSize = 13.sp,
                            fontFamily = PoppinsFontFamily,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        expenses.forEachIndexed { index, exp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "${index + 1}.",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NagadSecondaryText,
                                        modifier = Modifier.width(26.dp)
                                    )
                                    Column {
                                        Text(
                                            text = exp.description,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = NagadMainText,
                                            fontFamily = InterFontFamily
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = NagadLightBg
                                            ) {
                                                Text(
                                                    text = exp.category,
                                                    fontSize = 10.sp,
                                                    color = NagadPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = InterFontFamily,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${exp.date} · By ${exp.recordedBy}",
                                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 11.sp,
                                                color = NagadSecondaryText
                                            )
                                        }
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = CurrencyFormatter.formatCurrency(exp.amount),
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = NagadDanger,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                            HorizontalDivider(color = NagadBorder)
                        }
                    }
                }
            }
        }

        // Charts
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Expenses by Category",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DonutChartComposable(
                        slices = donutSlices,
                        centerLabel = "Total",
                        centerValue = CurrencyFormatter.formatCurrency(totalExpenses)
                    )
                }
            }
        }

        if (trendPoints.isNotEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "📈 Monthly Expense Trend",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NagadMainText
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        TrendLineChartComposable(points = trendPoints, lineColor = NagadDanger)
                    }
                }
            }
        }
    }

    // Add Expense Dialog
    if (showAddExpenseDialog) {
        val categories = listOf(
            "Office Expenses", "Transport", "Marketing",
            "Investment", "Emergency", "Business Expenses", "Miscellaneous"
        )
        var descInput by remember { mutableStateOf("") }
        var categoryInput by remember { mutableStateOf(categories.first()) }
        var amountInput by remember { mutableStateOf("") }
        var dateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        var catDropdownOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddExpenseDialog = false },
            title = { Text("Log Operational Expense", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Description *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    ExposedDropdownMenuBox(
                        expanded = catDropdownOpen,
                        onExpandedChange = { catDropdownOpen = !catDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = categoryInput,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catDropdownOpen) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = catDropdownOpen,
                            onDismissRequest = { catDropdownOpen = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        categoryInput = cat
                                        catDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount (৳) *") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = dateInput,
                        onValueChange = { dateInput = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toIntOrNull() ?: 0
                        if (descInput.isNotBlank() && amt > 0) {
                            viewModel.addExpense(descInput, categoryInput, amt, dateInput)
                            showAddExpenseDialog = false
                        }
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Expense", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddExpenseDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (expenseToDelete != null) {
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text("Delete Expense?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete \"${expenseToDelete?.description}\" (${CurrencyFormatter.formatCurrency(expenseToDelete?.amount ?: 0)})?", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        expenseToDelete?.id?.let { viewModel.deleteExpense(it) }
                        expenseToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Edit Expense Dialog
    if (expenseToEdit != null) {
        val exp = expenseToEdit!!
        var eDesc by remember { mutableStateOf(exp.description) }
        var eCat by remember { mutableStateOf(exp.category) }
        var eAmt by remember { mutableStateOf(exp.amount.toString()) }
        var eDate by remember { mutableStateOf(exp.date) }

        AlertDialog(
            onDismissRequest = { expenseToEdit = null },
            title = { Text("Edit Expense #${exp.id}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = eDesc,
                        onValueChange = { eDesc = it },
                        label = { Text("Description") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eCat,
                        onValueChange = { eCat = it },
                        label = { Text("Category") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eAmt,
                        onValueChange = { eAmt = it },
                        label = { Text("Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val a = eAmt.toIntOrNull() ?: exp.amount
                        viewModel.updateExpense(exp.copy(description = eDesc.trim(), category = eCat.trim(), amount = a, date = eDate.trim()))
                        expenseToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }
}
