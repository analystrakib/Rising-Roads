package com.example.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.local.SessionManager
import com.example.data.model.Deposit
import com.example.data.model.FinancialKpi
import com.example.data.model.Member
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithStats
import com.example.data.model.PaymentRequest
import com.example.util.CurrencyFormatter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReceiptGenerator {

    const val UNIFIED_BOTTOM_FOOTER = "Authorized by Rakib"

    @Volatile
    private var cachedRawLogo: Bitmap? = null

    private fun fmtAmount(amount: Int): String =
        CurrencyFormatter.formatNumber(amount)

    private fun fmtSignedTaka(amount: Int): String =
        if (amount >= 0) "৳${fmtAmount(amount)}" else "-৳${fmtAmount(-amount)}"

    private fun resolveAdminDisplayName(context: Context, adminName: String): String {
        val raw = adminName.trim().ifBlank {
            runCatching { SessionManager(context).username }.getOrDefault("Rakib")
        }
        return if (raw.isBlank()) "Admin" else raw
    }

    private fun getOrDecodeOfficialLogo(context: Context): Bitmap? {
        cachedRawLogo?.let { if (!it.isRecycled && it.width > 1) return it }
        val opts = BitmapFactory.Options().apply {
            inScaled = false
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.logo, opts)
        }.getOrNull() ?: runCatching {
            context.resources.openRawResource(R.drawable.logo).use { stream ->
                BitmapFactory.decodeStream(stream, null, opts)
            }
        }.getOrNull()

        if (decoded != null && decoded.width > 1 && decoded.height > 1) {
            cachedRawLogo = decoded
        }
        return decoded
    }

    private fun buildCircularLogoBitmap(source: Bitmap, diameterPx: Int): Bitmap {
        val size = diameterPx.coerceAtLeast(64)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val offscreenCanvas = Canvas(output)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = 255
        }
        val r = size / 2f

        // 1. Solid opaque circle mask
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        offscreenCanvas.drawCircle(r, r, r, p)

        // 2. Draw logo inside circle using SRC_IN at 100% opacity
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        val srcRect = Rect(0, 0, source.width, source.height)
        val dstRect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        offscreenCanvas.drawBitmap(source, srcRect, dstRect, p)
        p.xfermode = null

        return output
    }

    /**
     * Draws the official RRK logo neatly, sharply, and at 100% opacity inside a circular badge
     * in the top header of every PDF and PNG receipt (without relying on PdfDocument clipPath).
     */
    private fun drawCompactRrkLogo(
        canvas: Canvas,
        context: Context,
        paint: Paint,
        centerX: Float,
        centerY: Float,
        radius: Float
    ) {
        paint.shader = null
        paint.alpha = 255

        // Subtle outer halo ring
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#38FFFFFF")
        canvas.drawCircle(centerX, centerY, radius + 2.2f, paint)

        // Solid crisp white circular backing so logo colors never fade or bleed
        paint.color = Color.parseColor("#ECFDF5")
        paint.alpha = 255
        canvas.drawCircle(centerX, centerY, radius, paint)

        val logoBitmap = getOrDecodeOfficialLogo(context)
        if (logoBitmap != null && logoBitmap.width > 1 && logoBitmap.height > 1) {
            val renderPx = (radius * 6f).toInt().coerceIn(96, 360)
            val circularLogo = buildCircularLogoBitmap(logoBitmap, renderPx)
            val destRect = RectF(
                centerX - radius,
                centerY - radius,
                centerX + radius,
                centerY + radius
            )
            val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                isFilterBitmap = true
                isDither = true
                alpha = 255
            }
            canvas.drawBitmap(circularLogo, null, destRect, bmpPaint)
        } else {
            // Crisp vector emblem fallback (shield + rising road + leaves + RRK)
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#EBF9F1")
            paint.alpha = 255
            canvas.drawCircle(centerX, centerY, radius, paint)

            // Orange road motif on left
            paint.color = Color.parseColor("#D97706")
            canvas.drawArc(
                RectF(centerX - radius * 0.62f, centerY - radius * 0.52f, centerX + radius * 0.05f, centerY + radius * 0.18f),
                135f,
                190f,
                true,
                paint
            )
            // Green leaf motif on right
            paint.color = Color.parseColor("#059669")
            canvas.drawOval(
                RectF(centerX + radius * 0.02f, centerY - radius * 0.50f, centerX + radius * 0.55f, centerY + radius * 0.12f),
                paint
            )
            // Dark navy RRK wordmark at bottom
            paint.color = Color.parseColor("#0F2942")
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = radius * 0.54f
            canvas.drawText("RRK", centerX, centerY + radius * 0.58f, paint)
        }

        // Crisp white ring border at 100% opacity
        paint.style = Paint.Style.STROKE
        paint.color = Color.WHITE
        paint.alpha = 255
        paint.strokeWidth = (radius * 0.09f).coerceAtLeast(1.4f)
        canvas.drawCircle(centerX, centerY, radius, paint)
        paint.style = Paint.Style.FILL
        paint.alpha = 255
    }

    /**
     * Draws a clean, compact signature block ("Generated by: [Admin]") when generated by an Admin,
     * or a tidy "System Verified Receipt" pill badge when generated by a regular Member (PDF scale).
     */
    private fun drawCompactSignatureAreaPdf(
        canvas: Canvas,
        paint: Paint,
        sigY: Float,
        isAdmin: Boolean,
        adminDisplayName: String,
        leftInfoText: String = ""
    ) {
        paint.shader = null
        if (leftInfoText.isNotBlank()) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textSize = 9.5f
            paint.color = Color.parseColor("#64748B")
            canvas.drawText(leftInfoText, 55f, sigY + 12f, paint)
        }

        if (isAdmin) {
            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#064E3B")
            paint.strokeWidth = 1.3f
            canvas.drawLine(365f, sigY, 540f, sigY, paint)

            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 10.5f
            paint.color = Color.parseColor("#0F172A")
            canvas.drawText("Generated by: $adminDisplayName", 452.5f, sigY + 16f, paint)
        } else {
            val badgeRect = RectF(365f, sigY - 12f, 540f, sigY + 18f)
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#ECFDF5")
            canvas.drawRoundRect(badgeRect, 15f, 15f, paint)

            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#6EE7B7")
            paint.strokeWidth = 1.2f
            canvas.drawRoundRect(badgeRect, 15f, 15f, paint)

            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 10f
            paint.color = Color.parseColor("#065F46")
            canvas.drawText("System Verified Receipt", badgeRect.centerX(), sigY + 7f, paint)
        }
    }

    /**
     * Draws a clean, compact signature block ("Generated by: [Admin]") when generated by an Admin,
     * or a tidy "System Verified Receipt" pill badge when generated by a regular Member (High-Res PNG scale).
     */
    private fun drawCompactSignatureAreaImage(
        canvas: Canvas,
        paint: Paint,
        width: Int,
        sigY: Float,
        isAdmin: Boolean,
        adminDisplayName: String,
        leftInfoText: String = ""
    ) {
        paint.shader = null
        if (leftInfoText.isNotBlank()) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textSize = 20f
            paint.color = Color.parseColor("#64748B")
            canvas.drawText(leftInfoText, 88f, sigY + 24f, paint)
        }

        if (isAdmin) {
            val lineLeft = width - 460f
            val lineRight = width - 88f
            val centerX = (lineLeft + lineRight) / 2f
            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#064E3B")
            paint.strokeWidth = 2.5f
            canvas.drawLine(lineLeft, sigY, lineRight, sigY, paint)

            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 22f
            paint.color = Color.parseColor("#111827")
            canvas.drawText("Generated by: $adminDisplayName", centerX, sigY + 34f, paint)
        } else {
            val badgeRect = RectF(width - 450f, sigY - 22f, width - 88f, sigY + 38f)
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#ECFDF5")
            canvas.drawRoundRect(badgeRect, 30f, 30f, paint)

            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#6EE7B7")
            paint.strokeWidth = 2.5f
            canvas.drawRoundRect(badgeRect, 30f, 30f, paint)

            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 21f
            paint.color = Color.parseColor("#065F46")
            canvas.drawText("System Verified Receipt", badgeRect.centerX(), sigY + 16f, paint)
        }
    }

    private fun drawUnifiedBottomFooterPdf(canvas: Canvas, paint: Paint, y: Float = 794f) {
        paint.shader = null
        // Subtle thin top border (1px solid #E5E7EB) with clean padding above footer text
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#E5E7EB")
        paint.strokeWidth = 1f
        val borderY = y - 14f
        canvas.drawLine(55f, borderY, 540f, borderY, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 9.5f
        paint.color = Color.parseColor("#6B7280")
        canvas.drawText(UNIFIED_BOTTOM_FOOTER, 297.5f, y, paint)
    }

    private fun drawUnifiedBottomFooterImage(canvas: Canvas, paint: Paint, width: Int, y: Float) {
        paint.shader = null
        // Subtle thin top border (1px solid #E5E7EB) with clean padding above footer text
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#E5E7EB")
        paint.strokeWidth = 1.5f
        val borderY = y - 28f
        canvas.drawLine(88f, borderY, width - 88f, borderY, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 19f
        paint.color = Color.parseColor("#6B7280")
        canvas.drawText(UNIFIED_BOTTOM_FOOTER, width / 2f, y, paint)
    }

    /**
     * Generates an individual deposit payment receipt PDF.
     */
    fun generateDepositReceipt(
        context: Context,
        deposit: Deposit,
        member: Member,
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 (72 dpi)
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rNo = "RRK-${deposit.id.toString().padStart(4, '0')}"
        val total = deposit.amount + deposit.fine
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())

        // Background
        canvas.drawColor(Color.WHITE)

        // Outer border
        paint.color = Color.parseColor("#059669")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(30f, 30f, 565f, 812f), 16f, 16f, paint)

        // Top Header Green Gradient
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            30f, 30f, 565f, 180f,
            intArrayOf(Color.parseColor("#064E3B"), Color.parseColor("#059669"), Color.parseColor("#10B981")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(30f, 30f, 565f, 180f), 16f, 16f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 74f, centerY = 82f, radius = 22f)

        // Header Text
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 21f
        canvas.drawText("Rising Roads Of Kharkharian", 297.5f, 75f, paint)

        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Joint Capital Investment Platform", 297.5f, 98f, paint)
        canvas.drawText("${member.address} · risingroads@gmail.com", 297.5f, 115f, paint)

        // Receipt Number Badge
        paint.color = Color.parseColor("#10FFFFFF")
        canvas.drawRoundRect(RectF(200f, 130f, 395f, 160f), 12f, 12f, paint)
        paint.color = Color.WHITE
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(RectF(200f, 130f, 395f, 160f), 12f, 12f, paint)

        paint.style = Paint.Style.FILL
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = 13f
        canvas.drawText("RECEIPT: $rNo", 297.5f, 150f, paint)

        // Body Details
        var y = 220f
        fun drawRow(label: String, value: String, isBold: Boolean = false, isDanger: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#64748B")
            paint.textSize = 13f
            canvas.drawText(label, 60f, y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
            paint.color = if (isDanger) Color.parseColor("#DC2626") else Color.parseColor("#0F172A")
            canvas.drawText(value, 535f, y, paint)

            // Divider line
            paint.color = Color.parseColor("#F1F5F9")
            paint.strokeWidth = 1f
            canvas.drawLine(60f, y + 10f, 535f, y + 10f, paint)

            y += 38f
        }

        drawRow("Member Name", member.name, isBold = true)
        drawRow("Member ID", "RRK-${member.id.toString().padStart(3, '0')}")
        drawRow("Contact Phone", member.phone)
        drawRow("Address", member.address)
        drawRow("Payment Month", deposit.month)
        drawRow("Payment Date", deposit.paymentDate)
        drawRow("Monthly Contribution", "৳${fmtAmount(deposit.amount)}")

        if (deposit.fine > 0) {
            drawRow("Late Fine (after 15th)", "৳${fmtAmount(deposit.fine)}", isBold = true, isDanger = true)
        }

        // Total Paid Box
        y += 10f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#ECFDF5")
        canvas.drawRoundRect(RectF(60f, y, 535f, y + 55f), 12f, 12f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#6EE7B7")
        paint.strokeWidth = 1.5f
        canvas.drawRoundRect(RectF(60f, y, 535f, y + 55f), 12f, 12f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        paint.color = Color.parseColor("#065F46")
        canvas.drawText("Total Collected", 80f, y + 35f, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 20f
        paint.color = Color.parseColor("#059669")
        canvas.drawText("৳${fmtAmount(total)}", 515f, y + 36f, paint)

        // Compact Signature / System Verified Badge & Single Bottom Footer
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)
        drawCompactSignatureAreaPdf(
            canvas = canvas,
            paint = paint,
            sigY = 708f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Issued: $nowFormatted"
        )
        drawUnifiedBottomFooterPdf(canvas, paint, y = 788f)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, "RRK_Receipt_${rNo}_${deposit.month.replace(" ", "_")}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        savePdfToDownloads(context, outputFile, outputFile.name)

        return outputFile
    }

    /**
     * Generates a crisp, high-resolution PNG image of an individual member's personal deposit receipt,
     * saves a copy to the device Pictures/RisingRoads gallery (Android 10+) and returns the cached File
     * ready for sharing or saving.
     */
    fun generateDepositReceiptImage(
        context: Context,
        deposit: Deposit,
        member: Member,
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): Pair<File, Boolean> {
        val width = 1080
        val height = 1390
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val rNo = "RRK-${deposit.id.toString().padStart(4, '0')}"
        val total = deposit.amount + deposit.fine
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)

        // Canvas background
        canvas.drawColor(Color.WHITE)

        // Outer Card Border
        paint.color = Color.parseColor("#059669")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        canvas.drawRoundRect(RectF(36f, 36f, width - 36f, height - 36f), 28f, 28f, paint)

        // Header Gradient Banner
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            36f, 36f, width - 36f, 300f,
            intArrayOf(Color.parseColor("#064E3B"), Color.parseColor("#059669"), Color.parseColor("#10B981")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(36f, 36f, width - 36f, 300f), 28f, 28f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 114f, centerY = 122f, radius = 40f)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 38f
        canvas.drawText("Rising Roads Of Kharkharian", width / 2f + 22f, 114f, paint)

        paint.textSize = 21f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawText("Joint Capital Investment Platform · Official Payment Receipt", width / 2f + 22f, 156f, paint)

        // Receipt Pill Badge
        paint.color = Color.parseColor("#26FFFFFF")
        canvas.drawRoundRect(RectF(330f, 192f, 750f, 256f), 22f, 22f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.WHITE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(RectF(330f, 192f, 750f, 256f), 22f, 22f, paint)

        paint.style = Paint.Style.FILL
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = 26f
        canvas.drawText("RECEIPT: $rNo", width / 2f, 234f, paint)

        // Detail Rows
        var y = 376f
        fun drawImgRow(label: String, value: String, isBold: Boolean = false, isDanger: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#475569")
            paint.textSize = 26f
            canvas.drawText(label, 88f, y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
            paint.color = if (isDanger) Color.parseColor("#DC2626") else Color.parseColor("#111827")
            canvas.drawText(value, width - 88f, y, paint)

            paint.color = Color.parseColor("#E5E7EB")
            paint.strokeWidth = 2f
            canvas.drawLine(88f, y + 20f, width - 88f, y + 20f, paint)
            y += 72f
        }

        drawImgRow("Member Name", member.name, isBold = true)
        drawImgRow("Member ID", "RRK-${member.id.toString().padStart(3, '0')}")
        drawImgRow("Contact Phone", member.phone)
        drawImgRow("Payment Month", deposit.month, isBold = true)
        drawImgRow("Payment Date", deposit.paymentDate)
        drawImgRow("Payment Mode", deposit.paymentMode)
        drawImgRow("Monthly Contribution", "৳${fmtAmount(deposit.amount)}", isBold = true)
        if (deposit.fine > 0) {
            drawImgRow("Late Fine (after 15th)", "৳${fmtAmount(deposit.fine)}", isBold = true, isDanger = true)
        }

        // Total Collected Highlight Card
        y += 18f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#ECFDF5")
        canvas.drawRoundRect(RectF(88f, y, width - 88f, y + 104f), 20f, 20f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#6EE7B7")
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(88f, y, width - 88f, y + 104f), 20f, 20f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 30f
        paint.color = Color.parseColor("#065F46")
        canvas.drawText("Total Collected", 122f, y + 63f, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 38f
        paint.color = Color.parseColor("#059669")
        canvas.drawText("৳${fmtAmount(total)}", width - 122f, y + 66f, paint)

        // Compact Signature / System Verified Badge & Single Bottom Footer
        drawCompactSignatureAreaImage(
            canvas = canvas,
            paint = paint,
            width = width,
            sigY = 1210f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Issued: $nowFormatted"
        )
        drawUnifiedBottomFooterImage(canvas, paint, width = width, y = 1322f)

        val fileName = "Receipt_${rNo}_${deposit.month.replace(" ", "_")}.png"
        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, fileName)
        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        // Save directly to device Pictures/RisingRoads via MediaStore (Android 10+ requires zero storage permissions)
        val savedToGallery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/RisingRoads")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    true
                } else {
                    false
                }
            }.getOrDefault(false)
        } else {
            false
        }

        bitmap.recycle()
        return Pair(outputFile, savedToGallery)
    }

    /**
     * Generates a member summary receipt PDF showing all months & totals.
     */
    fun generateMemberSummaryReceipt(
        context: Context,
        stats: MemberWithStats,
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val member = stats.member
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())

        canvas.drawColor(Color.WHITE)

        // Border
        paint.color = Color.parseColor("#1E3A8A")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f
        canvas.drawRoundRect(RectF(30f, 30f, 565f, 812f), 14f, 14f, paint)

        // Header
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            30f, 30f, 565f, 160f,
            intArrayOf(Color.parseColor("#0F172A"), Color.parseColor("#1E3A8A")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(30f, 30f, 565f, 160f), 14f, 14f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 72f, centerY = 92f, radius = 21f)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f
        canvas.drawText("Rising Roads Of Kharkharian", 297.5f, 75f, paint)

        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Member Total Summary Statement", 297.5f, 98f, paint)
        canvas.drawText("Kharkharian, Bangladesh · Member ID: RRK-${member.id.toString().padStart(3, '0')}", 297.5f, 120f, paint)

        var y = 195f
        fun drawRow(label: String, value: String, isBold: Boolean = false, colorHex: String = "#0F172A") {
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#64748B")
            paint.textSize = 12f
            canvas.drawText(label, 60f, y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
            paint.color = Color.parseColor(colorHex)
            canvas.drawText(value, 535f, y, paint)

            paint.color = Color.parseColor("#F1F5F9")
            paint.strokeWidth = 1f
            canvas.drawLine(60f, y + 8f, 535f, y + 8f, paint)
            y += 32f
        }

        drawRow("Member Name", member.name, isBold = true)
        drawRow("Phone", member.phone)
        drawRow("Address", member.address)
        drawRow("Join Date", member.joinDate)
        drawRow(
            "Membership Status",
            stats.status.name,
            isBold = true,
            colorHex = if (stats.status.name == "ACTIVE") "#059669" else if (stats.status.name == "WARNING") "#D97706" else "#DC2626"
        )
        drawRow("Total Paid Months", "${stats.paidMonths.size} months")
        drawRow(
            "Pending Months Count",
            "${stats.pendingMonths.size} months",
            isBold = stats.pendingMonths.isNotEmpty(),
            colorHex = if (stats.pendingMonths.isNotEmpty()) "#DC2626" else "#059669"
        )
        drawRow("Consecutive Due", "${stats.consecutiveUnpaidMonths} months")

        // 3-Box Stats
        y += 10f
        val boxWidth = 150f
        val spacing = 12f
        val startX = 60f

        fun drawStatCard(x: Float, label: String, value: String, bgHex: String, textHex: String) {
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor(bgHex)
            canvas.drawRoundRect(RectF(x, y, x + boxWidth, y + 60f), 8f, 8f, paint)

            paint.textAlign = Paint.Align.CENTER
            paint.color = Color.parseColor(textHex)
            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(label.uppercase(), x + boxWidth / 2, y + 22f, paint)

            paint.textSize = 14f
            canvas.drawText(value, x + boxWidth / 2, y + 46f, paint)
        }

        drawStatCard(startX, "Total Contribution", "৳${fmtAmount(stats.totalPaidContribution)}", "#ECFDF5", "#059669")
        drawStatCard(startX + boxWidth + spacing, "Fine Paid", "৳${fmtAmount(stats.totalFinePaid)}", "#FFFBEB", "#D97706")
        drawStatCard(
            startX + (boxWidth + spacing) * 2,
            "Current Due",
            "৳${fmtAmount(stats.totalDue)}",
            if (stats.totalDue > 0) "#FEF2F2" else "#ECFDF5",
            if (stats.totalDue > 0) "#DC2626" else "#059669"
        )

        y += 85f
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 12f
        paint.color = Color.parseColor("#0F172A")
        canvas.drawText("Payment Months Record:", 60f, y, paint)

        y += 20f
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        val paidText = if (stats.paidMonths.isEmpty()) "None" else stats.paidMonths.joinToString(", ")
        canvas.drawText("Paid: $paidText", 60f, y, paint)

        y += 18f
        val pendingText = if (stats.pendingMonths.isEmpty()) "All up-to-date ✓" else stats.pendingMonths.joinToString(", ")
        paint.color = if (stats.pendingMonths.isEmpty()) Color.parseColor("#059669") else Color.parseColor("#DC2626")
        canvas.drawText("Pending: $pendingText", 60f, y, paint)

        // Compact Signature / Digital Badge & Single Bottom Footer
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)
        drawCompactSignatureAreaPdf(
            canvas = canvas,
            paint = paint,
            sigY = 706f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Issued: $nowFormatted"
        )
        drawUnifiedBottomFooterPdf(canvas, paint, y = 788f)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val memberCode = "RRK-${member.id.toString().padStart(3, '0')}"
        val outputFile = File(outputDir, "RRK_Receipt_${memberCode}_${member.name.replace(" ", "_")}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        savePdfToDownloads(context, outputFile, outputFile.name)

        return outputFile
    }

    /**
     * Generates an All-Members Combined Deposit Summary PDF containing a complete table of all members
     * (Name, ID, Monthly Status, Total Deposited, Total Fines Paid, Remaining Dues) + grand totals.
     */
    fun generateAllMembersSummaryPdf(
        context: Context,
        membersWithStats: List<MemberWithStats>,
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): File {
        val document = PdfDocument()
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())
        val currentMonthLabel = SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val sortedMembers = membersWithStats.sortedBy { it.member.id }
        val grandDeposits = sortedMembers.sumOf { it.totalPaidContribution }
        val grandFines = sortedMembers.sumOf { it.totalFinePaid }
        val grandDues = sortedMembers.sumOf { it.totalDue }
        val activeCount = sortedMembers.count { it.status == MemberStatus.ACTIVE }
        val warningCount = sortedMembers.count { it.status == MemberStatus.WARNING }
        val alertCount = sortedMembers.count { it.status == MemberStatus.RED_ALERT }

        val rowsPerPage = 16
        val chunks = if (sortedMembers.isEmpty()) listOf(emptyList()) else sortedMembers.chunked(rowsPerPage)

        chunks.forEachIndexed { pageIndex, pageMembers ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            canvas.drawColor(Color.WHITE)

            // Outer Border
            paint.color = Color.parseColor("#059669")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f
            canvas.drawRoundRect(RectF(25f, 25f, 570f, 817f), 12f, 12f, paint)

            // Header Banner
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(
                25f, 25f, 570f, 125f,
                intArrayOf(Color.parseColor("#064E3B"), Color.parseColor("#059669")),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(RectF(25f, 25f, 570f, 125f), 12f, 12f, paint)
            paint.shader = null

            // Compact Official RRK Logo in Header
            drawCompactRrkLogo(canvas, context, paint, centerX = 64f, centerY = 75f, radius = 19f)

            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 18f
            canvas.drawText("Rising Roads Of Kharkharian", 297.5f, 58f, paint)

            paint.textSize = 12f
            canvas.drawText("All-Members Combined Deposit Summary", 297.5f, 80f, paint)

            paint.textSize = 9.8f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#D1FAE5")
            canvas.drawText(
                "${sortedMembers.size} Members ($activeCount Active · $warningCount Warning · $alertCount Red Alert) · Cycle: May 2025 – $currentMonthLabel",
                297.5f,
                104f,
                paint
            )

            // KPI Summary Strip
            var y = 142f
            val pillW = 165f
            val pillGap = 10f
            fun drawTopPill(idx: Int, label: String, valStr: String, bgHex: String, textHex: String) {
                val x = 40f + idx * (pillW + pillGap)
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor(bgHex)
                canvas.drawRoundRect(RectF(x, y, x + pillW, y + 46f), 8f, 8f, paint)
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#E2E8F0")
                paint.strokeWidth = 1f
                canvas.drawRoundRect(RectF(x, y, x + pillW, y + 46f), 8f, 8f, paint)

                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.LEFT
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 8.5f
                paint.color = Color.parseColor("#475569")
                canvas.drawText(label, x + 10f, y + 17f, paint)

                paint.textSize = 13.5f
                paint.color = Color.parseColor(textHex)
                canvas.drawText(valStr, x + 10f, y + 36f, paint)
            }

            drawTopPill(0, "GRAND DEPOSITED", "৳${fmtAmount(grandDeposits)}", "#ECFDF5", "#059669")
            drawTopPill(1, "TOTAL FINES PAID", "৳${fmtAmount(grandFines)}", "#FFFBEB", "#D97706")
            drawTopPill(
                2,
                "REMAINING DUES",
                "৳${fmtAmount(grandDues)}",
                if (grandDues > 0) "#FEF2F2" else "#ECFDF5",
                if (grandDues > 0) "#DC2626" else "#059669"
            )

            // Table Header
            y = 204f
            val tableLeft = 36f
            val tableRight = 559f
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#064E3B")
            canvas.drawRoundRect(RectF(tableLeft, y, tableRight, y + 28f), 6f, 6f, paint)

            val colIdX = 44f
            val colNameX = 98f
            val colStatusX = 262f
            val colDepRightX = 398f
            val colFineRightX = 475f
            val colDueRightX = 551f

            paint.color = Color.WHITE
            paint.textSize = 9.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("ID", colIdX, y + 18f, paint)
            canvas.drawText("MEMBER NAME", colNameX, y + 18f, paint)
            canvas.drawText("MONTHLY STATUS", colStatusX, y + 18f, paint)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("DEPOSITED", colDepRightX, y + 18f, paint)
            canvas.drawText("FINES", colFineRightX, y + 18f, paint)
            canvas.drawText("REM. DUES", colDueRightX, y + 18f, paint)

            y += 30f
            val rowH = 29f

            pageMembers.forEachIndexed { idx, stats ->
                val bg = if (idx % 2 == 0) Color.WHITE else Color.parseColor("#F8FAFC")
                paint.style = Paint.Style.FILL
                paint.color = bg
                canvas.drawRect(RectF(tableLeft, y, tableRight, y + rowH), paint)

                val code = "RRK-${stats.member.id.toString().padStart(3, '0')}"
                val statusLabel = when (stats.status) {
                    MemberStatus.ACTIVE -> "ACTIVE (${stats.paidMonths.size}m)"
                    MemberStatus.WARNING -> "WARNING (${stats.consecutiveUnpaidMonths} due)"
                    MemberStatus.RED_ALERT -> "RED ALERT (${stats.consecutiveUnpaidMonths} due)"
                }
                val statusColor = when (stats.status) {
                    MemberStatus.ACTIVE -> Color.parseColor("#059669")
                    MemberStatus.WARNING -> Color.parseColor("#D97706")
                    MemberStatus.RED_ALERT -> Color.parseColor("#DC2626")
                }

                paint.textAlign = Paint.Align.LEFT
                paint.textSize = 9.5f
                paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                paint.color = Color.parseColor("#475569")
                canvas.drawText(code, colIdX, y + 19f, paint)

                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.color = Color.parseColor("#111827")
                val safeName = if (stats.member.name.length > 24) stats.member.name.take(22) + "…" else stats.member.name
                canvas.drawText(safeName, colNameX, y + 19f, paint)

                paint.textSize = 9f
                paint.color = statusColor
                canvas.drawText(statusLabel, colStatusX, y + 19f, paint)

                paint.textAlign = Paint.Align.RIGHT
                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.color = Color.parseColor("#059669")
                canvas.drawText("৳${fmtAmount(stats.totalPaidContribution)}", colDepRightX, y + 19f, paint)

                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                paint.color = Color.parseColor("#374151")
                canvas.drawText("৳${fmtAmount(stats.totalFinePaid)}", colFineRightX, y + 19f, paint)

                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.color = if (stats.totalDue > 0) Color.parseColor("#DC2626") else Color.parseColor("#059669")
                canvas.drawText("৳${fmtAmount(stats.totalDue)}", colDueRightX, y + 19f, paint)

                paint.color = Color.parseColor("#E2E8F0")
                paint.strokeWidth = 0.8f
                canvas.drawLine(tableLeft, y + rowH, tableRight, y + rowH, paint)
                y += rowH
            }

            // Grand Totals Row on Last Page
            if (pageIndex == chunks.lastIndex) {
                y += 4f
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#ECFDF5")
                canvas.drawRoundRect(RectF(tableLeft, y, tableRight, y + 34f), 6f, 6f, paint)
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#059669")
                paint.strokeWidth = 1.5f
                canvas.drawRoundRect(RectF(tableLeft, y, tableRight, y + 34f), 6f, 6f, paint)

                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.LEFT
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 10.5f
                paint.color = Color.parseColor("#064E3B")
                canvas.drawText("GRAND TOTALS (${sortedMembers.size} MEMBERS)", colIdX, y + 22f, paint)

                paint.textAlign = Paint.Align.RIGHT
                paint.color = Color.parseColor("#059669")
                canvas.drawText("৳${fmtAmount(grandDeposits)}", colDepRightX, y + 22f, paint)

                paint.color = Color.parseColor("#B45309")
                canvas.drawText("৳${fmtAmount(grandFines)}", colFineRightX, y + 22f, paint)

                paint.color = if (grandDues > 0) Color.parseColor("#DC2626") else Color.parseColor("#059669")
                canvas.drawText("৳${fmtAmount(grandDues)}", colDueRightX, y + 22f, paint)
            }

            // Compact Signature / Digital Badge & Single Bottom Footer
            drawCompactSignatureAreaPdf(
                canvas = canvas,
                paint = paint,
                sigY = 748f,
                isAdmin = isAdmin,
                adminDisplayName = resolvedAdmin,
                leftInfoText = "Page ${pageIndex + 1} of ${chunks.size} · $nowFormatted"
            )
            drawUnifiedBottomFooterPdf(canvas, paint, y = 798f)

            document.finishPage(page)
        }

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, "RRK_All_Members_Summary.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        savePdfToDownloads(context, outputFile, outputFile.name)

        return outputFile
    }

    /**
     * Generates a 1-page complete Overall Fund Financial Summary PDF showing Total Deposits,
     * Total Fines, Active & Closed Investments, Realized Profit & Loss, Bank Balance,
     * Cash in Hand, and Available Liquid Capital.
     */
    fun generateFinancialSummaryReport(
        context: Context,
        kpi: FinancialKpi,
        membersCount: Int,
        expensesCount: Int,
        investmentsCount: Int,
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())
        val currentMonthLabel = SimpleDateFormat("MMM yyyy", Locale.US).format(Date())

        canvas.drawColor(Color.WHITE)

        // Border
        paint.color = Color.parseColor("#064E3B")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f
        canvas.drawRoundRect(RectF(25f, 25f, 570f, 817f), 12f, 12f, paint)

        // Header
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            25f, 25f, 570f, 128f,
            intArrayOf(Color.parseColor("#064E3B"), Color.parseColor("#059669")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(25f, 25f, 570f, 128f), 12f, 12f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 64f, centerY = 76f, radius = 19f)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 17.5f
        canvas.drawText("Rising Roads Of Kharkharian - Fund Financial Summary", 308f, 62f, paint)

        paint.textSize = 10.8f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Official Reconciled Fund Statement · $membersCount Active Members · $investmentsCount Ventures", 308f, 86f, paint)
        canvas.drawText("Kharkharian, Bangladesh · Period: May 2025 – $currentMonthLabel", 308f, 106f, paint)

        // 9 KPI Grid
        var y = 152f
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 11.5f
        paint.color = Color.parseColor("#064E3B")
        canvas.drawText("OVERALL FUND FINANCIAL SNAPSHOT", 40f, y, paint)

        y += 14f
        val cardW = 165f
        val cardH = 48f
        val gap = 10f

        val pnlStr = fmtSignedTaka(kpi.realizedBusinessPnl)

        val kpiItems = listOf(
            Triple("Total Deposits", "৳${fmtAmount(kpi.totalDeposits)}", "#ECFDF5"),
            Triple("Total Fines", "৳${fmtAmount(kpi.fineCollection)}", "#FFFBEB"),
            Triple("Total Expenses", "৳${fmtAmount(kpi.totalExpenses)}", "#FEF2F2"),
            Triple("Active Investments", "৳${fmtAmount(kpi.totalRunningInvestments)}", "#EFF6FF"),
            Triple("Closed Investments", "৳${fmtAmount(kpi.totalClosedInvestments)}", "#F1F5F9"),
            Triple("Realized P&L", pnlStr, if (kpi.realizedBusinessPnl >= 0) "#ECFDF5" else "#FEF2F2"),
            Triple("Bank Balance", "৳${fmtAmount(kpi.bankBalance)}", "#EFF6FF"),
            Triple("Cash in Hand", "৳${fmtAmount(kpi.cashInHand)}", "#ECFDF5"),
            Triple("Available Liquid", "৳${fmtAmount(kpi.mainLiquidCapital)}", "#D1FAE5")
        )

        for (row in 0 until 3) {
            for (col in 0 until 3) {
                val idx = row * 3 + col
                val item = kpiItems[idx]
                val x = 40f + col * (cardW + gap)
                val curY = y + row * (cardH + gap)

                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor(item.third)
                canvas.drawRoundRect(RectF(x, curY, x + cardW, curY + cardH), 6f, 6f, paint)

                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#CBD5E1")
                paint.strokeWidth = 0.8f
                canvas.drawRoundRect(RectF(x, curY, x + cardW, curY + cardH), 6f, 6f, paint)

                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.LEFT
                paint.textSize = 8.5f
                paint.color = Color.parseColor("#475569")
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(item.first.uppercase(), x + 10f, curY + 17f, paint)

                paint.textSize = 13.5f
                paint.color = Color.parseColor("#0F172A")
                canvas.drawText(item.second, x + 10f, curY + 37f, paint)
            }
        }

        // Reconciled Ledger Breakdown Box
        y += 3 * (cardH + gap) + 20f
        paint.color = Color.parseColor("#064E3B")
        paint.textSize = 11.5f
        canvas.drawText("RECONCILED HEAD OFFICE LEDGER BREAKDOWN", 40f, y, paint)

        y += 10f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#F8FAFC")
        canvas.drawRoundRect(RectF(40f, y, 555f, y + 322f), 8f, 8f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawRoundRect(RectF(40f, y, 555f, y + 322f), 8f, 8f, paint)

        var bY = y + 22f
        fun drawLedgerRow(lbl: String, valStr: String, isPlus: Boolean? = null, isBold: Boolean = false, isFinal: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = 10.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold || isFinal) Typeface.BOLD else Typeface.NORMAL)
            paint.color = if (isFinal) Color.parseColor("#064E3B") else Color.parseColor("#334155")
            canvas.drawText(lbl, 55f, bY, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.color = when (isPlus) {
                true -> Color.parseColor("#059669")
                false -> Color.parseColor("#DC2626")
                else -> Color.parseColor("#0F172A")
            }
            canvas.drawText(valStr, 540f, bY, paint)

            paint.color = Color.parseColor("#E2E8F0")
            paint.strokeWidth = 0.8f
            canvas.drawLine(55f, bY + 6f, 540f, bY + 6f, paint)

            bY += 24f
        }

        val grossPnlStr = fmtSignedTaka(kpi.grossBusinessPnl)
        drawLedgerRow("Total Member Deposits (179 qty · $membersCount Members)", "৳${fmtAmount(kpi.totalDeposits)}", true)
        drawLedgerRow("Deposit Fine (17 qty · Cutoff: 15th)", "৳${fmtAmount(kpi.fineCollection)}", true)
        drawLedgerRow("Gross Business P/L (Profit ৳6,100 − Loss ৳6,700)", grossPnlStr, kpi.grossBusinessPnl >= 0)
        drawLedgerRow("Exited Members' Loss Share Retained (3 × ৳14)", "+৳${fmtAmount(kpi.exitedMembersLossRecovery)}", true)
        drawLedgerRow("Net Business P/L ($grossPnlStr + ৳${fmtAmount(kpi.exitedMembersLossRecovery)})", pnlStr, kpi.realizedBusinessPnl >= 0, isBold = true)
        drawLedgerRow("Total Amount (Inflow Total)", "৳${fmtAmount(kpi.totalCollection)}", true, isBold = true)
        drawLedgerRow("Operational Expenses ($expensesCount records) | Running: ৳${fmtAmount(kpi.totalRunningInvestments)}", "−৳${fmtAmount(kpi.costAndInvest)}", false)
        drawLedgerRow("Closed Investments (Settled Historical Volume)", "৳${fmtAmount(kpi.totalClosedInvestments)}", null)
        drawLedgerRow("Total Hand Cash (Inflow Total − Cost & Invest)", "৳${fmtAmount(kpi.cashInHand)}", true, isBold = true)
        drawLedgerRow("Bank Total", "৳${fmtAmount(kpi.bankBalance)}", true, isBold = true)
        drawLedgerRow("Grand Total / Main Capital (Bank + Hand Cash)", "৳${fmtAmount(kpi.mainLiquidCapital)}", true, isBold = true, isFinal = true)
        drawLedgerRow("Total Remaining Member Dues (Receivables)", "৳${fmtAmount(kpi.totalDue)}", if (kpi.totalDue > 0) false else true)

        // Compact Signature / Digital Badge & Single Bottom Footer
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)
        drawCompactSignatureAreaPdf(
            canvas = canvas,
            paint = paint,
            sigY = 740f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Statement Date: $nowFormatted"
        )
        drawUnifiedBottomFooterPdf(canvas, paint, y = 796f)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, "RRK_Fund_Financial_Summary.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        savePdfToDownloads(context, outputFile, outputFile.name)

        return outputFile
    }

    /**
     * Generates official Head Office Statement & Voucher PDF for Rising Roads Of Kharkharian.
     */
    fun generateHeadOfficeVoucherPdf(
        context: Context,
        kpi: FinancialKpi,
        adminName: String = "Md Rakib Hossain",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())

        canvas.drawColor(Color.WHITE)

        // Navy Outer Border
        paint.color = Color.parseColor("#0F172A")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f
        canvas.drawRoundRect(RectF(25f, 25f, 570f, 817f), 12f, 12f, paint)

        // Top Gradient Header
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            25f, 25f, 570f, 135f,
            intArrayOf(Color.parseColor("#0A1128"), Color.parseColor("#1C3782"), Color.parseColor("#0F172A")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(25f, 25f, 570f, 135f), 12f, 12f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 64f, centerY = 80f, radius = 19f)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 19f
        canvas.drawText("RISING ROADS OF KHARKHARIAN (RRK)", 306f, 65f, paint)

        paint.textSize = 11.5f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawText("Head Office Official Financial Reconciliation Statement", 306f, 88f, paint)
        paint.color = Color.parseColor("#D4AF37")
        paint.textSize = 10.2f
        canvas.drawText("11 Active Founding Members · Inception: May 1, 2025 · Monthly: ৳1,000", 306f, 110f, paint)

        // Liquid Capital Highlight Card
        var y = 155f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRoundRect(RectF(40f, y, 555f, y + 80f), 10f, 10f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#D4AF37")
        paint.strokeWidth = 1.2f
        canvas.drawRoundRect(RectF(40f, y, 555f, y + 80f), 10f, 10f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.parseColor("#94A3B8")
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("GRAND TOTAL / MAIN CAPITAL (BANK + HAND CASH)", 55f, y + 24f, paint)

        paint.color = Color.parseColor("#10B981")
        paint.textSize = 24f
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        canvas.drawText("৳${fmtAmount(kpi.mainLiquidCapital)}", 55f, y + 54f, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.color = Color.parseColor("#60A5FA")
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Bank Total: ৳${fmtAmount(kpi.bankBalance)}", 540f, y + 36f, paint)
        paint.color = Color.parseColor("#FBBF24")
        canvas.drawText("Total Hand Cash: ৳${fmtAmount(kpi.cashInHand)}", 540f, y + 58f, paint)

        y += 100f
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.parseColor("#0F172A")
        paint.textSize = 13f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("OFFICIAL FINANCIAL AUDIT LINE ITEMS", 40f, y, paint)

        y += 12f
        fun drawLineItem(label: String, valueStr: String, valueColor: String, isBold: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
            paint.color = Color.parseColor("#475569")
            paint.textSize = 11.5f
            canvas.drawText(label, 50f, y + 16f, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.MONOSPACE, if (isBold) Typeface.BOLD else Typeface.NORMAL)
            paint.color = Color.parseColor(valueColor)
            paint.textSize = 12.5f
            canvas.drawText(valueStr, 545f, y + 16f, paint)

            paint.color = Color.parseColor("#F1F5F9")
            paint.strokeWidth = 1f
            canvas.drawLine(50f, y + 24f, 545f, y + 24f, paint)
            y += 28f
        }

        val grossVoucherStr = fmtSignedTaka(kpi.grossBusinessPnl)
        drawLineItem("1. Total Member Deposits (179 qty)", "৳${fmtAmount(kpi.totalDeposits)}", "#059669")
        drawLineItem("2. Deposit Fine (17 qty · Cutoff: 15th)", "৳${fmtAmount(kpi.fineCollection)}", "#D97706")
        drawLineItem("3. Net Business P/L (Gross $grossVoucherStr + ৳${fmtAmount(kpi.exitedMembersLossRecovery)} exited share)", fmtSignedTaka(kpi.realizedBusinessPnl), if (kpi.realizedBusinessPnl >= 0) "#059669" else "#DC2626")
        drawLineItem("4. Total Amount (Inflow Total: 1 + 2 + 3)", "৳${fmtAmount(kpi.totalCollection)}", "#059669", isBold = true)
        drawLineItem("5. Operational Expenses (8 records)", "-৳${fmtAmount(kpi.totalExpenses)}", "#DC2626")
        drawLineItem("6. Investment Running", "৳${fmtAmount(kpi.totalRunningInvestments)}", "#2563EB")
        drawLineItem("7. Cost & Invest (Expenses + Running)", "-৳${fmtAmount(kpi.costAndInvest)}", "#DC2626")
        drawLineItem("8. Total Hand Cash (Inflow Total − Cost & Invest)", "৳${fmtAmount(kpi.cashInHand)}", "#059669", isBold = true)
        drawLineItem("9. Bank Total", "৳${fmtAmount(kpi.bankBalance)}", "#2563EB", isBold = true)
        drawLineItem("10. Grand Total / Main Capital (Bank + Hand Cash)", "৳${fmtAmount(kpi.mainLiquidCapital)}", "#D97706", isBold = true)
        drawLineItem("11. Member Remaining Receivables / Dues", "৳${fmtAmount(kpi.totalDue)}", if (kpi.totalDue > 0) "#DC2626" else "#059669")
        drawLineItem("12. General Emergency Reserve Fund", "৳${fmtAmount(kpi.reservedAmount)}", "#7C3AED")

        // Compact Signature / Digital Badge & Single Bottom Footer
        val resolvedAdmin = resolveAdminDisplayName(context, adminName)
        drawCompactSignatureAreaPdf(
            canvas = canvas,
            paint = paint,
            sigY = 730f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Voucher Timestamp: $nowFormatted"
        )
        drawUnifiedBottomFooterPdf(canvas, paint, y = 796f)

        document.finishPage(page)

        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, "RRK_Head_Office_Voucher.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        savePdfToDownloads(context, outputFile, outputFile.name)

        return outputFile
    }

    /**
     * Directly saves a generated PDF file into the device's public Downloads/RisingRoads folder
     * (using zero-permission MediaStore.Downloads on Android 10+ plus app external Downloads fallback).
     */
    fun savePdfToDownloads(
        context: Context,
        sourceFile: File,
        displayFileName: String = sourceFile.name
    ): Boolean {
        if (!sourceFile.exists()) return false
        var savedPublicly = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            savedPublicly = runCatching {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, displayFileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/RisingRoads")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    true
                } else {
                    false
                }
            }.getOrDefault(false)
        }

        // Also save a copy in app-accessible Downloads directory
        runCatching {
            val extDownloads = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "RisingRoads"
            ).apply { mkdirs() }
            sourceFile.copyTo(File(extDownloads, displayFileName), overwrite = true)
        }

        return savedPublicly
    }

    /**
     * Directly downloads the PDF file to Downloads/RisingRoads and opens/shares it.
     */
    fun sharePdf(context: Context, file: File, title: String = "Download PDF Receipt") {
        val saved = savePdfToDownloads(context, file, file.name)
        val toastMsg = if (saved) {
            "Downloaded ${file.name} to Downloads/RisingRoads"
        } else {
            "Downloaded ${file.name}"
        }
        runCatching {
            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
        }

        runCatching {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, title))
        }
    }

    /**
     * Opens the native Android Print dialog for any generated PDF receipt or report.
     */
    fun printPdf(context: Context, file: File, jobName: String = file.nameWithoutExtension) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            sharePdf(context, file, "Print / Share ${file.name}")
            return
        }
        runCatching {
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder(file.name)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    if (destination == null) {
                        callback?.onWriteFailed("No destination file descriptor")
                        return
                    }
                    try {
                        FileInputStream(file).use { input ->
                            FileOutputStream(destination.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            }
            printManager.print(jobName, adapter, PrintAttributes.Builder().build())
        }.onFailure {
            sharePdf(context, file, "Print / Share ${file.name}")
        }
    }

    /**
     * Share or Save generated PNG image using Android Intent
     */
    fun shareImage(context: Context, file: File, title: String = "Save or Share Receipt Image") {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, title))
    }

    /**
     * Generates a crisp, verified digital Payment Proof Receipt Image (.png) for an approved
     * manual payment request, showing RRK branding, Member Name & ID, Month, Amount,
     * Payment Method, TrxID, Approval Date, and a green VERIFIED & PAID badge.
     */
    fun generatePaymentProofReceiptImage(
        context: Context,
        request: PaymentRequest,
        memberPhone: String = "",
        adminName: String = "Rakib",
        isAdmin: Boolean = runCatching { SessionManager(context).isLoggedIn }.getOrDefault(false)
    ): Pair<File, Boolean> {
        val width = 1080
        val height = 1580
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val proofNo = "PR-${request.id.toString().padStart(4, '0')}"
        val linkedReceiptNo = request.approvedDepositId?.let { "RRK-${it.toString().padStart(4, '0')}" } ?: proofNo
        val total = request.amount + request.fine
        val dateFmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
        val approvalDateStr = request.reviewedAt?.let { dateFmt.format(Date(it)) } ?: dateFmt.format(Date())
        val resolvedAdmin = resolveAdminDisplayName(context, request.reviewedBy.ifBlank { adminName })

        // Background
        canvas.drawColor(Color.WHITE)

        // Outer Emerald Border
        paint.color = Color.parseColor("#059669")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        canvas.drawRoundRect(RectF(36f, 36f, width - 36f, height - 36f), 28f, 28f, paint)

        // Header Gradient Banner
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            36f, 36f, width - 36f, 310f,
            intArrayOf(Color.parseColor("#064E3B"), Color.parseColor("#059669"), Color.parseColor("#10B981")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(RectF(36f, 36f, width - 36f, 310f), 28f, 28f, paint)
        paint.shader = null

        // Compact Official RRK Logo in Header
        drawCompactRrkLogo(canvas, context, paint, centerX = 114f, centerY = 122f, radius = 40f)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 38f
        canvas.drawText("Rising Roads Of Kharkharian", width / 2f + 22f, 112f, paint)

        paint.textSize = 22f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#D1FAE5")
        canvas.drawText("Official Verified Payment Proof Receipt", width / 2f + 22f, 154f, paint)

        // Proof Number Pill
        paint.color = Color.parseColor("#26FFFFFF")
        canvas.drawRoundRect(RectF(270f, 192f, 810f, 258f), 22f, 22f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.WHITE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(RectF(270f, 192f, 810f, 258f), 22f, 22f, paint)

        paint.style = Paint.Style.FILL
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = 24f
        canvas.drawText("PROOF: #$proofNo · LEDGER: $linkedReceiptNo", width / 2f, 234f, paint)

        // Green VERIFIED & PAID Badge Pill
        val badgeTop = 342f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#ECFDF5")
        canvas.drawRoundRect(RectF(290f, badgeTop, width - 290f, badgeTop + 68f), 34f, 34f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#059669")
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(290f, badgeTop, width - 290f, badgeTop + 68f), 34f, 34f, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#065F46")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 28f
        canvas.drawText("✓  VERIFIED & PAID", width / 2f, badgeTop + 44f, paint)

        // Detail Rows
        var y = 480f
        fun drawProofRow(label: String, value: String, isBold: Boolean = false, isHighlight: Boolean = false, isDanger: Boolean = false) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#475569")
            paint.textSize = 25f
            canvas.drawText(label, 88f, y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isBold || isHighlight) Typeface.BOLD else Typeface.NORMAL)
            paint.color = when {
                isDanger -> Color.parseColor("#DC2626")
                isHighlight -> Color.parseColor("#059669")
                else -> Color.parseColor("#111827")
            }
            val safeVal = if (value.length > 34) value.take(32) + "…" else value
            canvas.drawText(safeVal, width - 88f, y, paint)

            paint.color = Color.parseColor("#E5E7EB")
            paint.strokeWidth = 2f
            canvas.drawLine(88f, y + 18f, width - 88f, y + 18f, paint)
            y += 66f
        }

        drawProofRow("Member Name", request.memberName, isBold = true)
        drawProofRow("Member ID", "RRK-${request.memberId.toString().padStart(3, '0')}", isBold = true)
        if (memberPhone.isNotBlank()) {
            drawProofRow("Phone", memberPhone)
        }
        drawProofRow("Billing Month", request.month, isBold = true)
        drawProofRow("Payment Method", request.paymentMethod, isBold = true, isHighlight = true)
        drawProofRow("Transaction ID (TrxID)", request.trxId.ifBlank { "Cash Handover" }, isBold = true)
        drawProofRow("Payment Date", request.paymentDate)
        drawProofRow("Approval Date", approvalDateStr, isBold = true)
        drawProofRow("Monthly Contribution", "৳${fmtAmount(request.amount)}", isBold = true)
        if (request.fine > 0) {
            drawProofRow("Late Fine", "৳${fmtAmount(request.fine)}", isBold = true, isDanger = true)
        }

        // Total Verified Paid Box
        y += 14f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#ECFDF5")
        canvas.drawRoundRect(RectF(88f, y, width - 88f, y + 102f), 20f, 20f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#6EE7B7")
        paint.strokeWidth = 3f
        canvas.drawRoundRect(RectF(88f, y, width - 88f, y + 102f), 20f, 20f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 29f
        paint.color = Color.parseColor("#065F46")
        canvas.drawText("Total Verified Paid", 122f, y + 62f, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 38f
        paint.color = Color.parseColor("#059669")
        canvas.drawText("৳${fmtAmount(total)}", width - 122f, y + 64f, paint)

        // Compact Signature / Digital Badge & Single Bottom Footer
        drawCompactSignatureAreaImage(
            canvas = canvas,
            paint = paint,
            width = width,
            sigY = 1385f,
            isAdmin = isAdmin,
            adminDisplayName = resolvedAdmin,
            leftInfoText = "Approved: $approvalDateStr"
        )
        drawUnifiedBottomFooterImage(canvas, paint, width = width, y = 1508f)

        val safeMonth = request.month.replace(" ", "_")
        val fileName = "RRK_Proof_${proofNo}_Member${request.memberId}_$safeMonth.png"
        val outputDir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val outputFile = File(outputDir, fileName)
        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        val savedToGallery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/RisingRoads")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    true
                } else {
                    false
                }
            }.getOrDefault(false)
        } else {
            false
        }

        bitmap.recycle()
        return Pair(outputFile, savedToGallery)
    }
}
