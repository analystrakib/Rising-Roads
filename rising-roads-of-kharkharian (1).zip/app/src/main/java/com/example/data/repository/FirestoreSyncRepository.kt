package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Success(val message: String, val timestamp: Long = System.currentTimeMillis()) : SyncState()
    data class Error(val error: String, val timestamp: Long = System.currentTimeMillis()) : SyncState()
}

/**
 * Interface defining Room-to-Firestore real-time data synchronization.
 */
interface SyncRepository {
    val syncState: StateFlow<SyncState>
    fun startRealtimeSync(scope: CoroutineScope)
    suspend fun pushAllLocalDataToFirestore()
    suspend fun pullRemoteDataFromFirestore()
}

/**
 * Production implementation of SyncRepository delegating to FirebaseRepository.
 */
class FirestoreSyncRepository(
    context: Context,
    dao: AppDao,
    private val delegate: FirebaseRepository = FirebaseRepository(context, dao)
) : SyncRepository by delegate
