package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiChatMessage
import com.example.ai.AiTaskState
import com.example.ui.MainViewModel
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadDeepGreen
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.TABULAR_NUMBERS

/**
 * Formats light markdown (**bold**, headings, bullets) cleanly into a high-contrast AnnotatedString.
 */
fun formatAiAnnotatedText(raw: String): AnnotatedString {
    val cleanedLines = raw.lines().map { line ->
        val trimmed = line.trimStart()
        when {
            trimmed.startsWith("### ") -> "• ${trimmed.removePrefix("### ").trim()}"
            trimmed.startsWith("## ") -> trimmed.removePrefix("## ").trim()
            trimmed.startsWith("# ") -> trimmed.removePrefix("# ").trim()
            trimmed.startsWith("* ") -> "• ${trimmed.removePrefix("* ")}"
            trimmed.startsWith("- ") -> "• ${trimmed.removePrefix("- ")}"
            else -> line
        }
    }.joinToString("\n")

    return buildAnnotatedString {
        var idx = 0
        while (idx < cleanedLines.length) {
            val boldStart = cleanedLines.indexOf("**", idx)
            if (boldStart == -1) {
                append(cleanedLines.substring(idx))
                break
            }
            if (boldStart > idx) {
                append(cleanedLines.substring(idx, boldStart))
            }
            val boldEnd = cleanedLines.indexOf("**", boldStart + 2)
            if (boldEnd == -1) {
                append(cleanedLines.substring(boldStart))
                break
            }
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = NagadMainText))
            append(cleanedLines.substring(boldStart + 2, boldEnd))
            pop()
            idx = boldEnd + 2
        }
    }
}

@Composable
fun AskRrkAiFab(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = NagadPrimary,
        contentColor = Color.White,
        shadowElevation = 4.dp,
        modifier = modifier
            .size(44.dp)
            .testTag("ask_rrk_ai_fab")
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Ask RRK AI",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun AiSummaryButton(
    onClick: () -> Unit,
    isLoading: Boolean = false,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.45f)),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
            containerColor = NagadLightBg,
            contentColor = NagadDeepGreen
        ),
        contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp),
        modifier = modifier
            .height(34.dp)
            .testTag("ai_summary_button")
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                strokeWidth = 2.dp,
                color = NagadPrimary,
                modifier = Modifier.size(13.dp)
            )
        } else {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = NagadPrimary,
                modifier = Modifier.size(13.dp)
            )
        }
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = "AI Summary",
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = NagadDeepGreen,
            maxLines = 1
        )
    }
}

@Composable
fun AiSummaryPanel(
    title: String,
    state: AiTaskState,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(visible = state !is AiTaskState.Idle) {
        Card(
            shape = AppCardShape,
            colors = CardDefaults.cardColors(containerColor = NagadLightBg),
            border = BorderStroke(1.5.dp, NagadPrimary.copy(alpha = 0.45f)),
            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
            modifier = modifier
                .fillMaxWidth()
                .testTag("ai_summary_panel")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(NagadPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = NagadMainText
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onRetry,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Regenerate AI summary",
                                tint = NagadPrimary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close AI summary",
                                tint = NagadSecondaryText,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = AppCardShape,
                    color = NagadWhite,
                    border = AppCardBorder,
                    shadowElevation = AppCardElevation,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    when (state) {
                        is AiTaskState.Idle -> Unit
                        is AiTaskState.Loading -> {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    strokeWidth = 2.dp,
                                    color = NagadPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Analyzing live RRK numbers with Gemini...",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 12.5.sp,
                                    color = NagadSecondaryText
                                )
                            }
                        }

                        is AiTaskState.Streaming -> {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = formatAiAnnotatedText(state.text),
                                    style = TextStyle(
                                        fontFamily = InterFontFamily,
                                        fontSize = 13.sp,
                                        color = NagadMainText,
                                        lineHeight = 19.sp,
                                        fontFeatureSettings = TABULAR_NUMBERS
                                    )
                                )
                            }
                        }

                        is AiTaskState.Success -> {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = formatAiAnnotatedText(state.text),
                                    style = TextStyle(
                                        fontFamily = InterFontFamily,
                                        fontSize = 13.sp,
                                        color = NagadMainText,
                                        lineHeight = 19.sp,
                                        fontFeatureSettings = TABULAR_NUMBERS
                                    )
                                )
                            }
                        }

                        is AiTaskState.Error -> {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = NagadDanger,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = state.message,
                                        fontFamily = InterFontFamily,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadDanger
                                    )
                                    TextButton(
                                        onClick = onRetry,
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text(
                                            text = "Retry",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = NagadPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RrkAiChatModal(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val messages by viewModel.aiChatMessages.collectAsState()
    val isResponding by viewModel.isAiChatResponding.collectAsState()
    var inputDraft by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val listState = rememberLazyListState()

    val quickPrompts = remember {
        listOf(
            "Summarize our current investment & profit/loss",
            "Who has pending dues?",
            "বর্তমান তহবিল ও লাভ-ক্ষতি সংক্ষেপে বলুন",
            "How much liquid capital is available?"
        )
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = NagadWhite,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        modifier = Modifier.testTag("rrk_ai_chat_modal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.86f)
                .imePadding()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NagadLightBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NagadPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "RRK AI Assistant",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.5.sp,
                            color = NagadMainText
                        )
                        Text(
                            text = "Live data access · English & বাংলা",
                            fontFamily = InterFontFamily,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.clearAiChat() },
                        enabled = !isResponding && messages.isNotEmpty()
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear chat",
                            tint = NagadSecondaryText
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close AI chat",
                            tint = NagadMainText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = NagadBorder)
            Spacer(modifier = Modifier.height(8.dp))

            // Quick suggestion chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickPrompts.forEach { suggestion ->
                    SuggestionChip(
                        onClick = {
                            if (!isResponding) {
                                viewModel.sendAiChatMessage(suggestion)
                            }
                        },
                        label = {
                            Text(
                                text = suggestion,
                                fontFamily = InterFontFamily,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadDeepGreen
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = NagadLightBg
                        ),
                        border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Surface(
                            shape = AppCardShape,
                            color = NagadLightBg,
                            border = BorderStroke(1.5.dp, NagadBorder),
                            shadowElevation = AppCardElevation,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Ask anything about Rising Roads of Kharkharian",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = NagadMainText
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "I have real-time read access to total deposits, liquid capital, member pending dues, investment profit/loss, expenses, and shared member ideas. Ask in English or Bengali!",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 12.5.sp,
                                    color = NagadSecondaryText,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                } else {
                    items(messages, key = { it.id }) { msg ->
                        AiChatBubble(message = msg)
                    }
                }
            }

            HorizontalDivider(color = NagadBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputDraft,
                    onValueChange = { inputDraft = it },
                    placeholder = {
                        Text(
                            text = "Ask about funds, dues, P&L or ideas...",
                            fontFamily = InterFontFamily,
                            fontSize = 13.sp
                        )
                    },
                    maxLines = 3,
                    textStyle = appInputTextStyle(13.5.sp),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input")
                )
                Button(
                    onClick = {
                        val query = inputDraft.trim()
                        if (query.isNotEmpty() && !isResponding) {
                            inputDraft = ""
                            viewModel.sendAiChatMessage(query)
                        }
                    },
                    enabled = inputDraft.isNotBlank() && !isResponding,
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    modifier = Modifier
                        .heightIn(min = 50.dp)
                        .testTag("ai_chat_send_button")
                ) {
                    if (isResponding) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send to RRK AI",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AiChatBubble(message: AiChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        val containerColor = when {
            message.isError -> Color(0xFFFEF2F2)
            message.isUser -> NagadPrimary
            else -> NagadLightBg
        }
        val borderStroke = when {
            message.isError -> BorderStroke(1.dp, Color(0xFFFCA5A5))
            message.isUser -> null
            else -> BorderStroke(1.dp, NagadBorder)
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 16.dp
            ),
            color = containerColor,
            border = borderStroke,
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            if (message.text.isEmpty() && !message.isUser && !message.isError) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = NagadPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Thinking...",
                        fontFamily = InterFontFamily,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText
                    )
                }
            } else {
                Text(
                    text = if (message.isUser || message.isError) {
                        AnnotatedString(message.text)
                    } else {
                        formatAiAnnotatedText(message.text)
                    },
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        color = when {
                            message.isError -> NagadDanger
                            message.isUser -> Color.White
                            else -> NagadMainText
                        },
                        lineHeight = 19.sp,
                        fontFeatureSettings = TABULAR_NUMBERS
                    ),
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp)
                )
            }
        }
    }
}
