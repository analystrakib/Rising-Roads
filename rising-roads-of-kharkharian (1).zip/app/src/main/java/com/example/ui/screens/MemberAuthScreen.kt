package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.RememberedUserSession
import com.example.ui.MainViewModel
import com.example.ui.components.AppCardBorder
import com.example.ui.components.AppCardElevation
import com.example.ui.components.AppCardShape
import com.example.ui.components.AppInputShape
import com.example.ui.components.appInputTextStyle
import com.example.ui.components.appOutlinedTextFieldColors
import com.example.ui.components.appSolidButtonColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadDeepGreen
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.TABULAR_NUMBERS

/**
 * Full-screen pre-app gate enforcing Sign In / Sign Up / bKash-Nagad 4-Digit Quick PIN
 * before any access to Dashboard, sidebar, or bottom navigation is granted.
 */
@Composable
fun AppLockAuthGate(
    viewModel: MainViewModel
) {
    val remembered by viewModel.rememberedSession.collectAsState()
    val pendingPinAccount by viewModel.pendingPinSetupAccount.collectAsState()

    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var showForgotPinDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp)
                .testTag("pre_app_auth_gate"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Centered RRK Brand Header
            Surface(
                shape = CircleShape,
                color = NagadLightBg,
                border = BorderStroke(1.5.dp, NagadPrimary.copy(alpha = 0.35f)),
                shadowElevation = 2.dp,
                modifier = Modifier.size(72.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Rising Roads Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Rising Roads",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                color = NagadMainText
            )

            Spacer(modifier = Modifier.height(18.dp))

            when {
                pendingPinAccount != null || (remembered.isValid && !remembered.hasPin) -> {
                    val displayName = pendingPinAccount?.fullName ?: remembered.fullName
                    val displayId = pendingPinAccount?.rrkMemberId ?: remembered.rrkMemberId
                    SetupQuickPinCard(
                        fullName = displayName,
                        rrkMemberId = displayId,
                        onSavePin = { pin, callback ->
                            viewModel.completePinSetup(pin, callback)
                        },
                        onSwitchAccount = { viewModel.switchAccount() }
                    )
                }

                remembered.isValid && remembered.hasPin -> {
                    QuickPinLockCard(
                        remembered = remembered,
                        onVerifyPin = { pin, callback ->
                            viewModel.unlockWithPin(pin, callback)
                        },
                        onForgotPin = { showForgotPinDialog = true },
                        onSwitchAccount = { viewModel.switchAccount() }
                    )
                }

                else -> {
                    AuthSignInSignUpCard(
                        viewModel = viewModel,
                        onOpenForgotPassword = { showForgotPasswordDialog = true },
                        onAuthSuccess = { /* viewModel unlocks automatically when PIN exists */ }
                    )
                }
            }
        }
    }

    if (showForgotPasswordDialog) {
        ForgotPasswordModal(
            onDismiss = { showForgotPasswordDialog = false },
            onSubmitReset = { recoveryContact, recoveryId, newPass, callback ->
                viewModel.resetMemberPasswordWithVerification(
                    contact = recoveryContact,
                    rrkMemberId = recoveryId,
                    newPassword = newPass,
                    onResult = callback
                )
            }
        )
    }

    if (showForgotPinDialog && remembered.isValid) {
        ForgotPinModal(
            remembered = remembered,
            onDismiss = { showForgotPinDialog = false },
            onResetPin = { password, newPin, callback ->
                viewModel.resetRememberedPin(
                    password = password,
                    newPin = newPin,
                    onResult = callback
                )
            }
        )
    }
}

@Composable
private fun QuickPinLockCard(
    remembered: RememberedUserSession,
    onVerifyPin: (String, (Boolean, String) -> Unit) -> Unit,
    onForgotPin: () -> Unit,
    onSwitchAccount: () -> Unit
) {
    var pinDigits by remember(remembered.rrkMemberId) { mutableStateOf("") }
    var errorMessage by remember(remembered.rrkMemberId) { mutableStateOf<String?>(null) }

    val initials = remember(remembered.fullName) {
        remembered.fullName
            .split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .mapNotNull { it.firstOrNull()?.uppercaseChar() }
            .joinToString("")
            .ifEmpty { "RR" }
    }

    fun submitIfComplete(candidate: String) {
        if (candidate.length == 4) {
            onVerifyPin(candidate) { success, msg ->
                if (success) {
                    errorMessage = null
                    pinDigits = ""
                } else {
                    errorMessage = msg
                    pinDigits = ""
                }
            }
        }
    }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quick_pin_lock_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NagadLightBg,
                border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.3f))
            ) {
                Text(
                    text = "QUICK PIN UNLOCK",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    color = NagadDeepGreen,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(NagadPrimary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = remembered.fullName,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = NagadMainText,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = NagadVeryLightBg,
                border = AppCardBorder
            ) {
                Text(
                    text = "ID: ${remembered.rrkMemberId}",
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp,
                        color = NagadSecondaryText,
                        fontFeatureSettings = TABULAR_NUMBERS
                    ),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Enter your 4-digit PIN to continue",
                fontFamily = InterFontFamily,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = NagadSecondaryText
            )

            Spacer(modifier = Modifier.height(12.dp))

            PinDotsIndicator(
                enteredCount = pinDigits.length,
                isError = errorMessage != null
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF2F2),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage ?: "",
                        fontFamily = InterFontFamily,
                        color = NagadDanger,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            NumericPinKeypad(
                onDigitClick = { digit ->
                    if (pinDigits.length < 4) {
                        errorMessage = null
                        val updated = pinDigits + digit
                        pinDigits = updated
                        submitIfComplete(updated)
                    }
                },
                onClearClick = {
                    pinDigits = ""
                    errorMessage = null
                },
                onBackspaceClick = {
                    if (pinDigits.isNotEmpty()) {
                        pinDigits = pinDigits.dropLast(1)
                        errorMessage = null
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = NagadBorder)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onForgotPin,
                    modifier = Modifier.testTag("forgot_pin_link")
                ) {
                    Text(
                        text = "Forgot PIN?",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NagadPrimary
                    )
                }

                TextButton(
                    onClick = onSwitchAccount,
                    modifier = Modifier.testTag("switch_account_link")
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = null,
                        tint = NagadSecondaryText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Switch Account",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = NagadSecondaryText
                    )
                }
            }
        }
    }
}

@Composable
private fun SetupQuickPinCard(
    fullName: String,
    rrkMemberId: String,
    onSavePin: (String, (Boolean, String) -> Unit) -> Unit,
    onSwitchAccount: () -> Unit
) {
    var pinDigits by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("setup_quick_pin_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(NagadLightBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Pin,
                    contentDescription = null,
                    tint = NagadPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Create Your 4-Digit Quick PIN",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 17.sp,
                color = NagadMainText,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$fullName · $rrkMemberId",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.5.sp,
                color = NagadDeepGreen
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Use this 4-digit PIN to unlock Rising Roads quickly next time you open the app.",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = NagadSecondaryText,
                textAlign = TextAlign.Center,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            PinDotsIndicator(
                enteredCount = pinDigits.length,
                isError = errorMessage != null
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage ?: "",
                    fontFamily = InterFontFamily,
                    color = NagadDanger,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            NumericPinKeypad(
                onDigitClick = { digit ->
                    if (pinDigits.length < 4) {
                        errorMessage = null
                        pinDigits += digit
                    }
                },
                onClearClick = {
                    pinDigits = ""
                    errorMessage = null
                },
                onBackspaceClick = {
                    if (pinDigits.isNotEmpty()) {
                        pinDigits = pinDigits.dropLast(1)
                        errorMessage = null
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    onSavePin(pinDigits) { success, msg ->
                        if (!success) {
                            errorMessage = msg
                        }
                    }
                },
                enabled = pinDigits.length == 4,
                colors = appSolidButtonColors(NagadPrimary),
                shape = AppInputShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_quick_pin_button")
            ) {
                Text(
                    text = "Save PIN & Enter App",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            TextButton(onClick = onSwitchAccount) {
                Text(
                    text = "Use a different account",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.5.sp,
                    color = NagadSecondaryText
                )
            }
        }
    }
}

@Composable
private fun PinDotsIndicator(
    enteredCount: Int,
    isError: Boolean
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(4) { index ->
            val filled = index < enteredCount
            val borderColor = when {
                isError -> NagadDanger
                filled -> NagadPrimary
                else -> NagadBorder
            }
            val bgColor = when {
                filled -> NagadLightBg
                else -> NagadVeryLightBg
            }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bgColor,
                border = BorderStroke(1.5.dp, borderColor),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (filled) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (isError) NagadDanger else NagadPrimary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NumericPinKeypad(
    onDigitClick: (String) -> Unit,
    onClearClick: () -> Unit,
    onBackspaceClick: () -> Unit
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("CLR", "0", "DEL")
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        rows.forEach { rowKeys ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowKeys.forEach { key ->
                    val isAction = key == "CLR" || key == "DEL"
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isAction) NagadVeryLightBg else NagadWhite,
                        border = AppCardBorder,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                when (key) {
                                    "CLR" -> onClearClick()
                                    "DEL" -> onBackspaceClick()
                                    else -> onDigitClick(key)
                                }
                            }
                            .testTag("pin_key_$key")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            when (key) {
                                "DEL" -> Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                                    contentDescription = "Backspace",
                                    tint = NagadMainText,
                                    modifier = Modifier.size(20.dp)
                                )
                                "CLR" -> Text(
                                    text = "Clear",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = NagadSecondaryText
                                )
                                else -> Text(
                                    text = key,
                                    style = TextStyle(
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = NagadMainText,
                                        fontFeatureSettings = TABULAR_NUMBERS
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthSignInSignUpCard(
    viewModel: MainViewModel,
    onOpenForgotPassword: () -> Unit,
    onAuthSuccess: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Sign In, 1 = Sign Up

    // Sign In fields
    var signInIdentifier by remember { mutableStateOf("") }
    var signInPassword by remember { mutableStateOf("") }
    var signInPassVisible by remember { mutableStateOf(false) }
    var signInError by remember { mutableStateOf<String?>(null) }

    // Sign Up fields
    var fullName by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var rrkMemberId by remember { mutableStateOf("") }
    var signUpPassword by remember { mutableStateOf("") }
    var signUpPassVisible by remember { mutableStateOf(false) }
    var signUpQuickPin by remember { mutableStateOf("") }
    var signUpPinVisible by remember { mutableStateOf(false) }
    var signUpError by remember { mutableStateOf<String?>(null) }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("member_auth_screen")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NagadLightBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (selectedTab == 0) Icons.Default.Lock else Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = NagadPrimary,
                        modifier = Modifier.size(21.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Member Portal Access",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.5.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Sign in or sign up with your RRK Member ID",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = NagadSecondaryText
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Switcher: Sign In | Sign Up
            Surface(
                shape = AppCardShape,
                color = NagadVeryLightBg,
                border = AppCardBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("Sign In", "Sign Up").forEachIndexed { index, title ->
                        val isSelected = selectedTab == index
                        Surface(
                            onClick = {
                                selectedTab = index
                                signInError = null
                                signUpError = null
                            },
                            shape = RoundedCornerShape(9.dp),
                            color = if (isSelected) NagadPrimary else Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("member_auth_tab_${title.lowercase().replace(" ", "_")}")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = title,
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = if (isSelected) Color.White else NagadSecondaryText
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedTab == 0) {
                OutlinedTextField(
                    value = signInIdentifier,
                    onValueChange = { signInIdentifier = it },
                    label = { Text("Phone, Email, or RRK Member ID", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. RRK-005 or 01792-430077", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signin_identifier_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = signInPassword,
                    onValueChange = { signInPassword = it },
                    label = { Text("Password", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    visualTransformation = if (signInPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { signInPassVisible = !signInPassVisible }) {
                            Icon(
                                imageVector = if (signInPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle password visibility",
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Password
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signin_password_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onOpenForgotPassword,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("forgot_password_link")
                    ) {
                        Text(
                            text = "Forgot Password?",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.5.sp,
                            color = NagadPrimary
                        )
                    }
                }

                if (signInError != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = signInError ?: "",
                            fontFamily = InterFontFamily,
                            color = NagadDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Button(
                    onClick = {
                        viewModel.signInMember(signInIdentifier, signInPassword) { success, msg ->
                            if (success) {
                                signInError = null
                                onAuthSuccess()
                            } else {
                                signInError = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("member_signin_submit_button")
                ) {
                    Text(
                        text = "Sign In",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            } else {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. Md. Rakib Hossen", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signup_fullname_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Phone Number or Email", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. 01792-430077 or name@email.com", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.ContactPhone,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Email
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signup_contact_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = rrkMemberId,
                    onValueChange = { rrkMemberId = it },
                    label = { Text("RRK Member ID", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. RRK-005", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        autoCorrectEnabled = false
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signup_rrkid_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = signUpPassword,
                    onValueChange = { signUpPassword = it },
                    label = { Text("Password (min 6 characters)", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    visualTransformation = if (signUpPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { signUpPassVisible = !signUpPassVisible }) {
                            Icon(
                                imageVector = if (signUpPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle password visibility",
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Password
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signup_password_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = signUpQuickPin,
                    onValueChange = { input ->
                        signUpQuickPin = input.filter { it.isDigit() }.take(4)
                    },
                    label = { Text("4-Digit Quick PIN (for fast unlock)", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. 1234", fontFamily = InterFontFamily) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Pin,
                            contentDescription = null,
                            tint = NagadPrimary
                        )
                    },
                    visualTransformation = if (signUpPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { signUpPinVisible = !signUpPinVisible }) {
                            Icon(
                                imageVector = if (signUpPinVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle PIN visibility",
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword
                    ),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_signup_pin_input")
                )

                if (signUpError != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = signUpError ?: "",
                            fontFamily = InterFontFamily,
                            color = NagadDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        viewModel.signUpMember(
                            fullName = fullName,
                            contact = contact,
                            rrkMemberId = rrkMemberId,
                            password = signUpPassword,
                            quickPin = signUpQuickPin
                        ) { success, msg ->
                            if (success) {
                                signUpError = null
                                onAuthSuccess()
                            } else {
                                signUpError = msg
                            }
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("member_signup_submit_button")
                ) {
                    Text(
                        text = "Sign Up & Enter App",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * Signed-in member profile view (used if navigated internally inside the unlocked app).
 */
@Composable
fun MemberAuthScreen(
    viewModel: MainViewModel,
    onAuthSuccess: () -> Unit,
    onNavigateToIdeas: () -> Unit
) {
    val memberSession by viewModel.memberSession.collectAsState()
    val initials = memberSession.fullName
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .joinToString("")
        .ifEmpty { "RR" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("member_profile_account_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = AppCardShape,
            colors = CardDefaults.cardColors(containerColor = NagadWhite),
            border = AppCardBorder,
            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NagadLightBg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = initials,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = NagadPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = memberSession.fullName,
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = NagadMainText
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NagadLightBg,
                        border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = memberSession.role,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = NagadDeepGreen,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NagadVeryLightBg,
                        border = BorderStroke(1.5.dp, NagadBorder)
                    ) {
                        Text(
                            text = "ID: ${memberSession.rrkMemberId}",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = NagadMainText,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                if (memberSession.contact.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = memberSession.contact,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = NagadSecondaryText
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = NagadBorder)
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onNavigateToIdeas,
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("go_to_ideas_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Explore Member Ideas",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { viewModel.lockApp() },
                    shape = AppInputShape,
                    border = BorderStroke(1.dp, NagadDanger.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadDanger),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("member_profile_lock_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = NagadDanger,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Lock / Logout",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = NagadDanger
                    )
                }
            }
        }
    }
}

@Composable
private fun ForgotPinModal(
    remembered: RememberedUserSession,
    onDismiss: () -> Unit,
    onResetPin: (password: String, newPin: String, onResult: (Boolean, String) -> Unit) -> Unit
) {
    var accountPassword by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var passVisible by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        shape = AppCardShape,
        icon = {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(NagadLightBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Pin,
                    contentDescription = null,
                    tint = NagadPrimary
                )
            }
        },
        title = {
            Text(
                text = "Reset 4-Digit Quick PIN",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = NagadMainText
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Verify the password for ${remembered.fullName} (${remembered.rrkMemberId}) to set a new 4-digit Quick PIN.",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = NagadSecondaryText,
                    lineHeight = 17.sp
                )

                OutlinedTextField(
                    value = accountPassword,
                    onValueChange = { accountPassword = it },
                    label = { Text("Account Password", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passVisible = !passVisible }) {
                            Icon(
                                imageVector = if (passVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reset_pin_password_input")
                )

                OutlinedTextField(
                    value = newPin,
                    onValueChange = { input -> newPin = input.filter { it.isDigit() }.take(4) },
                    label = { Text("New 4-Digit PIN", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reset_pin_new_input")
                )

                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { input -> confirmPin = input.filter { it.isDigit() }.take(4) },
                    label = { Text("Confirm 4-Digit PIN", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reset_pin_confirm_input")
                )

                if (feedbackMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSuccess) NagadLightBg else Color(0xFFFEF2F2),
                        border = BorderStroke(
                            1.dp,
                            if (isSuccess) NagadPrimary.copy(alpha = 0.4f) else Color(0xFFFCA5A5)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = feedbackMessage ?: "",
                            fontFamily = InterFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSuccess) NagadDeepGreen else NagadDanger,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (isSuccess) {
                Button(
                    onClick = onDismiss,
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape
                ) {
                    Text("Done", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            } else {
                Button(
                    onClick = {
                        if (newPin.length != 4) {
                            isSuccess = false
                            feedbackMessage = "PIN must be exactly 4 digits."
                            return@Button
                        }
                        if (newPin != confirmPin) {
                            isSuccess = false
                            feedbackMessage = "PINs do not match."
                            return@Button
                        }
                        onResetPin(accountPassword, newPin) { success, msg ->
                            isSuccess = success
                            feedbackMessage = msg
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier.testTag("reset_pin_submit_button")
                ) {
                    Text(
                        text = "Update PIN",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        },
        dismissButton = {
            if (!isSuccess) {
                TextButton(onClick = onDismiss) {
                    Text(
                        text = "Cancel",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = NagadSecondaryText
                    )
                }
            }
        }
    )
}

@Composable
private fun ForgotPasswordModal(
    onDismiss: () -> Unit,
    onSubmitReset: (contact: String, rrkMemberId: String, newPassword: String, onResult: (Boolean, String) -> Unit) -> Unit
) {
    var recoveryContact by remember { mutableStateOf("") }
    var recoveryMemberId by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        shape = AppCardShape,
        icon = {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(NagadLightBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.LockReset,
                    contentDescription = null,
                    tint = NagadPrimary
                )
            }
        },
        title = {
            Text(
                text = "Reset Member Password",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = NagadMainText
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Verify your registered Email or Phone Number alongside your RRK Member ID to reset your password.",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = NagadSecondaryText,
                    lineHeight = 17.sp
                )

                OutlinedTextField(
                    value = recoveryContact,
                    onValueChange = { recoveryContact = it },
                    label = { Text("Registered Email or Phone", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recovery_contact_input")
                )

                OutlinedTextField(
                    value = recoveryMemberId,
                    onValueChange = { recoveryMemberId = it },
                    label = { Text("RRK Member ID", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. RRK-005", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recovery_rrkid_input")
                )

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Password (min 6 chars)", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = NagadSecondaryText
                            )
                        }
                    },
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recovery_new_password_input")
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("Confirm New Password", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recovery_confirm_password_input")
                )

                if (feedbackMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSuccess) NagadLightBg else Color(0xFFFEF2F2),
                        border = BorderStroke(
                            1.dp,
                            if (isSuccess) NagadPrimary.copy(alpha = 0.4f) else Color(0xFFFCA5A5)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = feedbackMessage ?: "",
                            fontFamily = InterFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSuccess) NagadDeepGreen else NagadDanger,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (isSuccess) {
                Button(
                    onClick = onDismiss,
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape
                ) {
                    Text("Done", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            } else {
                Button(
                    onClick = {
                        if (newPassword != confirmPassword) {
                            isSuccess = false
                            feedbackMessage = "Passwords do not match."
                            return@Button
                        }
                        onSubmitReset(recoveryContact, recoveryMemberId, newPassword) { success, msg ->
                            isSuccess = success
                            feedbackMessage = msg
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape,
                    modifier = Modifier.testTag("recovery_submit_button")
                ) {
                    Text(
                        text = "Reset Password",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        },
        dismissButton = {
            if (!isSuccess) {
                TextButton(onClick = onDismiss) {
                    Text(
                        text = "Cancel",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = NagadSecondaryText
                    )
                }
            }
        }
    )
}
