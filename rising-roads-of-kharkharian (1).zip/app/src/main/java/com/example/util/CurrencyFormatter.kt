package com.example.util

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

object CurrencyFormatter {
    private val indianLocale = Locale("en", "IN")

    fun formatNumber(amount: Int): String {
        val formatter = NumberFormat.getIntegerInstance(indianLocale)
        return formatter.format(amount)
    }

    fun formatNumber(amount: Long): String {
        val formatter = NumberFormat.getIntegerInstance(indianLocale)
        return formatter.format(amount)
    }

    fun formatCurrency(amount: Int): String {
        return if (amount < 0) {
            "-৳${formatNumber(abs(amount.toLong()))}"
        } else {
            "৳${formatNumber(amount)}"
        }
    }

    fun formatCurrency(amount: Long): String {
        return if (amount < 0L) {
            "-৳${formatNumber(abs(amount))}"
        } else {
            "৳${formatNumber(amount)}"
        }
    }

    fun formatSignedCurrency(amount: Int): String {
        return when {
            amount > 0 -> "+৳${formatNumber(amount)}"
            amount < 0 -> "-৳${formatNumber(abs(amount.toLong()))}"
            else -> "৳0"
        }
    }
}
