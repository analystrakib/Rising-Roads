package com.example.util

import android.util.Patterns
import java.security.MessageDigest

object PasswordUtils {
    fun sha256(raw: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun normalizeRrkId(raw: String): String {
        return raw.trim().uppercase()
    }

    fun normalizeContact(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.contains("@")) {
            trimmed.lowercase()
        } else {
            trimmed.replace(Regex("[\\s\\-()]"), "")
        }
    }

    fun isEmail(raw: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(raw.trim()).matches()
    }
}
