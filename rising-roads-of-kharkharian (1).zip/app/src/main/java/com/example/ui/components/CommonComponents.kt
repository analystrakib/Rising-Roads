package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberStatus
import com.example.ui.theme.*

val AppCardShape = RoundedCornerShape(12.dp)
val AppInputShape = RoundedCornerShape(12.dp)
val AppCardBorder = androidx.compose.foundation.BorderStroke(1.5.dp, NagadBorder)
val AppCardElevation = 2.dp

@Composable
fun appOutlinedTextFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NagadPrimary,
    unfocusedBorderColor = InputBorder,
    disabledBorderColor = NagadBorder,
    errorBorderColor = NagadDanger,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White,
    disabledContainerColor = NagadVeryLightBg,
    focusedTextColor = NagadMainText,
    unfocusedTextColor = NagadMainText,
    focusedLabelColor = NagadPrimary,
    unfocusedLabelColor = NagadSecondaryText,
    focusedPlaceholderColor = NagadSecondaryText,
    unfocusedPlaceholderColor = NagadSecondaryText,
    focusedLeadingIconColor = NagadPrimary,
    unfocusedLeadingIconColor = NagadSecondaryText,
    focusedTrailingIconColor = NagadSecondaryText,
    unfocusedTrailingIconColor = NagadSecondaryText,
    cursorColor = NagadPrimary
)

fun appInputTextStyle(fontSize: androidx.compose.ui.unit.TextUnit = 14.sp): TextStyle = TextStyle(
    fontFamily = InterFontFamily,
    fontSize = fontSize,
    fontWeight = FontWeight.Medium,
    fontFeatureSettings = TABULAR_NUMBERS,
    color = NagadMainText
)

@Composable
fun appSolidButtonColors(containerColor: Color = NagadPrimary): ButtonColors =
    ButtonDefaults.buttonColors(
        containerColor = containerColor,
        contentColor = Color.White,
        disabledContainerColor = containerColor.copy(alpha = 0.45f),
        disabledContentColor = Color.White.copy(alpha = 0.85f)
    )

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector? = null,
    iconBgColor: Color = FintechMintTint,
    iconColor: Color = FintechPrimary,
    valueColor: Color = FintechPrimary,
    modifier: Modifier = Modifier,
    trendText: String? = null,
    isPositiveTrend: Boolean = true,
    titleFontSize: androidx.compose.ui.unit.TextUnit = 11.sp,
    subtitleFontSize: androidx.compose.ui.unit.TextUnit = 11.sp,
    titleLetterSpacing: androidx.compose.ui.unit.TextUnit = 0.sp,
    cardPadding: androidx.compose.ui.unit.Dp = 16.dp,
    containerColor: Color = Color.White
) {
    val displayValue = value.replace("$", "৳")

    Card(
        modifier = modifier.testTag("stat_card_${title.lowercase().replace(" ", "_")}"),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(
            containerColor = containerColor
        ),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(cardPadding),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title.uppercase(),
                style = TextStyle(
                    fontFamily = InterFontFamily,
                    fontSize = titleFontSize,
                    color = NagadSecondaryText,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = titleLetterSpacing
                ),
                maxLines = 2,
                softWrap = true,
                overflow = TextOverflow.Clip
            )

            Text(
                text = displayValue,
                style = TextStyle(
                    fontFamily = InterFontFamily,
                    fontSize = 17.sp,
                    color = valueColor,
                    fontWeight = FontWeight.Bold,
                    fontFeatureSettings = TABULAR_NUMBERS
                ),
                maxLines = 1,
                softWrap = false
            )

            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontSize = subtitleFontSize,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        fontFeatureSettings = TABULAR_NUMBERS
                    ),
                    maxLines = Int.MAX_VALUE,
                    softWrap = true,
                    overflow = TextOverflow.Clip
                )
            }
        }
    }
}

@Composable
fun StatusBadge(
    status: MemberStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (status) {
        MemberStatus.ACTIVE -> Triple(NagadLightBg, NagadPrimary, "Active")
        MemberStatus.WARNING -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "Warning")
        MemberStatus.RED_ALERT -> Triple(Color(0xFFFEE2E2), NagadDanger, "RED ALERT")
    }

    Surface(
        modifier = modifier.testTag("status_badge_${status.name.lowercase()}"),
        shape = RoundedCornerShape(20.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.35f))
    ) {
        Text(
            text = label,
            fontFamily = InterFontFamily,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun MemberAvatar(
    name: String,
    id: Int,
    size: Int = 44,
    photoUri: String? = null,
    modifier: Modifier = Modifier
) {
    val colors = listOf(
        Color(0xFF1E3A8A),
        Color(0xFF0891B2),
        Color(0xFF059669),
        Color(0xFFD97706),
        Color(0xFF7C3AED),
        Color(0xFFDB2777),
        Color(0xFF0D9488),
        Color(0xFF4F46E5)
    )
    val color = colors[id % colors.size]
    val initials = name.split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .joinToString("")

    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size / 4).dp))
            .background(color),
        contentAlignment = Alignment.Center
    ) {
        if (!photoUri.isNullOrBlank()) {
            coil.compose.AsyncImage(
                model = photoUri,
                contentDescription = "$name's photo",
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.size(size.dp)
            )
        } else {
            Text(
                text = initials,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size * 0.36f).sp
            )
        }
    }
}

@Composable
fun RedAlertBanner(
    alertMembers: List<String>,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(visible = alertMembers.isNotEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("red_alert_banner"),
            shape = AppCardShape,
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFCA5A5)),
            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "RED ALERT WARNING",
                    color = RedAlert,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${alertMembers.joinToString(", ")} have 3+ consecutive unpaid months!",
                    color = Color(0xFF991B1B),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
