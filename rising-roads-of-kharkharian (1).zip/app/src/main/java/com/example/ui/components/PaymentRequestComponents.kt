package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminAlertEmailSettings
import com.example.data.model.MemberDueReminder
import com.example.data.model.OfficialPaymentAccounts
import com.example.data.model.PaymentRequest
import com.example.pdf.PdfReceiptGenerator
import com.example.util.AdminNotificationHelper
import com.example.util.CurrencyFormatter
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.TABULAR_NUMBERS
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PaymentRequestStatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val normalized = status.uppercase()
    val (bgColor, borderColor, textColor, label, icon) = when (normalized) {
        "APPROVED" -> Tuple5(
            Color(0xFFECFDF5),
            Color(0xFF6EE7B7),
            Color(0xFF059669),
            "Approved / Success",
            Icons.Default.CheckCircle
        )
        "REJECTED" -> Tuple5(
            Color(0xFFFEF2F2),
            Color(0xFFFCA5A5),
            Color(0xFFDC2626),
            "Rejected",
            Icons.Default.Cancel
        )
        else -> Tuple5(
            Color(0xFFFFFBEB),
            Color(0xFFFCD34D),
            Color(0xFFB45309),
            "Pending Verification",
            Icons.Default.HourglassTop
        )
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                color = textColor
            )
        }
    }
}

private data class Tuple5<A, B, C, D, E>(
    val a: A,
    val b: B,
    val c: C,
    val d: D,
    val e: E
)

@Composable
fun MemberPaymentRequestItemCard(
    request: PaymentRequest,
    memberPhone: String = "",
    adminFallbackName: String = "Rakib",
    adminAlertEmail: String = AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL,
    showMemberIdentity: Boolean = true,
    onProofDownloaded: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val total = request.amount + request.fine
    val fmtTotal = remember(total) { CurrencyFormatter.formatCurrency(total) }
    val submittedDateStr = remember(request.createdAt) {
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date(request.createdAt))
    }
    val reviewedDateStr = remember(request.reviewedAt) {
        request.reviewedAt?.let {
            SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date(it))
        }
    }

    Surface(
        shape = AppCardShape,
        color = NagadWhite,
        border = AppCardBorder,
        shadowElevation = AppCardElevation,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("payment_request_card_${request.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (showMemberIdentity) {
                        Text(
                            text = "${request.memberName} · RRK-${request.memberId.toString().padStart(3, '0')}",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = NagadMainText
                        )
                    }
                    Text(
                        text = "#PR-${request.id.toString().padStart(4, '0')} · ${request.month}",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (showMemberIdentity) 12.sp else 13.5.sp,
                        color = if (showMemberIdentity) NagadPrimary else NagadMainText
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))
                PaymentRequestStatusBadge(status = request.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Method: ${request.paymentMethod} · TrxID: ${request.trxId.ifBlank { "Cash" }}",
                        fontFamily = InterFontFamily,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NagadMainText
                    )
                    Text(
                        text = "Paid Date: ${request.paymentDate} · Submitted: $submittedDateStr",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText
                    )
                    if (reviewedDateStr != null) {
                        Text(
                            text = if (request.status == "APPROVED") {
                                "Verified on $reviewedDateStr by ${request.reviewedBy.ifBlank { adminFallbackName }}"
                            } else {
                                "Reviewed on $reviewedDateStr by ${request.reviewedBy.ifBlank { adminFallbackName }}"
                            },
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (request.status == "APPROVED") NagadPrimary else NagadDanger
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = fmtTotal,
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = when (request.status.uppercase()) {
                            "APPROVED" -> NagadPrimary
                            "REJECTED" -> NagadDanger
                            else -> Color(0xFFB45309)
                        }
                    )
                    if (request.fine > 0) {
                        Text(
                            text = "Base ${CurrencyFormatter.formatCurrency(request.amount)} + Fine ${CurrencyFormatter.formatCurrency(request.fine)}",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadDanger
                        )
                    }
                }
            }

            if (request.status == "REJECTED" && request.rejectionReason.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF2F2),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Reason: ${request.rejectionReason}",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        color = NagadDanger,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }

            if (request.status == "PENDING") {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        AdminNotificationHelper.launchAdminEmailFallbackIntent(
                            context = context,
                            adminEmail = adminAlertEmail,
                            memberName = request.memberName,
                            memberId = request.memberId,
                            month = request.month,
                            amount = request.amount,
                            fine = request.fine,
                            paymentMethod = request.paymentMethod,
                            trxId = request.trxId,
                            paymentDate = request.paymentDate
                        )
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.2.dp, Color(0xFFD97706)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0xFFFFFBEB),
                        contentColor = Color(0xFFB45309)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("notify_admin_email_btn_${request.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = "Notify Admin via Email",
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Notify Admin via Email",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFFB45309)
                    )
                }
            }

            if (request.status == "APPROVED") {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val (pngFile, savedToGallery) = PdfReceiptGenerator.generatePaymentProofReceiptImage(
                            context = context,
                            request = request,
                            memberPhone = memberPhone,
                            adminName = request.reviewedBy.ifBlank { adminFallbackName }
                        )
                        onProofDownloaded(
                            if (savedToGallery) {
                                "Verified Proof Receipt saved to Pictures/RisingRoads!"
                            } else {
                                "Verified Proof Receipt PNG generated!"
                            }
                        )
                        PdfReceiptGenerator.shareImage(
                            context = context,
                            file = pngFile,
                            title = "Save or Share Payment Proof Receipt (.png)"
                        )
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = RoundedCornerShape(10.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_proof_png_btn_${request.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download Proof Receipt Image",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Download Proof Receipt (.png)",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun EditOfficialPaymentAccountsDialog(
    currentAccounts: OfficialPaymentAccounts,
    onDismiss: () -> Unit,
    onSave: (bkash: String, nagad: String, bank: String) -> Unit
) {
    var bkash by remember(currentAccounts) { mutableStateOf(currentAccounts.bkash) }
    var nagad by remember(currentAccounts) { mutableStateOf(currentAccounts.nagad) }
    var bank by remember(currentAccounts) { mutableStateOf(currentAccounts.bank) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        title = {
            Text(
                text = "Edit Official Payment Accounts",
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                color = NagadMainText
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = bkash,
                    onValueChange = { bkash = it },
                    label = { Text("Personal bKash Number & Note", fontFamily = InterFontFamily) },
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nagad,
                    onValueChange = { nagad = it },
                    label = { Text("Personal Nagad Number & Note", fontFamily = InterFontFamily) },
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = bank,
                    onValueChange = { bank = it },
                    label = { Text("Bank Account Details", fontFamily = InterFontFamily) },
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(bkash, nagad, bank) },
                colors = appSolidButtonColors(NagadPrimary),
                modifier = Modifier.height(48.dp)
            ) {
                Text(
                    text = "Save Accounts",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
            }
        }
    )
}

@Composable
fun MemberDueReminderBanner(
    reminder: MemberDueReminder,
    onPayNow: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bgColor, borderColor, titleColor, badgeColor) = when (reminder.dayOfMonth) {
        14 -> Tuple4(
            Color(0xFFFEF2F2),
            Color(0xFFFCA5A5),
            Color(0xFF991B1B),
            Color(0xFFDC2626)
        )
        8 -> Tuple4(
            Color(0xFFFFFBEB),
            Color(0xFFFCD34D),
            Color(0xFF92400E),
            Color(0xFFD97706)
        )
        else -> Tuple4(
            Color(0xFFECFDF5),
            Color(0xFF6EE7B7),
            Color(0xFF065F46),
            NagadPrimary
        )
    }

    Surface(
        shape = AppCardShape,
        color = bgColor,
        border = BorderStroke(1.5.dp, borderColor),
        shadowElevation = AppCardElevation,
        modifier = modifier
            .fillMaxWidth()
            .testTag("member_due_reminder_banner_${reminder.dayOfMonth}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = badgeColor
                    ) {
                        Text(
                            text = when (reminder.dayOfMonth) {
                                1 -> "1st of Month"
                                8 -> "8th of Month"
                                else -> "14th of Month"
                            },
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${reminder.memberName} (${reminder.rrkId})",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = titleColor
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("dismiss_due_reminder_btn_${reminder.dayOfMonth}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss due reminder",
                        tint = titleColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = reminder.message,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Cycle: ${reminder.billingMonth}" + if (reminder.isTestPreview) " · Preview Mode" else "",
                    fontFamily = InterFontFamily,
                    fontSize = 10.5.sp,
                    color = titleColor.copy(alpha = 0.8f)
                )
                Button(
                    onClick = onPayNow,
                    colors = appSolidButtonColors(badgeColor),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("pay_now_due_reminder_btn_${reminder.dayOfMonth}")
                ) {
                    Text(
                        text = "Pay Now →",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

private data class Tuple4<A, B, C, D>(
    val a: A,
    val b: B,
    val c: C,
    val d: D
)

