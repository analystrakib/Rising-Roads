package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Executive Fintech Theme Palette
val NagadPrimary = Color(0xFF16834B)         // Primary Green: #16834B
val NagadDeepGreen = Color(0xFF096638)       // Deep Green: #096638
val NagadLightBg = Color(0xFFF3FAF4)         // Light Green Tint: #F3FAF4
val NagadVeryLightBg = Color(0xFFF1F5F9)     // Cool Slate Gray Canvas: #F1F5F9
val NagadWhite = Color(0xFFFFFFFF)           // Pure White Card Surface: #FFFFFF
val NagadMainText = Color(0xFF0F172A)        // Deep Obsidian: #0F172A
val NagadSecondaryText = Color(0xFF334155)   // Crisp Dark Slate: #334155
val Slate200 = Color(0xFFCBD5E1)             // Crisp Slate Card Border: #CBD5E1
val NagadBorder = Color(0xFFCBD5E1)          // Crisp 1.5dp Card Border: #CBD5E1
val InputBorder = Color(0xFFCBD5E1)          // Crisp Input Field Border: #CBD5E1
val NagadSuccess = Color(0xFF16834B)         // Success: #16834B
val NagadWarning = Color(0xFFD97706)         // Accessible Amber: #D97706
val NagadDanger = Color(0xFFDC2626)          // Accessible Crimson: #DC2626
val TopBarMintBg = Color(0xFFD1FAE5)         // Soft Emerald-Mint Header Tint: #D1FAE5
val TopBarMintBorder = Color(0xFF6EE7B7)     // Clean Emerald Bottom Border: #6EE7B7
val TopBarForestCharcoal = Color(0xFF064E3B) // Crisp Dark Forest-Green: #064E3B

// Fintech Aliases mapped to executive fintech design system
val FintechPrimary = NagadPrimary
val FintechDeepGreen = NagadDeepGreen
val FintechBackground = NagadVeryLightBg
val FintechSurface = NagadWhite
val FintechMintTint = NagadLightBg
val FintechBorder = NagadBorder
val FintechTextPrimary = NagadMainText
val FintechTextSecondary = NagadSecondaryText
val FintechDuesRed = NagadDanger
val FintechAmber = NagadWarning

// Base theme variables
val Background = NagadVeryLightBg
val Surface = NagadWhite
val Border = NagadBorder
val Primary = NagadPrimary
val Emerald = NagadPrimary
val Crimson = NagadDanger
val Amber = NagadWarning
val White = NagadWhite
val Slate = NagadSecondaryText
val SlateDark = Color(0xFF0F172A)
val SlateDarker = NagadMainText

// Backward-compatible color aliases
val DeepNavy = NagadDeepGreen
val RoyalBlue = NagadPrimary
val RoyalBlueLight = NagadPrimary
val Gold = NagadWarning
val GoldDark = Color(0xFFC7841C)
val EmeraldGreen = NagadPrimary
val EmeraldGreenLight = Color(0xFF28A745)
val RedAlert = NagadDanger
val RedAlertLight = Color(0xFFE57373)

val GreenCardBg = NagadLightBg
val BlueCardBg = Color(0xFFE8F4F8)
val AmberCardBg = Color(0xFFFEF7E6)
val RedCardBg = Color(0xFFFDF0F0)
val PurpleCardBg = Color(0xFFF5F0FA)
