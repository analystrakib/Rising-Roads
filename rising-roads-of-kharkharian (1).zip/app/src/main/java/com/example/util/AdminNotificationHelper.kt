package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AdminAlertEmailSettings
import com.example.data.model.MemberDueReminder
import com.example.data.model.MemberWithStats
import com.example.data.repository.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object AdminNotificationHelper {

    private const val CHANNEL_ID = "rrk_payment_proof_alerts"
    private const val CHANNEL_NAME = "RRK Payment Proof Alerts"
    private const val CHANNEL_DESC = "Live notifications when members submit payment proofs for verification"

    fun ensureNotificationChannel(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    ?: return
                val existing = manager.getNotificationChannel(CHANNEL_ID)
                if (existing == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        CHANNEL_NAME,
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = CHANNEL_DESC
                        enableVibration(true)
                    }
                    manager.createNotificationChannel(channel)
                }
            }
        } catch (_: Throwable) {
            // Gracefully ignore notification channel errors on unsupported environments
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                NotificationManagerCompat.from(context).areNotificationsEnabled()
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun postNewPaymentProofNotification(
        context: Context,
        requestId: Int,
        memberId: Int,
        memberName: String,
        month: String,
        amount: Int,
        fine: Int,
        paymentMethod: String,
        trxId: String
    ) {
        runCatching {
            if (!hasNotificationPermission(context)) return
            ensureNotificationChannel(context)

            val rrkId = "RRK-${memberId.toString().padStart(3, '0')}"
            val total = amount + fine
            val fmtTotal = CurrencyFormatter.formatNumber(total)
            val cleanTrx = trxId.ifBlank { "Cash" }

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_admin_queue", true)
            }
            val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            val pendingIntent = PendingIntent.getActivity(
                context,
                requestId,
                openIntent,
                pendingIntentFlags
            )

            val title = "🔔 New Payment Proof Pending Verification"
            val shortText = "$memberName ($rrkId) · $month · ৳$fmtTotal via $paymentMethod"
            val bigText = buildString {
                appendLine("$memberName ($rrkId) submitted a payment proof for $month.")
                appendLine("Amount: ৳$fmtTotal (Deposit ৳$amount + Fine ৳$fine)")
                append("Method: $paymentMethod · TrxID: $cleanTrx — Tap to review & approve.")
            }

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(shortText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            NotificationManagerCompat.from(context).notify(2000 + requestId, notification)
        }
    }

    /**
     * Sends an automatic instant email alert to the Admin via EmailJS REST API if Service ID,
     * Template ID, and Public Key are configured.
     */
    suspend fun sendEmailJsAlert(
        settings: AdminAlertEmailSettings,
        memberId: Int,
        memberName: String,
        month: String,
        amount: Int,
        fine: Int,
        paymentMethod: String,
        trxId: String,
        paymentDate: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (!settings.isEmailJsConfigured) return@withContext false

        runCatching {
            val rrkId = "RRK-${memberId.toString().padStart(3, '0')}"
            val total = amount + fine
            val cleanTrx = trxId.ifBlank { "Cash / N/A" }
            val (subject, body) = buildAdminEmailSubjectAndBody(
                memberId = memberId,
                memberName = memberName,
                month = month,
                amount = amount,
                fine = fine,
                paymentMethod = paymentMethod,
                trxId = cleanTrx,
                paymentDate = paymentDate
            )

            val templateParams = JSONObject().apply {
                put("to_email", settings.adminAlertEmail.ifBlank { AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL })
                put("admin_email", settings.adminAlertEmail.ifBlank { AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL })
                put("member_name", memberName)
                put("rrk_id", rrkId)
                put("billing_month", month)
                put("deposit_amount", "৳$amount")
                put("fine_amount", "৳$fine")
                put("total_amount", "৳$total")
                put("payment_method", paymentMethod)
                put("trx_id", cleanTrx)
                put("payment_date", paymentDate)
                put("subject", subject)
                put("message", body)
            }

            val payload = JSONObject().apply {
                put("service_id", settings.emailJsServiceId.trim())
                put("template_id", settings.emailJsTemplateId.trim())
                put("user_id", settings.emailJsPublicKey.trim())
                put("template_params", templateParams)
            }

            val url = URL("https://api.emailjs.com/api/v1.0/email/send")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        }.getOrDefault(false)
    }

    fun buildAdminEmailSubjectAndBody(
        memberId: Int,
        memberName: String,
        month: String,
        amount: Int,
        fine: Int,
        paymentMethod: String,
        trxId: String,
        paymentDate: String
    ): Pair<String, String> {
        val rrkId = "RRK-${memberId.toString().padStart(3, '0')}"
        val total = amount + fine
        val fmtDeposit = CurrencyFormatter.formatNumber(amount)
        val fmtFine = CurrencyFormatter.formatNumber(fine)
        val fmtTotal = CurrencyFormatter.formatNumber(total)
        val cleanTrx = trxId.trim().ifBlank { "Cash / N/A" }

        val subject = "RRK Payment Proof Pending Verification — $memberName ($rrkId) · $month (৳$fmtTotal)"
        val body = """
            Hello Admin,

            A new payment proof has been submitted on Rising Roads Of Kharkharian (RRK) and is pending verification:

            • Member Name: $memberName
            • RRK ID: $rrkId
            • Billing Month: $month
            • Deposit Amount: ৳$fmtDeposit
            • Mandatory Fine: ৳$fmtFine
            • Total Proof Amount (Deposit + Fine): ৳$fmtTotal
            • Payment Method: $paymentMethod
            • TrxID / Reference: $cleanTrx
            • Payment Date: $paymentDate

            Please open the Admin Panel → Payment Approval Queue to review and approve this submission.

            — Rising Roads Of Kharkharian (RRK) System Alert
        """.trimIndent()

        return subject to body
    }

    /**
     * Opens the user's email client with a pre-filled `mailto:` message to the Admin Alert Email
     * containing Member Name, RRK ID, Billing Month, Deposit + Fine Amount, Payment Method, and TrxID.
     */
    fun launchAdminEmailFallbackIntent(
        context: Context,
        adminEmail: String,
        memberId: Int,
        memberName: String,
        month: String,
        amount: Int,
        fine: Int,
        paymentMethod: String,
        trxId: String,
        paymentDate: String
    ) {
        val targetEmail = adminEmail.trim().ifBlank { AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL }
        val (subject, body) = buildAdminEmailSubjectAndBody(
            memberId = memberId,
            memberName = memberName,
            month = month,
            amount = amount,
            fine = fine,
            paymentMethod = paymentMethod,
            trxId = trxId,
            paymentDate = paymentDate
        )

        runCatching {
            val mailtoUri = Uri.Builder()
                .scheme("mailto")
                .opaquePart(targetEmail)
                .appendQueryParameter("subject", subject)
                .appendQueryParameter("body", body)
                .build()

            val sendToIntent = Intent(Intent.ACTION_SENDTO, mailtoUri).apply {
                putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            try {
                context.startActivity(sendToIntent)
            } catch (_: Exception) {
                val fallbackSend = Intent(Intent.ACTION_SEND).apply {
                    type = "message/rfc822"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                context.startActivity(
                    Intent.createChooser(fallbackSend, "Notify Admin via Email").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }
        }.onFailure {
            runCatching {
                Toast.makeText(context, "Unable to open email app for $targetEmail", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Calculates exact pending Capital Due, Accrued Fine, and Total Payable Balance for a member
     * and generates the scheduled reminder for the 1st, 8th, or 14th of the month.
     * Returns null if totalPayable <= 0 (৳0 due -> zero due alerts).
     */
    fun buildReminderForDay(
        stats: MemberWithStats?,
        dayOfMonth: Int,
        billingMonth: String,
        paymentDate: String,
        isTestPreview: Boolean = false
    ): MemberDueReminder? {
        if (stats == null) return null
        if (dayOfMonth !in listOf(1, 8, 14)) return null

        val capitalDue = stats.totalDue.coerceAtLeast(0)
        val accruedFine = AppRepository.calculateMandatoryFineDue(
            stats = stats,
            selectedMonth = billingMonth,
            paymentDate = paymentDate
        ).coerceAtLeast(0)
        val totalPayable = capitalDue + accruedFine
        if (totalPayable <= 0) return null

        val fmtCapitalDue = CurrencyFormatter.formatNumber(capitalDue)
        val fmtFine = CurrencyFormatter.formatNumber(accruedFine)
        val fmtTotal = CurrencyFormatter.formatNumber(totalPayable)
        val rrkId = "RRK-${stats.member.id.toString().padStart(3, '0')}"

        val (stageLabel, message) = when (dayOfMonth) {
            1 -> "1st of the Month (Month Start Reminder)" to
                "📅 Monthly Contribution Reminder: Your current due is ৳$fmtCapitalDue (Total Payable: ৳$fmtTotal). Please deposit before the 15th to avoid late fines."
            8 -> "8th of the Month (Mid-Month Reminder)" to
                "⏰ Mid-Month Payment Reminder: 7 days left before the 15th deadline. Your pending balance is ৳$fmtTotal (Capital: ৳$fmtCapitalDue, Fine: ৳$fmtFine)."
            else -> "14th of the Month (Final Warning — Last Day Before Fine)" to
                "🚨 Final Reminder: Tomorrow is the 15th deadline! Pay your pending ৳$fmtTotal today to avoid an automatic ৳100 late fine."
        }

        return MemberDueReminder(
            id = "due_reminder_${stats.member.id}_${billingMonth.replace(" ", "_")}_day_$dayOfMonth",
            dayOfMonth = dayOfMonth,
            stageLabel = stageLabel,
            memberId = stats.member.id,
            memberName = stats.member.name,
            rrkId = rrkId,
            billingMonth = billingMonth,
            capitalDue = capitalDue,
            accruedFine = accruedFine,
            totalPayable = totalPayable,
            message = message,
            isTestPreview = isTestPreview
        )
    }

    fun postMemberDueReminderNotification(
        context: Context,
        reminder: MemberDueReminder
    ) {
        runCatching {
            if (!hasNotificationPermission(context)) return
            ensureNotificationChannel(context)

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_pay_submit", true)
            }
            val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            val notificationId = 5000 + (reminder.memberId * 20) + reminder.dayOfMonth
            val pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                openIntent,
                pendingIntentFlags
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("${reminder.stageLabel} · ${reminder.memberName}")
                .setContentText(reminder.message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(reminder.message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            NotificationManagerCompat.from(context).notify(notificationId, notification)
        }
    }
}

