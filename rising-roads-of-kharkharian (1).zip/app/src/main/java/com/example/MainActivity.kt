package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ContactMail
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.configureAppCheck
import com.example.data.model.MemberStatus
import com.example.ui.MainViewModel
import com.example.ui.components.AskRrkAiFab
import com.example.ui.components.MemberDueReminderBanner
import com.example.ui.components.RrkAiChatModal
import com.example.ui.components.appSolidButtonColors
import com.example.util.AdminNotificationHelper
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AppLockAuthGate
import com.example.ui.screens.CapitalContributionsScreen
import com.example.ui.screens.ContactScreen
import com.example.ui.screens.ContributionsScreen
import com.example.ui.screens.CustomPageDetailScreen
import com.example.ui.screens.CostSummaryScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DepositHistoryScreen
import com.example.ui.screens.FinancialDashboardScreen
import com.example.ui.screens.InvestmentsScreen
import com.example.ui.screens.MemberAuthScreen
import com.example.ui.screens.MemberIdeasScreen
import com.example.ui.screens.MemberProfileScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.MissionScreen
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadDeepGreen
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.RisingRoadsTheme
import com.example.ui.theme.TABULAR_NUMBERS
import com.example.ui.theme.TopBarForestCharcoal
import com.example.ui.theme.TopBarMintBorder
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String) {
    object Dashboard : Screen("dashboard", "Dashboard")
    object Members : Screen("members", "Members")
    object MemberProfile : Screen("member_profile", "Member Profile")
    object Contributions : Screen("contributions", "Contributions")
    object CapitalContributions : Screen("capital_contributions", "Capital Portfolios")
    object Deposits : Screen("deposits", "Deposit History")
    object FinancialDashboard : Screen("financial", "Financial Dashboard")
    object CostSummary : Screen("costs", "Cost Summary")
    object Investments : Screen("investments", "Investments")
    object MemberIdeas : Screen("member_ideas", "Member Ideas")
    object MemberAuth : Screen("member_auth", "Member Access")
    object Admin : Screen("admin", "Admin Panel")
    object About : Screen("about", "About Us")
    object Mission : Screen("mission", "Mission & Vision")
    object Contact : Screen("contact", "Contact Us")
    data class CustomPage(val pageId: Int) : Screen("custom_page_$pageId", "Custom Page")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            RisingRoadsTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    MainApp()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: MainViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    var selectedMemberId by remember { mutableIntStateOf(1) }
    var contributionsInitialTab by remember { mutableIntStateOf(0) }
    var showAiAssistantModal by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val memberSession by viewModel.memberSession.collectAsState()
    val rememberedSession by viewModel.rememberedSession.collectAsState()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsState()
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val pendingPaymentRequestsCount by viewModel.pendingPaymentRequestsCount.collectAsState()
    val activeMemberDueReminders by viewModel.activeMemberDueReminders.collectAsState()
    val configs by viewModel.configs.collectAsState()
    val developerCredit = remember(configs) {
        configs.find { it.key == "developer_credit" }?.value?.trim()?.takeIf { it.isNotEmpty() }
            ?: "Developed by Rakib"
    }
    var showNotificationBellMenu by remember { mutableStateOf(false) }
    var notifiedReminderIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    val activeMemberName = when {
        memberSession.isLoggedIn && memberSession.fullName.isNotBlank() -> memberSession.fullName
        rememberedSession.fullName.isNotBlank() -> rememberedSession.fullName
        isAdminLoggedIn -> adminUsername
        else -> "Member"
    }
    val activeMemberId = when {
        memberSession.isLoggedIn && memberSession.rrkMemberId.isNotBlank() -> memberSession.rrkMemberId
        rememberedSession.rrkMemberId.isNotBlank() -> rememberedSession.rrkMemberId
        isAdminLoggedIn -> "ADMIN"
        else -> "RRK"
    }

    val totalMembersCount = membersWithStats.size
    val redAlertCount = remember(membersWithStats) {
        membersWithStats.count { it.status == MemberStatus.RED_ALERT }
    }

    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(isAdminLoggedIn, memberSession.isLoggedIn) {
        AdminNotificationHelper.ensureNotificationChannel(context)
        if ((isAdminLoggedIn || memberSession.isLoggedIn) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!AdminNotificationHelper.hasNotificationPermission(context)) {
                runCatching {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }

    LaunchedEffect(activeMemberDueReminders) {
        activeMemberDueReminders.forEach { reminder ->
            if (!reminder.isTestPreview && reminder.id !in notifiedReminderIds) {
                notifiedReminderIds = notifiedReminderIds + reminder.id
                AdminNotificationHelper.postMemberDueReminderNotification(context, reminder)
            }
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.toastEvent.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    if (!isAppUnlocked) {
        AppLockAuthGate(viewModel = viewModel)
        return
    }

    if (currentScreen != Screen.Dashboard) {
        BackHandler {
            currentScreen = if (currentScreen == Screen.MemberProfile) {
                Screen.Members
            } else {
                Screen.Dashboard
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(300.dp)
                    .background(Color.White),
                drawerContainerColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 16.dp, horizontal = 12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NagadLightBg,
                            border = BorderStroke(1.dp, NagadBorder),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo),
                                contentDescription = "Rising Roads Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Rising Roads",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText,
                            fontSize = 16.sp
                        )
                    }

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    Text(
                        text = "MAIN",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadSecondaryText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )

                    DrawerItem(
                        label = "Dashboard",
                        icon = Icons.Default.Home,
                        selected = currentScreen == Screen.Dashboard,
                        onClick = {
                            currentScreen = Screen.Dashboard
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Members ($totalMembersCount)",
                        icon = Icons.Default.Groups,
                        selected = currentScreen == Screen.Members || currentScreen == Screen.MemberProfile,
                        onClick = {
                            currentScreen = Screen.Members
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Contributions",
                        icon = Icons.Default.Payments,
                        selected = currentScreen == Screen.Contributions,
                        onClick = {
                            contributionsInitialTab = 0
                            currentScreen = Screen.Contributions
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Capital Portfolios ($totalMembersCount)",
                        icon = Icons.Default.Payments,
                        selected = currentScreen == Screen.CapitalContributions,
                        onClick = {
                            currentScreen = Screen.CapitalContributions
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Deposit History",
                        icon = Icons.Default.History,
                        selected = currentScreen == Screen.Deposits,
                        onClick = {
                            currentScreen = Screen.Deposits
                            scope.launch { drawerState.close() }
                        }
                    )

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )

                    Text(
                        text = "FINANCE & ENTERPRISE",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadSecondaryText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )

                    DrawerItem(
                        label = "Financial Dashboard",
                        icon = Icons.Default.AccountBalance,
                        selected = currentScreen == Screen.FinancialDashboard,
                        onClick = {
                            currentScreen = Screen.FinancialDashboard
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Cost Summary",
                        icon = Icons.Default.MoneyOff,
                        selected = currentScreen == Screen.CostSummary,
                        onClick = {
                            currentScreen = Screen.CostSummary
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Investments",
                        icon = Icons.Default.TrendingUp,
                        selected = currentScreen == Screen.Investments,
                        onClick = {
                            currentScreen = Screen.Investments
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Member Ideas",
                        icon = Icons.Default.Lightbulb,
                        selected = currentScreen == Screen.MemberIdeas,
                        onClick = {
                            currentScreen = Screen.MemberIdeas
                            scope.launch { drawerState.close() }
                        }
                    )

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )

                    Text(
                        text = "ORGANIZATION",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadSecondaryText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )

                    DrawerItem(
                        label = "About Us",
                        icon = Icons.Default.Info,
                        selected = currentScreen == Screen.About,
                        onClick = {
                            currentScreen = Screen.About
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Mission & Vision",
                        icon = Icons.Default.Flag,
                        selected = currentScreen == Screen.Mission,
                        onClick = {
                            currentScreen = Screen.Mission
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Contact Us",
                        icon = Icons.Default.ContactMail,
                        selected = currentScreen == Screen.Contact,
                        onClick = {
                            currentScreen = Screen.Contact
                            scope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        label = "Admin Panel",
                        icon = Icons.Default.AdminPanelSettings,
                        selected = currentScreen == Screen.Admin,
                        badgeCount = pendingPaymentRequestsCount,
                        onClick = {
                            currentScreen = Screen.Admin
                            scope.launch { drawerState.close() }
                        }
                    )

                    val customPages by viewModel.customPages.collectAsState()
                    customPages.filter { it.isVisible }.forEach { page ->
                        val pageIcon = when (page.iconName.lowercase()) {
                            "flag", "mission" -> Icons.Default.Flag
                            "groups", "team", "members" -> Icons.Default.Groups
                            "star", "idea", "tips" -> Icons.Default.Lightbulb
                            "history" -> Icons.Default.History
                            "contact", "mail" -> Icons.Default.ContactMail
                            else -> Icons.Default.Info
                        }
                        DrawerItem(
                            label = page.title,
                            icon = pageIcon,
                            selected = currentScreen is Screen.CustomPage && (currentScreen as Screen.CustomPage).pageId == page.id,
                            onClick = {
                                currentScreen = Screen.CustomPage(page.id)
                                scope.launch { drawerState.close() }
                            }
                        )
                    }

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )

                    // Global Sync / Refresh All Data Button
                    Button(
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.refreshData()
                        },
                        enabled = !isRefreshing,
                        shape = RoundedCornerShape(12.dp),
                        colors = appSolidButtonColors(NagadPrimary),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .height(48.dp)
                            .testTag("sidebar_refresh_sync_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Refresh and sync all data",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isRefreshing) "Syncing All Data..." else "Refresh / Sync All Data",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }

                    // Logged-in Member Account Card (Bottom Footer)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NagadWhite,
                        border = BorderStroke(1.5.dp, NagadBorder),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            val initials = activeMemberName
                                .split(" ")
                                .filter { it.isNotBlank() }
                                .take(2)
                                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                                .joinToString("")
                                .ifEmpty { "RR" }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(NagadPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = initials,
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = activeMemberName,
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.5.sp,
                                            color = NagadMainText,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = NagadWhite,
                                            border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.35f))
                                        ) {
                                            Text(
                                                text = "ID: $activeMemberId",
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp,
                                                color = NagadDeepGreen,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    viewModel.lockApp()
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, NagadDanger.copy(alpha = 0.45f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = NagadWhite,
                                    contentColor = NagadDanger
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.fillMaxWidth().height(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = NagadDanger,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Lock / Logout",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = NagadDanger
                                )
                            }
                        }
                    }

                    val currentYear = remember {
                        java.util.Calendar.getInstance().get(java.util.Calendar.YEAR).coerceAtLeast(2026)
                    }
                    Text(
                        text = "© 2025–$currentYear Rising Roads Of Kharkharian",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 10.5.sp,
                        color = NagadSecondaryText,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Text(
                        text = developerCredit,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = NagadMainText,
                        lineHeight = 16.sp,
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 2.dp)
                            .testTag("sidebar_developer_credit")
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentScreen.title,
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = NagadMainText
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu",
                                tint = NagadMainText
                            )
                        }
                    },
                    actions = {
                        val dueRemindersCount = activeMemberDueReminders.size
                        val totalBellBadgeCount = dueRemindersCount + pendingPaymentRequestsCount
                        val hasAnyAlert = totalBellBadgeCount > 0

                        Box {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (hasAnyAlert) Color(0xFFFFFBEB) else NagadWhite,
                                border = BorderStroke(
                                    1.5.dp,
                                    if (hasAnyAlert) Color(0xFFF59E0B) else NagadBorder
                                ),
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { showNotificationBellMenu = true }
                                    .testTag("admin_header_notification_bell")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (hasAnyAlert) {
                                            Icons.Default.NotificationsActive
                                        } else {
                                            Icons.Default.Notifications
                                        },
                                        contentDescription = "Notifications & Due Reminders",
                                        tint = if (hasAnyAlert) Color(0xFFD97706) else NagadSecondaryText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    if (hasAnyAlert) {
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Surface(
                                            shape = RoundedCornerShape(999.dp),
                                            color = Color(0xFFD97706)
                                        ) {
                                            Text(
                                                text = "$totalBellBadgeCount",
                                                fontFamily = InterFontFamily,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            DropdownMenu(
                                expanded = showNotificationBellMenu,
                                onDismissRequest = { showNotificationBellMenu = false },
                                containerColor = Color.White,
                                modifier = Modifier
                                    .width(340.dp)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("header_notification_bell_dropdown")
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Notifications & Due Reminders",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = NagadMainText
                                        )
                                        Text(
                                            text = "$totalBellBadgeCount Active",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            color = if (hasAnyAlert) Color(0xFFD97706) else NagadSecondaryText
                                        )
                                    }

                                    HorizontalDivider(color = NagadBorder)

                                    if (pendingPaymentRequestsCount > 0) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color(0xFFFFFBEB),
                                            border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    showNotificationBellMenu = false
                                                    currentScreen = Screen.Admin
                                                }
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    text = "🔔 New Payment Proof Pending Verification — Review Now",
                                                    fontFamily = InterFontFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.5.sp,
                                                    color = Color(0xFF92400E)
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "$pendingPaymentRequestsCount pending payment proof(s) awaiting Admin verification →",
                                                    fontFamily = InterFontFamily,
                                                    fontSize = 10.5.sp,
                                                    color = NagadPrimary,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }

                                    if (activeMemberDueReminders.isNotEmpty()) {
                                        activeMemberDueReminders.forEach { reminder ->
                                            MemberDueReminderBanner(
                                                reminder = reminder,
                                                onPayNow = {
                                                    showNotificationBellMenu = false
                                                    contributionsInitialTab = 2
                                                    currentScreen = Screen.Contributions
                                                },
                                                onDismiss = {
                                                    viewModel.dismissDueReminder(reminder.id)
                                                }
                                            )
                                        }
                                    } else if (pendingPaymentRequestsCount == 0) {
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = NagadVeryLightBg,
                                            border = BorderStroke(1.5.dp, NagadBorder),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "0 Due Alerts — No pending monthly due reminders right now.",
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 11.5.sp,
                                                color = NagadSecondaryText,
                                                modifier = Modifier.padding(12.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        if (redAlertCount > 0) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFFDF0F0),
                                border = BorderStroke(1.dp, NagadDanger),
                                modifier = Modifier.padding(end = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = NagadDanger,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "$redAlertCount ALERT",
                                        fontFamily = InterFontFamily,
                                        color = NagadDanger,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        style = TextStyle(fontFeatureSettings = TABULAR_NUMBERS)
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        scrolledContainerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = NagadWhite,
                    border = BorderStroke(1.dp, NagadBorder),
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    NavigationBar(
                        containerColor = NagadWhite,
                        tonalElevation = 0.dp
                    ) {
                        val navItems = listOf(
                            Triple(Screen.Dashboard, Icons.Default.Home, "Dashboard"),
                            Triple(Screen.Members, Icons.Default.Groups, "Members"),
                            Triple(Screen.Contributions, Icons.Default.Payments, "Contribs"),
                            Triple(Screen.FinancialDashboard, Icons.Default.AccountBalance, "Finance"),
                            Triple(Screen.Investments, Icons.Default.TrendingUp, "Investments")
                        )

                        navItems.forEach { (screen, icon, label) ->
                            val isSelected = currentScreen == screen || (screen == Screen.Members && currentScreen == Screen.MemberProfile)
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    if (screen == Screen.Contributions) {
                                        contributionsInitialTab = 0
                                    }
                                    currentScreen = screen
                                },
                                icon = {
                                    if (screen == Screen.Contributions) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(NagadPrimary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = label,
                                                tint = NagadWhite,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    } else {
                                        Icon(imageVector = icon, contentDescription = label)
                                    }
                                },
                                label = {
                                    Text(
                                        text = label,
                                        fontFamily = InterFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NagadPrimary,
                                    selectedTextColor = NagadPrimary,
                                    indicatorColor = NagadLightBg,
                                    unselectedIconColor = NagadSecondaryText,
                                    unselectedTextColor = NagadSecondaryText
                                )
                            )
                        }
                    }
                }
            },
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        containerColor = TopBarForestCharcoal,
                        contentColor = Color.White,
                        actionContentColor = TopBarMintBorder
                    ) {
                        Text(
                            text = data.visuals.message,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.5.sp,
                            color = Color.White
                        )
                    }
                }
            },
            floatingActionButton = {
                AskRrkAiFab(
                    onClick = { showAiAssistantModal = true },
                    modifier = Modifier.padding(bottom = 12.dp, end = 4.dp)
                )
            },
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(NagadVeryLightBg)
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    Screen.Dashboard -> {
                        DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToMembers = { currentScreen = Screen.Members },
                            onNavigateToMemberProfile = { id ->
                                selectedMemberId = id
                                currentScreen = Screen.MemberProfile
                            },
                            onNavigateToDeposits = { currentScreen = Screen.Deposits },
                            onNavigateToFinance = { currentScreen = Screen.FinancialDashboard },
                            onNavigateToAdminApprovalQueue = { currentScreen = Screen.Admin },
                            onNavigateToPaySubmit = {
                                contributionsInitialTab = 2
                                currentScreen = Screen.Contributions
                            }
                        )
                    }

                    Screen.Members -> {
                        MembersScreen(
                            viewModel = viewModel,
                            onNavigateToMemberProfile = { id ->
                                selectedMemberId = id
                                currentScreen = Screen.MemberProfile
                            }
                        )
                    }

                    Screen.MemberProfile -> {
                        MemberProfileScreen(
                            memberId = selectedMemberId,
                            viewModel = viewModel,
                            onBack = { currentScreen = Screen.Members }
                        )
                    }

                    Screen.Contributions -> {
                        ContributionsScreen(
                            viewModel = viewModel,
                            onNavigateToMemberProfile = { id ->
                                selectedMemberId = id
                                currentScreen = Screen.MemberProfile
                            },
                            initialTab = contributionsInitialTab
                        )
                    }

                    Screen.CapitalContributions -> {
                        CapitalContributionsScreen(
                            viewModel = viewModel,
                            onNavigateToMemberProfile = { id ->
                                selectedMemberId = id
                                currentScreen = Screen.MemberProfile
                            },
                            onPayNowClick = {
                                contributionsInitialTab = 2
                                currentScreen = Screen.Contributions
                            }
                        )
                    }

                    Screen.Deposits -> {
                        DepositHistoryScreen(
                            viewModel = viewModel,
                            onNavigateToMemberProfile = { id ->
                                selectedMemberId = id
                                currentScreen = Screen.MemberProfile
                            }
                        )
                    }

                    Screen.FinancialDashboard -> {
                        FinancialDashboardScreen(viewModel = viewModel)
                    }

                    Screen.CostSummary -> {
                        CostSummaryScreen(viewModel = viewModel)
                    }

                    Screen.Investments -> {
                        InvestmentsScreen(viewModel = viewModel)
                    }

                    Screen.MemberIdeas -> {
                        MemberIdeasScreen(
                            viewModel = viewModel,
                            onNavigateToAuth = { currentScreen = Screen.MemberAuth }
                        )
                    }

                    Screen.MemberAuth -> {
                        MemberAuthScreen(
                            viewModel = viewModel,
                            onAuthSuccess = { currentScreen = Screen.Dashboard },
                            onNavigateToIdeas = { currentScreen = Screen.MemberIdeas }
                        )
                    }

                    Screen.Admin -> {
                        if (isAdminLoggedIn) {
                            AdminPanelScreen(
                                viewModel = viewModel,
                                onNavigateToMembers = { currentScreen = Screen.Members },
                                onNavigateToDeposits = { currentScreen = Screen.Deposits },
                                onNavigateToExpenses = { currentScreen = Screen.CostSummary },
                                onNavigateToInvestments = { currentScreen = Screen.Investments },
                                onNavigateToFinance = { currentScreen = Screen.FinancialDashboard },
                                onNavigateToCustomPage = { page -> currentScreen = Screen.CustomPage(page.id) }
                            )
                        } else {
                            AdminLoginScreen(
                                viewModel = viewModel,
                                onLoginSuccess = { currentScreen = Screen.Admin }
                            )
                        }
                    }

                    Screen.About -> {
                        AboutScreen(viewModel)
                    }

                    Screen.Mission -> {
                        MissionScreen(viewModel)
                    }

                    Screen.Contact -> {
                        ContactScreen(viewModel)
                    }

                    is Screen.CustomPage -> {
                        val pageId = (currentScreen as Screen.CustomPage).pageId
                        val customPagesList by viewModel.customPages.collectAsState()
                        val page = customPagesList.find { it.id == pageId }
                        if (page != null) {
                            CustomPageDetailScreen(page = page, onBack = { currentScreen = Screen.Dashboard })
                        } else {
                            LaunchedEffect(Unit) { currentScreen = Screen.Dashboard }
                        }
                    }
                }
            }
        }

        if (showAiAssistantModal) {
            RrkAiChatModal(
                viewModel = viewModel,
                onDismiss = { showAiAssistantModal = false }
            )
        }
    }
}

@Composable
fun DrawerItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    badgeCount: Int = 0,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Text(
                text = label,
                fontFamily = InterFontFamily,
                color = if (selected) NagadPrimary else NagadMainText,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.5.sp
            )
        },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) NagadPrimary else NagadSecondaryText,
                modifier = Modifier.size(20.dp)
            )
        },
        badge = if (badgeCount > 0) {
            {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFFFBEB),
                    border = BorderStroke(1.dp, Color(0xFFFCD34D))
                ) {
                    Text(
                        text = "$badgeCount",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        color = Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }
        } else null,
        selected = selected,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = NagadLightBg,
            unselectedContainerColor = Color.Transparent
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(vertical = 2.dp)
    )
}
