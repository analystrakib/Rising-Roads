package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.MemberSessionState

class SessionManager(context: Context) {
    private val prefs: SharedPreferences? = try {
        context.applicationContext.getSharedPreferences("rising_roads_session", Context.MODE_PRIVATE)
    } catch (_: Throwable) {
        null
    }

    companion object {
        private const val KEY_IS_LOGGED_IN = "is_admin_logged_in"
        private const val KEY_ADMIN_USERNAME = "admin_username"
        private const val KEY_ADMIN_ROLE = "admin_role"

        private const val KEY_MEMBER_LOGGED_IN = "is_member_logged_in"
        private const val KEY_MEMBER_ID = "member_rrk_id"
        private const val KEY_MEMBER_NAME = "member_full_name"
        private const val KEY_MEMBER_CONTACT = "member_contact"
        private const val KEY_MEMBER_ROLE = "member_role"

        private const val KEY_REMEMBERED_ID = "remembered_rrk_id"
        private const val KEY_REMEMBERED_NAME = "remembered_full_name"
        private const val KEY_REMEMBERED_CONTACT = "remembered_contact"
        private const val KEY_REMEMBERED_ROLE = "remembered_role"
        private const val KEY_REMEMBERED_PIN_HASH = "remembered_pin_hash"
        private const val PREFIX_PIN_HASH = "member_pin_hash_"
    }

    private fun safeGetBoolean(key: String, default: Boolean): Boolean = try {
        prefs?.getBoolean(key, default) ?: default
    } catch (_: Throwable) {
        default
    }

    private fun safeGetString(key: String, default: String): String = try {
        prefs?.getString(key, default) ?: default
    } catch (_: Throwable) {
        default
    }

    private fun safeGetNullableString(key: String): String? = try {
        prefs?.getString(key, null)
    } catch (_: Throwable) {
        null
    }

    private inline fun safeEdit(block: SharedPreferences.Editor.() -> Unit) {
        try {
            prefs?.edit()?.apply {
                block()
                apply()
            }
        } catch (_: Throwable) {
            // Gracefully ignore storage quota / IO errors without crashing
        }
    }

    var isLoggedIn: Boolean
        get() = safeGetBoolean(KEY_IS_LOGGED_IN, false)
        set(value) = safeEdit { putBoolean(KEY_IS_LOGGED_IN, value) }

    var username: String
        get() = safeGetString(KEY_ADMIN_USERNAME, "admin")
        set(value) = safeEdit { putString(KEY_ADMIN_USERNAME, value) }

    var role: String
        get() = safeGetString(KEY_ADMIN_ROLE, "Admin")
        set(value) = safeEdit { putString(KEY_ADMIN_ROLE, value) }

    fun saveLogin(username: String, role: String) {
        safeEdit {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_ADMIN_USERNAME, username)
            putString(KEY_ADMIN_ROLE, role)
        }
    }

    fun logout() {
        safeEdit {
            putBoolean(KEY_IS_LOGGED_IN, false)
            remove(KEY_ADMIN_USERNAME)
            remove(KEY_ADMIN_ROLE)
        }
    }

    fun getMemberSessionState(): MemberSessionState {
        return try {
            MemberSessionState(
                isLoggedIn = safeGetBoolean(KEY_MEMBER_LOGGED_IN, false),
                rrkMemberId = safeGetString(KEY_MEMBER_ID, ""),
                fullName = safeGetString(KEY_MEMBER_NAME, ""),
                contact = safeGetString(KEY_MEMBER_CONTACT, ""),
                role = safeGetString(KEY_MEMBER_ROLE, "Member")
            )
        } catch (_: Throwable) {
            MemberSessionState()
        }
    }

    fun saveMemberLogin(
        rrkMemberId: String,
        fullName: String,
        contact: String,
        role: String = "Member"
    ) {
        safeEdit {
            putBoolean(KEY_MEMBER_LOGGED_IN, true)
            putString(KEY_MEMBER_ID, rrkMemberId)
            putString(KEY_MEMBER_NAME, fullName)
            putString(KEY_MEMBER_CONTACT, contact)
            putString(KEY_MEMBER_ROLE, role)
        }
    }

    fun logoutMember() {
        safeEdit {
            putBoolean(KEY_MEMBER_LOGGED_IN, false)
            remove(KEY_MEMBER_ID)
            remove(KEY_MEMBER_NAME)
            remove(KEY_MEMBER_CONTACT)
            remove(KEY_MEMBER_ROLE)
        }
    }

    fun getRememberedUser(): com.example.data.model.RememberedUserSession {
        return try {
            val id = safeGetString(KEY_REMEMBERED_ID, "")
            val storedPinHash = if (id.isNotBlank()) {
                safeGetNullableString("$PREFIX_PIN_HASH$id")
                    ?: safeGetString(KEY_REMEMBERED_PIN_HASH, "")
            } else {
                ""
            }
            com.example.data.model.RememberedUserSession(
                rrkMemberId = id,
                fullName = safeGetString(KEY_REMEMBERED_NAME, ""),
                contact = safeGetString(KEY_REMEMBERED_CONTACT, ""),
                role = safeGetString(KEY_REMEMBERED_ROLE, "Member"),
                pinHash = storedPinHash
            )
        } catch (_: Throwable) {
            com.example.data.model.RememberedUserSession()
        }
    }

    fun saveRememberedUser(
        rrkMemberId: String,
        fullName: String,
        contact: String,
        role: String,
        pinHash: String? = null
    ) {
        val resolvedPinHash = pinHash ?: getPinHashForMember(rrkMemberId)
        safeEdit {
            putString(KEY_REMEMBERED_ID, rrkMemberId)
            putString(KEY_REMEMBERED_NAME, fullName)
            putString(KEY_REMEMBERED_CONTACT, contact)
            putString(KEY_REMEMBERED_ROLE, role)
            putString(KEY_REMEMBERED_PIN_HASH, resolvedPinHash)
            if (pinHash != null && rrkMemberId.isNotBlank()) {
                putString("$PREFIX_PIN_HASH$rrkMemberId", pinHash)
            }
        }
    }

    fun savePinHashForMember(rrkMemberId: String, pinHash: String) {
        if (rrkMemberId.isBlank()) return
        safeEdit {
            putString("$PREFIX_PIN_HASH$rrkMemberId", pinHash)
            if (safeGetString(KEY_REMEMBERED_ID, "") == rrkMemberId) {
                putString(KEY_REMEMBERED_PIN_HASH, pinHash)
            }
        }
    }

    fun getPinHashForMember(rrkMemberId: String): String {
        if (rrkMemberId.isBlank()) return ""
        return safeGetString("$PREFIX_PIN_HASH$rrkMemberId", "")
    }

    fun clearRememberedUser() {
        safeEdit {
            remove(KEY_REMEMBERED_ID)
            remove(KEY_REMEMBERED_NAME)
            remove(KEY_REMEMBERED_CONTACT)
            remove(KEY_REMEMBERED_ROLE)
            remove(KEY_REMEMBERED_PIN_HASH)
        }
    }
}
