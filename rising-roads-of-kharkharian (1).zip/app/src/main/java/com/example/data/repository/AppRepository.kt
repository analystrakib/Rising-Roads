package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.model.ActivityLog
import com.example.data.model.AdminAlertEmailSettings
import com.example.data.model.AdminUser
import com.example.data.model.AppConfig
import com.example.data.model.CustomPage
import com.example.data.model.Deposit
import com.example.data.model.ExitedMember
import com.example.data.model.Expense
import com.example.data.model.FinancialKpi
import com.example.data.model.IdeaComment
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberAccount
import com.example.data.model.MemberIdea
import com.example.data.model.MemberIdeaWithComments
import com.example.data.model.MemberSettlement
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithCapitalContributions
import com.example.data.model.MemberWithStats
import com.example.data.model.OfficialPaymentAccounts
import com.example.data.model.PaymentRequest
import com.example.util.PasswordUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppRepository(
    private val dao: AppDao,
    private val firebaseRepo: FirebaseRepository? = null
) {

    companion object {
        /**
         * Dynamically generates chronological billing cycles ("MMM yyyy") starting from inception: May 2025
         * up to the current real-world month/year (with a minimum floor of 18 cycles through Oct 2026).
         */
        fun getActiveMonths(deposits: List<Deposit> = emptyList()): List<String> {
            val sdf = SimpleDateFormat("MMM yyyy", Locale.US)
            val cursor = Calendar.getInstance().apply {
                set(2025, Calendar.MAY, 1, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val nowCal = Calendar.getInstance()
            var targetYear = nowCal.get(Calendar.YEAR)
            var targetMonth = nowCal.get(Calendar.MONTH)

            // Ensure at least May 2025 through Oct 2026 (18 inception cycles) are always included
            if (targetYear < 2026 || (targetYear == 2026 && targetMonth < Calendar.OCTOBER)) {
                targetYear = 2026
                targetMonth = Calendar.OCTOBER
            }

            // Also check any advance/future months in deposits
            deposits.forEach { d ->
                try {
                    val date = sdf.parse(d.month)
                    if (date != null) {
                        val cal = Calendar.getInstance().apply { time = date }
                        val y = cal.get(Calendar.YEAR)
                        val m = cal.get(Calendar.MONTH)
                        if (y > targetYear || (y == targetYear && m > targetMonth)) {
                            targetYear = y
                            targetMonth = m
                        }
                    }
                } catch (e: Exception) {}
            }

            val months = mutableListOf<String>()
            while (
                cursor.get(Calendar.YEAR) < targetYear ||
                (cursor.get(Calendar.YEAR) == targetYear && cursor.get(Calendar.MONTH) <= targetMonth)
            ) {
                months.add(sdf.format(cursor.time))
                cursor.add(Calendar.MONTH, 1)
            }
            return months
        }

        /**
         * Calculates the mandatory accrued late fine due for a member:
         * - ৳100 per unpaid overdue month past the 15th deadline (after subtracting any already-settled overdue months)
         * - Plus ৳100 if the selected billing month's paymentDate is past the 15th (day > 15) and that month
         *   is not already counted in the overdue months or settled.
         */
        fun calculateMandatoryFineDue(
            stats: MemberWithStats?,
            selectedMonth: String,
            paymentDate: String
        ): Int {
            val paymentDay = paymentDate.trim().split("-").getOrNull(2)?.toIntOrNull() ?: 1
            val isPaymentDatePast15th = paymentDay > 15

            if (stats == null) {
                return if (isPaymentDatePast15th) 100 else 0
            }

            val baseOverdueFine = stats.accruedFineDue

            // Check if the selected month incurs an additional ৳100 because its payment date is past the 15th
            // and it was not already counted in effectiveOverdueMonths (e.g. current month during grace period 1..15
            // or an advance/current month when totalDue == 0).
            val isSelectedMonthAlreadyPaid = stats.paidMonths.contains(selectedMonth)
            val hasUncountedGraceMonth = stats.consecutiveUnpaidMonths > stats.effectiveOverdueMonths
            val allCurrentUnpaidMonthsSettled = stats.consecutiveUnpaidMonths > 0 &&
                stats.settledFineMonths >= stats.consecutiveUnpaidMonths

            val selectedMonthExtraFine = if (
                isPaymentDatePast15th &&
                !isSelectedMonthAlreadyPaid &&
                !allCurrentUnpaidMonthsSettled &&
                (hasUncountedGraceMonth || stats.consecutiveUnpaidMonths == 0)
            ) {
                100
            } else {
                0
            }

            return baseOverdueFine + selectedMonthExtraFine
        }
    }

    val members: Flow<List<Member>> = dao.getAllMembers()
    val deposits: Flow<List<Deposit>> = dao.getAllDeposits()
    val expenses: Flow<List<Expense>> = dao.getAllExpenses()
    val investments: Flow<List<Investment>> = dao.getAllInvestments()
    val settlements: Flow<List<MemberSettlement>> = dao.getAllSettlements()
    val admins: Flow<List<AdminUser>> = dao.getAllAdmins()
    val activityLogs: Flow<List<ActivityLog>> = dao.getAllLogs()
    val configs: Flow<List<AppConfig>> = dao.getAllConfigs()
    val paymentRequests: Flow<List<PaymentRequest>> = dao.getAllPaymentRequests()
    val exitedMembers: Flow<List<ExitedMember>> = dao.getAllExitedMembers()
    val customPages: Flow<List<CustomPage>> = dao.getAllCustomPages()
    val officialPaymentAccounts: Flow<OfficialPaymentAccounts> = configs.map { list ->
        val bkash = list.find { it.key == "pay_bkash_number" }?.value?.takeIf { it.isNotBlank() }
            ?: OfficialPaymentAccounts.DEFAULT_BKASH
        val nagad = list.find { it.key == "pay_nagad_number" }?.value?.takeIf { it.isNotBlank() }
            ?: OfficialPaymentAccounts.DEFAULT_NAGAD
        val bank = list.find { it.key == "pay_bank_details" }?.value?.takeIf { it.isNotBlank() }
            ?: OfficialPaymentAccounts.DEFAULT_BANK
        OfficialPaymentAccounts(bkash = bkash, nagad = nagad, bank = bank)
    }
    val adminAlertEmailSettings: Flow<AdminAlertEmailSettings> = configs.map { list ->
        val email = list.find { it.key == "admin_alert_email" }?.value?.takeIf { it.isNotBlank() }
            ?: AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL
        val serviceId = list.find { it.key == "emailjs_service_id" }?.value.orEmpty()
        val templateId = list.find { it.key == "emailjs_template_id" }?.value.orEmpty()
        val publicKey = list.find { it.key == "emailjs_public_key" }?.value.orEmpty()
        AdminAlertEmailSettings(
            adminAlertEmail = email,
            emailJsServiceId = serviceId,
            emailJsTemplateId = templateId,
            emailJsPublicKey = publicKey
        )
    }
    val memberAccounts: Flow<List<MemberAccount>> = dao.getAllMemberAccounts()
    val memberIdeasWithComments: Flow<List<MemberIdeaWithComments>> =
        combine(dao.getAllMemberIdeas(), dao.getAllIdeaComments()) { ideas, comments ->
            val grouped = comments.groupBy { it.ideaId }
            ideas.map { idea ->
                MemberIdeaWithComments(
                    idea = idea,
                    comments = grouped[idea.id].orEmpty()
                )
            }
        }

    private val _refreshTick = MutableStateFlow(0L)

    fun triggerRecalculation() {
        _refreshTick.value = System.currentTimeMillis()
    }

    val membersWithStats: Flow<List<MemberWithStats>> = combine(members, deposits, configs, _refreshTick) { mList, dList, cList, _ ->
        val activeMonths = getActiveMonths()
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val sdfMonth = SimpleDateFormat("MMM yyyy", Locale.US)

        mList.map { member ->
            val memberDeposits = dList.filter { it.memberId == member.id }
            val totalContribution = memberDeposits.sumOf { it.amount }
            val totalFinePaid = memberDeposits.sumOf { it.fine }

            // Strictly calculate paid months from total contribution (৳1,000/month)
            val paidMonthsCount = totalContribution / 1000
            val distinctMonths = memberDeposits.map { it.month }.distinct()
            val paidMonths = if (distinctMonths.size >= paidMonthsCount) {
                distinctMonths
            } else {
                activeMonths.take(paidMonthsCount)
            }

            val joinDate = try {
                sdfDate.parse(member.joinDate) ?: sdfDate.parse("2025-05-01")
            } catch (e: Exception) {
                sdfDate.parse("2025-05-01")
            }

            val eligibleMonths = activeMonths.filter { m ->
                try {
                    val mDate = sdfMonth.parse(m)
                    mDate != null && (mDate.after(joinDate) || sdfMonth.format(mDate) == sdfMonth.format(joinDate ?: Date()))
                } catch (e: Exception) {
                    true
                }
            }

            val monthsElapsed = eligibleMonths.size

            // Dynamic Due Calculation: Total Due = (Active Months Elapsed * ৳1,000) - Total Contribution
            val totalDue = ((monthsElapsed * 1000) - totalContribution).coerceAtLeast(0)
            val unpaidMonths = if (totalDue <= 0) 0 else ((totalDue + 999) / 1000)

            val pendingMonths = eligibleMonths.filter { !paidMonths.contains(it) }
            val currentRunningMonth = eligibleMonths.lastOrNull() ?: activeMonths.lastOrNull()

            val currentCal = Calendar.getInstance()
            val dayOfMonth = currentCal.get(Calendar.DAY_OF_MONTH)
            val isGracePeriod = dayOfMonth <= 15

            // Grace Period Check:
            // If today is between Day 1 and Day 15 of current month, and the current ongoing month is unpaid,
            // the current month is in Grace Period and not overdue yet until after the 15th cutoff.
            val isCurrentMonthUnpaid = unpaidMonths > 0 && (pendingMonths.contains(currentRunningMonth) || (monthsElapsed - paidMonthsCount == unpaidMonths))
            val effectiveOverdueMonths = if (isGracePeriod && isCurrentMonthUnpaid) {
                (unpaidMonths - 1).coerceAtLeast(0)
            } else {
                unpaidMonths
            }

            val rawSettledFineMonths = cList
                .find { it.key == "settled_fine_months_member_${member.id}" }
                ?.value
                ?.toIntOrNull()
                ?: 0
            val activeSettledFineMonths = if (unpaidMonths == 0) {
                0
            } else {
                rawSettledFineMonths.coerceIn(0, unpaidMonths)
            }
            val unpaidOverdueMonthsAfterSettlement = (effectiveOverdueMonths - activeSettledFineMonths).coerceAtLeast(0)
            val accruedFineDue = unpaidOverdueMonthsAfterSettlement * 100

            // Status Rules:
            // 0 overdue months -> ACTIVE (Green)
            // 1 to 2 overdue months (Due ৳1,000 to ৳2,000 past 15th) -> WARNING (Amber)
            // 3 or more overdue months (Due >= ৳3,000) -> RED_ALERT (Red)
            val status = when {
                effectiveOverdueMonths >= 3 -> MemberStatus.RED_ALERT
                effectiveOverdueMonths in 1..2 -> MemberStatus.WARNING
                else -> MemberStatus.ACTIVE
            }

            val lastPayment = memberDeposits.maxByOrNull { it.paymentDate }?.paymentDate

            MemberWithStats(
                member = member,
                paidMonths = paidMonths,
                pendingMonths = pendingMonths,
                consecutiveUnpaidMonths = unpaidMonths,
                totalPaidContribution = totalContribution,
                totalFinePaid = totalFinePaid,
                totalDue = totalDue,
                status = status,
                lastPaymentDate = lastPayment,
                effectiveOverdueMonths = effectiveOverdueMonths,
                accruedFineDue = accruedFineDue,
                settledFineMonths = activeSettledFineMonths
            )
        }
    }

    /**
     * Cash & Balance Reconciliation Formula:
     * Main Liquid Capital / Net Cash in Hand =
     * (Total Deposits + Total Fines + Total Investment Net Profit)
     * - (Total Expenses + Total Ongoing Investments + Total Return Settlements).
     * Never display negative or unlinked static balances.
     */
    val financialKpi: Flow<FinancialKpi> = combine(
        combine(deposits, expenses, investments, settlements) { dList, eList, iList, sList ->
            val totalDeposits = dList.sumOf { it.amount }
            val fineCollection = dList.sumOf { it.fine }
            val totalExpenses = eList.sumOf { it.amount }

            val runningList = iList.filter { it.status.uppercase() == "RUNNING" || it.status.uppercase() == "ACTIVE" }
            val closedList = iList.filter { it.status.uppercase() == "CLOSED" || it.status.uppercase() == "COMPLETED" || it.status.uppercase() == "LIQUIDATED" }
            val totalRunningInvestments = runningList.sumOf { if (it.activeCapital > 0) it.activeCapital else it.amount }
            val totalClosedInvestments = closedList.sumOf { it.amount }
            val totalInvestments = totalRunningInvestments + totalClosedInvestments
            val realizedBusinessPnl = closedList.sumOf { it.profitLoss }
            val totalReturnSettlements = sList.filter { it.settlementStatus == "Done" }.sumOf { it.netReturnAmount }

            val bankInvestmentDelta = iList.sumOf { inv ->
                val statusUpper = inv.status.uppercase()
                val isRunning = statusUpper == "RUNNING" || statusUpper == "ACTIVE"
                val isClosed = statusUpper == "CLOSED" || statusUpper == "COMPLETED" || statusUpper == "LIQUIDATED"
                val deployedAmount = if (isRunning && inv.activeCapital > 0) inv.activeCapital else inv.amount
                val paidFromBank = inv.paymentSource.equals("Bank", ignoreCase = true)
                val effectiveReturnDest = inv.returnSource.ifBlank { inv.paymentSource }
                val returnedToBank = isClosed && effectiveReturnDest.equals("Bank", ignoreCase = true)

                val outflow = if ((isRunning || isClosed) && paidFromBank) deployedAmount else 0
                val inflow = if (returnedToBank) (inv.amount + inv.profitLoss) else 0
                inflow - outflow
            }

            val totalRevenue = totalDeposits + fineCollection + realizedBusinessPnl
            val calculatedCashInHand = (totalRevenue - totalExpenses - totalRunningInvestments - totalReturnSettlements - bankInvestmentDelta).coerceAtLeast(0)

            FinancialBaseNumbers(
                totalCollection = totalRevenue,
                totalDeposits = totalDeposits,
                fineCollection = fineCollection,
                totalExpenses = totalExpenses,
                totalInvestments = totalInvestments,
                totalRunningInvestments = totalRunningInvestments,
                totalClosedInvestments = totalClosedInvestments,
                totalOngoingInvestments = totalRunningInvestments,
                realizedBusinessPnl = realizedBusinessPnl,
                totalInvestmentNetProfit = realizedBusinessPnl,
                totalReturnSettlements = totalReturnSettlements,
                mainLiquidCapital = calculatedCashInHand,
                bankInvestmentDelta = bankInvestmentDelta
            )
        },
        configs,
        membersWithStats,
        exitedMembers
    ) { base, cList, mStats, eMemList ->
        val historical2025Fines = cList.find { it.key == "historical_2025_fines" }?.value?.toIntOrNull() ?: 1100
        val exitedLossRecovery = eMemList.sumOf { it.lossShareAmount }.takeIf { eMemList.isNotEmpty() } ?: 42
        val fineCollection = base.fineCollection + historical2025Fines
        val grossBusinessPnl = base.realizedBusinessPnl
        val netActiveBusinessPnl = grossBusinessPnl + exitedLossRecovery
        val totalCollection = base.totalDeposits + fineCollection + netActiveBusinessPnl
        val costAndInvest = base.totalExpenses + base.totalRunningInvestments + base.totalReturnSettlements
        val baseBankBalance = cList.find { it.key == "bank_balance" }?.value?.toIntOrNull() ?: 726
        val rawBankBalance = baseBankBalance + base.bankInvestmentDelta
        val bankBalance = rawBankBalance.coerceAtLeast(0)
        val bankShortfall = if (rawBankBalance < 0) -rawBankBalance else 0
        val cashInHand = (totalCollection - costAndInvest - base.bankInvestmentDelta - bankShortfall).coerceAtLeast(0)
        val totalLiquidCapital = cashInHand + bankBalance
        val reservedAmount = cList.find { it.key == "reserved_amount" }?.value?.toIntOrNull() ?: fineCollection
        val totalDue = mStats.sumOf { it.totalDue }

        FinancialKpi(
            totalCollection = totalCollection,
            totalDeposits = base.totalDeposits,
            fineCollection = fineCollection,
            totalExpenses = base.totalExpenses,
            totalInvestments = base.totalInvestments,
            totalRunningInvestments = base.totalRunningInvestments,
            totalClosedInvestments = base.totalClosedInvestments,
            totalOngoingInvestments = base.totalOngoingInvestments,
            grossBusinessPnl = grossBusinessPnl,
            exitedMembersLossRecovery = exitedLossRecovery,
            realizedBusinessPnl = netActiveBusinessPnl,
            totalInvestmentNetProfit = netActiveBusinessPnl,
            totalReturnSettlements = base.totalReturnSettlements,
            bankBalance = bankBalance,
            cashInHand = cashInHand,
            mainLiquidCapital = totalLiquidCapital,
            totalDue = totalDue,
            reservedAmount = reservedAmount
        )
    }

    fun observeMemberWithStats(memberId: Int): Flow<MemberWithStats?> =
        membersWithStats.map { list ->
            list.find { it.member.id == memberId }
        }

    val membersWithCapitalContributions: Flow<List<MemberWithCapitalContributions>> =
        dao.getAllMembersWithCapitalContributions()

    fun getMemberWithCapitalContributions(memberId: Int): Flow<MemberWithCapitalContributions?> =
        dao.getMemberWithCapitalContributions(memberId)

    fun getDepositsForMember(memberId: Int): Flow<List<Deposit>> =
        dao.getDepositsForMember(memberId)

    // Mutations - Strictly Called from Admin Panel
    suspend fun addMember(name: String, phone: String, joinDate: String, address: String): Member {
        val all = dao.getAllMembersSync()
        val nextId = (all.maxOfOrNull { it.id } ?: 11) + 1
        val member = Member(
            id = nextId,
            name = name,
            phone = phone,
            joinDate = joinDate,
            address = address
        )
        dao.insertMember(member)
        firebaseRepo?.pushMember(member)
        logActivity("member", "Added new member: $name (ID: $nextId)", "admin")
        return member
    }

    suspend fun updateMember(member: Member) {
        dao.updateMember(member)
        firebaseRepo?.pushMember(member)
        logActivity("member", "Updated profile for ${member.name} (ID: ${member.id})", "admin")
    }

    suspend fun updateMemberPhoto(memberId: Int, photoUri: String?) {
        dao.updateMemberPhoto(memberId, photoUri)
        dao.getMemberById(memberId)?.let { firebaseRepo?.pushMember(it) }
        logActivity("member", "Updated photo for member ID: $memberId", "admin")
    }

    suspend fun deleteMember(memberId: Int, memberName: String) {
        dao.deleteMemberById(memberId)
        dao.deleteDepositsForMember(memberId)
        firebaseRepo?.deleteMember(memberId)
        logActivity("delete", "Removed member $memberName (ID: $memberId)", "admin")
    }

    suspend fun recordDeposit(
        memberId: Int,
        month: String,
        paymentDate: String,
        amount: Int = 1000,
        fine: Int = 0,
        paymentMode: String = "Cash"
    ): Long {
        val deposit = Deposit(
            memberId = memberId,
            month = month,
            paymentDate = paymentDate,
            amount = amount,
            fine = fine,
            paymentMode = paymentMode
        )
        val id = dao.insertDeposit(deposit)
        val insertedDeposit = deposit.copy(id = id.toInt())
        firebaseRepo?.pushDeposit(insertedDeposit)
        val member = dao.getMemberById(memberId)
        logActivity("deposit", "Recorded deposit for ${member?.name ?: "ID $memberId"}: $month (৳${amount + fine})", "admin")
        return id
    }

    suspend fun recordBulkDeposits(depositsList: List<Deposit>): Int {
        dao.insertDeposits(depositsList)
        depositsList.forEach { firebaseRepo?.pushDeposit(it) }
        logActivity("deposit", "Recorded batch of ${depositsList.size} deposits", "admin")
        return depositsList.size
    }

    suspend fun updateDeposit(deposit: Deposit) {
        dao.updateDeposit(deposit)
        firebaseRepo?.pushDeposit(deposit)
        logActivity("update", "Updated deposit #${deposit.id}", "admin")
    }

    suspend fun deleteDeposit(depositId: Int) {
        dao.deleteDepositById(depositId)
        firebaseRepo?.deleteDeposit(depositId)
        logActivity("delete", "Deleted deposit #$depositId", "admin")
    }

    suspend fun addExpense(
        description: String,
        category: String,
        quantity: String,
        amount: Int,
        date: String,
        paidBy: String,
        remarks: String,
        by: String
    ): Long {
        val expense = Expense(
            description = description,
            category = category,
            quantity = quantity,
            amount = amount,
            date = date,
            paidBy = paidBy,
            remarks = remarks,
            recordedBy = by
        )
        val id = dao.insertExpense(expense)
        val insertedExpense = expense.copy(id = id.toInt())
        firebaseRepo?.pushExpense(insertedExpense)
        logActivity("cost", "Logged expense: $description (৳$amount, $category)", by)
        return id
    }

    suspend fun recordBulkExpenses(expensesList: List<Expense>): Int {
        dao.insertExpenses(expensesList)
        expensesList.forEach { firebaseRepo?.pushExpense(it) }
        logActivity("cost", "Logged batch of ${expensesList.size} expenses", "admin")
        return expensesList.size
    }

    suspend fun updateExpense(expense: Expense) {
        dao.updateExpense(expense)
        firebaseRepo?.pushExpense(expense)
        logActivity("update", "Updated expense #${expense.id}: ${expense.description}", "admin")
    }

    suspend fun deleteExpense(expenseId: Int) {
        dao.deleteExpenseById(expenseId)
        firebaseRepo?.deleteExpense(expenseId)
        logActivity("delete", "Deleted expense #$expenseId", "admin")
    }

    suspend fun addInvestment(investment: Investment): Long {
        val id = dao.insertInvestment(investment)
        val insertedInvestment = investment.copy(id = id.toInt())
        firebaseRepo?.pushInvestment(insertedInvestment)
        logActivity("investment", "Added investment: ${investment.name} (৳${investment.amount}, ${investment.type})", "admin")
        return id
    }

    suspend fun recordBulkInvestments(investmentsList: List<Investment>): Int {
        dao.insertInvestments(investmentsList)
        investmentsList.forEach { firebaseRepo?.pushInvestment(it) }
        logActivity("investment", "Added batch of ${investmentsList.size} investments", "admin")
        return investmentsList.size
    }

    suspend fun updateInvestment(investment: Investment) {
        dao.updateInvestment(investment)
        firebaseRepo?.pushInvestment(investment)
        logActivity("update", "Updated investment #${investment.id}: ${investment.name}", "admin")
    }

    suspend fun deleteInvestment(investmentId: Int) {
        dao.deleteInvestmentById(investmentId)
        firebaseRepo?.deleteInvestment(investmentId)
        logActivity("delete", "Deleted investment #$investmentId", "admin")
    }

    // Member Settlement & Return Ledger (Return System)
    suspend fun addSettlement(settlement: MemberSettlement): Long {
        val id = dao.insertSettlement(settlement)
        val insertedSettlement = settlement.copy(id = id.toInt())
        firebaseRepo?.pushSettlement(insertedSettlement)
        logActivity("settlement", "Issued member return settlement for ${settlement.memberName} (Net: ৳${settlement.netReturnAmount})", "admin")
        return id
    }

    suspend fun updateSettlement(settlement: MemberSettlement) {
        dao.updateSettlement(settlement)
        firebaseRepo?.pushSettlement(settlement)
        logActivity("settlement", "Updated settlement #${settlement.id} for ${settlement.memberName}", "admin")
    }

    suspend fun deleteSettlement(settlementId: Int) {
        dao.deleteSettlementById(settlementId)
        firebaseRepo?.deleteSettlement(settlementId)
        logActivity("delete", "Deleted settlement #$settlementId", "admin")
    }

    suspend fun updateConfig(key: String, value: String) {
        dao.setConfig(AppConfig(key, value))
        firebaseRepo?.pushAppSetting(key, value)
        logActivity("settings", "Updated config $key to $value", "admin")
    }

    suspend fun addAdmin(user: AdminUser) {
        dao.insertAdmin(user)
        logActivity("settings", "Added new admin user: ${user.username} (${user.role})", "admin")
    }

    suspend fun deleteAdmin(username: String) {
        dao.deleteAdmin(username)
        logActivity("delete", "Removed admin user: $username", "admin")
    }

    suspend fun getAdmin(username: String): AdminUser? = dao.getAdminByUsername(username)

    suspend fun logActivity(type: String, message: String, username: String) {
        dao.insertLog(ActivityLog(type = type, message = message, username = username))
    }

    suspend fun clearLogs() {
        dao.clearLogs()
    }

    // --- Member Auth & Password Reset ---
    suspend fun registerMemberAccount(
        fullName: String,
        contact: String,
        rrkMemberId: String,
        password: String
    ): Result<MemberAccount> {
        val cleanName = fullName.trim()
        val cleanContact = contact.trim()
        val normalizedId = PasswordUtils.normalizeRrkId(rrkMemberId)
        val normalizedContact = PasswordUtils.normalizeContact(cleanContact)

        if (cleanName.isEmpty() || cleanContact.isEmpty() || normalizedId.isEmpty() || password.length < 6) {
            return Result.failure(IllegalArgumentException("All fields are required and password must be at least 6 characters."))
        }
        if (dao.getMemberAccountById(normalizedId) != null) {
            return Result.failure(IllegalStateException("RRK Member ID \"$normalizedId\" is already registered."))
        }
        if (dao.getMemberAccountByContact(normalizedContact) != null) {
            return Result.failure(IllegalStateException("An account with this phone number or email already exists."))
        }

        val account = MemberAccount(
            rrkMemberId = normalizedId,
            fullName = cleanName,
            contact = cleanContact,
            normalizedContact = normalizedContact,
            passwordHash = PasswordUtils.sha256(password),
            role = "Member"
        )
        dao.insertMemberAccount(account)
        logActivity("member", "Member signed up: $cleanName ($normalizedId)", cleanName)
        return Result.success(account)
    }

    suspend fun authenticateMember(identifier: String, password: String): Result<MemberAccount> {
        val cleanTrimmed = identifier.trim()
        val cleanId = PasswordUtils.normalizeRrkId(cleanTrimmed)
        val cleanContact = PasswordUtils.normalizeContact(cleanTrimmed)
        if (cleanTrimmed.isEmpty() || password.isBlank()) {
            return Result.failure(IllegalArgumentException("Please enter your Email/Phone/RRK ID and password."))
        }

        val account = dao.getMemberAccountById(cleanId)
            ?: dao.getMemberAccountByContact(cleanContact)

        if (account != null) {
            if (account.passwordHash != PasswordUtils.sha256(password)) {
                return Result.failure(IllegalArgumentException("Incorrect password. Please try again or use Forgot Password."))
            }
            logActivity("login", "Member signed in: ${account.fullName} (${account.rrkMemberId})", account.fullName)
            return Result.success(account)
        }

        // Also allow registered Admin credentials on the sign-in screen
        val admin = dao.getAdminByUsername(cleanTrimmed)
        val effectiveAdmin = if ((admin == null || admin.password.trim() != password.trim()) &&
            cleanTrimmed.equals("admin", ignoreCase = true) &&
            password.trim() == "rrk2025"
        ) {
            AdminUser(
                username = "admin",
                password = "rrk2025",
                role = "Super Admin",
                addedBy = "System",
                addedAt = "2025-05-01"
            ).also { dao.insertAdmin(it) }
        } else {
            admin
        }

        if (effectiveAdmin != null && effectiveAdmin.password.trim() == password.trim()) {
            val adminAccount = MemberAccount(
                rrkMemberId = "RRK-ADMIN-${effectiveAdmin.username.uppercase()}",
                fullName = effectiveAdmin.username,
                contact = effectiveAdmin.username,
                normalizedContact = effectiveAdmin.username.lowercase(),
                passwordHash = PasswordUtils.sha256(password.trim()),
                role = effectiveAdmin.role
            )
            logActivity("login", "Admin signed in via portal: ${effectiveAdmin.username}", effectiveAdmin.username)
            return Result.success(adminAccount)
        }

        return Result.failure(IllegalStateException("No member account found for \"$identifier\"."))
    }

    suspend fun verifyMemberOrAdminPassword(rrkMemberId: String, password: String): Boolean {
        if (password.isBlank()) return false
        val memberAcc = dao.getMemberAccountById(rrkMemberId)
        if (memberAcc != null) {
            return memberAcc.passwordHash == PasswordUtils.sha256(password)
        }
        if (rrkMemberId.startsWith("RRK-ADMIN-")) {
            val username = rrkMemberId.removePrefix("RRK-ADMIN-").lowercase()
            val admin = dao.getAdminByUsername(username)
            if (admin != null && admin.password.trim() == password.trim()) {
                return true
            }
            if (username == "admin" && password.trim() == "rrk2025") {
                return true
            }
        }
        return false
    }

    suspend fun saveMemberPinHash(rrkMemberId: String, pinHash: String) {
        dao.setConfig(AppConfig(key = "member_pin_$rrkMemberId", value = pinHash))
    }

    suspend fun getMemberPinHash(rrkMemberId: String): String {
        return dao.getAllConfigsSync()
            .firstOrNull { it.key == "member_pin_$rrkMemberId" }
            ?.value
            ?: ""
    }

    suspend fun resetMemberPassword(
        contact: String,
        rrkMemberId: String,
        newPassword: String
    ): Result<MemberAccount> {
        val normalizedId = PasswordUtils.normalizeRrkId(rrkMemberId)
        val normalizedContact = PasswordUtils.normalizeContact(contact)
        if (normalizedId.isEmpty() || normalizedContact.isEmpty()) {
            return Result.failure(IllegalArgumentException("Please provide both your registered Email/Phone and RRK Member ID."))
        }
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }

        val account = dao.getMemberAccountById(normalizedId)
            ?: return Result.failure(IllegalStateException("No account found with RRK Member ID \"$normalizedId\"."))

        if (account.normalizedContact != normalizedContact) {
            return Result.failure(IllegalArgumentException("Registered Email/Phone does not match RRK Member ID \"$normalizedId\"."))
        }

        val newHash = PasswordUtils.sha256(newPassword)
        dao.updateMemberAccountPassword(normalizedId, newHash)
        logActivity("settings", "Member password reset via recovery: ${account.fullName} ($normalizedId)", account.fullName)
        return Result.success(account.copy(passwordHash = newHash))
    }

    suspend fun adminResetMemberPassword(
        rrkMemberId: String,
        newPassword: String,
        adminUsername: String
    ): Result<MemberAccount> {
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val account = dao.getMemberAccountById(rrkMemberId)
            ?: return Result.failure(IllegalStateException("Member account \"$rrkMemberId\" not found."))

        val newHash = PasswordUtils.sha256(newPassword)
        dao.updateMemberAccountPassword(rrkMemberId, newHash)
        logActivity("settings", "Admin $adminUsername reset password for member ${account.fullName} ($rrkMemberId)", adminUsername)
        return Result.success(account.copy(passwordHash = newHash))
    }

    // --- Member Ideas & Comments ---
    suspend fun addMemberIdea(
        title: String,
        category: String,
        businessType: String = "Product",
        estimatedBudget: Long = 0L,
        description: String,
        authorId: String,
        authorName: String,
        authorRole: String
    ): Long {
        val normalizedType = if (businessType.equals("Service", ignoreCase = true)) "Service" else "Product"
        val id = dao.insertMemberIdea(
            MemberIdea(
                title = title.trim(),
                category = category.trim(),
                businessType = normalizedType,
                estimatedBudget = estimatedBudget.coerceAtLeast(0L),
                description = description.trim(),
                authorId = authorId,
                authorName = authorName,
                authorRole = authorRole
            )
        )
        logActivity("investment", "New $normalizedType idea shared: \"$title\" by $authorName", authorName)
        return id
    }

    suspend fun toggleIdeaUpvote(ideaId: Int, userKey: String): Boolean =
        toggleIdeaAgree(ideaId, userKey)

    suspend fun toggleIdeaAgree(ideaId: Int, userKey: String): Boolean {
        val idea = dao.getMemberIdeaById(ideaId) ?: return false
        val currentLikes = idea.likedUsersSet().toMutableSet()
        val currentDislikes = idea.dislikedUsersSet().toMutableSet()
        val agreedNow = if (currentLikes.contains(userKey)) {
            currentLikes.remove(userKey)
            false
        } else {
            currentLikes.add(userKey)
            currentDislikes.remove(userKey)
            true
        }
        dao.updateMemberIdea(
            idea.copy(
                likedByUserIds = currentLikes.joinToString(","),
                dislikedByUserIds = currentDislikes.joinToString(",")
            )
        )
        return agreedNow
    }

    suspend fun toggleIdeaDisagree(ideaId: Int, userKey: String): Boolean {
        val idea = dao.getMemberIdeaById(ideaId) ?: return false
        val currentLikes = idea.likedUsersSet().toMutableSet()
        val currentDislikes = idea.dislikedUsersSet().toMutableSet()
        val disagreedNow = if (currentDislikes.contains(userKey)) {
            currentDislikes.remove(userKey)
            false
        } else {
            currentDislikes.add(userKey)
            currentLikes.remove(userKey)
            true
        }
        dao.updateMemberIdea(
            idea.copy(
                likedByUserIds = currentLikes.joinToString(","),
                dislikedByUserIds = currentDislikes.joinToString(",")
            )
        )
        return disagreedNow
    }

    suspend fun addIdeaComment(
        ideaId: Int,
        authorId: String,
        authorName: String,
        authorRole: String,
        content: String
    ): Long {
        val commentId = dao.insertIdeaComment(
            IdeaComment(
                ideaId = ideaId,
                authorId = authorId,
                authorName = authorName,
                authorRole = authorRole,
                content = content.trim()
            )
        )
        logActivity("member", "Comment posted on Idea #$ideaId by $authorName", authorName)
        return commentId
    }

    suspend fun deleteMemberIdea(ideaId: Int, actorName: String) {
        dao.deleteCommentsForIdea(ideaId)
        dao.deleteMemberIdeaById(ideaId)
        logActivity("delete", "Deleted member idea #$ideaId", actorName)
    }

    // --- Manual Payment Requests, Admin Verification & Auto-Ledger Sync ---
    suspend fun submitPaymentRequest(
        memberId: Int,
        memberName: String,
        month: String,
        paymentMethod: String,
        amount: Int,
        fine: Int,
        trxId: String,
        paymentDate: String,
        notes: String = ""
    ): Long {
        val request = PaymentRequest(
            memberId = memberId,
            memberName = memberName,
            month = month,
            paymentMethod = paymentMethod,
            amount = amount,
            fine = fine,
            trxId = trxId.trim(),
            paymentDate = paymentDate,
            notes = notes.trim(),
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        val id = dao.insertPaymentRequest(request)
        logActivity(
            "deposit",
            "Submitted payment request #PR-${id.toString().padStart(4, '0')} by $memberName for $month (৳${amount + fine} via $paymentMethod, TrxID: ${request.trxId.ifBlank { "Cash" }}) — Pending Admin Approval",
            memberName
        )
        return id
    }

    suspend fun approvePaymentRequest(requestId: Int, adminName: String): Result<PaymentRequest> {
        val existing = dao.getPaymentRequestById(requestId)
            ?: return Result.failure(IllegalStateException("Payment request not found."))
        if (existing.status != "PENDING") {
            return Result.failure(IllegalStateException("Request is already ${existing.status.lowercase()}."))
        }

        val depositId = dao.insertDeposit(
            Deposit(
                memberId = existing.memberId,
                month = existing.month,
                paymentDate = existing.paymentDate,
                amount = existing.amount,
                fine = existing.fine,
                paymentMode = existing.paymentMethod
            )
        )

        if (existing.paymentMethod.equals("Bank", ignoreCase = true)) {
            val currentBank = dao.getConfig("bank_balance")?.toIntOrNull() ?: 726
            val updatedBank = currentBank + existing.amount + existing.fine
            dao.setConfig(AppConfig("bank_balance", updatedBank.toString()))
        }

        // Clear the member's paid accrued fine so only the remaining Capital Due is carried forward
        val member = dao.getMemberById(existing.memberId)
        val activeMonths = getActiveMonths()
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val sdfMonth = SimpleDateFormat("MMM yyyy", Locale.US)
        val joinDate = try {
            sdfDate.parse(member?.joinDate ?: "2025-05-01") ?: sdfDate.parse("2025-05-01")
        } catch (e: Exception) {
            sdfDate.parse("2025-05-01")
        }
        val eligibleMonthsCount = activeMonths.count { m ->
            try {
                val mDate = sdfMonth.parse(m)
                mDate != null && (mDate.after(joinDate) || sdfMonth.format(mDate) == sdfMonth.format(joinDate ?: Date()))
            } catch (e: Exception) {
                true
            }
        }
        val updatedMemberDeposits = dao.getDepositsForMember(existing.memberId).first()
        val newTotalContribution = updatedMemberDeposits.sumOf { it.amount }
        val remainingCapitalDue = ((eligibleMonthsCount * 1000) - newTotalContribution).coerceAtLeast(0)
        val remainingUnpaidMonths = if (remainingCapitalDue <= 0) 0 else ((remainingCapitalDue + 999) / 1000)
        dao.setConfig(
            AppConfig(
                key = "settled_fine_months_member_${existing.memberId}",
                value = remainingUnpaidMonths.toString()
            )
        )

        val updated = existing.copy(
            status = "APPROVED",
            reviewedAt = System.currentTimeMillis(),
            reviewedBy = adminName.ifBlank { "admin" },
            approvedDepositId = depositId.toInt(),
            rejectionReason = ""
        )
        dao.updatePaymentRequest(updated)
        triggerRecalculation()

        logActivity(
            "deposit",
            "Approved payment #PR-${existing.id.toString().padStart(4, '0')} for ${existing.memberName} (${existing.month}, ৳${existing.amount + existing.fine} via ${existing.paymentMethod}) — Ledger synced & Proof Receipt unlocked",
            adminName.ifBlank { "admin" }
        )
        return Result.success(updated)
    }

    suspend fun rejectPaymentRequest(
        requestId: Int,
        adminName: String,
        reason: String = ""
    ): Result<PaymentRequest> {
        val existing = dao.getPaymentRequestById(requestId)
            ?: return Result.failure(IllegalStateException("Payment request not found."))
        if (existing.status != "PENDING") {
            return Result.failure(IllegalStateException("Request is already ${existing.status.lowercase()}."))
        }

        val updated = existing.copy(
            status = "REJECTED",
            reviewedAt = System.currentTimeMillis(),
            reviewedBy = adminName.ifBlank { "admin" },
            rejectionReason = reason.trim()
        )
        dao.updatePaymentRequest(updated)

        logActivity(
            "delete",
            "Rejected payment #PR-${existing.id.toString().padStart(4, '0')} for ${existing.memberName} (${existing.month})${if (reason.isNotBlank()) " — $reason" else ""}",
            adminName.ifBlank { "admin" }
        )
        return Result.success(updated)
    }

    suspend fun updateOfficialPaymentAccounts(
        bkash: String,
        nagad: String,
        bank: String,
        adminName: String
    ) {
        dao.setConfig(AppConfig("pay_bkash_number", bkash.trim().ifBlank { OfficialPaymentAccounts.DEFAULT_BKASH }))
        dao.setConfig(AppConfig("pay_nagad_number", nagad.trim().ifBlank { OfficialPaymentAccounts.DEFAULT_NAGAD }))
        dao.setConfig(AppConfig("pay_bank_details", bank.trim().ifBlank { OfficialPaymentAccounts.DEFAULT_BANK }))
        logActivity("settings", "Updated Official Payment Accounts (bKash/Nagad/Bank)", adminName.ifBlank { "admin" })
    }

    suspend fun getAdminAlertEmailSettingsSync(): AdminAlertEmailSettings {
        val email = dao.getConfig("admin_alert_email")?.takeIf { it.isNotBlank() }
            ?: AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL
        val serviceId = dao.getConfig("emailjs_service_id").orEmpty()
        val templateId = dao.getConfig("emailjs_template_id").orEmpty()
        val publicKey = dao.getConfig("emailjs_public_key").orEmpty()
        return AdminAlertEmailSettings(
            adminAlertEmail = email,
            emailJsServiceId = serviceId,
            emailJsTemplateId = templateId,
            emailJsPublicKey = publicKey
        )
    }

    suspend fun updateAdminAlertEmailSettings(
        adminAlertEmail: String,
        emailJsServiceId: String,
        emailJsTemplateId: String,
        emailJsPublicKey: String,
        adminName: String
    ) {
        val cleanEmail = adminAlertEmail.trim().ifBlank { AdminAlertEmailSettings.DEFAULT_ADMIN_EMAIL }
        dao.setConfig(AppConfig("admin_alert_email", cleanEmail))
        dao.setConfig(AppConfig("emailjs_service_id", emailJsServiceId.trim()))
        dao.setConfig(AppConfig("emailjs_template_id", emailJsTemplateId.trim()))
        dao.setConfig(AppConfig("emailjs_public_key", emailJsPublicKey.trim()))
        logActivity("settings", "Updated Admin Alert Email & EmailJS Settings ($cleanEmail)", adminName.ifBlank { "admin" })
    }

    suspend fun addExitedMember(member: ExitedMember) {
        val id = dao.insertExitedMember(member)
        val inserted = member.copy(id = id.toInt())
        firebaseRepo?.pushExitedMember(inserted)
        logActivity("exited_member", "Added exited member: ${member.name} (Loss Share: ৳${member.lossShareAmount})", "admin")
    }

    suspend fun updateExitedMember(member: ExitedMember) {
        dao.updateExitedMember(member)
        firebaseRepo?.pushExitedMember(member)
        logActivity("exited_member", "Updated exited member: ${member.name}", "admin")
    }

    suspend fun deleteExitedMember(id: Int) {
        dao.deleteExitedMember(id)
        firebaseRepo?.deleteExitedMember(id)
        logActivity("exited_member", "Deleted exited member #$id", "admin")
    }

    suspend fun addCustomPage(page: CustomPage) {
        val id = dao.insertCustomPage(page)
        val inserted = page.copy(id = id.toInt())
        firebaseRepo?.pushCustomPage(inserted)
        logActivity("custom_page", "Created custom page: ${page.title}", "admin")
    }

    suspend fun updateCustomPage(page: CustomPage) {
        dao.updateCustomPage(page)
        firebaseRepo?.pushCustomPage(page)
        logActivity("custom_page", "Updated custom page: ${page.title}", "admin")
    }

    suspend fun deleteCustomPage(id: Int) {
        dao.deleteCustomPage(id)
        firebaseRepo?.deleteCustomPage(id)
        logActivity("custom_page", "Deleted custom page #$id", "admin")
    }
}

private data class FinancialBaseNumbers(
    val totalCollection: Int,
    val totalDeposits: Int,
    val fineCollection: Int,
    val totalExpenses: Int,
    val totalInvestments: Int,
    val totalRunningInvestments: Int,
    val totalClosedInvestments: Int,
    val totalOngoingInvestments: Int,
    val realizedBusinessPnl: Int,
    val totalInvestmentNetProfit: Int,
    val totalReturnSettlements: Int,
    val mainLiquidCapital: Int,
    val bankInvestmentDelta: Int = 0
)

