package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.FinancialKpi
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberSettlement
import com.example.data.repository.AppRepository
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Data class representing an editable row in Bulk Deposit Entry
data class BulkDepositRowState(
    var memberId: Int,
    var month: String,
    var amountStr: String = "1000",
    var paymentDate: String,
    var fineStr: String = "0",
    var paymentMode: String = "Cash"
)

// Data class representing an editable row in Bulk Expense Entry
data class BulkExpenseRowState(
    var date: String,
    var description: String,
    var category: String = "Agro",
    var quantity: String = "",
    var amountStr: String = "",
    var paidBy: String = "Finance Dept",
    var remarks: String = ""
)

// Data class representing an editable row in Bulk Investment Entry
data class BulkInvestmentRowState(
    var date: String,
    var type: String = "Agro",
    var name: String,
    var amountStr: String = "",
    var purchasedQuantity: String = "",
    var supervisor: String = "Rupok / Jalil Mom",
    var status: String = "Active",
    var saleDate: String = "",
    var soldQuantity: String = "",
    var saleRevenueStr: String = "0",
    var expensesStr: String = "0",
    var profitLossStr: String = "0",
    var stockStatus: String = "In Stock"
)

/**
 * A. Bulk Member Deposit Entry Modal (Admin Only)
 * Responsive multi-row grid interface:
 * [Member Dropdown (11 Members)] | [Billing Month/Year] | [Amount (default ৳1,000)] | [Payment Date] | [Fine (Auto ৳100 if Date > 15th)] | [Payment Mode (Cash/Bank)] | [Action: Remove Row]
 * Actions: "+ Add Row" and "Save All Deposits".
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkDepositEntryDialog(
    members: List<Member>,
    onDismiss: () -> Unit,
    onSaveAll: (List<Deposit>) -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val activeMonths = remember { AppRepository.getActiveMonths() }
    val defaultMonth = activeMonths.lastOrNull() ?: "Oct 2026"

    val rows = remember {
        mutableStateListOf<BulkDepositRowState>().apply {
            members.forEach { m ->
                val dayOfMonth = SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1
                val autoFine = if (dayOfMonth > 15) 100 else 0
                add(
                    BulkDepositRowState(
                        memberId = m.id,
                        month = defaultMonth,
                        amountStr = "1000",
                        paymentDate = today,
                        fineStr = autoFine.toString(),
                        paymentMode = "Cash"
                    )
                )
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f),
            shape = AppCardShape,
            color = NagadWhite,
            border = AppCardBorder,
            shadowElevation = AppCardElevation
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Multi-Entry Deposits",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = NagadMainText)
                        )
                        Text(
                            text = "Batch entry for 11 founding members (৳1,000/mo, Auto-fine ৳100 after 15th)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = NagadMainText)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = NagadBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Action Bar: Add Row & Quick Month Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val firstMemberId = members.firstOrNull()?.id ?: 1
                            rows.add(
                                BulkDepositRowState(
                                    memberId = firstMemberId,
                                    month = defaultMonth,
                                    amountStr = "1000",
                                    paymentDate = today,
                                    fineStr = "0",
                                    paymentMode = "Cash"
                                )
                            )
                        },
                        colors = appSolidButtonColors(RoyalBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Add Row", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Text(
                        text = "Total Rows: ${rows.size} | Total: ${CurrencyFormatter.formatCurrency(rows.sumOf { (it.amountStr.toIntOrNull() ?: 0) + (it.fineStr.toIntOrNull() ?: 0) })}",
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = EmeraldGreen
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Table of Rows
                val hScrollState = rememberScrollState()
                Box(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(hScrollState)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("MEMBER", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(180.dp))
                            Text("BILLING MONTH", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(140.dp))
                            Text("AMOUNT (৳)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(100.dp))
                            Text("PAYMENT DATE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(130.dp))
                            Text("FINE (৳)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(90.dp))
                            Text("MODE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(100.dp))
                            Text("ACTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(70.dp))
                        }

                        HorizontalDivider(color = Color(0xFFCBD5E1))

                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(rows) { index, rowState ->
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Member Selector Dropdown
                                    var memberExpanded by remember { mutableStateOf(false) }
                                    val selectedMember = members.find { it.id == rowState.memberId } ?: members.firstOrNull()

                                    Box(modifier = Modifier.width(180.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { memberExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = selectedMember?.let { "RRK-${it.id.toString().padStart(3, '0')} ${it.name}" } ?: "Select",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1
                                                )
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = memberExpanded,
                                            onDismissRequest = { memberExpanded = false }
                                        ) {
                                            members.forEach { m ->
                                                DropdownMenuItem(
                                                    text = { Text("RRK-${m.id.toString().padStart(3, '0')} ${m.name}", fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.memberId = m.id
                                                        memberExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Billing Month Dropdown / Input
                                    var monthExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(140.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { monthExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(text = rowState.month, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = monthExpanded,
                                            onDismissRequest = { monthExpanded = false }
                                        ) {
                                            activeMonths.forEach { m ->
                                                DropdownMenuItem(
                                                    text = { Text(m, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.month = m
                                                        monthExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Amount
                                    OutlinedTextField(
                                        value = rowState.amountStr,
                                        onValueChange = { rowState.amountStr = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(100.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Payment Date (auto-calculates fine if day > 15)
                                    OutlinedTextField(
                                        value = rowState.paymentDate,
                                        onValueChange = { newDate ->
                                            rowState.paymentDate = newDate
                                            val day = newDate.split("-").getOrNull(2)?.toIntOrNull() ?: 1
                                            if (day > 15) {
                                                rowState.fineStr = "100"
                                            } else {
                                                rowState.fineStr = "0"
                                            }
                                        },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(130.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Fine
                                    OutlinedTextField(
                                        value = rowState.fineStr,
                                        onValueChange = { rowState.fineStr = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(90.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Payment Mode
                                    var modeExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(100.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { modeExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(text = rowState.paymentMode, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = modeExpanded,
                                            onDismissRequest = { modeExpanded = false }
                                        ) {
                                            listOf("Cash", "Bank").forEach { mode ->
                                                DropdownMenuItem(
                                                    text = { Text(mode, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.paymentMode = mode
                                                        modeExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Remove Row
                                    IconButton(
                                        onClick = { if (rows.size > 1) rows.removeAt(index) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = RedAlert, modifier = Modifier.size(18.dp))
                                    }
                                }
                                HorizontalDivider(color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Footer: Cancel & Save All
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = NagadSecondaryText)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val depositEntities = rows.map { row ->
                                Deposit(
                                    memberId = row.memberId,
                                    month = row.month.trim(),
                                    paymentDate = row.paymentDate.trim(),
                                    amount = row.amountStr.toIntOrNull() ?: 1000,
                                    fine = row.fineStr.toIntOrNull() ?: 0,
                                    paymentMode = row.paymentMode
                                )
                            }
                            onSaveAll(depositEntities)
                        },
                        colors = appSolidButtonColors(EmeraldGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save All Deposits (${rows.size})", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * B. Bulk Expense Entry Modal (Admin Only)
 * Columns: [Expense Date] | [Expense Description] | [Category (Agro/Admin/Bank Charge)] | [Quantity] | [Amount (৳)] | [Paid By (Finance Dept / Bank Auto Trnx)] | [Remarks] | [Remove Row]
 * Features "+ Add Expense Row" and a single batch submission button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkExpenseEntryDialog(
    onDismiss: () -> Unit,
    onSaveAll: (List<Expense>) -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val categories = listOf("Agro", "Admin", "Bank Charge", "Office Expenses", "Transport", "Marketing", "Emergency", "Miscellaneous")
    val payers = listOf("Finance Dept", "Bank Auto Trnx", "Cash Fund")

    val rows = remember {
        mutableStateListOf(
            BulkExpenseRowState(date = today, description = "", category = "Agro", quantity = "1 Unit", amountStr = "", paidBy = "Finance Dept", remarks = "")
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f),
            shape = AppCardShape,
            color = NagadWhite,
            border = AppCardBorder,
            shadowElevation = AppCardElevation
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Multi-Entry Expenses",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = NagadMainText)
                        )
                        Text(
                            text = "Batch log operational expenses (Agro, Admin, Bank Charge, etc.)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = NagadMainText)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = NagadBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            rows.add(
                                BulkExpenseRowState(date = today, description = "", category = "Agro", quantity = "", amountStr = "", paidBy = "Finance Dept", remarks = "")
                            )
                        },
                        colors = appSolidButtonColors(Color(0xFF0891B2)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Add Expense Row", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Text(
                        text = "Total Expenses: ${CurrencyFormatter.formatCurrency(rows.sumOf { it.amountStr.toIntOrNull() ?: 0 })}",
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0891B2)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table
                val hScrollState = rememberScrollState()
                Box(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(hScrollState)
                    ) {
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("DATE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(120.dp))
                            Text("DESCRIPTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(180.dp))
                            Text("CATEGORY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(130.dp))
                            Text("QTY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(90.dp))
                            Text("AMOUNT (৳)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(110.dp))
                            Text("PAID BY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(130.dp))
                            Text("REMARKS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(140.dp))
                            Text("ACTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(70.dp))
                        }

                        HorizontalDivider(color = Color(0xFFCBD5E1))

                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(rows) { index, rowState ->
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Date
                                    OutlinedTextField(
                                        value = rowState.date,
                                        onValueChange = { rowState.date = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(120.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Description
                                    OutlinedTextField(
                                        value = rowState.description,
                                        onValueChange = { rowState.description = it },
                                        placeholder = { Text("e.g. Fodder", fontSize = 12.sp) },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(180.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Category Dropdown
                                    var catExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(130.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { catExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(rowState.category, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = catExpanded,
                                            onDismissRequest = { catExpanded = false }
                                        ) {
                                            categories.forEach { cat ->
                                                DropdownMenuItem(
                                                    text = { Text(cat, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.category = cat
                                                        catExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Qty
                                    OutlinedTextField(
                                        value = rowState.quantity,
                                        onValueChange = { rowState.quantity = it },
                                        placeholder = { Text("1 Unit", fontSize = 12.sp) },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(90.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Amount
                                    OutlinedTextField(
                                        value = rowState.amountStr,
                                        onValueChange = { rowState.amountStr = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(110.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Paid By Dropdown
                                    var payerExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(130.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { payerExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(rowState.paidBy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = payerExpanded,
                                            onDismissRequest = { payerExpanded = false }
                                        ) {
                                            payers.forEach { p ->
                                                DropdownMenuItem(
                                                    text = { Text(p, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.paidBy = p
                                                        payerExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Remarks
                                    OutlinedTextField(
                                        value = rowState.remarks,
                                        onValueChange = { rowState.remarks = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(140.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Delete
                                    IconButton(
                                        onClick = { if (rows.size > 1) rows.removeAt(index) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = RedAlert, modifier = Modifier.size(18.dp))
                                    }
                                }
                                HorizontalDivider(color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel", color = NagadSecondaryText) }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val validExpenses = rows.filter { it.description.isNotBlank() && (it.amountStr.toIntOrNull() ?: 0) > 0 }.map { r ->
                                Expense(
                                    description = r.description.trim(),
                                    category = r.category,
                                    quantity = r.quantity.trim(),
                                    amount = r.amountStr.toIntOrNull() ?: 0,
                                    date = r.date.trim(),
                                    paidBy = r.paidBy,
                                    remarks = r.remarks.trim(),
                                    recordedBy = "admin"
                                )
                            }
                            onSaveAll(validExpenses)
                        },
                        colors = appSolidButtonColors(Color(0xFF0891B2)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save All Expenses (${rows.size})", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * C. Bulk Investment / Asset Entry Modal (Admin Only)
 * Support dynamic multi-row inputs for purchases, asset valuation, liquidated sales, and supervision notes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkInvestmentEntryDialog(
    onDismiss: () -> Unit,
    onSaveAll: (List<Investment>) -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val types = listOf("Agro", "Stock/Commodities", "Retail", "Other")
    val statuses = listOf("Active", "Completed", "Liquidated", "On Hold")

    val rows = remember {
        mutableStateListOf(
            BulkInvestmentRowState(
                date = today,
                type = "Agro",
                name = "",
                amountStr = "",
                purchasedQuantity = "",
                supervisor = "Rupok / Jalil Mom",
                status = "Active",
                stockStatus = "In Stock"
            )
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f),
            shape = AppCardShape,
            color = NagadWhite,
            border = AppCardBorder,
            shadowElevation = AppCardElevation
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Multi-Entry Investments",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = NagadMainText)
                        )
                        Text(
                            text = "Record Agro (Goats) and Commodities (Cumin/Jira) purchases & sales",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = NagadMainText)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = NagadBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            rows.add(
                                BulkInvestmentRowState(
                                    date = today,
                                    type = "Agro",
                                    name = "",
                                    amountStr = "",
                                    purchasedQuantity = "",
                                    supervisor = "Rupok / Jalil Mom",
                                    status = "Active",
                                    stockStatus = "In Stock"
                                )
                            )
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Add Investment Row", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "Total Capital: ${CurrencyFormatter.formatCurrency(rows.sumOf { it.amountStr.toIntOrNull() ?: 0 })}",
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NagadPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table
                val hScrollState = rememberScrollState()
                Box(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(hScrollState)
                    ) {
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("DATE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(120.dp))
                            Text("TYPE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(130.dp))
                            Text("NAME / DESCRIPTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(180.dp))
                            Text("INITIAL COST (৳)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(110.dp))
                            Text("PURCHASED QTY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(120.dp))
                            Text("SUPERVISOR", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(140.dp))
                            Text("STATUS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(110.dp))
                            Text("NET P/L (৳)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(100.dp))
                            Text("ACTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DeepNavy, modifier = Modifier.width(70.dp))
                        }

                        HorizontalDivider(color = Color(0xFFCBD5E1))

                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(rows) { index, rowState ->
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Date
                                    OutlinedTextField(
                                        value = rowState.date,
                                        onValueChange = { rowState.date = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(120.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Type Dropdown
                                    var typeExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(130.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { typeExpanded = true }
                                        ) {
                                            Row(modifier = Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text(rowState.type, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = typeExpanded,
                                            onDismissRequest = { typeExpanded = false }
                                        ) {
                                            types.forEach { t ->
                                                DropdownMenuItem(
                                                    text = { Text(t, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.type = t
                                                        typeExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Name
                                    OutlinedTextField(
                                        value = rowState.name,
                                        onValueChange = { rowState.name = it },
                                        placeholder = { Text("Goat Farming / Cumin", fontSize = 12.sp) },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(180.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Amount / Initial Cost
                                    OutlinedTextField(
                                        value = rowState.amountStr,
                                        onValueChange = { rowState.amountStr = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(110.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Purchased Qty
                                    OutlinedTextField(
                                        value = rowState.purchasedQuantity,
                                        onValueChange = { rowState.purchasedQuantity = it },
                                        placeholder = { Text("e.g. 6 Goats", fontSize = 12.sp) },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(120.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Supervisor
                                    OutlinedTextField(
                                        value = rowState.supervisor,
                                        onValueChange = { rowState.supervisor = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(140.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Status
                                    var statExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.width(110.dp)) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                            shape = RoundedCornerShape(8.dp),
                                            onClick = { statExpanded = true }
                                        ) {
                                            Row(modifier = Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text(rowState.status, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        androidx.compose.material3.DropdownMenu(
                                            expanded = statExpanded,
                                            onDismissRequest = { statExpanded = false }
                                        ) {
                                            statuses.forEach { s ->
                                                DropdownMenuItem(
                                                    text = { Text(s, fontSize = 12.sp) },
                                                    onClick = {
                                                        rowState.status = s
                                                        statExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Profit Loss
                                    OutlinedTextField(
                                        value = rowState.profitLossStr,
                                        onValueChange = { rowState.profitLossStr = it },
                                        singleLine = true,
                                        textStyle = appInputTextStyle(12.5.sp),
                                        colors = appOutlinedTextFieldColors(),
                                        modifier = Modifier.width(100.dp).height(52.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    // Remove
                                    IconButton(
                                        onClick = { if (rows.size > 1) rows.removeAt(index) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = RedAlert, modifier = Modifier.size(18.dp))
                                    }
                                }
                                HorizontalDivider(color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel", color = NagadSecondaryText) }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val validInvestments = rows.filter { it.name.isNotBlank() && (it.amountStr.toIntOrNull() ?: 0) > 0 }.map { r ->
                                val amt = r.amountStr.toIntOrNull() ?: 0
                                Investment(
                                    name = r.name.trim(),
                                    type = r.type,
                                    amount = amt,
                                    purchasedQuantity = r.purchasedQuantity.trim(),
                                    saleDate = r.saleDate.trim(),
                                    soldQuantity = r.soldQuantity.trim(),
                                    saleRevenue = r.saleRevenueStr.toIntOrNull() ?: 0,
                                    expenses = r.expensesStr.toIntOrNull() ?: 0,
                                    profitLoss = r.profitLossStr.toIntOrNull() ?: 0,
                                    activeCapital = if (r.status == "Active") amt else 0,
                                    status = r.status,
                                    date = r.date.trim(),
                                    supervisor = r.supervisor.trim(),
                                    stockStatus = r.stockStatus,
                                    description = "${r.purchasedQuantity} supervised by ${r.supervisor}"
                                )
                            }
                            onSaveAll(validInvestments)
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save All Investments (${rows.size})", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * Member Settlement & Return Dialog
 * When a member resigns or withdraws:
 * Net Return Amount = Total Deposit Paid - (Stamp/Typing Legal Charge + Shared Losses).
 * Settlement Status: 'Done' / 'Pending'.
 */
@Composable
fun MemberSettlementDialog(
    members: List<Member>,
    deposits: List<Deposit>,
    onDismiss: () -> Unit,
    onSave: (MemberSettlement) -> Unit
) {
    var selectedMemberId by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    val selectedMember = members.find { it.id == selectedMemberId } ?: members.firstOrNull()

    val totalDepositsPaid = remember(selectedMemberId, deposits) {
        deposits.filter { it.memberId == selectedMemberId }.sumOf { it.amount }
    }

    var resignationDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var legalChargeStr by remember { mutableStateOf("500") } // Stamp/Typing legal charge
    var sharedLossesStr by remember { mutableStateOf("0") }
    var settlementStatus by remember { mutableStateOf("Pending") }
    var paymentMode by remember { mutableStateOf("Cash") }
    var notes by remember { mutableStateOf("Formal resignation and capital return settlement") }

    val netReturn = remember(totalDepositsPaid, legalChargeStr, sharedLossesStr) {
        val legal = legalChargeStr.toIntOrNull() ?: 0
        val loss = sharedLossesStr.toIntOrNull() ?: 0
        (totalDepositsPaid - (legal + loss)).coerceAtLeast(0)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        title = { Text("Member Settlement & Return Ledger", fontWeight = FontWeight.Bold, color = NagadMainText) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Calculate return amount upon member resignation or withdrawal according to somiti bylaws:",
                    fontSize = 11.5.sp,
                    color = NagadSecondaryText
                )

                // Select Member
                var memberDropdown by remember { mutableStateOf(false) }
                Text("Select Member:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NagadMainText)
                Box {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .border(1.dp, InputBorder, RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        color = NagadWhite,
                        onClick = { memberDropdown = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = selectedMember?.let { "RRK-${it.id.toString().padStart(3, '0')} ${it.name}" } ?: "Select Member",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NagadMainText
                            )
                        }
                    }

                    androidx.compose.material3.DropdownMenu(
                        expanded = memberDropdown,
                        onDismissRequest = { memberDropdown = false }
                    ) {
                        members.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("RRK-${m.id.toString().padStart(3, '0')} ${m.name}") },
                                onClick = {
                                    selectedMemberId = m.id
                                    memberDropdown = false
                                }
                            )
                        }
                    }
                }

                // Verified Deposit Box
                Surface(
                    shape = AppCardShape,
                    color = NagadLightBg,
                    border = AppCardBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Deposit Paid:", fontSize = 12.sp, color = NagadMainText, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = CurrencyFormatter.formatCurrency(totalDepositsPaid),
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NagadPrimary
                        )
                    }
                }

                OutlinedTextField(
                    value = resignationDate,
                    onValueChange = { resignationDate = it },
                    label = { Text("Resignation / Withdrawal Date") },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )

                OutlinedTextField(
                    value = legalChargeStr,
                    onValueChange = { legalChargeStr = it },
                    label = { Text("Stamp / Typing Legal Charge (৳)") },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )

                OutlinedTextField(
                    value = sharedLossesStr,
                    onValueChange = { sharedLossesStr = it },
                    label = { Text("Shared Losses / Adjustments (৳)") },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )

                // Calculated Net Return Card
                Surface(
                    shape = AppCardShape,
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.5.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Net Return Calculation:", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText)
                        Text(
                            text = "Net Return = ${CurrencyFormatter.formatCurrency(totalDepositsPaid)} - (${CurrencyFormatter.formatCurrency(legalChargeStr.toIntOrNull() ?: 0)} + ${CurrencyFormatter.formatCurrency(sharedLossesStr.toIntOrNull() ?: 0)})",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadMainText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Net Payable: ${CurrencyFormatter.formatCurrency(netReturn)}",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldGreen
                        )
                    }
                }

                // Status & Mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { settlementStatus = if (settlementStatus == "Pending") "Done" else "Pending" },
                        border = BorderStroke(1.dp, InputBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Status: $settlementStatus", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (settlementStatus == "Done") EmeraldGreen else RedAlert)
                    }

                    OutlinedButton(
                        onClick = { paymentMode = if (paymentMode == "Cash") "Bank Transfer" else "Cash" },
                        border = BorderStroke(1.dp, InputBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadMainText),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Mode: $paymentMode", fontSize = 12.sp, color = NagadMainText)
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Settlement Agreement") },
                    singleLine = false,
                    maxLines = 3,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val entity = MemberSettlement(
                        memberId = selectedMemberId,
                        memberName = selectedMember?.name ?: "Member $selectedMemberId",
                        resignationDate = resignationDate.trim(),
                        totalDepositPaid = totalDepositsPaid,
                        legalCharge = legalChargeStr.toIntOrNull() ?: 0,
                        sharedLosses = sharedLossesStr.toIntOrNull() ?: 0,
                        netReturnAmount = netReturn,
                        settlementStatus = settlementStatus,
                        paymentMode = paymentMode,
                        notes = notes.trim()
                    )
                    onSave(entity)
                },
                colors = appSolidButtonColors(RoyalBlue)
            ) {
                Text("Confirm Settlement", fontWeight = FontWeight.Bold, color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = NagadSecondaryText) }
        }
    )
}

/**
 * Head Office RRK Voucher & Monthly Summary Statement
 * Allows Admin to inspect & share Head Office RRK voucher with correct reconciliation:
 * Total Collection, Fines, Profit/Loss, Bank Total, Hand Cash.
 */
@Composable
fun HeadOfficeVoucherCard(
    kpi: FinancialKpi,
    context: Context,
    adminName: String = "Md Rakib Hossain"
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavy),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, RoyalBlue.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "RISING ROADS OF KHARKHARIAN",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp),
                        color = Gold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Official Somiti Head Office Reconciliation Statement",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldGreen.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "AUDITED",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reconciled Liquid Capital Banner (Native Dark Glassmorphism)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF0A1128),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTAL LIQUID ASSETS / MAIN CAPITAL",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "11 Founding Members",
                            fontSize = 10.sp,
                            color = Gold,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CurrencyFormatter.formatCurrency(kpi.mainLiquidCapital),
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldGreen
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cash in Hand", fontSize = 11.sp, color = Color.White.copy(alpha = 0.85f))
                            Text(
                                text = CurrencyFormatter.formatCurrency(kpi.cashInHand),
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Bank Total Balance", fontSize = 11.sp, color = Color.White.copy(alpha = 0.85f))
                            Text(
                                text = CurrencyFormatter.formatCurrency(kpi.bankBalance),
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF93C5FD)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Export Actions (PDF Statement + Text Share)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val pdfFile = PdfReceiptGenerator.generateHeadOfficeVoucherPdf(context, kpi, adminName = adminName)
                        PdfReceiptGenerator.sharePdf(context, pdfFile, "Download Head Office Voucher (.pdf)")
                    },
                    colors = appSolidButtonColors(EmeraldGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Download PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        val pdfFile = PdfReceiptGenerator.generateHeadOfficeVoucherPdf(context, kpi, adminName = adminName)
                        PdfReceiptGenerator.printPdf(context, pdfFile, "RRK_Head_Office_Voucher")
                    },
                    border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(0.75f)
                ) {
                    Icon(imageVector = Icons.Default.Print, contentDescription = "Print Voucher PDF", modifier = Modifier.size(15.dp), tint = EmeraldGreen)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Print", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EmeraldGreen, maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        val grossStr = CurrencyFormatter.formatSignedCurrency(kpi.grossBusinessPnl)
                        val netPnlStr = CurrencyFormatter.formatSignedCurrency(kpi.realizedBusinessPnl)
                        val voucherText = """
                            ==================================================
                            RISING ROADS OF KHARKHARIAN (RRK) SOMITI
                            HEAD OFFICE OFFICIAL RECONCILIATION STATEMENT
                            Date: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())}
                            ==================================================
                            Active Founding Members: 11 Members
                            Monthly Contribution Rate: ৳1,000 / month
                            Inception Date: May 1, 2025
                            
                            1. REVENUE & INFLOW RECONCILIATION:
                               - Total Member Deposits (179 qty): ${CurrencyFormatter.formatCurrency(kpi.totalDeposits)}
                               - Deposit Fine (17 qty): ${CurrencyFormatter.formatCurrency(kpi.fineCollection)}
                               - Gross Business P/L (Profit ৳6,100 - Loss ৳6,700): $grossStr
                               - Exited Members' Loss Share Retained (3 × ৳14): +${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)}
                               - Net Business P/L ($grossStr + ${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)}): $netPnlStr
                               - Total Amount (Inflow Total): ${CurrencyFormatter.formatCurrency(kpi.totalCollection)}
                            
                            2. COST & INVESTMENT OUTFLOWS:
                               - Operational Expenses (8 records): ${CurrencyFormatter.formatCurrency(kpi.totalExpenses)}
                               - Investment Running: ${CurrencyFormatter.formatCurrency(kpi.totalRunningInvestments)}
                               - Cost & Invest: ${CurrencyFormatter.formatCurrency(kpi.costAndInvest)}
                            
                            3. CASH & BANK RECONCILIATION:
                               - Total Hand Cash (${CurrencyFormatter.formatCurrency(kpi.totalCollection)} - ${CurrencyFormatter.formatCurrency(kpi.costAndInvest)}): ${CurrencyFormatter.formatCurrency(kpi.cashInHand)}
                               - Bank Total: ${CurrencyFormatter.formatCurrency(kpi.bankBalance)}
                               - Grand Total / Main Capital (Bank + Hand Cash): ${CurrencyFormatter.formatCurrency(kpi.mainLiquidCapital)}
                            
                            4. DUES & RESERVES:
                               - Total Member Remaining Dues: ${CurrencyFormatter.formatCurrency(kpi.totalDue)}
                               - General Reserve Fund: ${CurrencyFormatter.formatCurrency(kpi.reservedAmount)}
                            ==================================================
                            Authorized by Rakib
                        """.trimIndent()

                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "RRK Head Office Official Statement")
                            putExtra(Intent.EXTRA_TEXT, voucherText)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Head Office Statement"))
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(0.7f)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = Gold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share Text", fontSize = 12.sp, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            // Financial Breakdown Rows
            val grossStr = CurrencyFormatter.formatSignedCurrency(kpi.grossBusinessPnl)
            val netPnlStr = CurrencyFormatter.formatSignedCurrency(kpi.realizedBusinessPnl)
            VoucherLineItem("1. Total Member Deposits (179 qty)", CurrencyFormatter.formatCurrency(kpi.totalDeposits), EmeraldGreen)
            VoucherLineItem("2. Deposit Fine (17 qty)", CurrencyFormatter.formatCurrency(kpi.fineCollection), Gold)
            VoucherLineItem("3. Net Business P/L (Gross $grossStr + ${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)} exited share)", netPnlStr, if (kpi.realizedBusinessPnl >= 0) EmeraldGreen else RedAlert)
            VoucherLineItem("4. Total Amount (Inflow Total: 1+2+3)", CurrencyFormatter.formatCurrency(kpi.totalCollection), EmeraldGreen)
            VoucherLineItem("5. Operational Expenses (8 Records)", "-${CurrencyFormatter.formatCurrency(kpi.totalExpenses)}", RedAlert)
            VoucherLineItem("6. Investment Running", CurrencyFormatter.formatCurrency(kpi.totalRunningInvestments), Color(0xFF93C5FD))
            VoucherLineItem("7. Cost & Invest (Expenses + Running)", "-${CurrencyFormatter.formatCurrency(kpi.costAndInvest)}", RedAlert)
            VoucherLineItem("8. Total Hand Cash (${CurrencyFormatter.formatCurrency(kpi.totalCollection)} - ${CurrencyFormatter.formatCurrency(kpi.costAndInvest)})", CurrencyFormatter.formatCurrency(kpi.cashInHand), EmeraldGreen)
            VoucherLineItem("9. Bank Total", CurrencyFormatter.formatCurrency(kpi.bankBalance), Color(0xFF93C5FD))
            VoucherLineItem("10. Grand Total / Main Capital (Bank + Hand Cash)", CurrencyFormatter.formatCurrency(kpi.mainLiquidCapital), Gold)

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(10.dp))

            VoucherLineItem("Member Total Outstanding Dues", CurrencyFormatter.formatCurrency(kpi.totalDue), if (kpi.totalDue > 0) RedAlert else EmeraldGreen)
            VoucherLineItem("General Reserve Fund", CurrencyFormatter.formatCurrency(kpi.reservedAmount), Gold)

            Spacer(modifier = Modifier.height(18.dp))

            // Signature block with Authorized by Rakib
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White.copy(alpha = 0.05f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Certified Institutional Audit", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                        Text("Rising Roads Of Kharkharian", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Official Authority", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                        Text("Authorized by Rakib", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF86EFAC))
                    }
                }
            }
        }
    }
}

@Composable
private fun VoucherLineItem(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = Color.White)
        Text(
            text = value,
            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = color
        )
    }
}
