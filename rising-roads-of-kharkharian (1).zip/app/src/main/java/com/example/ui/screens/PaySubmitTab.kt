package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AppRepository
import com.example.ui.MainViewModel
import com.example.util.AdminNotificationHelper
import com.example.ui.components.AppCardBorder
import com.example.ui.components.AppCardElevation
import com.example.ui.components.AppCardShape
import com.example.ui.components.AppInputShape
import com.example.ui.components.EditOfficialPaymentAccountsDialog
import com.example.ui.components.MemberPaymentRequestItemCard
import com.example.ui.components.appInputTextStyle
import com.example.ui.components.appOutlinedTextFieldColors
import com.example.ui.components.appSolidButtonColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.TABULAR_NUMBERS
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaySubmitTab(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val officialAccounts by viewModel.officialPaymentAccounts.collectAsState()
    val adminAlertEmailSettings by viewModel.adminAlertEmailSettings.collectAsState()
    val allRequests by viewModel.paymentRequests.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val memberSession by viewModel.memberSession.collectAsState()
    val rememberedSession by viewModel.rememberedSession.collectAsState()

    val activeMonths = remember { AppRepository.getActiveMonths() }
    val todayDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    // Match logged-in member identity to one of the 11 members if possible
    val loggedInMatchedMemberId = remember(membersWithStats, memberSession, rememberedSession) {
        val rawId = memberSession.rrkMemberId.ifBlank { rememberedSession.rrkMemberId }
        val parsedNumeric = Regex("(\\d+)").find(rawId)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val rawName = memberSession.fullName.ifBlank { rememberedSession.fullName }.trim()
        membersWithStats.find { it.member.id == parsedNumeric }?.member?.id
            ?: membersWithStats.find { it.member.name.equals(rawName, ignoreCase = true) }?.member?.id
    }

    var selectedMemberId by remember { mutableIntStateOf(loggedInMatchedMemberId ?: 1) }
    LaunchedEffect(loggedInMatchedMemberId, membersWithStats) {
        if (loggedInMatchedMemberId != null) {
            selectedMemberId = loggedInMatchedMemberId
        } else if (membersWithStats.isNotEmpty() && membersWithStats.none { it.member.id == selectedMemberId }) {
            selectedMemberId = membersWithStats.first().member.id
        }
    }

    val selectedMemberStats = membersWithStats.find { it.member.id == selectedMemberId } ?: membersWithStats.firstOrNull()
    val defaultMonth = remember(selectedMemberStats, activeMonths) {
        selectedMemberStats?.pendingMonths?.firstOrNull() ?: activeMonths.lastOrNull() ?: "Oct 2026"
    }

    var selectedMonth by remember { mutableStateOf(defaultMonth) }
    LaunchedEffect(selectedMemberId) {
        val st = membersWithStats.find { it.member.id == selectedMemberId }
        selectedMonth = st?.pendingMonths?.firstOrNull() ?: activeMonths.lastOrNull() ?: "Oct 2026"
    }

    var selectedMethod by remember { mutableStateOf("bKash") }
    var paymentDateText by remember { mutableStateOf(todayDate) }

    val capitalDue = selectedMemberStats?.totalDue ?: 0
    val mandatoryFineDue = remember(selectedMemberStats, selectedMonth, paymentDateText) {
        AppRepository.calculateMandatoryFineDue(
            stats = selectedMemberStats,
            selectedMonth = selectedMonth,
            paymentDate = paymentDateText
        )
    }
    val totalPayableBalance = capitalDue + mandatoryFineDue

    var depositAmountText by remember {
        mutableStateOf(if (capitalDue > 0) capitalDue.toString() else "1000")
    }
    LaunchedEffect(selectedMemberStats?.member?.id, selectedMemberStats?.totalDue) {
        val due = selectedMemberStats?.totalDue ?: 0
        depositAmountText = if (due > 0) due.toString() else "1000"
    }

    var trxIdText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var formFeedback by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var lastSubmittedTrxId by remember { mutableStateOf("") }
    var lastSubmittedAmount by remember { mutableIntStateOf(0) }
    var lastSubmittedFine by remember { mutableIntStateOf(0) }
    var lastSubmittedMonth by remember { mutableStateOf("") }
    var lastSubmittedMethod by remember { mutableStateOf("") }
    var lastSubmittedDate by remember { mutableStateOf("") }

    var memberDropdownExpanded by remember { mutableStateOf(false) }
    var monthDropdownExpanded by remember { mutableStateOf(false) }
    var showEditAccountsDialog by remember { mutableStateOf(false) }
    LaunchedEffect(isAdmin) {
        if (!isAdmin) showEditAccountsDialog = false
    }
    var historyFilterMode by remember { mutableStateOf("Mine") } // "Mine" or "All"

    val displayedRequests = remember(allRequests, selectedMemberId, historyFilterMode) {
        if (historyFilterMode == "Mine") {
            allRequests.filter { it.memberId == selectedMemberId }
        } else {
            allRequests
        }
    }

    val membersPhoneMap = remember(membersWithStats) {
        membersWithStats.associate { it.member.id to it.member.phone }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("pay_submit_tab"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Official Payment Accounts Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Official Payment Accounts",
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.5.sp,
                                color = NagadMainText
                            )
                            Text(
                                text = "Send your monthly contribution, then submit TrxID below",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.5.sp,
                                color = NagadSecondaryText
                            )
                        }

                        if (isAdmin) {
                            OutlinedButton(
                                onClick = { showEditAccountsDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, NagadPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("edit_official_accounts_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit payment accounts",
                                    tint = NagadPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Edit",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    color = NagadPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OfficialAccountCopyRow(
                        label = "Personal bKash",
                        value = officialAccounts.bkash,
                        accentColor = Color(0xFFD81B60),
                        bgColor = Color(0xFFFDF2F8),
                        icon = Icons.Default.PhoneAndroid,
                        onCopy = {
                            val numberOnly = officialAccounts.bkash.substringBefore(" (").trim()
                            clipboardManager.setText(AnnotatedString(numberOnly))
                            viewModel.showToast("bKash account copied: $numberOnly")
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OfficialAccountCopyRow(
                        label = "Personal Nagad",
                        value = officialAccounts.nagad,
                        accentColor = Color(0xFFEA580C),
                        bgColor = Color(0xFFFFF7ED),
                        icon = Icons.Default.Payments,
                        onCopy = {
                            val numberOnly = officialAccounts.nagad.substringBefore(" (").trim()
                            clipboardManager.setText(AnnotatedString(numberOnly))
                            viewModel.showToast("Nagad account copied: $numberOnly")
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OfficialAccountCopyRow(
                        label = "Bank Account Details",
                        value = officialAccounts.bank,
                        accentColor = Color(0xFF1D4ED8),
                        bgColor = Color(0xFFEFF6FF),
                        icon = Icons.Default.AccountBalance,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(officialAccounts.bank))
                            viewModel.showToast("Bank details copied to clipboard!")
                        }
                    )
                }
            }
        }

        // 2. Submit Payment Proof Form Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("submit_payment_proof_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Submit Payment Proof",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Requests enter PENDING status until verified by Admin",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp,
                        color = NagadSecondaryText
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Member Selector
                    ExposedDropdownMenuBox(
                        expanded = memberDropdownExpanded,
                        onExpandedChange = { memberDropdownExpanded = !memberDropdownExpanded }
                    ) {
                        val currentLabel = selectedMemberStats?.let {
                            "RRK-${it.member.id.toString().padStart(3, '0')} · ${it.member.name}"
                        } ?: "Select Member"
                        OutlinedTextField(
                            value = currentLabel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Member *", fontFamily = InterFontFamily) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownExpanded) },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = memberDropdownExpanded,
                            onDismissRequest = { memberDropdownExpanded = false }
                        ) {
                            membersWithStats.forEach { st ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "RRK-${st.member.id.toString().padStart(3, '0')} · ${st.member.name}",
                                            fontFamily = InterFontFamily,
                                            fontWeight = if (st.member.id == selectedMemberId) FontWeight.Bold else FontWeight.Normal,
                                            color = if (st.member.id == selectedMemberId) NagadPrimary else NagadMainText
                                        )
                                    },
                                    onClick = {
                                        selectedMemberId = st.member.id
                                        memberDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Billing Month Selector
                    ExposedDropdownMenuBox(
                        expanded = monthDropdownExpanded,
                        onExpandedChange = { monthDropdownExpanded = !monthDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedMonth,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Billing Month *", fontFamily = InterFontFamily) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthDropdownExpanded) },
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = monthDropdownExpanded,
                            onDismissRequest = { monthDropdownExpanded = false }
                        ) {
                            activeMonths.reversed().forEach { monthItem ->
                                val isAlreadyPaid = selectedMemberStats?.paidMonths?.contains(monthItem) == true
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = monthItem,
                                                fontFamily = InterFontFamily,
                                                fontWeight = if (monthItem == selectedMonth) FontWeight.Bold else FontWeight.Normal,
                                                color = if (monthItem == selectedMonth) NagadPrimary else NagadMainText
                                            )
                                            if (isAlreadyPaid) {
                                                Text(
                                                    text = "Paid",
                                                    fontFamily = InterFontFamily,
                                                    fontSize = 11.sp,
                                                    color = NagadPrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedMonth = monthItem
                                        monthDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Live Member Dues & Auto-Fine Summary Card
                    val fmtCapDue = remember(capitalDue) {
                        CurrencyFormatter.formatNumber(capitalDue)
                    }
                    val fmtFineDue = remember(mandatoryFineDue) {
                        CurrencyFormatter.formatNumber(mandatoryFineDue)
                    }
                    val fmtTotalPayable = remember(totalPayableBalance) {
                        CurrencyFormatter.formatNumber(totalPayableBalance)
                    }

                    Surface(
                        shape = AppCardShape,
                        color = if (capitalDue > 0 || mandatoryFineDue > 0) NagadVeryLightBg else NagadLightBg,
                        border = BorderStroke(
                            1.5.dp,
                            if (mandatoryFineDue > 0) Color(0xFFFCD34D) else NagadBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_dues_auto_fine_summary_card")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Live Member Dues & Mandatory Fine Summary",
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = NagadMainText,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 8.dp)
                                )
                                val unpaidMonthsCount = selectedMemberStats?.consecutiveUnpaidMonths ?: 0
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (capitalDue > 0) Color(0xFFFEF2F2) else Color(0xFFECFDF5),
                                    border = BorderStroke(
                                        0.8.dp,
                                        if (capitalDue > 0) Color(0xFFFCA5A5) else Color(0xFF6EE7B7)
                                    )
                                ) {
                                    Text(
                                        text = if (capitalDue > 0) {
                                            if (unpaidMonthsCount == 1) "1 Unpaid Month" else "$unpaidMonthsCount Unpaid Months"
                                        } else {
                                            "All Clear"
                                        },
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.5.sp,
                                        color = if (capitalDue > 0) NagadDanger else NagadPrimary,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Max),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // 1. Total Capital Due
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFFFF5F6),
                                    border = BorderStroke(1.dp, Color(0xFFFECDD3)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Total Capital Due",
                                            fontFamily = InterFontFamily,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = NagadSecondaryText,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "৳$fmtCapDue",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.5.sp,
                                            color = if (capitalDue > 0) NagadDanger else NagadPrimary,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }

                                // 2. Mandatory Fine
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (mandatoryFineDue > 0) Color(0xFFFFFCF2) else NagadWhite,
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (mandatoryFineDue > 0) Color(0xFFFDE68A) else NagadBorder
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Mandatory Fine",
                                            fontFamily = InterFontFamily,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (mandatoryFineDue > 0) Color(0xFFB45309) else NagadSecondaryText,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "৳$fmtFineDue",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.5.sp,
                                            color = if (mandatoryFineDue > 0) Color(0xFFB45309) else NagadPrimary,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }

                                // 3. Total Payable Balance
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFECFDF5),
                                    border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Total Payable",
                                            fontFamily = InterFontFamily,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF065F46),
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "৳$fmtTotalPayable",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.5.sp,
                                            color = NagadPrimary,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Fine rule: ৳100 per overdue month past the 15th deadline (+৳100 if selected month is paid after the 15th). Deposit is editable for partial payment; Fine is mandatory.",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.5.sp,
                                color = NagadSecondaryText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Payment Method Chips
                    Text(
                        text = "Payment Method *",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = NagadSecondaryText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("bKash", "Nagad", "Bank", "Cash").forEach { method ->
                            val isSelected = selectedMethod == method
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedMethod = method },
                                leadingIcon = if (isSelected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = NagadPrimary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                } else null,
                                label = {
                                    Text(
                                        text = method,
                                        fontFamily = InterFontFamily,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.5.sp,
                                        color = if (isSelected) NagadPrimary else NagadMainText
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NagadLightBg,
                                    containerColor = NagadWhite
                                ),
                                border = BorderStroke(
                                    1.2.dp,
                                    if (isSelected) NagadPrimary else NagadBorder
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Deposit Amount (Freely Editable) + Mandatory Locked Fine Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = depositAmountText,
                            onValueChange = { input ->
                                depositAmountText = input.filter { it.isDigit() }
                            },
                            label = { Text("Deposit (৳) *", fontFamily = InterFontFamily) },
                            singleLine = true,
                            textStyle = appInputTextStyle(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("payment_deposit_input")
                        )
                        OutlinedTextField(
                            value = mandatoryFineDue.toString(),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Fine (৳, Locked)", fontFamily = InterFontFamily) },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Mandatory locked fine",
                                    tint = if (mandatoryFineDue > 0) Color(0xFFB45309) else NagadSecondaryText,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            singleLine = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("payment_fine_locked_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // TrxID & Date
                    OutlinedTextField(
                        value = trxIdText,
                        onValueChange = { trxIdText = it },
                        label = {
                            Text(
                                text = if (selectedMethod == "Cash") {
                                    "Reference / Receipt Note (Optional)"
                                } else {
                                    "$selectedMethod Transaction ID (TrxID) *"
                                },
                                fontFamily = InterFontFamily
                            )
                        },
                        placeholder = {
                            Text(
                                text = if (selectedMethod == "Cash") "e.g., Handed to Treasurer" else "e.g., BKH89A42X9",
                                fontFamily = InterFontFamily,
                                color = NagadSecondaryText
                            )
                        },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            autoCorrectEnabled = false
                        ),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payment_trxid_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = paymentDateText,
                        onValueChange = { paymentDateText = it },
                        label = { Text("Payment Date (YYYY-MM-DD)", fontFamily = InterFontFamily) },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Summary Preview Strip
                    val amtInt = depositAmountText.toIntOrNull() ?: 0
                    val fineInt = mandatoryFineDue
                    val totalPreview = CurrencyFormatter.formatNumber(amtInt + fineInt)
                    val fmtAmtPreview = CurrencyFormatter.formatNumber(amtInt)
                    val fmtFinePreview = CurrencyFormatter.formatNumber(fineInt)
                    val remainingCapitalAfterPayment = (capitalDue - amtInt).coerceAtLeast(0)
                    val fmtRemainingCap = CurrencyFormatter.formatNumber(remainingCapitalAfterPayment)

                    Surface(
                        shape = AppCardShape,
                        color = NagadLightBg,
                        border = AppCardBorder,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = NagadPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            text = "Total Proof Amount",
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.5.sp,
                                            color = NagadMainText
                                        )
                                        Text(
                                            text = "Deposit ৳$fmtAmtPreview + Mandatory Fine ৳$fmtFinePreview",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 10.5.sp,
                                            color = NagadSecondaryText
                                        )
                                    }
                                }
                                Text(
                                    text = "৳$totalPreview",
                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = NagadPrimary,
                                    modifier = Modifier.testTag("total_proof_amount_text")
                                )
                            }
                            if (capitalDue > 0 && amtInt in 1 until capitalDue) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Partial Capital Deposit: ৳$fmtRemainingCap Capital Due will carry forward after Admin approval (Mandatory Fine ৳$fmtFinePreview settled).",
                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }

                    if (formFeedback != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val (isSuccess, msg) = formFeedback!!
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSuccess) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, if (isSuccess) Color(0xFF6EE7B7) else Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = msg,
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = if (isSuccess) NagadPrimary else NagadDanger,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val member = selectedMemberStats?.member
                            if (member == null) {
                                formFeedback = false to "Please select a valid member."
                                return@Button
                            }
                            val submittedDate = paymentDateText.ifBlank { todayDate }
                            val submittedTrx = trxIdText.trim().ifEmpty {
                                "CASH-${submittedDate.replace("-", "")}"
                            }
                            viewModel.submitPaymentRequest(
                                memberId = member.id,
                                memberName = member.name,
                                month = selectedMonth,
                                paymentMethod = selectedMethod,
                                amount = amtInt,
                                fine = mandatoryFineDue,
                                trxId = trxIdText,
                                paymentDate = submittedDate,
                                notes = notesText
                            ) { ok, message ->
                                formFeedback = ok to message
                                if (ok) {
                                    lastSubmittedTrxId = submittedTrx
                                    lastSubmittedAmount = amtInt
                                    lastSubmittedFine = mandatoryFineDue
                                    lastSubmittedMonth = selectedMonth
                                    lastSubmittedMethod = selectedMethod
                                    lastSubmittedDate = submittedDate
                                    trxIdText = ""
                                    notesText = ""
                                }
                            }
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(12.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_payment_proof_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Submit payment proof",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Submit Payment Proof",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            val member = selectedMemberStats?.member ?: return@OutlinedButton
                            val emailMonth = lastSubmittedMonth.ifBlank { selectedMonth }
                            val emailMethod = lastSubmittedMethod.ifBlank { selectedMethod }
                            val emailAmount = if (lastSubmittedAmount > 0) lastSubmittedAmount else amtInt
                            val emailFine = if (lastSubmittedAmount > 0) lastSubmittedFine else mandatoryFineDue
                            val emailDate = lastSubmittedDate.ifBlank { paymentDateText.ifBlank { todayDate } }
                            val emailTrx = trxIdText.trim().ifBlank {
                                lastSubmittedTrxId.ifBlank { "CASH-${emailDate.replace("-", "")}" }
                            }
                            AdminNotificationHelper.launchAdminEmailFallbackIntent(
                                context = context,
                                adminEmail = adminAlertEmailSettings.adminAlertEmail,
                                memberName = member.name,
                                memberId = member.id,
                                month = emailMonth,
                                amount = emailAmount,
                                fine = emailFine,
                                paymentMethod = emailMethod,
                                trxId = emailTrx,
                                paymentDate = emailDate
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.2.dp, NagadPrimary.copy(alpha = 0.45f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = NagadLightBg,
                            contentColor = NagadPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("notify_admin_via_email_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Notify Admin via Email",
                            tint = NagadPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Notify Admin via Email",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = NagadPrimary
                        )
                    }
                }
            }
        }

        // 3. My Payment Requests History Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "My Payment Requests (${displayedRequests.size})",
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.5.sp,
                                color = NagadMainText
                            )
                            Text(
                                text = "Live Admin verification status & proof downloads",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.5.sp,
                                color = NagadSecondaryText
                            )
                        }

                        if (selectedMemberStats != null) {
                            Text(
                                text = "Profile →",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = NagadPrimary,
                                modifier = Modifier
                                    .clickable { onNavigateToMemberProfile(selectedMemberStats.member.id) }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "Mine" to (selectedMemberStats?.member?.name?.split(" ")?.firstOrNull() ?: "Selected"),
                            "All" to "All Members (${allRequests.size})"
                        ).forEach { (key, label) ->
                            val selected = historyFilterMode == key
                            FilterChip(
                                selected = selected,
                                onClick = { historyFilterMode = key },
                                label = {
                                    Text(
                                        text = label,
                                        fontFamily = InterFontFamily,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selected) NagadPrimary else NagadSecondaryText
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NagadLightBg,
                                    containerColor = NagadWhite
                                ),
                                border = BorderStroke(1.dp, if (selected) NagadPrimary else NagadBorder)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = NagadBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (displayedRequests.isEmpty()) {
                        Surface(
                            shape = AppCardShape,
                            color = NagadVeryLightBg,
                            border = AppCardBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "No payment proof requests submitted yet. Once you send funds and submit your TrxID above, your live status and verified receipt will appear here.",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.sp,
                                color = NagadSecondaryText,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
            }
        }

        if (displayedRequests.isNotEmpty()) {
            items(displayedRequests, key = { it.id }) { req ->
                MemberPaymentRequestItemCard(
                    request = req,
                    memberPhone = membersPhoneMap[req.memberId].orEmpty(),
                    adminFallbackName = adminUsername,
                    adminAlertEmail = adminAlertEmailSettings.adminAlertEmail,
                    showMemberIdentity = true,
                    onProofDownloaded = { msg -> viewModel.showToast(msg) }
                )
            }
        }
    }

    if (isAdmin && showEditAccountsDialog) {
        EditOfficialPaymentAccountsDialog(
            currentAccounts = officialAccounts,
            onDismiss = { showEditAccountsDialog = false },
            onSave = { bkash, nagad, bank ->
                viewModel.updateOfficialPaymentAccounts(bkash, nagad, bank)
                showEditAccountsDialog = false
            }
        )
    }
}

@Composable
private fun OfficialAccountCopyRow(
    label: String,
    value: String,
    accentColor: Color,
    bgColor: Color,
    icon: ImageVector,
    onCopy: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = label,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = accentColor
                    )
                    Text(
                        text = value,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = NagadMainText
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedButton(
                onClick = onCopy,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy $label",
                    tint = accentColor,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Copy",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = accentColor
                )
            }
        }
    }
}
