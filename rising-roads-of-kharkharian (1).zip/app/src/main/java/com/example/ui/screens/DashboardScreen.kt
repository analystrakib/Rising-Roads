package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.FinancialKpi
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithStats
import com.example.data.repository.AppRepository
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private enum class TransactionFilter(val label: String) {
    ALL("All"),
    DEPOSITS("Deposits"),
    INVESTMENTS("Investments"),
    EXPENSES("Expenses")
}

private sealed class DashboardTransaction(val sortDate: String, val sortId: Int) {
    class DepositTx(val deposit: Deposit, val member: Member?) :
        DashboardTransaction(deposit.paymentDate, deposit.id)

    class InvestmentTx(val investment: Investment) :
        DashboardTransaction(investment.date, investment.id)

    class ExpenseTx(val expense: Expense) :
        DashboardTransaction(expense.date, expense.id)
}

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToMembers: () -> Unit,
    onNavigateToMemberProfile: (Int) -> Unit,
    onNavigateToDeposits: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToAdminApprovalQueue: () -> Unit = {},
    onNavigateToPaySubmit: () -> Unit = {}
) {
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val deposits by viewModel.deposits.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val kpi by viewModel.financialKpi.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val adminRole by viewModel.adminRole.collectAsState()
    val pendingPaymentRequestsCount by viewModel.pendingPaymentRequestsCount.collectAsState()
    val activeMemberDueReminders by viewModel.activeMemberDueReminders.collectAsState()

    var selectedMemberId by remember { mutableStateOf<Int?>(null) }
    var isMemberMenuExpanded by remember { mutableStateOf(false) }
    var isBalanceVisible by remember { mutableStateOf(true) }
    var txFilter by remember { mutableStateOf(TransactionFilter.ALL) }

    var selectedReceiptDeposit by remember { mutableStateOf<Deposit?>(null) }
    var selectedReceiptMember by remember { mutableStateOf<Member?>(null) }

    val selectedMemberStats = remember(membersWithStats, selectedMemberId) {
        selectedMemberId?.let { id -> membersWithStats.find { it.member.id == id } }
    }

    val redAlertNames = remember(membersWithStats) {
        membersWithStats.filter { it.status == MemberStatus.RED_ALERT }.map { it.member.name }
    }

    val currentMonth = remember {
        SimpleDateFormat("MMMM yyyy", Locale.US).format(Date())
    }
    val currentShortMonthYear = remember {
        SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
    }
    val currentIsoYearMonth = remember {
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    }

    val currentMonthDeposits = remember(deposits, currentMonth, currentShortMonthYear) {
        deposits.filter {
            it.month.equals(currentMonth, true) ||
                it.month.equals(currentShortMonthYear, true)
        }.sumOf { it.amount + it.fine }
    }

    val currentMonthExpenses = remember(expenses, currentMonth, currentIsoYearMonth) {
        val parseFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        expenses.filter { exp ->
            try {
                val d = parseFmt.parse(exp.date)
                if (d != null) {
                    val mStr = SimpleDateFormat("MMMM yyyy", Locale.US).format(d)
                    mStr.equals(currentMonth, true) || exp.date.startsWith(currentIsoYearMonth)
                } else {
                    exp.date.startsWith(currentIsoYearMonth)
                }
            } catch (e: Exception) {
                exp.date.contains(currentIsoYearMonth)
            }
        }.sumOf { it.amount }
    }

    val netMonthlyFlow = currentMonthDeposits - currentMonthExpenses

    // Unified Recent Transaction History sorted newest-first
    val recentTransactions = remember(deposits, investments, expenses, membersWithStats, selectedMemberId, txFilter) {
        val membersMap = membersWithStats.associate { it.member.id to it.member }
        val filteredDeposits = if (selectedMemberId != null) {
            deposits.filter { it.memberId == selectedMemberId }
        } else {
            deposits
        }

        val items = buildList {
            if (txFilter == TransactionFilter.ALL || txFilter == TransactionFilter.DEPOSITS) {
                filteredDeposits.forEach { add(DashboardTransaction.DepositTx(it, membersMap[it.memberId])) }
            }
            if (selectedMemberId == null && (txFilter == TransactionFilter.ALL || txFilter == TransactionFilter.INVESTMENTS)) {
                investments.forEach { add(DashboardTransaction.InvestmentTx(it)) }
            }
            if (selectedMemberId == null && (txFilter == TransactionFilter.ALL || txFilter == TransactionFilter.EXPENSES)) {
                expenses.forEach { add(DashboardTransaction.ExpenseTx(it)) }
            }
        }

        items.sortedWith(
            compareByDescending<DashboardTransaction> { it.sortDate }
                .thenByDescending { it.sortId }
        ).take(8)
    }

    // Chart data for monthly collections
    val barItems = remember(deposits) {
        val activeMonths = AppRepository.getActiveMonths().takeLast(6)
        activeMonths.map { month ->
            val totalMonth = deposits.filter { it.month == month }.sumOf { it.amount + it.fine }.toFloat()
            BarItem(
                label = month.split(" ").firstOrNull() ?: month,
                value = totalMonth,
                color = NagadPrimary
            )
        }
    }

    // Chart data for member statuses
    val donutSlices = remember(membersWithStats) {
        val activeCount = membersWithStats.count { it.status == MemberStatus.ACTIVE }.toFloat()
        val warningCount = membersWithStats.count { it.status == MemberStatus.WARNING }.toFloat()
        val redAlertCount = membersWithStats.count { it.status == MemberStatus.RED_ALERT }.toFloat()
        listOf(
            DonutSlice("Active", activeCount, NagadPrimary),
            DonutSlice("Warning", warningCount, NagadWarning),
            DonutSlice("RED ALERT", redAlertCount, NagadDanger)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (pendingPaymentRequestsCount > 0) {
            item {
                Surface(
                    shape = AppCardShape,
                    color = Color(0xFFFFFBEB),
                    border = BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                    shadowElevation = AppCardElevation,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(AppCardShape)
                        .clickable { onNavigateToAdminApprovalQueue() }
                        .testTag("dashboard_pending_payment_alert_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🔔 New Payment Proof Pending Verification — Review Now",
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = "$pendingPaymentRequestsCount pending payment request(s) awaiting Admin verification",
                                fontFamily = PoppinsFontFamily,
                                fontSize = 10.5.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFFD97706)
                        ) {
                            Text(
                                text = "$pendingPaymentRequestsCount",
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        if (activeMemberDueReminders.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    activeMemberDueReminders.forEach { reminder ->
                        MemberDueReminderBanner(
                            reminder = reminder,
                            onPayNow = onNavigateToPaySubmit,
                            onDismiss = { viewModel.dismissDueReminder(reminder.id) }
                        )
                    }
                }
            }
        }

        // Top Welcome Header & Member Portfolio Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Welcome Back",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NagadMainText
                    )
                    Text(
                        text = "Rising Roads · $currentMonth",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = NagadSecondaryText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NagadLightBg,
                        border = BorderStroke(1.2.dp, NagadPrimary.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .clickable { isMemberMenuExpanded = true }
                            .testTag("member_balance_selector")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Select member portfolio",
                                tint = NagadPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedMemberStats?.member?.name?.split(" ")?.firstOrNull()
                                    ?: "All Partners",
                                fontFamily = PoppinsFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NagadPrimary,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = NagadPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = isMemberMenuExpanded,
                        onDismissRequest = { isMemberMenuExpanded = false },
                        containerColor = NagadWhite
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "All Partners (Fund Overview)",
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedMemberId == null) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedMemberId == null) NagadPrimary else NagadMainText
                                )
                            },
                            onClick = {
                                selectedMemberId = null
                                isMemberMenuExpanded = false
                            }
                        )
                        HorizontalDivider(color = NagadBorder)
                        membersWithStats.forEach { stats ->
                            val isSelected = selectedMemberId == stats.member.id
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = stats.member.name,
                                            fontFamily = PoppinsFontFamily,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) NagadPrimary else NagadMainText
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = "৳${formatAmount(stats.totalPaidContribution)}",
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadPrimary
                                        )
                                    }
                                },
                                onClick = {
                                    selectedMemberId = stats.member.id
                                    isMemberMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // RED ALERT Banner if any
        if (redAlertNames.isNotEmpty()) {
            item {
                RedAlertBanner(alertMembers = redAlertNames)
            }
        }

        // Hero Card: Current Investment Balance (Member Portfolio or Collective Fund)
        item {
            InvestmentBalanceHeroCard(
                kpi = kpi,
                selectedMember = selectedMemberStats,
                totalMembersCount = membersWithStats.size.coerceAtLeast(1),
                isBalanceVisible = isBalanceVisible,
                onToggleBalanceVisibility = { isBalanceVisible = !isBalanceVisible },
                onNavigateToFinance = onNavigateToFinance,
                onNavigateToSecondary = {
                    if (selectedMemberStats != null) {
                        onNavigateToMemberProfile(selectedMemberStats.member.id)
                    } else {
                        onNavigateToMembers()
                    }
                }
            )
        }

        // Stat Cards & Business P&L Grid (2x2 Grid)
        item {
            val pnlVal = kpi.realizedBusinessPnl
            val pnlColor = if (pnlVal < 0) NagadDanger else NagadPrimary
            val pnlDisplay = if (pnlVal > 0) "+৳${formatAmount(pnlVal)}" else if (pnlVal < 0) "-৳${formatAmount(-pnlVal)}" else "৳0"
            val closedInvestments = remember(investments) {
                investments.filter {
                    val st = it.status.uppercase()
                    st == "CLOSED" || st == "COMPLETED" || st == "LIQUIDATED"
                }
            }
            val realizedProfits = remember(closedInvestments) {
                closedInvestments.filter { it.profitLoss > 0 }.sumOf { it.profitLoss }
            }
            val realizedLosses = remember(closedInvestments) {
                closedInvestments.filter { it.profitLoss < 0 }.sumOf { -it.profitLoss }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Total Deposits",
                        value = CurrencyFormatter.formatCurrency(kpi.totalDeposits),
                        valueColor = NagadPrimary,
                        subtitle = "Pure member contributions",
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Active Members",
                        value = "${membersWithStats.size}",
                        valueColor = NagadPrimary,
                        subtitle = "Founding Partners",
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val grossStr = if (kpi.grossBusinessPnl >= 0) "+৳${formatAmount(kpi.grossBusinessPnl)}" else "-৳${formatAmount(-kpi.grossBusinessPnl)}"
                    StatCard(
                        title = "Business P&L",
                        value = pnlDisplay,
                        subtitle = "Gross $grossStr + ৳${formatAmount(kpi.exitedMembersLossRecovery)} exited share",
                        valueColor = pnlColor,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Total Dues",
                        value = "৳${formatAmount(kpi.totalDue)}",
                        valueColor = if (kpi.totalDue > 0) NagadDanger else NagadPrimary,
                        subtitle = "Pending Receivables",
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }
            }
        }

        // Recent Transaction History Card (Unified Deposits, Investments & Expenses)
        item {
            RecentTransactionHistoryCard(
                transactions = recentTransactions,
                selectedFilter = txFilter,
                selectedMemberName = selectedMemberStats?.member?.name,
                onSelectFilter = { txFilter = it },
                onViewAllHistory = onNavigateToDeposits,
                onDepositClick = { deposit, member ->
                    if (member != null) {
                        selectedReceiptDeposit = deposit
                        selectedReceiptMember = member
                    }
                }
            )
        }

        // Monthly Financial Summary Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth().testTag("monthly_financial_summary_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Monthly Financial Summary",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = NagadMainText
                            )
                            Text(
                                text = "Deposits vs. Expenses for $currentMonth",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadSecondaryText,
                                fontFamily = PoppinsFontFamily
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = NagadLightBg
                        ) {
                            Text(
                                text = "Live Ledger",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = NagadPrimary,
                                fontFamily = PoppinsFontFamily,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Max),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier.weight(1f).fillMaxHeight()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Total Deposits", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = NagadPrimary, fontFamily = InterFontFamily)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("৳${formatAmount(currentMonthDeposits)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = NagadPrimary)
                            }
                        }

                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier.weight(1f).fillMaxHeight()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Total Expenses", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = NagadDanger, fontFamily = InterFontFamily)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("৳${formatAmount(currentMonthExpenses)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = NagadDanger)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Net Monthly Balance:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadSecondaryText,
                            fontFamily = InterFontFamily
                        )
                        Text(
                            text = if (netMonthlyFlow >= 0) "+৳${formatAmount(netMonthlyFlow)}" else "-৳${formatAmount(-netMonthlyFlow)}",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (netMonthlyFlow >= 0) NagadPrimary else NagadDanger
                        )
                    }
                }
            }
        }

        // Member Overview Card
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Member Overview",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = NagadMainText
                        )
                        TextButton(onClick = onNavigateToMembers) {
                            Text("View All (${membersWithStats.size})", fontWeight = FontWeight.Bold, color = NagadPrimary, fontFamily = PoppinsFontFamily)
                        }
                    }

                    membersWithStats.take(5).forEach { stats ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToMemberProfile(stats.member.id) }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                MemberAvatar(name = stats.member.name, id = stats.member.id, size = 36)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = stats.member.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = NagadMainText,
                                        fontFamily = PoppinsFontFamily
                                    )
                                    Text(
                                        text = "Paid: ৳${formatAmount(stats.totalPaidContribution)} (${stats.paidMonths.size} mos)",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.5.sp,
                                        color = NagadSecondaryText
                                    )
                                }
                            }
                            StatusBadge(status = stats.status)
                        }
                        HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
                    }
                }
            }
        }

        // Monthly Collection Summary Table Card
        item {
            val activeMonths = remember(deposits) { AppRepository.getActiveMonths(deposits) }
            val totalMembersCount = membersWithStats.size.coerceAtLeast(1)

            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.testTag("monthly_collection_summary_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Monthly Collection Summary",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = NagadMainText
                            )
                            Text(
                                text = "Capital Inflows Breakdown (${activeMonths.firstOrNull()} – ${activeMonths.lastOrNull()})",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = NagadSecondaryText,
                                fontFamily = PoppinsFontFamily
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = NagadLightBg
                        ) {
                            Text(
                                text = "৳${formatAmount(deposits.sumOf { it.amount + it.fine })} Total",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                color = NagadPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val hScrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(hScrollState)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier
                                .background(NagadLightBg, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("MONTH", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(90.dp))
                            Text("PAID", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(60.dp))
                            Text("BASE DEPOSIT", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(100.dp))
                            Text("FINE", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(70.dp))
                            Text("TOTAL INFLOW", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(100.dp))
                            Text("RATE", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(60.dp))
                        }

                        HorizontalDivider(color = NagadBorder, thickness = 1.dp)

                        activeMonths.forEachIndexed { idx, m ->
                            val mDeps = deposits.filter { it.month == m }
                            val baseAmount = mDeps.sumOf { it.amount }
                            val fineAmount = mDeps.sumOf { it.fine }
                            val totalInflow = baseAmount + fineAmount
                            val paidCount = mDeps.map { it.memberId }.distinct().size
                            val ratePct = if (totalMembersCount > 0) ((paidCount.toFloat() / totalMembersCount) * 100).toInt() else 0
                            val rowBg = if (idx % 2 == 0) Color.Transparent else NagadVeryLightBg

                            Row(
                                modifier = Modifier
                                    .background(rowBg)
                                    .padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(m, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadMainText, fontFamily = InterFontFamily, modifier = Modifier.width(90.dp))
                                Text("$paidCount/$totalMembersCount", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 11.sp, color = if (paidCount >= totalMembersCount) NagadPrimary else NagadSecondaryText, modifier = Modifier.width(60.dp))
                                Text("৳${formatAmount(baseAmount)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NagadMainText, modifier = Modifier.width(100.dp))
                                Text("৳${formatAmount(fineAmount)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 11.sp, color = if (fineAmount > 0) NagadDanger else NagadSecondaryText, modifier = Modifier.width(70.dp))
                                Text("৳${formatAmount(totalInflow)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = NagadPrimary, modifier = Modifier.width(100.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (ratePct >= 100) NagadLightBg else Color(0xFFFEF7E6),
                                    modifier = Modifier.width(60.dp)
                                ) {
                                    Text(
                                        text = "$ratePct%",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ratePct >= 100) NagadPrimary else NagadWarning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
                        }

                        // Summary Footer Row
                        val grandBase = deposits.sumOf { it.amount }
                        val grandFine = deposits.sumOf { it.fine }
                        val grandTotal = grandBase + grandFine
                        Row(
                            modifier = Modifier
                                .background(NagadLightBg, RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("TOTAL SUMMARY", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, color = NagadPrimary, fontFamily = InterFontFamily, modifier = Modifier.width(150.dp))
                            Text("৳${formatAmount(grandBase)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, color = NagadMainText, modifier = Modifier.width(100.dp))
                            Text("৳${formatAmount(grandFine)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, color = NagadWarning, modifier = Modifier.width(70.dp))
                            Text("৳${formatAmount(grandTotal)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = NagadPrimary, modifier = Modifier.width(100.dp))
                            Text("100%", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadPrimary, modifier = Modifier.width(60.dp))
                        }
                    }
                }
            }
        }

        // Charts
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Monthly Collections Chart",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = NagadMainText
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = NagadLightBg
                        ) {
                            Text(
                                text = "Last 6 Months",
                                color = NagadPrimary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = InterFontFamily,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    BarChartComposable(items = barItems)
                }
            }
        }

        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Member Status Breakdown",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NagadMainText
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DonutChartComposable(
                        slices = donutSlices,
                        centerLabel = "Members",
                        centerValue = "${membersWithStats.size}"
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Receipt Modal Dialog
    if (selectedReceiptDeposit != null && selectedReceiptMember != null) {
        val memberDue = membersWithStats.find { it.member.id == selectedReceiptMember?.id }?.totalDue ?: 0
        DepositReceiptDialog(
            deposit = selectedReceiptDeposit!!,
            member = selectedReceiptMember!!,
            dynamicDue = memberDue,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = {
                selectedReceiptDeposit = null
                selectedReceiptMember = null
            }
        )
    }
}

@Composable
private fun InvestmentBalanceHeroCard(
    kpi: FinancialKpi,
    selectedMember: MemberWithStats?,
    totalMembersCount: Int,
    isBalanceVisible: Boolean,
    onToggleBalanceVisibility: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToSecondary: () -> Unit
) {
    val totalPortfolioValue = (kpi.mainCapital.coerceAtLeast(0) + kpi.totalRunningInvestments)
    val shareFraction = if (selectedMember != null && kpi.totalDeposits > 0) {
        selectedMember.totalPaidContribution.toFloat() / kpi.totalDeposits.toFloat()
    } else {
        1f / totalMembersCount.coerceAtLeast(1)
    }
    val sharePercent = (shareFraction * 100f)
    val estimatedMemberEquity = (totalPortfolioValue * shareFraction).toInt()

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadDeepGreen),
        border = BorderStroke(1.5.dp, NagadDeepGreen),
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("investment_balance_hero_card")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(NagadDeepGreen, NagadPrimary)
                    )
                )
                .drawBehind {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = size.height * 0.62f,
                        center = Offset(size.width * 0.92f, size.height * 0.14f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        radius = size.height * 0.42f,
                        center = Offset(size.width * 0.72f, size.height * 0.88f)
                    )
                }
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Top Badge + Eye Visibility Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedMember != null) {
                                    "RRK-${selectedMember.member.id.toString().padStart(3, '0')} · MEMBER BALANCE"
                                } else {
                                    "CURRENT INVESTMENT BALANCE"
                                },
                                fontFamily = PoppinsFontFamily,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.4.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onToggleBalanceVisibility,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("toggle_balance_visibility")
                    ) {
                        Icon(
                            imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = if (isBalanceVisible) "Hide balance" else "Show balance",
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Main Amount + Context Subtitle
                AnimatedContent(
                    targetState = Triple(selectedMember?.member?.id, isBalanceVisible, kpi.mainCapital),
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "balance_display"
                ) { (_, visible, _) ->
                    Column {
                        if (selectedMember == null) {
                            Text(
                                text = "Available Liquid Capital",
                                fontFamily = PoppinsFontFamily,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (visible) "৳${formatAmount(kpi.mainCapital.coerceAtLeast(0))}" else "৳ ••••••",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 30.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val activeDeployedPart = if (kpi.totalRunningInvestments > 0) {
                                " • Active Deployed: ৳${formatAmount(kpi.totalRunningInvestments)}"
                            } else ""
                            Text(
                                text = if (visible) {
                                    "Deposits + Fines - Expenses ± P/L$activeDeployedPart • Total Equity: ৳${formatAmount(totalPortfolioValue)}"
                                } else {
                                    "Deposits + Fines - Expenses ± P/L • Total Equity: ৳••••"
                                },
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        } else {
                            Text(
                                text = "${selectedMember.member.name} · Contributed Capital",
                                fontFamily = InterFontFamily,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (visible) "৳${formatAmount(selectedMember.totalPaidContribution)}" else "৳ ••••••",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 30.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${selectedMember.paidMonths.size} Paid Mos · Fund Share: ${String.format(Locale.US, "%.1f", sharePercent)}%",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 11.5.sp,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Frosted 3-metric summary strip
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (selectedMember == null) {
                            HeroMetricColumn(
                                label = "Bank Balance",
                                value = if (isBalanceVisible) "৳${formatAmount(kpi.bankBalance)}" else "৳••••",
                                alignment = Alignment.Start
                            )
                            HeroMetricColumn(
                                label = "Cash in Hand",
                                value = if (isBalanceVisible) "৳${formatAmount(kpi.cashInHand)}" else "৳••••",
                                alignment = Alignment.CenterHorizontally
                            )
                            val pnlSign = if (kpi.realizedBusinessPnl >= 0) "+" else "-"
                            HeroMetricColumn(
                                label = "Business P&L",
                                value = if (isBalanceVisible) "$pnlSign৳${formatAmount(abs(kpi.realizedBusinessPnl))}" else "৳••••",
                                alignment = Alignment.End
                            )
                        } else {
                            HeroMetricColumn(
                                label = "Est. Equity",
                                value = if (isBalanceVisible) "৳${formatAmount(estimatedMemberEquity)}" else "৳••••",
                                alignment = Alignment.Start
                            )
                            HeroMetricColumn(
                                label = "Pending Due",
                                value = if (isBalanceVisible) "৳${formatAmount(selectedMember.totalDue)}" else "৳••••",
                                alignment = Alignment.CenterHorizontally
                            )
                            HeroMetricColumn(
                                label = "Fines Paid",
                                value = if (isBalanceVisible) "৳${formatAmount(selectedMember.totalFinePaid)}" else "৳••••",
                                alignment = Alignment.End
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onNavigateToFinance,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NagadWhite,
                            contentColor = NagadPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Text(
                            text = "Financials",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    OutlinedButton(
                        onClick = onNavigateToSecondary,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Text(
                            text = if (selectedMember != null) "Full Profile" else "All Members",
                            color = Color.White,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroMetricColumn(
    label: String,
    value: String,
    alignment: Alignment.Horizontal
) {
    Column(horizontalAlignment = alignment) {
        Text(
            text = label,
            fontFamily = PoppinsFontFamily,
            fontSize = 10.5.sp,
            color = Color.White.copy(alpha = 0.8f)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

@Composable
private fun RecentTransactionHistoryCard(
    transactions: List<DashboardTransaction>,
    selectedFilter: TransactionFilter,
    selectedMemberName: String?,
    onSelectFilter: (TransactionFilter) -> Unit,
    onViewAllHistory: () -> Unit,
    onDepositClick: (Deposit, Member?) -> Unit
) {
    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recent_transactions_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Recent Transaction History",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadMainText
                    )
                    Text(
                        text = if (selectedMemberName != null) {
                            "Showing deposits for $selectedMemberName"
                        } else {
                            "Deposits, investments & expenses"
                        },
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp,
                        color = NagadSecondaryText
                    )
                }

                TextButton(
                    onClick = onViewAllHistory,
                    modifier = Modifier.testTag("view_all_transactions_button")
                ) {
                    Text(
                        text = "All History",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = NagadPrimary
                    )
                }
            }

            if (selectedMemberName == null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TransactionFilter.entries.forEach { filter ->
                        val isSelected = selectedFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectFilter(filter) },
                            label = {
                                Text(
                                    text = filter.label,
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) NagadPrimary else NagadSecondaryText
                                )
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NagadLightBg,
                                containerColor = NagadWhite
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isSelected) NagadPrimary else NagadBorder
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (transactions.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NagadLightBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = NagadPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No transactions found for this view",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = NagadMainText
                    )
                    Text(
                        text = "Switch filters or select All Partners to inspect recent ledger activity.",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 11.sp,
                        color = NagadSecondaryText
                    )
                }
            } else {
                transactions.forEachIndexed { index, tx ->
                    when (tx) {
                        is DashboardTransaction.DepositTx -> {
                            val total = tx.deposit.amount + tx.deposit.fine
                            TransactionRowItem(
                                icon = Icons.Default.ArrowDownward,
                                iconBgColor = NagadLightBg,
                                iconTint = NagadPrimary,
                                title = tx.member?.name ?: "Member #${tx.deposit.memberId}",
                                subtitle = "${tx.deposit.month} · ${tx.deposit.paymentDate} · ${tx.deposit.paymentMode}",
                                amountText = "+৳${formatAmount(total)}",
                                amountColor = NagadPrimary,
                                badgeText = if (tx.deposit.fine > 0) "Fine ${CurrencyFormatter.formatCurrency(tx.deposit.fine)}" else "Deposit",
                                badgeColor = if (tx.deposit.fine > 0) NagadDanger else NagadPrimary,
                                onClick = { onDepositClick(tx.deposit, tx.member) }
                            )
                        }

                        is DashboardTransaction.InvestmentTx -> {
                            val isRunning = tx.investment.status.equals("RUNNING", true) ||
                                tx.investment.status.equals("ACTIVE", true)
                            TransactionRowItem(
                                icon = Icons.AutoMirrored.Filled.TrendingUp,
                                iconBgColor = if (isRunning) NagadLightBg else Color(0xFFFEF7E6),
                                iconTint = if (isRunning) NagadPrimary else NagadWarning,
                                title = tx.investment.name,
                                subtitle = "${tx.investment.type} · ${tx.investment.date}",
                                amountText = "৳${formatAmount(tx.investment.amount)}",
                                amountColor = NagadMainText,
                                badgeText = if (isRunning) "Running" else "Closed",
                                badgeColor = if (isRunning) NagadPrimary else NagadSecondaryText,
                                onClick = null
                            )
                        }

                        is DashboardTransaction.ExpenseTx -> {
                            TransactionRowItem(
                                icon = Icons.Default.ReceiptLong,
                                iconBgColor = Color(0xFFFDF0F0),
                                iconTint = NagadDanger,
                                title = tx.expense.description,
                                subtitle = "${tx.expense.category} · ${tx.expense.date} · ${tx.expense.paidBy}",
                                amountText = "-৳${formatAmount(tx.expense.amount)}",
                                amountColor = NagadDanger,
                                badgeText = "Expense",
                                badgeColor = NagadDanger,
                                onClick = null
                            )
                        }
                    }

                    if (index < transactions.lastIndex) {
                        HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TransactionRowItem(
    icon: ImageVector,
    iconBgColor: Color,
    iconTint: Color,
    title: String,
    subtitle: String,
    amountText: String,
    amountColor: Color,
    badgeText: String,
    badgeColor: Color,
    onClick: (() -> Unit)?
) {
    val rowModifier = Modifier
        .fillMaxWidth()
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(vertical = 10.dp)

    Row(
        modifier = rowModifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = NagadMainText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    color = NagadSecondaryText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = amountText,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = amountColor
            )
            Text(
                text = badgeText,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 10.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = badgeColor
            )
        }
    }
}

private fun formatAmount(value: Int): String {
    return CurrencyFormatter.formatNumber(value)
}

private fun formatCompactK(value: Int): String {
    val absVal = abs(value)
    if (absVal < 1000) return formatAmount(value)
    val prefix = if (value < 0) "-" else ""
    return if (absVal % 1000 == 0) {
        "$prefix${absVal / 1000}k"
    } else {
        val tenths = kotlin.math.round(absVal / 100.0).toInt()
        if (tenths % 10 == 0) {
            "$prefix${tenths / 10}k"
        } else {
            "$prefix${tenths / 10}.${tenths % 10}k"
        }
    }
}
