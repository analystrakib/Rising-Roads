package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiTaskState
import com.example.data.model.MemberIdeaWithComments
import com.example.ui.MainViewModel
import com.example.ui.components.AiSummaryPanel
import com.example.ui.components.AppCardBorder
import com.example.ui.components.AppCardElevation
import com.example.ui.components.AppCardShape
import com.example.ui.components.AppInputShape
import com.example.ui.components.appInputTextStyle
import com.example.ui.components.appOutlinedTextFieldColors
import com.example.ui.components.appSolidButtonColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadDeepGreen
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.TABULAR_NUMBERS
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val IDEA_CATEGORIES = listOf("Agro", "Trade", "Tech", "Service", "Other")

@Composable
fun MemberIdeasScreen(
    viewModel: MainViewModel,
    onNavigateToAuth: () -> Unit
) {
    val ideas by viewModel.memberIdeas.collectAsState()
    val ideaResearchStates by viewModel.ideaResearchStates.collectAsState()
    val memberSession by viewModel.memberSession.collectAsState()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()

    val currentUserKey = remember(memberSession, isAdminLoggedIn, adminUsername) {
        when {
            memberSession.isLoggedIn && memberSession.rrkMemberId.isNotBlank() -> memberSession.rrkMemberId
            isAdminLoggedIn -> "ADMIN_$adminUsername"
            else -> ""
        }
    }

    var selectedFilter by remember { mutableStateOf("All") }
    var showNewIdeaModal by remember { mutableStateOf(false) }
    var showAuthRequiredDialog by remember { mutableStateOf(false) }

    val filteredIdeas = remember(ideas, selectedFilter) {
        if (selectedFilter == "All") ideas else ideas.filter { it.idea.category.equals(selectedFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("member_ideas_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Card + Share New Idea CTA
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(NagadLightBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = NagadPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Member Venture Ideas",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp,
                                    color = NagadMainText
                                )
                                Text(
                                    text = "${ideas.size} community proposals",
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 12.sp,
                                    color = NagadSecondaryText
                                )
                            }
                        }

                        Button(
                            onClick = {
                                if (currentUserKey.isBlank()) {
                                    showAuthRequiredDialog = true
                                } else {
                                    showNewIdeaModal = true
                                }
                            },
                            colors = appSolidButtonColors(NagadPrimary),
                            shape = AppInputShape,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier
                                .heightIn(min = 44.dp)
                                .testTag("share_new_idea_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Share New Idea",
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = Color.White
                            )
                        }
                    }

                    if (currentUserKey.isBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = NagadLightBg,
                            border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Sign in as an RRK member to submit, vote, and comment.",
                                    fontFamily = InterFontFamily,
                                    fontSize = 12.sp,
                                    color = NagadMainText,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                TextButton(
                                    onClick = onNavigateToAuth,
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "Sign In",
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = NagadPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Category Filter Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (listOf("All") + IDEA_CATEGORIES).forEach { category ->
                    val selected = selectedFilter == category
                    FilterChip(
                        selected = selected,
                        onClick = { selectedFilter = category },
                        label = {
                            Text(
                                text = category,
                                fontFamily = InterFontFamily,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.5.sp,
                                color = if (selected) Color.White else NagadSecondaryText
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NagadPrimary,
                            containerColor = NagadWhite
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = NagadBorder,
                            selectedBorderColor = NagadPrimary
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }
        }

        if (filteredIdeas.isEmpty()) {
            item {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(NagadLightBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = NagadPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (selectedFilter == "All") "No Ideas Shared Yet" else "No $selectedFilter Ideas Yet",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NagadMainText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Have a promising Agro, Trade, Tech, or Service business proposal for Rising Roads? Tap '+ Share New Idea' to pitch it to members.",
                            fontFamily = InterFontFamily,
                            fontSize = 13.sp,
                            color = NagadSecondaryText,
                            textAlign = TextAlign.Center,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        } else {
            items(filteredIdeas, key = { it.idea.id }) { item ->
                IdeaCard(
                    item = item,
                    currentUserKey = currentUserKey,
                    isAdminLoggedIn = isAdminLoggedIn,
                    formattedBudget = if (item.idea.estimatedBudget > 0L) {
                        CurrencyFormatter.formatCurrency(item.idea.estimatedBudget)
                    } else null,
                    researchState = ideaResearchStates[item.idea.id] ?: AiTaskState.Idle,
                    onResearchIdea = { viewModel.researchMemberIdea(item.idea.id) },
                    onClearResearch = { viewModel.clearIdeaResearch(item.idea.id) },
                    onToggleAgree = {
                        if (currentUserKey.isBlank()) {
                            showAuthRequiredDialog = true
                        } else {
                            viewModel.toggleIdeaAgree(item.idea.id)
                        }
                    },
                    onToggleDisagree = {
                        if (currentUserKey.isBlank()) {
                            showAuthRequiredDialog = true
                        } else {
                            viewModel.toggleIdeaDisagree(item.idea.id)
                        }
                    },
                    onAddComment = { commentText, onDone ->
                        if (currentUserKey.isBlank()) {
                            showAuthRequiredDialog = true
                        } else {
                            viewModel.addIdeaComment(item.idea.id, commentText) { success, _ ->
                                if (success) onDone()
                            }
                        }
                    },
                    onDeleteIdea = { viewModel.deleteMemberIdea(item.idea.id) }
                )
            }
        }
    }

    if (showNewIdeaModal) {
        ShareNewIdeaModal(
            onDismiss = { showNewIdeaModal = false },
            onSubmit = { title, category, businessType, budgetText, description, callback ->
                viewModel.submitMemberIdea(
                    title = title,
                    category = category,
                    businessType = businessType,
                    estimatedBudgetText = budgetText,
                    description = description,
                    onResult = callback
                )
            }
        )
    }

    if (showAuthRequiredDialog) {
        AlertDialog(
            onDismissRequest = { showAuthRequiredDialog = false },
            containerColor = NagadWhite,
            shape = AppCardShape,
            icon = {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NagadLightBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Login,
                        contentDescription = null,
                        tint = NagadPrimary
                    )
                }
            },
            title = {
                Text(
                    text = "Member Sign In Required",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Text(
                    text = "Please sign in or create an RRK Member account to share new ideas, vote on proposals, or post comments.",
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp,
                    color = NagadSecondaryText,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAuthRequiredDialog = false
                        onNavigateToAuth()
                    },
                    colors = appSolidButtonColors(NagadPrimary),
                    shape = AppInputShape
                ) {
                    Text("Sign In / Sign Up", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAuthRequiredDialog = false }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun IdeaCard(
    item: MemberIdeaWithComments,
    currentUserKey: String,
    isAdminLoggedIn: Boolean,
    formattedBudget: String?,
    researchState: AiTaskState,
    onResearchIdea: () -> Unit,
    onClearResearch: () -> Unit,
    onToggleAgree: () -> Unit,
    onToggleDisagree: () -> Unit,
    onAddComment: (String, onSuccess: () -> Unit) -> Unit,
    onDeleteIdea: () -> Unit
) {
    val idea = item.idea
    val comments = item.comments
    var showComments by remember { mutableStateOf(false) }
    var commentDraft by remember { mutableStateOf("") }

    val isAgreed = idea.isLikedBy(currentUserKey)
    val isDisagreed = idea.isDislikedBy(currentUserKey)
    val canDelete = isAdminLoggedIn || (currentUserKey.isNotBlank() && idea.authorId == currentUserKey)

    val initials = remember(idea.authorName) {
        idea.authorName
            .split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .mapNotNull { it.firstOrNull()?.uppercaseChar() }
            .joinToString("")
            .ifEmpty { "RR" }
    }

    val formattedDate = remember(idea.createdAt) {
        SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date(idea.createdAt))
    }

    val (catBg, catFg) = when (idea.category.lowercase()) {
        "agro" -> Color(0xFFDCFCE7) to NagadDeepGreen
        "trade" -> Color(0xFFE0F2FE) to Color(0xFF0369A1)
        "tech" -> Color(0xFFEDE9FE) to Color(0xFF5B21B6)
        "service" -> Color(0xFFFEF3C7) to Color(0xFFB45309)
        else -> NagadVeryLightBg to NagadSecondaryText
    }

    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("idea_card_${idea.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Author Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NagadLightBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = NagadPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = idea.authorName,
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = NagadMainText
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NagadVeryLightBg,
                                border = BorderStroke(1.dp, NagadBorder)
                            ) {
                                Text(
                                    text = idea.authorRole,
                                    fontFamily = InterFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NagadSecondaryText,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = formattedDate,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isServiceType = idea.businessType.equals("Service", ignoreCase = true)
                    val typeBg = if (isServiceType) Color(0xFFFFF7ED) else Color(0xFFEEF2FF)
                    val typeFg = if (isServiceType) Color(0xFFC2410C) else Color(0xFF3730A3)
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = typeBg,
                        border = BorderStroke(1.dp, typeFg.copy(alpha = 0.25f))
                    ) {
                        Text(
                            text = if (isServiceType) "Service" else "Product",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = typeFg,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = catBg
                    ) {
                        Text(
                            text = idea.category,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = catFg,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    if (canDelete) {
                        IconButton(
                            onClick = onDeleteIdea,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete idea",
                                tint = NagadDanger,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = idea.title,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = NagadMainText
            )

            Spacer(modifier = Modifier.height(8.dp))

            val hasBudget = formattedBudget != null
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (hasBudget) NagadLightBg else NagadVeryLightBg,
                border = BorderStroke(1.dp, if (hasBudget) NagadPrimary.copy(alpha = 0.25f) else NagadBorder)
            ) {
                Text(
                    text = if (hasBudget) "Estimated Budget: $formattedBudget" else "Budget: Not Specified",
                    style = TextStyle(
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = if (hasBudget) NagadDeepGreen else NagadSecondaryText,
                        fontFeatureSettings = TABULAR_NUMBERS
                    ),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = idea.description,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 13.5.sp,
                color = NagadSecondaryText,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = NagadBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Agree / Disagree & Comment Actions Row
            val disagreeCrimson = Color(0xFFDC2626)
            val disagreeSoftBg = Color(0xFFFEF2F2)
            val disagreeSoftBorder = Color(0xFFFCA5A5)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleAgree,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isAgreed) NagadPrimary else NagadPrimary.copy(alpha = 0.35f)
                    ),
                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isAgreed) NagadLightBg else NagadWhite,
                        contentColor = if (isAgreed) NagadPrimary else NagadDeepGreen
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .heightIn(min = 42.dp)
                        .testTag("agree_idea_${idea.id}")
                ) {
                    Icon(
                        imageVector = if (isAgreed) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                        contentDescription = "Agree with idea",
                        tint = if (isAgreed) NagadPrimary else NagadDeepGreen,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Agree (${idea.likeCount()})",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isAgreed) NagadPrimary else NagadDeepGreen,
                            fontFeatureSettings = TABULAR_NUMBERS
                        )
                    )
                }

                OutlinedButton(
                    onClick = onToggleDisagree,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isDisagreed) disagreeCrimson else disagreeSoftBorder
                    ),
                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isDisagreed) disagreeSoftBg else NagadWhite,
                        contentColor = disagreeCrimson
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .heightIn(min = 42.dp)
                        .testTag("disagree_idea_${idea.id}")
                ) {
                    Icon(
                        imageVector = if (isDisagreed) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                        contentDescription = "Disagree with idea",
                        tint = disagreeCrimson,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Disagree (${idea.dislikeCount()})",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = disagreeCrimson,
                            fontFeatureSettings = TABULAR_NUMBERS
                        )
                    )
                }

                OutlinedButton(
                    onClick = { showComments = !showComments },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (showComments) NagadPrimary else NagadBorder),
                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                        containerColor = if (showComments) NagadLightBg else NagadWhite,
                        contentColor = if (showComments) NagadPrimary else NagadSecondaryText
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .heightIn(min = 42.dp)
                        .testTag("comment_idea_${idea.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = if (showComments) NagadPrimary else NagadSecondaryText,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Comments (${comments.size})",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (showComments) NagadPrimary else NagadSecondaryText,
                            fontFeatureSettings = TABULAR_NUMBERS
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // AI Research & Feasibility Action Button
            val isResearching = researchState is AiTaskState.Loading || researchState is AiTaskState.Streaming
            OutlinedButton(
                onClick = onResearchIdea,
                enabled = !isResearching,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.45f)),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                    containerColor = NagadLightBg,
                    contentColor = NagadDeepGreen
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 42.dp)
                    .testTag("ai_research_idea_${idea.id}")
            ) {
                if (isResearching) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = NagadPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NagadPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isResearching) "Analyzing Feasibility..." else "AI Research & Feasibility",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = NagadDeepGreen
                )
            }

            if (researchState !is AiTaskState.Idle) {
                Spacer(modifier = Modifier.height(10.dp))
                AiSummaryPanel(
                    title = "AI Research & Feasibility",
                    state = researchState,
                    onDismiss = onClearResearch,
                    onRetry = onResearchIdea
                )
            }

            AnimatedVisibility(visible = showComments) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = NagadBorder)

                    if (comments.isEmpty()) {
                        Text(
                            text = "No comments yet. Start the discussion!",
                            fontFamily = InterFontFamily,
                            fontSize = 12.sp,
                            color = NagadSecondaryText
                        )
                    } else {
                        comments.forEach { comment ->
                            val commentInitials = comment.authorName
                                .split(" ")
                                .filter { it.isNotBlank() }
                                .take(2)
                                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                                .joinToString("")
                                .ifEmpty { "RR" }
                            val commentTime = SimpleDateFormat("MMM dd, hh:mm a", Locale.US)
                                .format(Date(comment.createdAt))

                            Surface(
                                shape = AppCardShape,
                                color = NagadVeryLightBg,
                                border = AppCardBorder,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(NagadLightBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = commentInitials,
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = NagadPrimary
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${comment.authorName} · ${comment.authorRole}",
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = NagadMainText
                                            )
                                            Text(
                                                text = commentTime,
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 10.5.sp,
                                                color = NagadSecondaryText
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = comment.content,
                                            fontFamily = InterFontFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 12.5.sp,
                                            color = NagadSecondaryText,
                                            lineHeight = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Comment composer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = commentDraft,
                            onValueChange = { commentDraft = it },
                            placeholder = {
                                Text(
                                    text = "Write a comment...",
                                    fontFamily = InterFontFamily,
                                    fontSize = 12.5.sp
                                )
                            },
                            singleLine = true,
                            textStyle = appInputTextStyle(13.sp),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("comment_input_${idea.id}")
                        )
                        Button(
                            onClick = {
                                val text = commentDraft
                                onAddComment(text) {
                                    commentDraft = ""
                                }
                            },
                            colors = appSolidButtonColors(NagadPrimary),
                            shape = AppInputShape,
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("send_comment_${idea.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Post comment",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShareNewIdeaModal(
    onDismiss: () -> Unit,
    onSubmit: (
        title: String,
        category: String,
        businessType: String,
        budgetText: String,
        description: String,
        onResult: (Boolean, String) -> Unit
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Agro") }
    var selectedBusinessType by remember { mutableStateOf("Product") }
    var budgetText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        shape = AppCardShape,
        title = {
            Text(
                text = "Share New Venture Idea",
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = NagadMainText
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Idea Title", fontFamily = InterFontFamily) },
                    placeholder = { Text("e.g. Seasonal Mustard Oil Supply", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("idea_title_input")
                )

                Column {
                    Text(
                        text = "Business Type",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Product" to "Product Type", "Service" to "Service Type").forEach { (value, label) ->
                            val isSelected = selectedBusinessType == value
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedBusinessType = value },
                                label = {
                                    Text(
                                        text = label,
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        color = if (isSelected) Color.White else NagadMainText,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NagadPrimary,
                                    containerColor = NagadWhite
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = NagadBorder,
                                    selectedBorderColor = NagadPrimary
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("business_type_${value.lowercase()}")
                            )
                        }
                    }
                }

                Column {
                    Text(
                        text = "Category",
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = NagadSecondaryText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IDEA_CATEGORIES.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = {
                                    Text(
                                        text = cat,
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        color = if (isSelected) Color.White else NagadMainText
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NagadPrimary,
                                    containerColor = NagadWhite
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = NagadBorder,
                                    selectedBorderColor = NagadPrimary
                                )
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Estimated Budget (৳) (Optional)", fontFamily = InterFontFamily) },
                    placeholder = { Text("Optional — e.g. 50000", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("idea_budget_input")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Detailed Description", fontFamily = InterFontFamily) },
                    placeholder = { Text("Explain capital use, expected return timeline, and risks...", fontFamily = InterFontFamily) },
                    minLines = 3,
                    maxLines = 5,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("idea_description_input")
                )

                if (errorText != null) {
                    Text(
                        text = errorText ?: "",
                        fontFamily = InterFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NagadDanger
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(title, selectedCategory, selectedBusinessType, budgetText, description) { success, msg ->
                        if (success) {
                            onDismiss()
                        } else {
                            errorText = msg
                        }
                    }
                },
                colors = appSolidButtonColors(NagadPrimary),
                shape = AppInputShape,
                modifier = Modifier.testTag("submit_idea_button")
            ) {
                Text(
                    text = "Publish Idea",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "Cancel",
                    fontFamily = InterFontFamily,
                    color = NagadSecondaryText
                )
            }
        }
    )
}
