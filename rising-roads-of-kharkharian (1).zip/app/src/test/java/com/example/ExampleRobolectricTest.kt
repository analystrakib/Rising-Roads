package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.Deposit
import com.example.data.model.Member
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class ExampleRobolectricTest {

  private lateinit var database: AppDatabase

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rising Roads", appName)
  }

  @Test
  fun `verify 11 members and their capital contributions`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)

    val members = dao.getAllMembers().first()
    assertEquals(11, members.size)

    val capitalContributions = dao.getAllMembersWithCapitalContributions().first()
    assertEquals(11, capitalContributions.size)

    // Verify Mohsin Ali (Member 1) has capital contributions
    val member1 = capitalContributions.find { it.member.id == 1 }
    assertNotNull(member1)
    assertEquals("Mohsin Ali", member1!!.member.name)
    assertTrue("Member 1 should have deposits recorded", member1.contributions.isNotEmpty())
    val totalContributed = member1.contributions.sumOf { it.amount }
    assertEquals(18000, totalContributed)

    val count = dao.getMemberCount()
    assertEquals(11, count)
  }

  @Test
  fun `verify EnvConfig handles missing keys gracefully without crash`() {
    val key = com.example.util.EnvConfig.geminiApiKey
    // Should return empty string gracefully without throwing
    assertNotNull(key)
    val customSecret = com.example.util.EnvConfig.getSecret("NON_EXISTENT_KEY", "default_val")
    assertEquals("default_val", customSecret)
  }

  @Test
  fun `paymentRequest pending reject approve and proof png sync`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    val baselineKpi = repo.financialKpi.first()
    val baselineMember3 = repo.membersWithStats.first().first { it.member.id == 3 }

    // 1. Submit PENDING payment request -> must NOT mutate financial totals
    val req1Id = repo.submitPaymentRequest(
      memberId = 3,
      memberName = "Jony Mia",
      month = "Nov 2026",
      paymentMethod = "bKash",
      amount = 1000,
      fine = 100,
      trxId = "BKH998877",
      paymentDate = "2026-11-18"
    ).toInt()

    val afterSubmitKpi = repo.financialKpi.first()
    assertEquals(baselineKpi.totalDeposits, afterSubmitKpi.totalDeposits)
    assertEquals(baselineKpi.fineCollection, afterSubmitKpi.fineCollection)
    assertEquals(baselineKpi.mainLiquidCapital, afterSubmitKpi.mainLiquidCapital)

    // 2. Reject a request -> must mark REJECTED and leave totals untouched
    val req2Id = repo.submitPaymentRequest(
      memberId = 3,
      memberName = "Jony Mia",
      month = "Dec 2026",
      paymentMethod = "Nagad",
      amount = 1000,
      fine = 0,
      trxId = "BADTRX123",
      paymentDate = "2026-12-05"
    ).toInt()
    val rejectRes = repo.rejectPaymentRequest(req2Id, "admin", "Invalid TrxID")
    assertTrue(rejectRes.isSuccess)
    assertEquals("REJECTED", dao.getPaymentRequestById(req2Id)?.status)
    assertEquals(baselineKpi.totalDeposits, repo.financialKpi.first().totalDeposits)

    // 3. Approve bKash request -> must insert deposit, update KPIs & member stats, and generate PNG proof
    val approveRes = repo.approvePaymentRequest(req1Id, "admin")
    assertTrue(approveRes.isSuccess)
    val approvedReq = approveRes.getOrThrow()
    assertEquals("APPROVED", approvedReq.status)
    assertNotNull(approvedReq.approvedDepositId)

    val afterApproveKpi = repo.financialKpi.first()
    val afterApproveMember3 = repo.membersWithStats.first().first { it.member.id == 3 }
    assertEquals(baselineKpi.totalDeposits + 1000, afterApproveKpi.totalDeposits)
    assertEquals(baselineKpi.fineCollection + 100, afterApproveKpi.fineCollection)
    assertEquals(baselineKpi.mainLiquidCapital + 1100, afterApproveKpi.mainLiquidCapital)
    assertEquals(baselineKpi.cashInHand + 1100, afterApproveKpi.cashInHand)
    assertEquals(baselineMember3.totalPaidContribution + 1000, afterApproveMember3.totalPaidContribution)
    assertEquals(baselineMember3.totalFinePaid + 100, afterApproveMember3.totalFinePaid)
    assertEquals((baselineMember3.totalDue - 1000).coerceAtLeast(0), afterApproveMember3.totalDue)

    // 4. Generate Payment Proof PNG receipt
    val (pngFile, _) = com.example.pdf.PdfReceiptGenerator.generatePaymentProofReceiptImage(
      context = context,
      request = approvedReq,
      memberPhone = baselineMember3.member.phone,
      adminName = "admin"
    )
    assertTrue(pngFile.exists())
    assertTrue(pngFile.length() > 1000L)
  }

  @Test
  fun `officialPaymentAccounts update syncs immediately across repository flow`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    repo.updateOfficialPaymentAccounts(
      bkash = "01811-999888 (Personal)",
      nagad = "01911-777666 (Personal)",
      bank = "City Bank · A/C 1122334455 · Motijheel",
      adminName = "admin"
    )

    val updated = repo.officialPaymentAccounts.first()
    assertEquals("01811-999888 (Personal)", updated.bkash)
    assertEquals("01911-777666 (Personal)", updated.nagad)
    assertEquals("City Bank · A/C 1122334455 · Motijheel", updated.bank)
  }

  @Test
  fun `partialDeposit and mandatoryFineSettlement clears fine and carries forward remaining capital due`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    // Create a test scenario where Member 1 (Mohsin Ali) has 5,000 BDT Capital Due and 4 overdue months (400 BDT fine)
    // Member 1 initially has 18,000 paid (May 2025..Oct 2026) and 1,000 due (Nov 2026).
    // Removing 4 months (Jul, Aug, Sep, Oct 2026) gives 5,000 BDT Capital Due and 4 overdue months past the 15th.
    val m1Deposits = dao.getDepositsForMember(1).first()
    val monthsToClear = setOf("Jul 2026", "Aug 2026", "Sep 2026", "Oct 2026")
    m1Deposits.filter { it.month in monthsToClear }.forEach { dao.deleteDepositById(it.id) }

    val statsBefore = repo.membersWithStats.first().first { it.member.id == 1 }
    assertEquals(5000, statsBefore.totalDue)
    // Jul, Aug, Sep, Oct 2026 are 4 overdue months past the 15th deadline -> 400 BDT base fine
    assertEquals(4, statsBefore.effectiveOverdueMonths)
    assertEquals(400, statsBefore.accruedFineDue)

    // Check calculateMandatoryFineDue on the 15th vs after the 15th (e.g. Nov 18 adds +100 for Nov 2026)
    val fineOn15th = com.example.data.repository.AppRepository.calculateMandatoryFineDue(
      stats = statsBefore,
      selectedMonth = "Nov 2026",
      paymentDate = "2026-11-15"
    )
    assertEquals(400, fineOn15th)

    val fineAfter15th = com.example.data.repository.AppRepository.calculateMandatoryFineDue(
      stats = statsBefore,
      selectedMonth = "Nov 2026",
      paymentDate = "2026-11-18"
    )
    assertEquals(500, fineAfter15th)

    // Member submits a partial deposit of 4,000 BDT (out of 5,000 due) + mandatory 400 BDT fine
    val reqId = repo.submitPaymentRequest(
      memberId = 1,
      memberName = statsBefore.member.name,
      month = "Nov 2026",
      paymentMethod = "bKash",
      amount = 4000,
      fine = 400,
      trxId = "PARTIAL4000",
      paymentDate = "2026-11-15"
    ).toInt()

    // Admin approves the partial payment + mandatory fine
    val approveRes = repo.approvePaymentRequest(reqId, "Rakib")
    assertTrue(approveRes.isSuccess)

    val statsAfter = repo.membersWithStats.first().first { it.member.id == 1 }
    // Remaining Capital Due carried forward must be 1,000 BDT (5,000 - 4,000)
    assertEquals(1000, statsAfter.totalDue)
    // Paid fine is credited (+400) and accruedFineDue is cleared to 0 so carried-forward 1,000 is not double-fined
    assertEquals(statsBefore.totalFinePaid + 400, statsAfter.totalFinePaid)
    assertEquals(0, statsAfter.accruedFineDue)
  }

  @Test
  fun `receiptGenerators render cleanly with compact logo role signature and unified footer`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    val membersStats = repo.membersWithStats.first()
    val firstMember = membersStats.first()
    val firstDeposit = dao.getDepositsForMember(firstMember.member.id).first().first()

    val reqId = repo.submitPaymentRequest(
      memberId = firstMember.member.id,
      memberName = firstMember.member.name,
      month = "Nov 2026",
      paymentMethod = "bKash",
      amount = 1000,
      fine = 0,
      trxId = "TESTPROOF99",
      paymentDate = "2026-11-10"
    ).toInt()
    val approvedReq = repo.approvePaymentRequest(reqId, "Rakib").getOrThrow()

    for (isAdminMode in listOf(true, false)) {
      val (depPng, _) = com.example.pdf.PdfReceiptGenerator.generateDepositReceiptImage(
        context = context,
        deposit = firstDeposit,
        member = firstMember.member,
        adminName = "Rakib",
        isAdmin = isAdminMode
      )
      assertTrue(depPng.exists() && depPng.length() > 1000L)

      val (proofPng, _) = com.example.pdf.PdfReceiptGenerator.generatePaymentProofReceiptImage(
        context = context,
        request = approvedReq,
        memberPhone = firstMember.member.phone,
        adminName = "Rakib",
        isAdmin = isAdminMode
      )
      assertTrue(proofPng.exists() && proofPng.length() > 1000L)
    }
  }

  @Test
  fun `verifyMasterExcelSheetAuditTotalsAndMembers`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    val kpi = repo.financialKpi.first()
    val membersStats = repo.membersWithStats.first()
    val investments = repo.investments.first()
    val expenses = repo.expenses.first()

    // 1. Overall Master Totals (May 2025 - Nov 2026)
    assertEquals(179000, kpi.totalDeposits)
    assertEquals(4200, kpi.fineCollection)
    assertEquals(-600, kpi.grossBusinessPnl)
    assertEquals(42, kpi.exitedMembersLossRecovery)
    assertEquals(-558, kpi.realizedBusinessPnl)
    assertEquals(182642, kpi.totalCollection)
    assertEquals(1487, kpi.totalExpenses)
    assertEquals(0, kpi.totalRunningInvestments)
    assertEquals(1487, kpi.costAndInvest)
    assertEquals(181155, kpi.cashInHand)
    assertEquals(726, kpi.bankBalance)
    assertEquals(181881, kpi.mainLiquidCapital)
    assertEquals(30000, kpi.totalDue)
    assertEquals(4, investments.size)
    assertEquals(8, expenses.size)

    // 2. 11 Active Members' Verified Paid Months, Total Deposits, Capital Due & Total Paid Fines
    val expectedMembers = listOf(
      Triple(1, "Mohsin Ali", "01773-313693") to Triple(18000, 1000, 300),
      Triple(2, "Mostafizur Rahman", "01611-985331") to Triple(18000, 1000, 0),
      Triple(3, "Jony Mia", "01332-330113") to Triple(12000, 7000, 100),
      Triple(4, "Saiful Islam", "01955-609509") to Triple(16000, 3000, 500),
      Triple(5, "Rakib Hossen (A)", "01792-430077") to Triple(18000, 1000, 400),
      Triple(6, "Ropok Islam", "01649-108567") to Triple(18000, 1000, 500),
      Triple(7, "Rakibul Islam", "01405-184559") to Triple(18000, 1000, 0),
      Triple(8, "Sumon Mia", "01967-284173") to Triple(18000, 1000, 400),
      Triple(9, "Hasanuzzaman", "01581-282197") to Triple(15000, 4000, 100),
      Triple(10, "Rafiqul Islam", "01921-827138") to Triple(10000, 9000, 100),
      Triple(11, "Jakir Hossen", "8221021306708") to Triple(18000, 1000, 700)
    )

    for ((identity, amounts) in expectedMembers) {
      val (id, name, phone) = identity
      val (expectedDeposit, expectedDue, expectedFine) = amounts
      val stat = membersStats.first { it.member.id == id }
      assertEquals(name, stat.member.name)
      assertEquals(phone, stat.member.phone)
      assertEquals(expectedDeposit, stat.totalPaidContribution)
      assertEquals(expectedDue, stat.totalDue)
      assertEquals(expectedFine, stat.totalFinePaid)
    }
  }

  @Test
  fun `verify exited members ledger and dynamic custom page builder`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    // Verify initial seeded exited members
    val exited = repo.exitedMembers.first()
    assertEquals(3, exited.size)
    assertEquals(42, exited.sumOf { it.lossShareAmount })

    // Verify initial KPI has 42 exited loss recovery
    val kpi = repo.financialKpi.first()
    assertEquals(-600, kpi.grossBusinessPnl)
    assertEquals(42, kpi.exitedMembersLossRecovery)
    assertEquals(-558, kpi.realizedBusinessPnl)

    // Add a 4th exited member
    repo.addExitedMember(
      com.example.data.model.ExitedMember(
        name = "Test Resigned Member",
        phone = "01700000000",
        resignationDate = "2026-11-15",
        lossShareAmount = 14,
        notes = "Test exit"
      )
    )

    val updatedExited = repo.exitedMembers.first()
    assertEquals(4, updatedExited.size)
    assertEquals(56, updatedExited.sumOf { it.lossShareAmount })

    val updatedKpi = repo.financialKpi.first()
    assertEquals(56, updatedKpi.exitedMembersLossRecovery)
    assertEquals(-544, updatedKpi.realizedBusinessPnl)

    // Test Custom Page CRUD
    repo.addCustomPage(
      com.example.data.model.CustomPage(
        title = "Organization Bylaws",
        iconName = "Article",
        content = "Sample Bylaws content",
        isVisible = true,
        displayOrder = 1
      )
    )

    val pages = repo.customPages.first()
    assertEquals(1, pages.size)
    assertEquals("Organization Bylaws", pages[0].title)
    assertTrue(pages[0].isVisible)
  }

  @Test
  fun `investment create and close updates liquid capital cash bank active closed and pnl in realtime`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    val baseline = repo.financialKpi.first()
    assertEquals(181881, baseline.mainLiquidCapital)
    assertEquals(181155, baseline.cashInHand)
    assertEquals(726, baseline.bankBalance)
    assertEquals(-558, baseline.realizedBusinessPnl)
    assertEquals(0, baseline.totalRunningInvestments)
    val baselineClosed = baseline.totalClosedInvestments

    // 1. Add Cash-funded RUNNING investment of ৳10,000
    val cashInvId = repo.addInvestment(
      com.example.data.model.Investment(
        name = "Test Cash Venture",
        amount = 10000,
        activeCapital = 10000,
        status = "RUNNING",
        stockStatus = "In Stock",
        date = "2026-11-15",
        paymentSource = "Cash"
      )
    ).toInt()

    val afterCashAdd = repo.financialKpi.first()
    assertEquals(10000, afterCashAdd.totalRunningInvestments)
    assertEquals(baselineClosed, afterCashAdd.totalClosedInvestments)
    assertEquals(171155, afterCashAdd.cashInHand)
    assertEquals(726, afterCashAdd.bankBalance)
    assertEquals(171881, afterCashAdd.mainLiquidCapital)
    assertEquals(-558, afterCashAdd.realizedBusinessPnl)

    // 2. Add Bank-funded RUNNING investment of ৳500
    val bankInvId = repo.addInvestment(
      com.example.data.model.Investment(
        name = "Test Bank Venture",
        amount = 500,
        activeCapital = 500,
        status = "RUNNING",
        stockStatus = "In Stock",
        date = "2026-11-15",
        paymentSource = "Bank"
      )
    ).toInt()

    val afterBankAdd = repo.financialKpi.first()
    assertEquals(10500, afterBankAdd.totalRunningInvestments)
    assertEquals(171155, afterBankAdd.cashInHand)
    assertEquals(226, afterBankAdd.bankBalance)
    assertEquals(171381, afterBankAdd.mainLiquidCapital)

    // 3. Close Bank venture with +৳200 profit returning to Bank (৳700 total returned)
    val bankInv = dao.getAllInvestments().first().first { it.id == bankInvId }
    repo.updateInvestment(
      bankInv.copy(
        status = "CLOSED",
        stockStatus = "Closed",
        activeCapital = 0,
        saleRevenue = 700,
        profitLoss = 200,
        saleDate = "2026-11-15",
        returnSource = "Bank"
      )
    )

    val afterBankClose = repo.financialKpi.first()
    assertEquals(10000, afterBankClose.totalRunningInvestments)
    assertEquals(baselineClosed + 500, afterBankClose.totalClosedInvestments)
    assertEquals(-358, afterBankClose.realizedBusinessPnl)
    assertEquals(171155, afterBankClose.cashInHand)
    assertEquals(926, afterBankClose.bankBalance)
    assertEquals(172081, afterBankClose.mainLiquidCapital)

    // 4. Close Cash venture with -৳1,000 loss returning to Cash (৳9,000 total returned)
    val cashInv = dao.getAllInvestments().first().first { it.id == cashInvId }
    repo.updateInvestment(
      cashInv.copy(
        status = "CLOSED",
        stockStatus = "Closed",
        activeCapital = 0,
        saleRevenue = 9000,
        profitLoss = -1000,
        saleDate = "2026-11-15",
        returnSource = "Cash"
      )
    )

    val afterCashClose = repo.financialKpi.first()
    assertEquals(0, afterCashClose.totalRunningInvestments)
    assertEquals(baselineClosed + 10500, afterCashClose.totalClosedInvestments)
    assertEquals(-1358, afterCashClose.realizedBusinessPnl)
    assertEquals(180155, afterCashClose.cashInHand)
    assertEquals(926, afterCashClose.bankBalance)
    assertEquals(181081, afterCashClose.mainLiquidCapital)
  }

  @Test
  fun `memberIdea supports businessType optional budget and mutually exclusive agree disagree voting`() = runBlocking {
    val dao = database.appDao()
    AppDatabase.populateInitialData(dao)
    val repo = com.example.data.repository.AppRepository(dao)

    // 1. Submit idea with Service businessType and blank/0 optional budget
    val serviceIdeaId = repo.addMemberIdea(
      title = "Kharkharian Delivery Fleet",
      category = "Service",
      businessType = "Service",
      estimatedBudget = 0L,
      description = "Local parcel and grocery courier service.",
      authorId = "RRK-001",
      authorName = "Mohsin Ali",
      authorRole = "Member"
    ).toInt()

    // 2. Submit idea with Product businessType and explicit budget
    val productIdeaId = repo.addMemberIdea(
      title = "Cold-Pressed Mustard Oil",
      category = "Agro",
      businessType = "Product",
      estimatedBudget = 45000L,
      description = "Packaged organic mustard oil retail.",
      authorId = "RRK-002",
      authorName = "Mostafizur Rahman",
      authorRole = "Member"
    ).toInt()

    val ideasAfterAdd = repo.memberIdeasWithComments.first()
    val serviceIdea = ideasAfterAdd.first { it.idea.id == serviceIdeaId }.idea
    val productIdea = ideasAfterAdd.first { it.idea.id == productIdeaId }.idea

    assertEquals("Service", serviceIdea.businessType)
    assertEquals(0L, serviceIdea.estimatedBudget)
    assertEquals("Product", productIdea.businessType)
    assertEquals(45000L, productIdea.estimatedBudget)

    // 3. Agree then switch to Disagree (mutually exclusive) then toggle off Disagree
    repo.toggleIdeaAgree(serviceIdeaId, "RRK-003")
    var updated = repo.memberIdeasWithComments.first().first { it.idea.id == serviceIdeaId }.idea
    assertEquals(1, updated.likeCount())
    assertEquals(0, updated.dislikeCount())
    assertTrue(updated.isLikedBy("RRK-003"))

    // Another member agrees too
    repo.toggleIdeaAgree(serviceIdeaId, "RRK-004")
    updated = repo.memberIdeasWithComments.first().first { it.idea.id == serviceIdeaId }.idea
    assertEquals(2, updated.likeCount())
    assertEquals(0, updated.dislikeCount())

    // RRK-003 switches from Agree -> Disagree
    repo.toggleIdeaDisagree(serviceIdeaId, "RRK-003")
    updated = repo.memberIdeasWithComments.first().first { it.idea.id == serviceIdeaId }.idea
    assertEquals(1, updated.likeCount())
    assertEquals(1, updated.dislikeCount())
    assertTrue(!updated.isLikedBy("RRK-003"))
    assertTrue(updated.isDislikedBy("RRK-003"))

    // RRK-003 taps Disagree again to remove vote
    repo.toggleIdeaDisagree(serviceIdeaId, "RRK-003")
    updated = repo.memberIdeasWithComments.first().first { it.idea.id == serviceIdeaId }.idea
    assertEquals(1, updated.likeCount())
    assertEquals(0, updated.dislikeCount())
    assertTrue(!updated.isDislikedBy("RRK-003"))
  }
}


