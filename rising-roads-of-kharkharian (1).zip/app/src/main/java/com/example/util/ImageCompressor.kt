package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

object ImageCompressor {
    private const val DEFAULT_MAX_DIM = 180
    private const val DEFAULT_QUALITY = 65
    private const val MAX_BYTES_BUDGET = 48 * 1024 // ~48 KB raw JPEG (~64 KB Base64) to stay safely under SQLite CursorWindow limits

    /**
     * Compresses and resizes an image URI to a lightweight Base64 data URI
     * (default max 180x180 px JPEG 0.65 quality) using safe two-pass downsampling to avoid OOM
     * and keep Room/SQLite/storage lightweight.
     */
    fun compressUriToDataUri(
        context: Context,
        uri: Uri,
        maxDim: Int = DEFAULT_MAX_DIM,
        quality: Int = DEFAULT_QUALITY
    ): String {
        return try {
            val safeMaxDim = maxDim.coerceIn(64, 180)
            val safeQuality = quality.coerceIn(30, 65)

            // Pass 1: Read bounds only to compute safe inSampleSize and avoid OOM on large photos
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            } ?: return ""

            val origWidth = boundsOptions.outWidth
            val origHeight = boundsOptions.outHeight
            if (origWidth <= 0 || origHeight <= 0) return ""

            var inSampleSize = 1
            while ((origWidth / inSampleSize) > safeMaxDim * 2 || (origHeight / inSampleSize) > safeMaxDim * 2) {
                inSampleSize *= 2
            }

            // Pass 2: Decode downsampled bitmap
            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            val decodedBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return ""

            val width = decodedBitmap.width
            val height = decodedBitmap.height
            if (width <= 0 || height <= 0) {
                decodedBitmap.recycle()
                return ""
            }

            val scale = if (width > safeMaxDim || height > safeMaxDim) {
                if (width >= height) safeMaxDim.toFloat() / width else safeMaxDim.toFloat() / height
            } else {
                1f
            }

            val resizedBitmap = if (scale < 1f) {
                val matrix = Matrix().apply { postScale(scale, scale) }
                Bitmap.createBitmap(decodedBitmap, 0, 0, width, height, matrix, true).also {
                    if (it != decodedBitmap) decodedBitmap.recycle()
                }
            } else {
                decodedBitmap
            }

            val outputStream = ByteArrayOutputStream()
            var currentQuality = safeQuality
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, currentQuality, outputStream)
            while (outputStream.size() > MAX_BYTES_BUDGET && currentQuality > 30) {
                outputStream.reset()
                currentQuality -= 10
                resizedBitmap.compress(Bitmap.CompressFormat.JPEG, currentQuality, outputStream)
            }

            val byteArray = outputStream.toByteArray()
            resizedBitmap.recycle()

            val base64String = Base64.encodeToString(byteArray, Base64.NO_WRAP)
            "data:image/jpeg;base64,$base64String"
        } catch (_: Throwable) {
            ""
        }
    }
}
