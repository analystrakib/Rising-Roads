package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.R
import com.example.data.local.AppDao
import com.example.data.model.AppConfig
import com.example.data.model.CustomPage
import com.example.data.model.Deposit
import com.example.data.model.ExitedMember
import com.example.data.model.Expense
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberSettlement
import com.example.data.model.OfficialPaymentAccounts
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.InputStream
import java.util.UUID

/**
 * Production Firebase Cloud Repository managing real-time Cloud Firestore & Firebase Storage synchronization.
 * Supports offline persistence, automatic first-launch seeding of reconciled master ledger figures,
 * real-time snapshot listeners across all collections, and image asset uploads to Firebase Storage.
 */
class FirebaseRepository(
    private val context: Context,
    private val dao: AppDao
) : SyncRepository {

    private val tag = "FirebaseRepository"

    val db: FirebaseFirestore? = runCatching {
        val dbId = runCatching {
            context.applicationContext.getString(R.string.firestore_database_id)
        }.getOrNull()

        val instance = if (!dbId.isNullOrBlank()) {
            FirebaseFirestore.getInstance(dbId)
        } else {
            FirebaseFirestore.getInstance()
        }

        runCatching {
            val settings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()
            instance.firestoreSettings = settings
        }
        instance
    }.onFailure {
        Log.w(tag, "FirebaseFirestore initialization failed or running in local fallback: ${it.message}")
    }.getOrNull()

    val storage: FirebaseStorage? = runCatching {
        FirebaseStorage.getInstance()
    }.onFailure {
        Log.w(tag, "FirebaseStorage initialization failed or running in local fallback: ${it.message}")
    }.getOrNull()

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    override val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _isCloudConnected = MutableStateFlow(db != null)
    val isCloudConnected: StateFlow<Boolean> = _isCloudConnected.asStateFlow()

    private val listeners = mutableListOf<ListenerRegistration>()
    private var isSyncActive = false

    override fun startRealtimeSync(scope: CoroutineScope) {
        val firestore = db ?: run {
            Log.i(tag, "Cloud Firestore unavailable — running in offline/local Room database mode.")
            return
        }

        if (isSyncActive) return
        isSyncActive = true

        scope.launch(Dispatchers.IO) {
            checkAndSeedInitialDataIfNeeded()
        }

        registerRealtimeListeners(scope, firestore)
    }

    /**
     * Checks if Cloud Firestore has any members. If empty, automatically seeds all initial reconciled master data.
     */
    suspend fun checkAndSeedInitialDataIfNeeded() {
        val firestore = db ?: return
        try {
            val snapshot = firestore.collection("members").limit(1).get().await()
            if (snapshot.isEmpty) {
                Log.i(tag, "Firestore collections are empty. Auto-seeding reconciled master data to Cloud Firestore...")
                pushAllLocalDataToFirestore()
            } else {
                Log.d(tag, "Firestore already populated with cloud documents. Preserving live cloud data.")
            }
        } catch (e: Exception) {
            Log.w(tag, "Auto-seed check failed or offline: ${e.message}")
        }
    }

    private fun registerRealtimeListeners(scope: CoroutineScope, firestore: FirebaseFirestore) {
        // 1. Members
        runCatching {
            val reg = firestore.collection("members").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Members listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val m = dc.document.toObject(Member::class.java)
                                        dao.insertMember(m)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteMemberById(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 2. Deposits & Contributions
        runCatching {
            val reg = firestore.collection("deposits").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Deposits listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val d = dc.document.toObject(Deposit::class.java)
                                        dao.insertDeposit(d)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteDepositById(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 3. Expenses
        runCatching {
            val reg = firestore.collection("expenses").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Expenses listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val e = dc.document.toObject(Expense::class.java)
                                        dao.insertExpense(e)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteExpenseById(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 4. Investments
        runCatching {
            val reg = firestore.collection("investments").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Investments listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val inv = dc.document.toObject(Investment::class.java)
                                        dao.insertInvestment(inv)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteInvestmentById(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 5. Exited Members
        runCatching {
            val reg = firestore.collection("exited_members").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Exited members listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val em = dc.document.toObject(ExitedMember::class.java)
                                        dao.insertExitedMember(em)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteExitedMember(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 6. Custom Pages
        runCatching {
            val reg = firestore.collection("custom_pages").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Custom pages listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val cp = dc.document.toObject(CustomPage::class.java)
                                        dao.insertCustomPage(cp)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteCustomPage(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 7. App Settings & Balances
        runCatching {
            val reg = firestore.collection("app_settings").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "App settings listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    val key = dc.document.getString("key") ?: dc.document.id
                                    val value = dc.document.getString("value") ?: ""
                                    dao.setConfig(AppConfig(key, value))
                                }
                                DocumentChange.Type.REMOVED -> {}
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }

        // 8. Member Settlements
        runCatching {
            val reg = firestore.collection("member_settlements").addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Member settlements listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    scope.launch(Dispatchers.IO) {
                        for (dc in snapshot.documentChanges) {
                            if (dc.document.metadata.hasPendingWrites()) continue
                            when (dc.type) {
                                DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                    runCatching {
                                        val s = dc.document.toObject(MemberSettlement::class.java)
                                        dao.insertSettlement(s)
                                    }
                                }
                                DocumentChange.Type.REMOVED -> {
                                    val id = dc.document.id.toIntOrNull()
                                    if (id != null) dao.deleteSettlementById(id)
                                }
                            }
                        }
                    }
                }
            }
            listeners.add(reg)
        }
    }

    fun stopRealtimeSync() {
        listeners.forEach { it.remove() }
        listeners.clear()
        isSyncActive = false
    }

    // --- Direct Push / Mutate Methods (Invoked on Admin edits) ---

    suspend fun pushMember(member: Member) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("members").document(member.id.toString())
                .set(member, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing member ${member.id}: ${it.message}") }
    }

    suspend fun deleteMember(memberId: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("members").document(memberId.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote member $memberId: ${it.message}") }
    }

    suspend fun pushDeposit(deposit: Deposit) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("deposits").document(deposit.id.toString())
                .set(deposit, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing deposit ${deposit.id}: ${it.message}") }
    }

    suspend fun deleteDeposit(depositId: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("deposits").document(depositId.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote deposit $depositId: ${it.message}") }
    }

    suspend fun pushExpense(expense: Expense) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("expenses").document(expense.id.toString())
                .set(expense, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing expense ${expense.id}: ${it.message}") }
    }

    suspend fun deleteExpense(expenseId: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("expenses").document(expenseId.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote expense $expenseId: ${it.message}") }
    }

    suspend fun pushInvestment(investment: Investment) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("investments").document(investment.id.toString())
                .set(investment, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing investment ${investment.id}: ${it.message}") }
    }

    suspend fun deleteInvestment(investmentId: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("investments").document(investmentId.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote investment $investmentId: ${it.message}") }
    }

    suspend fun pushExitedMember(member: ExitedMember) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("exited_members").document(member.id.toString())
                .set(member, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing exited member ${member.id}: ${it.message}") }
    }

    suspend fun deleteExitedMember(id: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("exited_members").document(id.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote exited member $id: ${it.message}") }
    }

    suspend fun pushCustomPage(page: CustomPage) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("custom_pages").document(page.id.toString())
                .set(page, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing custom page ${page.id}: ${it.message}") }
    }

    suspend fun deleteCustomPage(id: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("custom_pages").document(id.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote custom page $id: ${it.message}") }
    }

    suspend fun pushAppSetting(key: String, value: String) {
        val firestore = db ?: return
        runCatching {
            val data = mapOf("key" to key, "value" to value)
            firestore.collection("app_settings").document(key)
                .set(data, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing setting $key: ${it.message}") }
    }

    suspend fun pushSettlement(settlement: MemberSettlement) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("member_settlements").document(settlement.id.toString())
                .set(settlement, SetOptions.merge())
                .await()
        }.onFailure { Log.w(tag, "Error pushing settlement ${settlement.id}: ${it.message}") }
    }

    suspend fun deleteSettlement(id: Int) {
        val firestore = db ?: return
        runCatching {
            firestore.collection("member_settlements").document(id.toString()).delete().await()
        }.onFailure { Log.w(tag, "Error deleting remote settlement $id: ${it.message}") }
    }

    // --- Bulk Sync Operations ---

    override suspend fun pushAllLocalDataToFirestore() {
        val firestore = db ?: return
        _syncState.value = SyncState.Syncing
        try {
            val members = dao.getAllMembersSync()
            val deposits = dao.getAllDepositsSync()
            val expenses = dao.getAllExpensesSync()
            val investments = dao.getAllInvestmentsSync()
            val exitedMembers = dao.getAllExitedMembersSync()
            val customPages = dao.getAllCustomPagesSync()
            val settlements = dao.getAllSettlementsSync()
            val configs = dao.getAllConfigsSync()

            // Push in batches to prevent hitting Firestore 500-operation transaction limits
            val batch = firestore.batch()

            members.forEach { m ->
                batch.set(firestore.collection("members").document(m.id.toString()), m, SetOptions.merge())
            }
            deposits.forEach { d ->
                batch.set(firestore.collection("deposits").document(d.id.toString()), d, SetOptions.merge())
            }
            expenses.forEach { e ->
                batch.set(firestore.collection("expenses").document(e.id.toString()), e, SetOptions.merge())
            }
            investments.forEach { inv ->
                batch.set(firestore.collection("investments").document(inv.id.toString()), inv, SetOptions.merge())
            }
            exitedMembers.forEach { em ->
                batch.set(firestore.collection("exited_members").document(em.id.toString()), em, SetOptions.merge())
            }
            customPages.forEach { cp ->
                batch.set(firestore.collection("custom_pages").document(cp.id.toString()), cp, SetOptions.merge())
            }
            settlements.forEach { s ->
                batch.set(firestore.collection("member_settlements").document(s.id.toString()), s, SetOptions.merge())
            }
            configs.forEach { cfg ->
                batch.set(
                    firestore.collection("app_settings").document(cfg.key),
                    mapOf("key" to cfg.key, "value" to cfg.value),
                    SetOptions.merge()
                )
            }

            // Ensure baseline cash balances exist
            if (configs.none { it.key == "hand_cash_balance" }) {
                batch.set(
                    firestore.collection("app_settings").document("hand_cash_balance"),
                    mapOf("key" to "hand_cash_balance", "value" to "181155"),
                    SetOptions.merge()
                )
            }
            if (configs.none { it.key == "bank_account_balance" }) {
                batch.set(
                    firestore.collection("app_settings").document("bank_account_balance"),
                    mapOf("key" to "bank_account_balance", "value" to "726"),
                    SetOptions.merge()
                )
            }

            batch.commit().await()
            _syncState.value = SyncState.Success("All local data successfully synced with Cloud Firestore.")
            Log.i(tag, "Batch sync to Cloud Firestore committed successfully.")
        } catch (e: Exception) {
            Log.e(tag, "Failed to push local data to Firestore", e)
            _syncState.value = SyncState.Error("Push sync failed: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    override suspend fun pullRemoteDataFromFirestore() {
        val firestore = db ?: return
        _syncState.value = SyncState.Syncing
        try {
            val membersSnap = firestore.collection("members").get().await()
            val remoteMembers = membersSnap.toObjects(Member::class.java)
            if (remoteMembers.isNotEmpty()) {
                remoteMembers.forEach { dao.insertMember(it) }
            }

            val depositsSnap = firestore.collection("deposits").get().await()
            val remoteDeposits = depositsSnap.toObjects(Deposit::class.java)
            if (remoteDeposits.isNotEmpty()) {
                dao.insertDeposits(remoteDeposits)
            }

            val expensesSnap = firestore.collection("expenses").get().await()
            val remoteExpenses = expensesSnap.toObjects(Expense::class.java)
            if (remoteExpenses.isNotEmpty()) {
                dao.insertExpenses(remoteExpenses)
            }

            val investmentsSnap = firestore.collection("investments").get().await()
            val remoteInvestments = investmentsSnap.toObjects(Investment::class.java)
            if (remoteInvestments.isNotEmpty()) {
                dao.insertInvestments(remoteInvestments)
            }

            val exitedSnap = firestore.collection("exited_members").get().await()
            val remoteExited = exitedSnap.toObjects(ExitedMember::class.java)
            if (remoteExited.isNotEmpty()) {
                dao.insertExitedMembers(remoteExited)
            }

            val customPagesSnap = firestore.collection("custom_pages").get().await()
            val remotePages = customPagesSnap.toObjects(CustomPage::class.java)
            if (remotePages.isNotEmpty()) {
                dao.insertCustomPages(remotePages)
            }

            val settingsSnap = firestore.collection("app_settings").get().await()
            for (doc in settingsSnap.documents) {
                val key = doc.getString("key") ?: doc.id
                val value = doc.getString("value") ?: ""
                dao.setConfig(AppConfig(key, value))
            }

            val settlementsSnap = firestore.collection("member_settlements").get().await()
            val remoteSettlements = settlementsSnap.toObjects(MemberSettlement::class.java)
            if (remoteSettlements.isNotEmpty()) {
                dao.insertSettlements(remoteSettlements)
            }

            _syncState.value = SyncState.Success("Remote Cloud Firestore data pulled and reconciled locally.")
        } catch (e: Exception) {
            Log.e(tag, "Error pulling remote data from Firestore", e)
            _syncState.value = SyncState.Error("Pull sync failed: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    // --- Firebase Cloud Storage Asset Uploads ---

    /**
     * Uploads an image byte array to Firebase Storage and returns the public download URL.
     * Falls back to returning null if Firebase Storage is unavailable or offline.
     */
    suspend fun uploadImageBytes(bytes: ByteArray, folder: String, filename: String): String? {
        val s = storage ?: return null
        return runCatching {
            val ref = s.reference.child("$folder/$filename")
            ref.putBytes(bytes).await()
            ref.downloadUrl.await().toString()
        }.onFailure {
            Log.w(tag, "Firebase Storage byte upload failed: ${it.message}")
        }.getOrNull()
    }

    /**
     * Uploads an image from a device Uri to Firebase Storage.
     * Generates a unique filename if none is provided.
     */
    suspend fun uploadImageUri(context: Context, uri: Uri, folder: String, filename: String? = null): String? {
        val s = storage ?: return null
        return runCatching {
            val name = filename ?: "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val ref = s.reference.child("$folder/$name")
            ref.putFile(uri).await()
            ref.downloadUrl.await().toString()
        }.onFailure {
            Log.w(tag, "Firebase Storage URI upload failed: ${it.message}")
        }.getOrNull()
    }

    /**
     * Parses a base64 Data URI (e.g. data:image/jpeg;base64,...), uploads to Firebase Storage,
     * and returns the cloud download URL.
     */
    suspend fun uploadDataUri(dataUri: String, folder: String, filename: String): String? {
        if (!dataUri.startsWith("data:") || !dataUri.contains(",")) return null
        return runCatching {
            val base64Data = dataUri.substringAfter(",")
            val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
            uploadImageBytes(decodedBytes, folder, filename)
        }.onFailure {
            Log.w(tag, "Data URI parse and upload failed: ${it.message}")
        }.getOrNull()
    }
}
