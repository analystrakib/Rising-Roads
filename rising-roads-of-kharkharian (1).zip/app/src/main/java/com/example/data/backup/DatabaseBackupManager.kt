package com.example.data.backup

import android.content.Context
import com.example.data.local.AppDao
import com.example.data.model.ActivityLog
import com.example.data.model.AdminUser
import com.example.data.model.AppConfig
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.Investment
import com.example.data.model.Member
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DatabaseBackupManager(private val dao: AppDao) {

    suspend fun exportToJson(context: Context): Pair<File, String> {
        val root = JSONObject()
        root.put("appName", "Rising Roads Of Kharkharian")
        root.put("backupVersion", 1)
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))

        // Members
        val membersArr = JSONArray()
        dao.getAllMembersSync().forEach { m ->
            val obj = JSONObject().apply {
                put("id", m.id)
                put("name", m.name)
                put("phone", m.phone)
                put("joinDate", m.joinDate)
                put("address", m.address)
                put("photoUri", m.photoUri ?: JSONObject.NULL)
            }
            membersArr.put(obj)
        }
        root.put("members", membersArr)

        // Deposits
        val depositsArr = JSONArray()
        dao.getAllDepositsSync().forEach { d ->
            val obj = JSONObject().apply {
                put("id", d.id)
                put("memberId", d.memberId)
                put("month", d.month)
                put("paymentDate", d.paymentDate)
                put("amount", d.amount)
                put("fine", d.fine)
                put("inputTimestamp", d.inputTimestamp)
            }
            depositsArr.put(obj)
        }
        root.put("deposits", depositsArr)

        // Expenses
        val expensesArr = JSONArray()
        dao.getAllExpensesSync().forEach { e ->
            val obj = JSONObject().apply {
                put("id", e.id)
                put("description", e.description)
                put("category", e.category)
                put("amount", e.amount)
                put("date", e.date)
                put("recordedBy", e.recordedBy)
            }
            expensesArr.put(obj)
        }
        root.put("expenses", expensesArr)

        // Investments
        val investmentsArr = JSONArray()
        dao.getAllInvestmentsSync().forEach { i ->
            val obj = JSONObject().apply {
                put("id", i.id)
                put("name", i.name)
                put("type", i.type)
                put("amount", i.amount)
                put("purchasedQuantity", i.purchasedQuantity)
                put("saleDate", i.saleDate)
                put("soldQuantity", i.soldQuantity)
                put("saleRevenue", i.saleRevenue)
                put("expenses", i.expenses)
                put("profitLoss", i.profitLoss)
                put("status", i.status)
                put("date", i.date)
                put("supervisor", i.supervisor)
                put("stockStatus", i.stockStatus)
                put("description", i.description)
                put("photoUri", i.photoUri)
                put("paymentSource", i.paymentSource)
                put("returnSource", i.returnSource)
            }
            investmentsArr.put(obj)
        }
        root.put("investments", investmentsArr)

        // Admin Users
        val adminsArr = JSONArray()
        dao.getAllAdminsSync().forEach { a ->
            val obj = JSONObject().apply {
                put("username", a.username)
                put("password", a.password)
                put("role", a.role)
                put("addedBy", a.addedBy)
                put("addedAt", a.addedAt)
            }
            adminsArr.put(obj)
        }
        root.put("adminUsers", adminsArr)

        // App Configs
        val configsArr = JSONArray()
        dao.getAllConfigsSync().forEach { c ->
            val obj = JSONObject().apply {
                put("key", c.key)
                put("value", c.value)
            }
            configsArr.put(obj)
        }
        root.put("appConfigs", configsArr)

        // Activity Logs
        val logsArr = JSONArray()
        dao.getAllLogsSync().take(100).forEach { l ->
            val obj = JSONObject().apply {
                put("id", l.id)
                put("type", l.type)
                put("message", l.message)
                put("username", l.username)
                put("timestamp", l.timestamp)
            }
            logsArr.put(obj)
        }
        root.put("activityLogs", logsArr)

        val jsonString = root.toString(2)
        val backupDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val fileName = "RRK_Backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.json"
        val outputFile = File(backupDir, fileName)

        FileOutputStream(outputFile).use { out ->
            out.write(jsonString.toByteArray(Charsets.UTF_8))
        }

        return Pair(outputFile, jsonString)
    }

    suspend fun restoreFromJson(jsonString: String, operatorUsername: String): Result<String> {
        return try {
            val root = JSONObject(jsonString)

            if (!root.has("members") || !root.has("deposits")) {
                return Result.failure(IllegalArgumentException("Invalid backup JSON format: Missing members or deposits data"))
            }

            // 1. Parse Members
            val membersList = mutableListOf<Member>()
            val membersArr = root.optJSONArray("members") ?: JSONArray()
            for (i in 0 until membersArr.length()) {
                val obj = membersArr.getJSONObject(i)
                membersList.add(
                    Member(
                        id = obj.getInt("id"),
                        name = obj.getString("name"),
                        phone = obj.getString("phone"),
                        joinDate = obj.optString("joinDate", "2025-05-01"),
                        address = obj.optString("address", "Kharkharian"),
                        photoUri = if (obj.isNull("photoUri")) null else obj.optString("photoUri")
                    )
                )
            }

            // 2. Parse Deposits
            val depositsList = mutableListOf<Deposit>()
            val depositsArr = root.optJSONArray("deposits") ?: JSONArray()
            for (i in 0 until depositsArr.length()) {
                val obj = depositsArr.getJSONObject(i)
                depositsList.add(
                    Deposit(
                        id = obj.optInt("id", 0),
                        memberId = obj.getInt("memberId"),
                        month = obj.getString("month"),
                        paymentDate = obj.getString("paymentDate"),
                        amount = obj.optInt("amount", 1000),
                        fine = obj.optInt("fine", 0),
                        inputTimestamp = obj.optLong("inputTimestamp", System.currentTimeMillis())
                    )
                )
            }

            // 3. Parse Expenses
            val expensesList = mutableListOf<Expense>()
            val expensesArr = root.optJSONArray("expenses") ?: JSONArray()
            for (i in 0 until expensesArr.length()) {
                val obj = expensesArr.getJSONObject(i)
                expensesList.add(
                    Expense(
                        id = obj.optInt("id", 0),
                        description = obj.getString("description"),
                        category = obj.optString("category", "Office Expenses"),
                        amount = obj.getInt("amount"),
                        date = obj.optString("date", "2025-05-01"),
                        recordedBy = obj.optString("recordedBy", "admin")
                    )
                )
            }

            // 4. Parse Investments
            val investmentsList = mutableListOf<Investment>()
            val investmentsArr = root.optJSONArray("investments") ?: JSONArray()
            for (i in 0 until investmentsArr.length()) {
                val obj = investmentsArr.getJSONObject(i)
                val rawStatus = obj.optString("status", "RUNNING").uppercase()
                val normalizedStatus = when (rawStatus) {
                    "CLOSED", "COMPLETED", "LIQUIDATED" -> "CLOSED"
                    else -> "RUNNING"
                }
                investmentsList.add(
                    Investment(
                        id = obj.optInt("id", 0),
                        name = obj.getString("name"),
                        type = obj.optString("type", "Agro"),
                        amount = obj.getInt("amount"),
                        purchasedQuantity = obj.optString("purchasedQuantity", ""),
                        saleDate = obj.optString("saleDate", ""),
                        soldQuantity = obj.optString("soldQuantity", ""),
                        saleRevenue = obj.optInt("saleRevenue", 0),
                        expenses = obj.optInt("expenses", 0),
                        profitLoss = obj.optInt("profitLoss", 0),
                        activeCapital = obj.optInt("activeCapital", 0),
                        status = normalizedStatus,
                        date = obj.optString("date", "2025-05-01"),
                        supervisor = obj.optString("supervisor", ""),
                        stockStatus = obj.optString("stockStatus", "In Stock"),
                        description = obj.optString("description", ""),
                        photoUri = obj.optString("photoUri", ""),
                        paymentSource = obj.optString("paymentSource", "Cash"),
                        returnSource = obj.optString("returnSource", "")
                    )
                )
            }

            // 5. Parse Admin Users
            val adminsList = mutableListOf<AdminUser>()
            val adminsArr = root.optJSONArray("adminUsers") ?: JSONArray()
            for (i in 0 until adminsArr.length()) {
                val obj = adminsArr.getJSONObject(i)
                adminsList.add(
                    AdminUser(
                        username = obj.getString("username"),
                        password = obj.getString("password"),
                        role = obj.optString("role", "Admin"),
                        addedBy = obj.optString("addedBy", "System"),
                        addedAt = obj.optString("addedAt", "2025-05-01")
                    )
                )
            }

            // 6. Parse App Configs
            val configsList = mutableListOf<AppConfig>()
            val configsArr = root.optJSONArray("appConfigs") ?: JSONArray()
            for (i in 0 until configsArr.length()) {
                val obj = configsArr.getJSONObject(i)
                configsList.add(
                    AppConfig(
                        key = obj.getString("key"),
                        value = obj.getString("value")
                    )
                )
            }

            // Perform Database Restoration (Transactionally clear and re-insert)
            dao.clearMembers()
            dao.clearDeposits()
            dao.clearExpenses()
            dao.clearInvestments()
            dao.clearConfigs()

            if (membersList.isNotEmpty()) dao.insertMembers(membersList)
            if (depositsList.isNotEmpty()) dao.insertDeposits(depositsList)
            if (expensesList.isNotEmpty()) dao.insertExpenses(expensesList)
            if (investmentsList.isNotEmpty()) dao.insertInvestments(investmentsList)
            if (adminsList.isNotEmpty()) dao.insertAdmins(adminsList)
            if (configsList.isNotEmpty()) dao.insertConfigs(configsList)

            dao.insertLog(
                ActivityLog(
                    type = "settings",
                    message = "Database restored successfully from backup: ${membersList.size} members, ${depositsList.size} deposits, ${expensesList.size} expenses, ${investmentsList.size} investments",
                    username = operatorUsername
                )
            )

            Result.success("Restored ${membersList.size} members, ${depositsList.size} deposits, ${expensesList.size} expenses, ${investmentsList.size} investments successfully! ✅")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
