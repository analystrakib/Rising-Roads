package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiChatMessage
import com.example.ai.AiTaskState
import com.example.ai.RrkAiAssistant
import com.example.data.local.AppDatabase
import com.example.data.local.SessionManager
import com.example.data.model.ActivityLog
import com.example.data.model.AdminAlertEmailSettings
import com.example.data.model.AdminUser
import com.example.data.model.CustomPage
import com.example.data.model.Deposit
import com.example.data.model.ExitedMember
import com.example.data.model.Expense
import com.example.data.model.FinancialKpi
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberAccount
import com.example.data.model.MemberDueReminder
import com.example.data.model.MemberIdeaWithComments
import com.example.data.model.MemberSessionState
import com.example.data.model.MemberSettlement
import com.example.data.model.MemberWithCapitalContributions
import com.example.data.model.MemberWithStats
import com.example.data.model.OfficialPaymentAccounts
import com.example.data.model.PaymentRequest
import com.example.data.model.RememberedUserSession
import com.example.data.repository.AppRepository
import com.example.util.AdminNotificationHelper
import com.example.util.PasswordUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val firebaseRepository = com.example.data.repository.FirebaseRepository(application, database.appDao())
    private val repository = AppRepository(database.appDao(), firebaseRepository)
    val sessionManager = SessionManager(application)

    // Admin Session State
    private val _isAdminLoggedIn = MutableStateFlow(sessionManager.isLoggedIn)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _adminUsername = MutableStateFlow(sessionManager.username)
    val adminUsername: StateFlow<String> = _adminUsername.asStateFlow()

    private val _adminRole = MutableStateFlow(sessionManager.role)
    val adminRole: StateFlow<String> = _adminRole.asStateFlow()

    // Member Session State
    private val _memberSession = MutableStateFlow(sessionManager.getMemberSessionState())
    val memberSession: StateFlow<MemberSessionState> = _memberSession.asStateFlow()

    // Pre-App Lock Gate & Remembered Quick PIN State
    private val _isAppUnlocked = MutableStateFlow(false)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    private val _rememberedSession = MutableStateFlow(sessionManager.getRememberedUser())
    val rememberedSession: StateFlow<RememberedUserSession> = _rememberedSession.asStateFlow()

    private val _pendingPinSetupAccount = MutableStateFlow<MemberAccount?>(null)
    val pendingPinSetupAccount: StateFlow<MemberAccount?> = _pendingPinSetupAccount.asStateFlow()

    // Snackbar / Feedback message event
    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    // Pull-to-refresh & Cloud Sync state
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    val syncState: StateFlow<com.example.data.repository.SyncState> = firebaseRepository.syncState
    val isCloudConnected: StateFlow<Boolean> = firebaseRepository.isCloudConnected

    fun refreshData() {
        viewModelScope.launch {
            _isRefreshing.value = true
            runCatching { firebaseRepository.pullRemoteDataFromFirestore() }
            repository.triggerRecalculation()
            delay(350)
            _isRefreshing.value = false
            _toastEvent.emit("Capital and Member data refreshed! 🔄")
        }
    }

    // Repository Flows
    val membersWithStats: StateFlow<List<MemberWithStats>> = repository.membersWithStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val membersWithCapitalContributions: StateFlow<List<MemberWithCapitalContributions>> = repository.membersWithCapitalContributions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deposits: StateFlow<List<Deposit>> = repository.deposits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = repository.expenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val investments: StateFlow<List<Investment>> = repository.investments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settlements: StateFlow<List<MemberSettlement>> = repository.settlements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val financialKpi: StateFlow<FinancialKpi> = repository.financialKpi
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            FinancialKpi()
        )

    val admins: StateFlow<List<AdminUser>> = repository.admins
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activityLogs: StateFlow<List<ActivityLog>> = repository.activityLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val configs: StateFlow<List<com.example.data.model.AppConfig>> = repository.configs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val paymentRequests: StateFlow<List<PaymentRequest>> = repository.paymentRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exitedMembers: StateFlow<List<ExitedMember>> = repository.exitedMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customPages: StateFlow<List<CustomPage>> = repository.customPages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingPaymentRequestsCount: StateFlow<Int> = repository.paymentRequests
        .map { list -> list.count { it.status == "PENDING" } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val officialPaymentAccounts: StateFlow<OfficialPaymentAccounts> = repository.officialPaymentAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OfficialPaymentAccounts())

    val adminAlertEmailSettings: StateFlow<AdminAlertEmailSettings> = repository.adminAlertEmailSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminAlertEmailSettings())

    val memberAccounts: StateFlow<List<MemberAccount>> = repository.memberAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberIdeas: StateFlow<List<MemberIdeaWithComments>> = repository.memberIdeasWithComments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Automated Scheduled Member Due Reminder System (1st, 8th, 14th of every month) ---
    // null = live real-world calendar day; 1, 8, 14 = test specific day; 0 = preview all 3 days
    private val _simulatedReminderDay = MutableStateFlow<Int?>(null)
    val simulatedReminderDay: StateFlow<Int?> = _simulatedReminderDay.asStateFlow()

    private val _previewTargetMemberId = MutableStateFlow<Int?>(null)
    val previewTargetMemberId: StateFlow<Int?> = _previewTargetMemberId.asStateFlow()

    private val _dismissedReminderIds = MutableStateFlow<Set<String>>(emptySet())
    val dismissedReminderIds: StateFlow<Set<String>> = _dismissedReminderIds.asStateFlow()

    val activeMemberDueReminders: StateFlow<List<MemberDueReminder>> = combine(
        membersWithStats,
        _memberSession,
        _rememberedSession,
        _simulatedReminderDay,
        combine(_dismissedReminderIds, _previewTargetMemberId) { dismissed, previewId -> dismissed to previewId }
    ) { statsList, mSession, rSession, simDay, (dismissedIds, previewId) ->
        if (statsList.isEmpty()) return@combine emptyList<MemberDueReminder>()

        val rawId = mSession.rrkMemberId.ifBlank { rSession.rrkMemberId }
        val parsedNumeric = Regex("(\\d+)").find(rawId)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val rawName = mSession.fullName.ifBlank { rSession.fullName }.trim()

        val matchedMemberStats = when {
            previewId != null -> statsList.find { it.member.id == previewId }
            parsedNumeric != null -> statsList.find { it.member.id == parsedNumeric }
            rawName.isNotBlank() -> statsList.find { it.member.name.equals(rawName, ignoreCase = true) }
            simDay != null -> statsList.firstOrNull { it.totalDue > 0 } ?: statsList.firstOrNull()
            else -> null
        } ?: return@combine emptyList<MemberDueReminder>()

        val activeMonths = AppRepository.getActiveMonths()
        val billingMonth = matchedMemberStats.pendingMonths.firstOrNull()
            ?: activeMonths.lastOrNull()
            ?: SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
        val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        val daysToEvaluate = when (simDay) {
            0 -> listOf(1, 8, 14)
            1, 8, 14 -> listOf(simDay)
            else -> {
                val realDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                if (realDay in listOf(1, 8, 14)) listOf(realDay) else emptyList()
            }
        }

        daysToEvaluate.mapNotNull { day ->
            AdminNotificationHelper.buildReminderForDay(
                stats = matchedMemberStats,
                dayOfMonth = day,
                billingMonth = billingMonth,
                paymentDate = todayDate,
                isTestPreview = simDay != null
            )
        }.filter { it.id !in dismissedIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Seed official 11-member matrix if database is empty
                val membersList = database.appDao().getAllMembersSync()
                if (membersList.isEmpty()) {
                    AppDatabase.populateInitialData(database.appDao())
                } else {
                    AppDatabase.ensureMasterSheetCalibrated(database.appDao())
                }
                // Start real-time Firestore synchronization & first-launch auto-seeding
                firebaseRepository.startRealtimeSync(viewModelScope)
                val admin = repository.getAdmin("admin")
                if (admin == null) {
                    repository.addAdmin(
                        AdminUser(
                            username = "admin",
                            password = "rrk2025",
                            role = "Super Admin",
                            addedBy = "System",
                            addedAt = "2025-05-01"
                        )
                    )
                }
                val ms = _memberSession.value
                if (!_rememberedSession.value.isValid && ms.isLoggedIn && ms.rrkMemberId.isNotBlank()) {
                    val savedPinHash = sessionManager.getPinHashForMember(ms.rrkMemberId)
                        .ifBlank { repository.getMemberPinHash(ms.rrkMemberId) }
                    sessionManager.saveRememberedUser(
                        rrkMemberId = ms.rrkMemberId,
                        fullName = ms.fullName,
                        contact = ms.contact,
                        role = ms.role,
                        pinHash = savedPinHash
                    )
                    _rememberedSession.value = sessionManager.getRememberedUser()
                }
            } catch (e: Throwable) {
                Log.e("MainViewModel", "Error ensuring database consistency: ${e.message}")
            }
        }
    }

    // --- Authentication ---
    fun login(u: String, p: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val cleanUser = u.trim()
            val cleanPass = p.trim()

            if (cleanUser.isEmpty() || cleanPass.isEmpty()) {
                onResult(false, "Please enter both username and password")
                return@launch
            }

            // 1. Try finding in database (case-insensitive query via LOWER(TRIM(username)))
            var admin = repository.getAdmin(cleanUser)

            // 2. Default credentials fallback:
            // If username is "admin" (case-insensitive) and password is "rrk2025",
            // always allow login, even if database admin record was missing or delayed!
            if ((admin == null || admin.password.trim() != cleanPass) &&
                cleanUser.equals("admin", ignoreCase = true) &&
                cleanPass == "rrk2025"
            ) {
                val defaultAdmin = AdminUser(
                    username = "admin",
                    password = "rrk2025",
                    role = "Super Admin",
                    addedBy = "System",
                    addedAt = "2025-05-01"
                )
                repository.addAdmin(defaultAdmin)
                admin = defaultAdmin
            }

            if (admin != null && admin.password.trim() == cleanPass) {
                sessionManager.saveLogin(admin.username, admin.role)
                _isAdminLoggedIn.value = true
                _adminUsername.value = admin.username
                _adminRole.value = admin.role
                repository.logActivity("login", "Admin signed in: ${admin.username} (${admin.role})", admin.username)
                _toastEvent.emit("Welcome back, ${admin.username}! 🔐")
                onResult(true, "Login successful")
            } else {
                onResult(false, "Invalid credentials. Default: admin / rrk2025")
            }
        }
    }

    fun logout() {
        val user = _adminUsername.value
        viewModelScope.launch {
            repository.logActivity("logout", "Admin signed out: $user", user)
            sessionManager.logout()
            _isAdminLoggedIn.value = false
            _adminUsername.value = "admin"
            _adminRole.value = "Admin"
            _toastEvent.emit("Logged out successfully")
        }
    }

    fun changePassword(current: String, newPass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val username = _adminUsername.value
            val admin = repository.getAdmin(username)
            if (admin == null || admin.password != current) {
                onResult(false, "Current password is incorrect")
                return@launch
            }
            if (newPass.length < 6) {
                onResult(false, "Password must be at least 6 characters")
                return@launch
            }
            repository.addAdmin(admin.copy(password = newPass))
            repository.logActivity("settings", "Password changed for $username", username)
            _toastEvent.emit("Password updated successfully! ✅")
            onResult(true, "Success")
        }
    }

    // --- Member CRUD (Admin Only) ---
    fun addMember(name: String, phone: String, joinDate: String, address: String) {
        viewModelScope.launch {
            repository.addMember(name.trim(), phone.trim(), joinDate, address.trim())
            _toastEvent.emit("Member \"$name\" added! ✅")
        }
    }

    fun updateMember(member: Member) {
        viewModelScope.launch {
            repository.updateMember(member)
            _toastEvent.emit("Member updated! ✅")
        }
    }

    fun updateMemberPhoto(memberId: Int, photoUri: String?) {
        viewModelScope.launch {
            val finalUri = if (photoUri != null && photoUri.startsWith("data:")) {
                val cloudUrl = firebaseRepository.uploadDataUri(
                    photoUri,
                    "member_avatars",
                    "member_${memberId}_${System.currentTimeMillis()}.jpg"
                )
                cloudUrl ?: photoUri
            } else {
                photoUri
            }
            repository.updateMemberPhoto(memberId, finalUri)
            _toastEvent.emit("Member photo updated! 📸")
        }
    }

    fun deleteMember(memberId: Int, memberName: String) {
        viewModelScope.launch {
            repository.deleteMember(memberId, memberName)
            _toastEvent.emit("Member \"$memberName\" deleted")
        }
    }

    // --- Deposit CRUD (Admin Only) ---
    fun recordDeposit(
        memberId: Int,
        month: String,
        paymentDate: String,
        amount: Int = 1000,
        fine: Int = 0,
        paymentMode: String = "Cash",
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.recordDeposit(memberId, month, paymentDate, amount, fine, paymentMode)
            _toastEvent.emit("Deposit of ${com.example.util.CurrencyFormatter.formatCurrency(amount + fine)} recorded! ✅")
            onSuccess(id)
        }
    }

    fun recordBulkDeposits(depositsList: List<Deposit>, onComplete: () -> Unit) {
        viewModelScope.launch {
            if (depositsList.isEmpty()) {
                _toastEvent.emit("No deposits to save!")
                return@launch
            }
            repository.recordBulkDeposits(depositsList)
            _toastEvent.emit("Recorded batch of ${depositsList.size} deposits! ✅")
            onComplete()
        }
    }

    fun updateDeposit(deposit: Deposit) {
        viewModelScope.launch {
            repository.updateDeposit(deposit)
            _toastEvent.emit("Deposit #${deposit.id} updated! ✅")
        }
    }

    fun deleteDeposit(depositId: Int) {
        viewModelScope.launch {
            repository.deleteDeposit(depositId)
            _toastEvent.emit("Deposit #$depositId deleted")
        }
    }

    // --- Expense CRUD (Admin Only) ---
    fun addExpense(
        description: String,
        category: String,
        amount: Int,
        date: String,
        quantity: String = "",
        paidBy: String = "Finance Dept",
        remarks: String = ""
    ) {
        viewModelScope.launch {
            repository.addExpense(description, category, quantity, amount, date, paidBy, remarks, _adminUsername.value)
            _toastEvent.emit("Expense of ${com.example.util.CurrencyFormatter.formatCurrency(amount)} logged! ✅")
        }
    }

    fun recordBulkExpenses(expensesList: List<Expense>, onComplete: () -> Unit) {
        viewModelScope.launch {
            if (expensesList.isEmpty()) {
                _toastEvent.emit("No expenses to save!")
                return@launch
            }
            repository.recordBulkExpenses(expensesList)
            _toastEvent.emit("Recorded batch of ${expensesList.size} expenses! ✅")
            onComplete()
        }
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            repository.updateExpense(expense)
            _toastEvent.emit("Expense updated! ✅")
        }
    }

    fun deleteExpense(expenseId: Int) {
        viewModelScope.launch {
            repository.deleteExpense(expenseId)
            _toastEvent.emit("Expense #$expenseId deleted")
        }
    }

    // --- Investment CRUD (Admin Only) ---
    fun addInvestment(investment: Investment) {
        viewModelScope.launch {
            val finalInv = if (investment.photoUri.startsWith("data:")) {
                val cloudUrl = firebaseRepository.uploadDataUri(
                    investment.photoUri,
                    "investment_photos",
                    "inv_${System.currentTimeMillis()}.jpg"
                )
                investment.copy(photoUri = cloudUrl ?: investment.photoUri)
            } else {
                investment
            }
            repository.addInvestment(finalInv)
            _toastEvent.emit("Investment \"${investment.name}\" recorded! ✅")
        }
    }

    fun recordBulkInvestments(investmentsList: List<Investment>, onComplete: () -> Unit) {
        viewModelScope.launch {
            if (investmentsList.isEmpty()) {
                _toastEvent.emit("No investments to save!")
                return@launch
            }
            repository.recordBulkInvestments(investmentsList)
            _toastEvent.emit("Recorded batch of ${investmentsList.size} investments! ✅")
            onComplete()
        }
    }

    fun updateInvestment(investment: Investment) {
        viewModelScope.launch {
            val finalInv = if (investment.photoUri.startsWith("data:")) {
                val cloudUrl = firebaseRepository.uploadDataUri(
                    investment.photoUri,
                    "investment_photos",
                    "inv_${investment.id}_${System.currentTimeMillis()}.jpg"
                )
                investment.copy(photoUri = cloudUrl ?: investment.photoUri)
            } else {
                investment
            }
            repository.updateInvestment(finalInv)
            _toastEvent.emit("Investment updated! ✅")
        }
    }

    fun deleteInvestment(investmentId: Int) {
        viewModelScope.launch {
            repository.deleteInvestment(investmentId)
            _toastEvent.emit("Investment #$investmentId deleted")
        }
    }

    // --- Member Settlement CRUD (Admin Only) ---
    fun addSettlement(settlement: MemberSettlement, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.addSettlement(settlement)
            _toastEvent.emit("Settlement for ${settlement.memberName} saved! ✅")
            onComplete()
        }
    }

    fun updateSettlement(settlement: MemberSettlement) {
        viewModelScope.launch {
            repository.updateSettlement(settlement)
            _toastEvent.emit("Settlement #${settlement.id} updated! ✅")
        }
    }

    fun deleteSettlement(settlementId: Int) {
        viewModelScope.launch {
            repository.deleteSettlement(settlementId)
            _toastEvent.emit("Settlement #$settlementId deleted")
        }
    }

    // --- Financial Settings ---
    fun updateFinancialSettings(bank: Int, reserve: Int) {
        viewModelScope.launch {
            repository.updateConfig("bank_balance", bank.toString())
            repository.updateConfig("reserved_amount", reserve.toString())
            _toastEvent.emit("Bank balance and reserve updated! Cash in Hand recalculated automatically. ✅")
        }
    }

    fun updateConfig(key: String, value: String) {
        viewModelScope.launch {
            repository.updateConfig(key, value)
            _toastEvent.emit("Organization content updated! ✅")
        }
    }

    fun showToast(message: String) {
        viewModelScope.launch {
            _toastEvent.emit(message)
        }
    }

    // --- Manual Payment Requests & Admin Verification ---
    fun submitPaymentRequest(
        memberId: Int,
        memberName: String,
        month: String,
        paymentMethod: String,
        amount: Int,
        fine: Int,
        trxId: String,
        paymentDate: String,
        notes: String = "",
        onResult: (Boolean, String) -> Unit
    ) {
        if (amount <= 0) {
            onResult(false, "Deposit amount must be greater than ৳0.")
            return
        }
        val cleanTrx = trxId.trim()
        if (!paymentMethod.equals("Cash", ignoreCase = true) && cleanTrx.isEmpty()) {
            onResult(false, "Please enter your $paymentMethod Transaction ID (TrxID).")
            return
        }
        viewModelScope.launch {
            val effectiveTrx = if (cleanTrx.isEmpty()) "CASH-${paymentDate.replace("-", "")}" else cleanTrx
            val cleanFine = fine.coerceAtLeast(0)
            val requestId = repository.submitPaymentRequest(
                memberId = memberId,
                memberName = memberName,
                month = month,
                paymentMethod = paymentMethod,
                amount = amount,
                fine = cleanFine,
                trxId = effectiveTrx,
                paymentDate = paymentDate,
                notes = notes
            )

            // 1. Trigger system notification if permission is granted
            runCatching {
                AdminNotificationHelper.postNewPaymentProofNotification(
                    context = getApplication(),
                    requestId = requestId.toInt(),
                    memberId = memberId,
                    memberName = memberName,
                    month = month,
                    amount = amount,
                    fine = cleanFine,
                    paymentMethod = paymentMethod,
                    trxId = effectiveTrx
                )
            }

            // 2. Automatically send EmailJS alert to Admin if configured
            val emailSettings = runCatching { repository.getAdminAlertEmailSettingsSync() }
                .getOrDefault(AdminAlertEmailSettings())
            var emailSentViaEmailJs = false
            if (emailSettings.isEmailJsConfigured) {
                emailSentViaEmailJs = AdminNotificationHelper.sendEmailJsAlert(
                    settings = emailSettings,
                    memberId = memberId,
                    memberName = memberName,
                    month = month,
                    amount = amount,
                    fine = cleanFine,
                    paymentMethod = paymentMethod,
                    trxId = effectiveTrx,
                    paymentDate = paymentDate
                )
            }

            val statusMessage = if (emailSentViaEmailJs) {
                "Submitted as Pending Verification. Admin email alert sent to ${emailSettings.adminAlertEmail}."
            } else {
                "Submitted as Pending Verification."
            }
            _toastEvent.emit("Payment proof submitted! Pending Admin verification.")
            onResult(true, statusMessage)
        }
    }

    fun approvePaymentRequest(
        requestId: Int,
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val res = repository.approvePaymentRequest(requestId, _adminUsername.value)
            res.onSuccess { req ->
                _toastEvent.emit("Approved ${req.memberName} (${req.month})! Ledger synced & Proof unlocked.")
                onComplete(true, "Approved & synced")
            }.onFailure { err ->
                _toastEvent.emit(err.message ?: "Unable to approve request.")
                onComplete(false, err.message ?: "Error")
            }
        }
    }

    fun rejectPaymentRequest(
        requestId: Int,
        reason: String = "",
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val res = repository.rejectPaymentRequest(requestId, _adminUsername.value, reason)
            res.onSuccess { req ->
                _toastEvent.emit("Rejected payment request for ${req.memberName}.")
                onComplete(true, "Rejected")
            }.onFailure { err ->
                _toastEvent.emit(err.message ?: "Unable to reject request.")
                onComplete(false, err.message ?: "Error")
            }
        }
    }

    fun updateOfficialPaymentAccounts(bkash: String, nagad: String, bank: String) {
        if (!_isAdminLoggedIn.value) {
            viewModelScope.launch {
                _toastEvent.emit("Admin login required to edit Official Payment Accounts.")
            }
            return
        }
        viewModelScope.launch {
            repository.updateOfficialPaymentAccounts(
                bkash = bkash,
                nagad = nagad,
                bank = bank,
                adminName = _adminUsername.value
            )
            _toastEvent.emit("Official payment accounts updated!")
        }
    }

    fun updateAdminAlertEmailSettings(
        adminAlertEmail: String,
        emailJsServiceId: String,
        emailJsTemplateId: String,
        emailJsPublicKey: String
    ) {
        if (!_isAdminLoggedIn.value) {
            viewModelScope.launch {
                _toastEvent.emit("Admin login required to edit Admin Alert Email Settings.")
            }
            return
        }
        viewModelScope.launch {
            repository.updateAdminAlertEmailSettings(
                adminAlertEmail = adminAlertEmail,
                emailJsServiceId = emailJsServiceId,
                emailJsTemplateId = emailJsTemplateId,
                emailJsPublicKey = emailJsPublicKey,
                adminName = _adminUsername.value
            )
            _toastEvent.emit("Admin Alert Email settings saved! 📧")
        }
    }

    fun dismissDueReminder(reminderId: String) {
        _dismissedReminderIds.update { it + reminderId }
    }

    fun triggerTestDueReminders(dayOfMonth: Int?, targetMemberId: Int? = null) {
        _dismissedReminderIds.value = emptySet()
        _previewTargetMemberId.value = targetMemberId
        _simulatedReminderDay.value = dayOfMonth

        if (dayOfMonth == null) {
            viewModelScope.launch {
                _toastEvent.emit("Due reminder preview reset to live calendar schedule.")
            }
            return
        }

        viewModelScope.launch {
            val statsList = membersWithStats.value
            val rawId = _memberSession.value.rrkMemberId.ifBlank { _rememberedSession.value.rrkMemberId }
            val parsedNumeric = Regex("(\\d+)").find(rawId)?.groupValues?.getOrNull(1)?.toIntOrNull()
            val targetStats = when {
                targetMemberId != null -> statsList.find { it.member.id == targetMemberId }
                parsedNumeric != null -> statsList.find { it.member.id == parsedNumeric }
                else -> statsList.firstOrNull { it.totalDue > 0 } ?: statsList.firstOrNull()
            }

            if (targetStats == null) {
                _toastEvent.emit("No member found to preview due reminders.")
                return@launch
            }

            val activeMonths = AppRepository.getActiveMonths()
            val billingMonth = targetStats.pendingMonths.firstOrNull()
                ?: activeMonths.lastOrNull()
                ?: SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
            val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

            val days = if (dayOfMonth == 0) listOf(1, 8, 14) else listOf(dayOfMonth)
            val builtReminders = days.mapNotNull { d ->
                AdminNotificationHelper.buildReminderForDay(
                    stats = targetStats,
                    dayOfMonth = d,
                    billingMonth = billingMonth,
                    paymentDate = todayDate,
                    isTestPreview = true
                )
            }

            if (builtReminders.isEmpty()) {
                _toastEvent.emit("${targetStats.member.name} has ৳0 pending due — zero due alerts shown.")
            } else {
                builtReminders.forEach { reminder ->
                    AdminNotificationHelper.postMemberDueReminderNotification(
                        context = getApplication(),
                        reminder = reminder
                    )
                }
                val label = when (dayOfMonth) {
                    1 -> "1st of Month"
                    8 -> "8th of Month"
                    14 -> "14th of Month"
                    else -> "1st, 8th & 14th (All 3)"
                }
                _toastEvent.emit("Triggered $label due reminder preview for ${targetStats.member.name}! 🔔")
            }
        }
    }

    // --- Admin Management ---
    fun addNewAdmin(username: String, pass: String, role: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val trimmed = username.trim()
            if (trimmed.isEmpty() || pass.isEmpty()) {
                onResult(false, "Username and password cannot be empty")
                return@launch
            }
            if (pass.length < 6) {
                onResult(false, "Password must be at least 6 characters")
                return@launch
            }
            if (repository.getAdmin(trimmed) != null) {
                onResult(false, "Username \"$trimmed\" already exists")
                return@launch
            }

            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            repository.addAdmin(
                AdminUser(
                    username = trimmed,
                    password = pass,
                    role = role,
                    addedBy = _adminUsername.value,
                    addedAt = today
                )
            )
            _toastEvent.emit("Admin user \"$trimmed\" added! ✅")
            onResult(true, "Admin added successfully")
        }
    }

    fun deleteAdminUser(username: String) {
        if (username == _adminUsername.value) {
            viewModelScope.launch { _toastEvent.emit("You cannot delete your own account!") }
            return
        }
        if (username == "admin") {
            viewModelScope.launch { _toastEvent.emit("Primary admin account cannot be deleted!") }
            return
        }
        viewModelScope.launch {
            repository.deleteAdmin(username)
            _toastEvent.emit("Admin \"$username\" removed")
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _toastEvent.emit("Activity logs cleared")
        }
    }

    // --- Member Sign Up, Sign In, Quick PIN & Password Recovery ---
    fun signUpMember(
        fullName: String,
        contact: String,
        rrkMemberId: String,
        password: String,
        quickPin: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val cleanPin = quickPin.trim()
        if (cleanPin.length != 4 || !cleanPin.all { it.isDigit() }) {
            onResult(false, "Please set a 4-digit numeric Quick PIN.")
            return
        }
        viewModelScope.launch {
            val res = repository.registerMemberAccount(fullName, contact, rrkMemberId, password)
            res.onSuccess { account ->
                val pinHash = PasswordUtils.sha256(cleanPin)
                repository.saveMemberPinHash(account.rrkMemberId, pinHash)
                sessionManager.saveMemberLogin(
                    rrkMemberId = account.rrkMemberId,
                    fullName = account.fullName,
                    contact = account.contact,
                    role = account.role
                )
                sessionManager.saveRememberedUser(
                    rrkMemberId = account.rrkMemberId,
                    fullName = account.fullName,
                    contact = account.contact,
                    role = account.role,
                    pinHash = pinHash
                )
                _memberSession.value = sessionManager.getMemberSessionState()
                _rememberedSession.value = sessionManager.getRememberedUser()
                sessionManager.logout()
                _isAdminLoggedIn.value = false
                _adminUsername.value = "admin"
                _adminRole.value = "Admin"
                _pendingPinSetupAccount.value = null
                _isAppUnlocked.value = true
                _toastEvent.emit("Welcome to Rising Roads, ${account.fullName}!")
                onResult(true, "Account created successfully!")
            }.onFailure { err ->
                onResult(false, err.message ?: "Unable to create account.")
            }
        }
    }

    fun signInMember(
        identifier: String,
        password: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.authenticateMember(identifier, password)
            res.onSuccess { account ->
                var existingPinHash = sessionManager.getPinHashForMember(account.rrkMemberId)
                if (existingPinHash.isBlank()) {
                    existingPinHash = repository.getMemberPinHash(account.rrkMemberId)
                }

                sessionManager.saveMemberLogin(
                    rrkMemberId = account.rrkMemberId,
                    fullName = account.fullName,
                    contact = account.contact,
                    role = account.role
                )
                sessionManager.saveRememberedUser(
                    rrkMemberId = account.rrkMemberId,
                    fullName = account.fullName,
                    contact = account.contact,
                    role = account.role,
                    pinHash = existingPinHash
                )
                if (account.rrkMemberId.startsWith("RRK-ADMIN-")) {
                    sessionManager.saveLogin(account.fullName, account.role)
                    _isAdminLoggedIn.value = true
                    _adminUsername.value = account.fullName
                    _adminRole.value = account.role
                } else {
                    sessionManager.logout()
                    _isAdminLoggedIn.value = false
                    _adminUsername.value = "admin"
                    _adminRole.value = "Admin"
                }

                _memberSession.value = sessionManager.getMemberSessionState()
                _rememberedSession.value = sessionManager.getRememberedUser()

                if (existingPinHash.isNotBlank()) {
                    _pendingPinSetupAccount.value = null
                    _isAppUnlocked.value = true
                    _toastEvent.emit("Welcome back, ${account.fullName}!")
                    onResult(true, "Sign in successful!")
                } else {
                    _pendingPinSetupAccount.value = account
                    onResult(true, "Set your 4-digit Quick PIN to continue.")
                }
            }.onFailure { err ->
                onResult(false, err.message ?: "Invalid credentials.")
            }
        }
    }

    fun completePinSetup(pin: String, onResult: (Boolean, String) -> Unit) {
        val cleanPin = pin.trim()
        if (cleanPin.length != 4 || !cleanPin.all { it.isDigit() }) {
            onResult(false, "Please enter a valid 4-digit numeric PIN.")
            return
        }
        val account = _pendingPinSetupAccount.value
        val remembered = _rememberedSession.value
        val targetId = account?.rrkMemberId ?: remembered.rrkMemberId
        val targetName = account?.fullName ?: remembered.fullName
        val targetContact = account?.contact ?: remembered.contact
        val targetRole = account?.role ?: remembered.role
        if (targetId.isBlank()) {
            onResult(false, "Session expired. Please sign in again.")
            return
        }
        viewModelScope.launch {
            val pinHash = PasswordUtils.sha256(cleanPin)
            repository.saveMemberPinHash(targetId, pinHash)
            sessionManager.saveMemberLogin(targetId, targetName, targetContact, targetRole)
            sessionManager.saveRememberedUser(targetId, targetName, targetContact, targetRole, pinHash)
            _memberSession.value = sessionManager.getMemberSessionState()
            _rememberedSession.value = sessionManager.getRememberedUser()
            _pendingPinSetupAccount.value = null
            _isAppUnlocked.value = true
            _toastEvent.emit("4-Digit Quick PIN saved!")
            onResult(true, "Quick PIN saved!")
        }
    }

    fun unlockWithPin(pin: String, onResult: (Boolean, String) -> Unit) {
        val remembered = _rememberedSession.value
        if (!remembered.isValid || !remembered.hasPin) {
            onResult(false, "No Quick PIN configured. Please switch account and sign in.")
            return
        }
        val cleanPin = pin.trim()
        if (cleanPin.length != 4 || !cleanPin.all { it.isDigit() }) {
            onResult(false, "Enter your 4-digit numeric PIN.")
            return
        }
        if (PasswordUtils.sha256(cleanPin) != remembered.pinHash) {
            onResult(false, "Incorrect PIN. Try again or tap Forgot PIN?")
            return
        }
        sessionManager.saveMemberLogin(
            rrkMemberId = remembered.rrkMemberId,
            fullName = remembered.fullName,
            contact = remembered.contact,
            role = remembered.role
        )
        _memberSession.value = sessionManager.getMemberSessionState()
        if (remembered.rrkMemberId.startsWith("RRK-ADMIN-")) {
            sessionManager.saveLogin(remembered.fullName, remembered.role)
            _isAdminLoggedIn.value = true
            _adminUsername.value = remembered.fullName
            _adminRole.value = remembered.role
        } else {
            sessionManager.logout()
            _isAdminLoggedIn.value = false
            _adminUsername.value = "admin"
            _adminRole.value = "Admin"
        }
        _pendingPinSetupAccount.value = null
        _isAppUnlocked.value = true
        viewModelScope.launch {
            repository.logActivity("login", "Unlocked via Quick PIN: ${remembered.fullName} (${remembered.rrkMemberId})", remembered.fullName)
        }
        onResult(true, "Unlocked!")
    }

    fun resetRememberedPin(
        password: String,
        newPin: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val remembered = _rememberedSession.value
        if (!remembered.isValid) {
            onResult(false, "No remembered member found.")
            return
        }
        val cleanPin = newPin.trim()
        if (cleanPin.length != 4 || !cleanPin.all { it.isDigit() }) {
            onResult(false, "New PIN must be exactly 4 digits.")
            return
        }
        viewModelScope.launch {
            val valid = repository.verifyMemberOrAdminPassword(remembered.rrkMemberId, password)
            if (!valid) {
                onResult(false, "Account password is incorrect.")
                return@launch
            }
            val newPinHash = PasswordUtils.sha256(cleanPin)
            repository.saveMemberPinHash(remembered.rrkMemberId, newPinHash)
            sessionManager.savePinHashForMember(remembered.rrkMemberId, newPinHash)
            _rememberedSession.value = sessionManager.getRememberedUser()
            _toastEvent.emit("Quick PIN reset for ${remembered.fullName}!")
            onResult(true, "Quick PIN updated! You can now unlock with your new PIN.")
        }
    }

    fun lockApp() {
        val currentName = _memberSession.value.fullName.ifBlank { _rememberedSession.value.fullName }
        _pendingPinSetupAccount.value = null
        _isAppUnlocked.value = false
        viewModelScope.launch {
            if (currentName.isNotBlank()) {
                repository.logActivity("logout", "App locked: $currentName", currentName)
            }
            _toastEvent.emit("App locked")
        }
    }

    fun switchAccount() {
        _pendingPinSetupAccount.value = null
        _isAppUnlocked.value = false
        sessionManager.clearRememberedUser()
        sessionManager.logoutMember()
        sessionManager.logout()
        _rememberedSession.value = RememberedUserSession()
        _memberSession.value = MemberSessionState()
        _isAdminLoggedIn.value = false
        _adminUsername.value = "admin"
        _adminRole.value = "Admin"
    }

    fun resetMemberPasswordWithVerification(
        contact: String,
        rrkMemberId: String,
        newPassword: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.resetMemberPassword(contact, rrkMemberId, newPassword)
            res.onSuccess { account ->
                // Seamless Firebase Auth reset email hook when an email address is registered
                val firebaseEmailPrepared = PasswordUtils.isEmail(account.contact)
                if (firebaseEmailPrepared) {
                    runCatching {
                        Firebase.auth.sendPasswordResetEmail(account.contact.trim())
                    }
                }
                val suffix = if (firebaseEmailPrepared) {
                    " Firebase password reset sync is also ready for ${account.contact}."
                } else {
                    ""
                }
                _toastEvent.emit("Password reset successful for ${account.fullName}!")
                onResult(true, "Password reset successful!$suffix You can now sign in.")
            }.onFailure { err ->
                onResult(false, err.message ?: "Password recovery failed.")
            }
        }
    }

    fun adminResetMemberPassword(
        rrkMemberId: String,
        newPassword: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.adminResetMemberPassword(
                rrkMemberId = rrkMemberId,
                newPassword = newPassword,
                adminUsername = _adminUsername.value
            )
            res.onSuccess { account ->
                _toastEvent.emit("Password reset for ${account.fullName} (${account.rrkMemberId})!")
                onResult(true, "Password updated for ${account.fullName}.")
            }.onFailure { err ->
                onResult(false, err.message ?: "Failed to reset member password.")
            }
        }
    }

    fun logoutMember() {
        val name = _memberSession.value.fullName
        viewModelScope.launch {
            if (name.isNotBlank()) {
                repository.logActivity("logout", "Member signed out: $name", name)
            }
            sessionManager.logoutMember()
            _memberSession.value = MemberSessionState()
            _toastEvent.emit("Signed out successfully")
        }
    }

    fun logoutActiveUser() {
        val adminWasIn = _isAdminLoggedIn.value
        val memberWasIn = _memberSession.value.isLoggedIn
        val actor = when {
            adminWasIn -> _adminUsername.value
            memberWasIn -> _memberSession.value.fullName
            else -> ""
        }
        viewModelScope.launch {
            if (adminWasIn) {
                sessionManager.logout()
                _isAdminLoggedIn.value = false
                _adminUsername.value = "admin"
                _adminRole.value = "Admin"
            }
            if (memberWasIn) {
                sessionManager.logoutMember()
                _memberSession.value = MemberSessionState()
            }
            if (actor.isNotBlank()) {
                repository.logActivity("logout", "Signed out: $actor", actor)
                _toastEvent.emit("Logged out successfully")
            }
        }
    }

    // --- Member Ideas & Community ---
    fun currentParticipantIdentity(): Triple<String, String, String>? {
        val member = _memberSession.value
        if (member.isLoggedIn && member.rrkMemberId.isNotBlank()) {
            return Triple(member.rrkMemberId, member.fullName, "Member")
        }
        if (_isAdminLoggedIn.value) {
            return Triple("ADMIN_${_adminUsername.value}", _adminUsername.value, "Admin")
        }
        return null
    }

    fun submitMemberIdea(
        title: String,
        category: String,
        businessType: String = "Product",
        estimatedBudgetText: String,
        description: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val author = currentParticipantIdentity()
        if (author == null) {
            onResult(false, "Please sign in as a Member first to share an idea.")
            return
        }
        val cleanTitle = title.trim()
        val cleanDesc = description.trim()
        val budget = estimatedBudgetText.replace(Regex("[^0-9]"), "").toLongOrNull()?.takeIf { it > 0L } ?: 0L
        if (cleanTitle.isEmpty() || cleanDesc.isEmpty()) {
            onResult(false, "Please provide a title and detailed description.")
            return
        }

        viewModelScope.launch {
            repository.addMemberIdea(
                title = cleanTitle,
                category = category,
                businessType = businessType,
                estimatedBudget = budget,
                description = cleanDesc,
                authorId = author.first,
                authorName = author.second,
                authorRole = author.third
            )
            _toastEvent.emit("Idea \"$cleanTitle\" published!")
            onResult(true, "Idea submitted!")
        }
    }

    fun toggleIdeaUpvote(ideaId: Int): Boolean = toggleIdeaAgree(ideaId)

    fun toggleIdeaAgree(ideaId: Int): Boolean {
        val user = currentParticipantIdentity() ?: return false
        viewModelScope.launch {
            repository.toggleIdeaAgree(ideaId, user.first)
        }
        return true
    }

    fun toggleIdeaDisagree(ideaId: Int): Boolean {
        val user = currentParticipantIdentity() ?: return false
        viewModelScope.launch {
            repository.toggleIdeaDisagree(ideaId, user.first)
        }
        return true
    }

    fun addIdeaComment(
        ideaId: Int,
        content: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val author = currentParticipantIdentity()
        if (author == null) {
            onResult(false, "Please sign in to post a comment.")
            return
        }
        if (content.isBlank()) {
            onResult(false, "Comment cannot be empty.")
            return
        }
        viewModelScope.launch {
            repository.addIdeaComment(
                ideaId = ideaId,
                authorId = author.first,
                authorName = author.second,
                authorRole = author.third,
                content = content
            )
            onResult(true, "Comment added!")
        }
    }

    fun deleteMemberIdea(ideaId: Int) {
        val actor = currentParticipantIdentity()?.second ?: "admin"
        viewModelScope.launch {
            repository.deleteMemberIdea(ideaId, actor)
            _toastEvent.emit("Idea removed")
        }
    }

    fun resetToOfficial11Data(onComplete: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                AppDatabase.populateInitialData(database.appDao())
                _toastEvent.emit("Reset to 11 Founding Members matrix! ✅")
                withContext(Dispatchers.Main) { onComplete() }
            } catch (e: Throwable) {
                _toastEvent.emit("Error resetting data: ${e.message}")
            }
        }
    }

    // --- CSV Export ---
    fun exportDepositsCsv(): File {
        val context = getApplication<Application>()
        val file = File(context.cacheDir, "RRK_Deposits_${System.currentTimeMillis()}.csv")
        file.bufferedWriter().use { writer ->
            writer.write("Deposit ID,Member ID,Member Name,Billing Month,Payment Date,Amount (BDT),Fine (BDT),Total (BDT)\n")
            val membersMap = membersWithStats.value.associate { it.member.id to it.member.name }
            deposits.value.forEach { dep ->
                val name = membersMap[dep.memberId] ?: "Unknown"
                writer.write("${dep.id},${dep.memberId},\"$name\",${dep.month},${dep.paymentDate},${dep.amount},${dep.fine},${dep.amount + dep.fine}\n")
            }
        }
        return file
    }

    // --- JSON Database Backup & Restore ---
    fun exportDatabaseBackup(context: Context, onComplete: (File, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val dao = database.appDao()
                val members = dao.getAllMembersSync()
                val deposits = dao.getAllDepositsSync()
                val expenses = dao.getAllExpensesSync()
                val investments = dao.getAllInvestmentsSync()
                val settlements = dao.getAllSettlementsSync()

                val json = org.json.JSONObject().apply {
                    put("version", 4)
                    put("timestamp", System.currentTimeMillis())
                    put("members_count", members.size)
                    put("members", org.json.JSONArray().apply {
                        members.forEach { m ->
                            put(org.json.JSONObject().apply {
                                put("id", m.id)
                                put("name", m.name)
                                put("phone", m.phone)
                                put("joinDate", m.joinDate)
                                put("address", m.address)
                                put("photoUri", m.photoUri ?: "")
                            })
                        }
                    })
                    put("deposits", org.json.JSONArray().apply {
                        deposits.forEach { d ->
                            put(org.json.JSONObject().apply {
                                put("id", d.id)
                                put("memberId", d.memberId)
                                put("month", d.month)
                                put("paymentDate", d.paymentDate)
                                put("amount", d.amount)
                                put("fine", d.fine)
                                put("paymentMode", d.paymentMode)
                            })
                        }
                    })
                    put("expenses", org.json.JSONArray().apply {
                        expenses.forEach { e ->
                            put(org.json.JSONObject().apply {
                                put("id", e.id)
                                put("description", e.description)
                                put("category", e.category)
                                put("quantity", e.quantity)
                                put("amount", e.amount)
                                put("date", e.date)
                                put("paidBy", e.paidBy)
                                put("remarks", e.remarks)
                            })
                        }
                    })
                    put("investments", org.json.JSONArray().apply {
                        investments.forEach { i ->
                            put(org.json.JSONObject().apply {
                                put("id", i.id)
                                put("name", i.name)
                                put("type", i.type)
                                put("amount", i.amount)
                                put("purchasedQuantity", i.purchasedQuantity)
                                put("saleDate", i.saleDate)
                                put("soldQuantity", i.soldQuantity)
                                put("saleRevenue", i.saleRevenue)
                                put("expenses", i.expenses)
                                put("profitLoss", i.profitLoss)
                                put("status", i.status)
                                put("date", i.date)
                                put("supervisor", i.supervisor)
                                put("stockStatus", i.stockStatus)
                                put("description", i.description)
                                put("photoUri", i.photoUri)
                            })
                        }
                    })
                    put("settlements", org.json.JSONArray().apply {
                        settlements.forEach { s ->
                            put(org.json.JSONObject().apply {
                                put("id", s.id)
                                put("memberId", s.memberId)
                                put("memberName", s.memberName)
                                put("resignationDate", s.resignationDate)
                                put("totalDepositPaid", s.totalDepositPaid)
                                put("legalCharge", s.legalCharge)
                                put("sharedLosses", s.sharedLosses)
                                put("netReturnAmount", s.netReturnAmount)
                                put("settlementStatus", s.settlementStatus)
                                put("paymentMode", s.paymentMode)
                                put("notes", s.notes)
                            })
                        }
                    })
                }

                val jsonString = json.toString(2)
                val file = File(context.cacheDir, "RRK_Backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.json")
                file.writeText(jsonString)

                withContext(Dispatchers.Main) {
                    _toastEvent.emit("Database backup exported successfully! 💾")
                    onComplete(file, jsonString)
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _toastEvent.emit("Export failed: ${e.message}")
                }
            }
        }
    }

    fun restoreDatabaseBackup(jsonString: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val json = org.json.JSONObject(jsonString)
                val dao = database.appDao()

                dao.clearMembers()
                dao.clearDeposits()
                dao.clearExpenses()
                dao.clearInvestments()
                dao.clearSettlements()

                val membersArr = json.optJSONArray("members")
                if (membersArr != null) {
                    val mList = mutableListOf<Member>()
                    for (i in 0 until membersArr.length()) {
                        val obj = membersArr.getJSONObject(i)
                        mList.add(
                            Member(
                                id = obj.getInt("id"),
                                name = obj.getString("name"),
                                phone = obj.getString("phone"),
                                joinDate = obj.optString("joinDate", "2025-05-01"),
                                address = obj.optString("address", "Kharkharian"),
                                photoUri = obj.optString("photoUri").ifBlank { null }
                            )
                        )
                    }
                    dao.insertMembers(mList)
                }

                val depositsArr = json.optJSONArray("deposits")
                if (depositsArr != null) {
                    val dList = mutableListOf<Deposit>()
                    for (i in 0 until depositsArr.length()) {
                        val obj = depositsArr.getJSONObject(i)
                        dList.add(
                            Deposit(
                                id = obj.optInt("id", 0),
                                memberId = obj.getInt("memberId"),
                                month = obj.getString("month"),
                                paymentDate = obj.getString("paymentDate"),
                                amount = obj.getInt("amount"),
                                fine = obj.optInt("fine", 0),
                                paymentMode = obj.optString("paymentMode", "Cash")
                            )
                        )
                    }
                    dao.insertDeposits(dList)
                }

                val expensesArr = json.optJSONArray("expenses")
                if (expensesArr != null) {
                    val eList = mutableListOf<Expense>()
                    for (i in 0 until expensesArr.length()) {
                        val obj = expensesArr.getJSONObject(i)
                        eList.add(
                            Expense(
                                id = obj.optInt("id", 0),
                                description = obj.getString("description"),
                                category = obj.getString("category"),
                                quantity = obj.optString("quantity", ""),
                                amount = obj.getInt("amount"),
                                date = obj.getString("date"),
                                paidBy = obj.optString("paidBy", "Finance Dept"),
                                remarks = obj.optString("remarks", "")
                            )
                        )
                    }
                    dao.insertExpenses(eList)
                }

                val investmentsArr = json.optJSONArray("investments")
                if (investmentsArr != null) {
                    val iList = mutableListOf<Investment>()
                    for (i in 0 until investmentsArr.length()) {
                        val obj = investmentsArr.getJSONObject(i)
                        val rawStatus = obj.optString("status", "RUNNING").uppercase()
                        val normalizedStatus = when (rawStatus) {
                            "CLOSED", "COMPLETED", "LIQUIDATED" -> "CLOSED"
                            else -> "RUNNING"
                        }
                        iList.add(
                            Investment(
                                id = obj.optInt("id", 0),
                                name = obj.getString("name"),
                                type = obj.optString("type", "Agro"),
                                amount = obj.getInt("amount"),
                                purchasedQuantity = obj.optString("purchasedQuantity", ""),
                                saleDate = obj.optString("saleDate", ""),
                                soldQuantity = obj.optString("soldQuantity", ""),
                                saleRevenue = obj.optInt("saleRevenue", 0),
                                expenses = obj.optInt("expenses", 0),
                                profitLoss = obj.optInt("profitLoss", 0),
                                activeCapital = obj.optInt("activeCapital", 0),
                                status = normalizedStatus,
                                date = obj.getString("date"),
                                supervisor = obj.optString("supervisor", ""),
                                stockStatus = obj.optString("stockStatus", "In Stock"),
                                description = obj.optString("description", ""),
                                photoUri = obj.optString("photoUri", ""),
                                paymentSource = obj.optString("paymentSource", "Cash"),
                                returnSource = obj.optString("returnSource", "")
                            )
                        )
                    }
                    dao.insertInvestments(iList)
                }

                val settlementsArr = json.optJSONArray("settlements")
                if (settlementsArr != null) {
                    val sList = mutableListOf<MemberSettlement>()
                    for (i in 0 until settlementsArr.length()) {
                        val obj = settlementsArr.getJSONObject(i)
                        sList.add(
                            MemberSettlement(
                                id = obj.optInt("id", 0),
                                memberId = obj.getInt("memberId"),
                                memberName = obj.getString("memberName"),
                                resignationDate = obj.getString("resignationDate"),
                                totalDepositPaid = obj.getInt("totalDepositPaid"),
                                legalCharge = obj.optInt("legalCharge", 0),
                                sharedLosses = obj.optInt("sharedLosses", 0),
                                netReturnAmount = obj.optInt("netReturnAmount", 0),
                                settlementStatus = obj.optString("settlementStatus", "Pending"),
                                paymentMode = obj.optString("paymentMode", "Cash"),
                                notes = obj.optString("notes", "")
                            )
                        )
                    }
                    dao.insertSettlements(sList)
                }

                withContext(Dispatchers.Main) {
                    _toastEvent.emit("Database backup restored successfully! 📥")
                    onComplete(true, "Restored successfully")
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _toastEvent.emit("Restore failed: ${e.message}")
                    onComplete(false, "Restore failed: ${e.message}")
                }
            }
        }
    }

    // --- RRK AI Assistant (Firebase AI Logic + Live App Data) ---
    private val _aiChatMessages = MutableStateFlow<List<AiChatMessage>>(emptyList())
    val aiChatMessages: StateFlow<List<AiChatMessage>> = _aiChatMessages.asStateFlow()

    private val _isAiChatResponding = MutableStateFlow(false)
    val isAiChatResponding: StateFlow<Boolean> = _isAiChatResponding.asStateFlow()

    private val _financialSummaryState = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val financialSummaryState: StateFlow<AiTaskState> = _financialSummaryState.asStateFlow()

    private val _investmentSummaryState = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val investmentSummaryState: StateFlow<AiTaskState> = _investmentSummaryState.asStateFlow()

    private val _ideaResearchStates = MutableStateFlow<Map<Int, AiTaskState>>(emptyMap())
    val ideaResearchStates: StateFlow<Map<Int, AiTaskState>> = _ideaResearchStates.asStateFlow()

    private var chatJob: Job? = null
    private var financialSummaryJob: Job? = null
    private var investmentSummaryJob: Job? = null
    private val ideaResearchJobs = mutableMapOf<Int, Job>()
    private var chatMessageSeq = 0L

    private fun nextChatMessageId(): Long {
        chatMessageSeq += 1L
        return System.currentTimeMillis() * 1000L + (chatMessageSeq % 1000L)
    }

    private fun buildCurrentLiveAiContext(): String {
        return RrkAiAssistant.buildLiveAppContext(
            kpi = financialKpi.value,
            membersWithStats = membersWithStats.value,
            investments = investments.value,
            expenses = expenses.value,
            ideas = memberIdeas.value
        )
    }

    fun sendAiChatMessage(prompt: String) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isEmpty()) return

        chatJob?.cancel()
        val priorHistory = _aiChatMessages.value
        val userMsg = AiChatMessage(id = nextChatMessageId(), isUser = true, text = cleanPrompt)
        val assistantMsgId = nextChatMessageId()
        val assistantPlaceholder = AiChatMessage(id = assistantMsgId, isUser = false, text = "")

        _aiChatMessages.value = priorHistory + userMsg + assistantPlaceholder
        _isAiChatResponding.value = true

        chatJob = viewModelScope.launch {
            try {
                val liveContext = buildCurrentLiveAiContext()
                RrkAiAssistant.streamChat(
                    userPrompt = cleanPrompt,
                    priorHistory = priorHistory,
                    liveContext = liveContext
                ).collect { state ->
                    when (state) {
                        is AiTaskState.Idle,
                        is AiTaskState.Loading -> Unit

                        is AiTaskState.Streaming -> {
                            _aiChatMessages.update { list ->
                                list.map { msg ->
                                    if (msg.id == assistantMsgId) msg.copy(text = state.text, isError = false) else msg
                                }
                            }
                        }

                        is AiTaskState.Success -> {
                            _aiChatMessages.update { list ->
                                list.map { msg ->
                                    if (msg.id == assistantMsgId) msg.copy(text = state.text, isError = false) else msg
                                }
                            }
                        }

                        is AiTaskState.Error -> {
                            _aiChatMessages.update { list ->
                                list.map { msg ->
                                    if (msg.id == assistantMsgId) msg.copy(text = state.message, isError = true) else msg
                                }
                            }
                        }
                    }
                }
            } finally {
                _isAiChatResponding.value = false
            }
        }
    }

    fun clearAiChat() {
        chatJob?.cancel()
        _isAiChatResponding.value = false
        _aiChatMessages.value = emptyList()
    }

    fun generateFinancialAiSummary() {
        financialSummaryJob?.cancel()
        financialSummaryJob = viewModelScope.launch {
            val liveContext = buildCurrentLiveAiContext()
            RrkAiAssistant.streamExecutiveSummary(
                focusArea = "Financial Dashboard (Total Collection, Liquid Capital, Bank/Cash/Reserve, Expenses, and Dues)",
                liveContext = liveContext
            ).collect { state ->
                _financialSummaryState.value = state
            }
        }
    }

    fun clearFinancialAiSummary() {
        financialSummaryJob?.cancel()
        _financialSummaryState.value = AiTaskState.Idle
    }

    fun generateInvestmentAiSummary() {
        investmentSummaryJob?.cancel()
        investmentSummaryJob = viewModelScope.launch {
            val liveContext = buildCurrentLiveAiContext()
            RrkAiAssistant.streamExecutiveSummary(
                focusArea = "Investments & Portfolio P&L (Active vs Closed ventures, Disbursed Capital, and Realized ROI)",
                liveContext = liveContext
            ).collect { state ->
                _investmentSummaryState.value = state
            }
        }
    }

    fun clearInvestmentAiSummary() {
        investmentSummaryJob?.cancel()
        _investmentSummaryState.value = AiTaskState.Idle
    }

    fun researchMemberIdea(ideaId: Int) {
        val targetIdea = memberIdeas.value.firstOrNull { it.idea.id == ideaId } ?: return
        ideaResearchJobs[ideaId]?.cancel()
        ideaResearchJobs[ideaId] = viewModelScope.launch {
            val liveContext = buildCurrentLiveAiContext()
            RrkAiAssistant.streamIdeaFeasibility(
                idea = targetIdea,
                liveContext = liveContext
            ).collect { state ->
                _ideaResearchStates.update { current ->
                    current + (ideaId to state)
                }
            }
        }
    }

    fun clearIdeaResearch(ideaId: Int) {
        ideaResearchJobs[ideaId]?.cancel()
        ideaResearchJobs.remove(ideaId)
        _ideaResearchStates.update { current ->
            current - ideaId
        }
    }

    fun addExitedMember(name: String, phone: String, resignationDate: String, lossShareAmount: Int, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addExitedMember(ExitedMember(name = name.trim(), phone = phone.trim(), resignationDate = resignationDate.trim(), lossShareAmount = lossShareAmount, notes = notes.trim()))
            _toastEvent.emit("Exited member recorded! ✅")
        }
    }

    fun updateExitedMember(member: ExitedMember) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateExitedMember(member)
            _toastEvent.emit("Exited member updated! ✅")
        }
    }

    fun deleteExitedMember(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteExitedMember(id)
            _toastEvent.emit("Exited member removed")
        }
    }

    fun addCustomPage(title: String, iconName: String, coverImageUrl: String, content: String, isVisible: Boolean, displayOrder: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val finalCover = if (coverImageUrl.startsWith("data:")) {
                val cloudUrl = firebaseRepository.uploadDataUri(
                    coverImageUrl,
                    "custom_pages",
                    "page_${System.currentTimeMillis()}.jpg"
                )
                cloudUrl ?: coverImageUrl
            } else {
                coverImageUrl
            }
            repository.addCustomPage(CustomPage(title = title.trim(), iconName = iconName.trim(), coverImageUrl = finalCover.trim(), content = content.trim(), isVisible = isVisible, displayOrder = displayOrder))
            _toastEvent.emit("Custom page created! ✅")
        }
    }

    fun updateCustomPage(page: CustomPage) {
        viewModelScope.launch(Dispatchers.IO) {
            val finalCover = if (page.coverImageUrl.startsWith("data:")) {
                val cloudUrl = firebaseRepository.uploadDataUri(
                    page.coverImageUrl,
                    "custom_pages",
                    "page_${page.id}_${System.currentTimeMillis()}.jpg"
                )
                cloudUrl ?: page.coverImageUrl
            } else {
                page.coverImageUrl
            }
            repository.updateCustomPage(page.copy(coverImageUrl = finalCover))
            _toastEvent.emit("Custom page updated! ✅")
        }
    }

    fun deleteCustomPage(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCustomPage(id)
            _toastEvent.emit("Custom page deleted")
        }
    }
}
