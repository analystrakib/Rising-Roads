package com.example.util

import android.util.Log

/**
 * Safe configuration utility for accessing environment variables and API keys
 * without crashing if BuildConfig fields are missing, empty, or uninitialized.
 */
object EnvConfig {
    private const val TAG = "EnvConfig"

    /**
     * Safely retrieves GEMINI_API_KEY from BuildConfig or environment without throwing
     * NoSuchFieldError, ClassNotFoundException, or NullPointerException.
     * Treats placeholder values as empty.
     */
    val geminiApiKey: String
        get() = try {
            val clazz = Class.forName("com.example.BuildConfig")
            val field = clazz.getField("GEMINI_API_KEY")
            val raw = (field.get(null) as? String)?.trim() ?: ""
            if (raw == "placeholder" || raw == "MY_GEMINI_API_KEY") "" else raw
        } catch (e: NoSuchFieldException) {
            Log.d(TAG, "GEMINI_API_KEY field not found in BuildConfig (optional feature)")
            ""
        } catch (t: Throwable) {
            Log.w(TAG, "Could not read GEMINI_API_KEY: ${t.message}")
            ""
        }

    /**
     * Returns true if a valid non-empty Gemini API key is configured.
     */
    fun isGeminiConfigured(): Boolean = geminiApiKey.isNotBlank()

    /**
     * Safely retrieves any generic String field from BuildConfig with fallback.
     */
    fun getSecret(key: String, defaultValue: String = ""): String = try {
        val clazz = Class.forName("com.example.BuildConfig")
        val field = clazz.getField(key)
        val raw = (field.get(null) as? String)?.trim()
        if (raw.isNullOrEmpty() || raw == "placeholder") defaultValue else raw
    } catch (t: Throwable) {
        defaultValue
    }
}
