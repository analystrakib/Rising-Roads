const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const path = require("node:path");
const firebaseCompatPath = path.dirname(
  require.resolve("@firebase/rules-unit-testing")
);
const firebase = require(
  require.resolve("firebase/compat/app", { paths: [firebaseCompatPath] })
);
require(
  require.resolve("firebase/compat/firestore", { paths: [firebaseCompatPath] })
);
const serverTimestamp = () => firebase.firestore.FieldValue.serverTimestamp();
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validMemberPayload(userId, memberNumber = 1) {
  return {
    userId,
    memberNumber,
    name: "Mohsin Ali",
    phone: "01773-313693",
    email: "mohsin@risingroads.org",
    role: "Founding Partner",
    joinDate: "2025-05-01",
    address: "Kharkharian",
    nomineeName: "Ayesha Begum",
    bio: "Founding investor & community advisor.",
    shareUnits: 1,
    committedMonthly: 1000,
    totalInvested: 18000,
    totalFinesPaid: 300,
    totalDue: 0,
    paidMonthsCount: 18,
    status: "ACTIVE",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

function validWorkspacePayload(userId) {
  return {
    userId,
    displayName: "Alice",
    email: "alice@example.com",
    membersSeeded: true,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or list members", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("members").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("members").doc("member_01").get()
  );
});

test("Unauthenticated user: cannot write member", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("members")
      .doc("member_01")
      .set(validMemberPayload(ALICE_UID, 1))
  );
});

test("Authenticated user: can create and read own workspace & members", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validWorkspacePayload(ALICE_UID))
  );
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("members")
      .doc("member_01")
      .set(validMemberPayload(ALICE_UID, 1))
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("members").get()
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("members").doc("member_01").get()
  );
});

test("Authenticated user: can update allowed profile fields preserving immutables", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const memberRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("members")
    .doc("member_01");

  await assertSucceeds(memberRef.set(validMemberPayload(ALICE_UID, 1)));
  await assertSucceeds(
    memberRef.update({
      role: "Treasury Lead",
      shareUnits: 2,
      bio: "Updated bio note",
      photoUri: "https://example.com/avatar.jpg",
      updatedAt: serverTimestamp(),
    })
  );
});

test("Cross-user isolation: Bob cannot read, list, create, update, or delete Alice's members", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("members")
      .doc("member_01")
      .set(validMemberPayload(ALICE_UID, 1))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const aliceMemberRef = bobDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("members")
    .doc("member_01");

  await assertFails(aliceMemberRef.get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("members").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("members")
      .doc("member_02")
      .set(validMemberPayload(BOB_UID, 2))
  );
  await assertFails(
    aliceMemberRef.update({ name: "Hacked", updatedAt: serverTimestamp() })
  );
  await assertFails(aliceMemberRef.delete());
});

test("Adversarial: rejects ghost field, identity spoofing, invalid status, and immutable field tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const colRef = aliceDb.collection("users").doc(ALICE_UID).collection("members");

  // Ghost field
  await assertFails(
    colRef.doc("member_ghost").set({
      ...validMemberPayload(ALICE_UID, 1),
      isAdmin: true,
    })
  );

  // Identity spoofing
  await assertFails(
    colRef.doc("member_spoof").set(validMemberPayload(BOB_UID, 1))
  );

  // Invalid status enum
  await assertFails(
    colRef.doc("member_bad_status").set({
      ...validMemberPayload(ALICE_UID, 1),
      status: "SUSPENDED",
    })
  );

  // Immutable memberNumber tampering on update
  await assertSucceeds(colRef.doc("member_01").set(validMemberPayload(ALICE_UID, 1)));
  await assertFails(
    colRef.doc("member_01").update({
      memberNumber: 99,
      updatedAt: serverTimestamp(),
    })
  );
});
