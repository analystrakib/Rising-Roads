package com.example.data.model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

/**
 * Room Entity representing a founding member/investor of Rising Roads of Kharkharian.
 * Used to track the 11 active founding members and their investment profile.
 */
@Entity(tableName = "members")
data class Member(
    @PrimaryKey val id: Int = 0,
    val name: String = "",
    val phone: String = "",
    val joinDate: String = "2025-05-01",
    val address: String = "Kharkharian",
    val photoUri: String? = null
)

/**
 * Room Entity representing an investor's capital contribution (monthly ৳1000 contribution).
 * Foreign key relationship linking directly to Member via memberId.
 */
@Entity(
    tableName = "deposits",
    indices = [
        Index(value = ["memberId"]),
        Index(value = ["month"])
    ]
)
data class Deposit(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val memberId: Int = 0,
    val month: String = "", // e.g. "May 2025", "Mar 2026", "Oct 2026"
    val paymentDate: String = "", // e.g. "2026-03-10"
    val amount: Int = 1000,
    val fine: Int = 0,
    val paymentMode: String = "Cash", // Cash, Bank
    val inputTimestamp: Long = System.currentTimeMillis()
)

/**
 * Typealias for Deposit to represent CapitalContribution interchangeably throughout the system.
 */
typealias CapitalContribution = Deposit

/**
 * Room 1-to-many relationship class pairing a Member (investor) with all of their
 * capital contributions (deposits).
 */
data class MemberWithCapitalContributions(
    @Embedded val member: Member,
    @Relation(
        parentColumn = "id",
        entityColumn = "memberId"
    )
    val contributions: List<Deposit>
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String = "",
    val category: String = "Miscellaneous", // Agro, Admin, Bank Charge, Office Expenses, Transport, Marketing, Emergency, Miscellaneous
    val quantity: String = "",
    val amount: Int = 0,
    val date: String = "",
    val paidBy: String = "Finance Dept", // Finance Dept, Bank Auto Trnx
    val remarks: String = "",
    val recordedBy: String = "admin"
)

@Entity(tableName = "investments")
data class Investment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "",
    val type: String = "Agro", // Agro, Stock/Commodities, Retail, Other
    val amount: Int = 0, // Initial Cost / Capital
    val purchasedQuantity: String = "", // e.g., "6 Goats", "150 kg Cumin"
    val saleDate: String = "",
    val soldQuantity: String = "",
    val saleRevenue: Int = 0,
    val expenses: Int = 0,
    val profitLoss: Int = 0, // Net Profit/Loss
    val activeCapital: Int = 0, // Active Running Capital
    val status: String = "RUNNING", // RUNNING, CLOSED
    val date: String = "",
    val supervisor: String = "", // e.g., Rupok / Jalil Mom
    val stockStatus: String = "In Stock", // In Stock, Partial, Sold Out
    val description: String = "",
    val photoUri: String = "",
    val paymentSource: String = "Cash", // "Cash" or "Bank"
    val returnSource: String = "" // "Cash" or "Bank" (defaults to paymentSource when blank)
)

/**
 * Member Settlement & Return Ledger (Return System):
 * When a member resigns or withdraws:
 * Net Return Amount = Total Deposit Paid - (Stamp/Typing Legal Charge + Shared Losses).
 * Track Settlement Status: 'Done' / 'Pending'.
 */
@Entity(tableName = "member_settlements")
data class MemberSettlement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val memberId: Int = 0,
    val memberName: String = "",
    val resignationDate: String = "",
    val totalDepositPaid: Int = 0,
    val legalCharge: Int = 0, // Stamp/Typing Legal Charge
    val sharedLosses: Int = 0,
    val netReturnAmount: Int = 0, // TotalDepositPaid - (LegalCharge + SharedLosses)
    val settlementStatus: String = "Pending", // Done, Pending
    val paymentMode: String = "Cash", // Cash, Bank Transfer
    val notes: String = ""
)

@Entity(tableName = "admin_users")
data class AdminUser(
    @PrimaryKey val username: String = "",
    val password: String = "",
    val role: String = "Admin", // Super Admin, Admin, Moderator, Viewer
    val addedBy: String = "System",
    val addedAt: String = "2025-05-01"
)

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String = "",
    val message: String = "",
    val username: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_config")
data class AppConfig(
    @PrimaryKey val key: String = "",
    val value: String = ""
)

enum class MemberStatus {
    ACTIVE,
    WARNING,
    RED_ALERT
}

data class MemberWithStats(
    val member: Member,
    val paidMonths: List<String>,
    val pendingMonths: List<String>,
    val consecutiveUnpaidMonths: Int,
    val totalPaidContribution: Int,
    val totalFinePaid: Int,
    val totalDue: Int,
    val status: MemberStatus,
    val lastPaymentDate: String?,
    val effectiveOverdueMonths: Int = 0,
    val accruedFineDue: Int = 0,
    val settledFineMonths: Int = 0
)

data class FinancialKpi(
    val totalCollection: Int = 0,
    val totalDeposits: Int = 0,
    val fineCollection: Int = 0,
    val totalExpenses: Int = 0,
    val totalInvestments: Int = 0,
    val totalRunningInvestments: Int = 0,
    val totalClosedInvestments: Int = 0,
    val totalOngoingInvestments: Int = 0,
    val grossBusinessPnl: Int = -600,
    val exitedMembersLossRecovery: Int = 42,
    val realizedBusinessPnl: Int = 0,
    val totalInvestmentNetProfit: Int = 0,
    val totalReturnSettlements: Int = 0,
    val bankBalance: Int = 0,
    val cashInHand: Int = 0,
    val mainLiquidCapital: Int = 0,
    val totalDue: Int = 0,
    val reservedAmount: Int = 0
) {
    // Backward compatibility getters for existing UI
    val grossCollections: Int get() = totalDeposits + fineCollection
    val costAndInvest: Int get() = totalExpenses + totalRunningInvestments + totalReturnSettlements
    val mainCapital: Int get() = mainLiquidCapital
    val totalProfitLoss: Int get() = realizedBusinessPnl
    val netBusinessProfitLoss: Int get() = grossBusinessPnl + exitedMembersLossRecovery
    val formattedNetBusinessPL: String get() = com.example.util.CurrencyFormatter.formatCurrency(netBusinessProfitLoss)
    val activeMembersCount: Int get() = 11
    val exitedMembersCount: Int get() = 3
}

@Entity(tableName = "member_accounts")
data class MemberAccount(
    @PrimaryKey val rrkMemberId: String,
    val fullName: String,
    val contact: String,
    val normalizedContact: String,
    val passwordHash: String,
    val role: String = "Member",
    val createdAt: Long = System.currentTimeMillis()
)

data class MemberSessionState(
    val isLoggedIn: Boolean = false,
    val rrkMemberId: String = "",
    val fullName: String = "",
    val contact: String = "",
    val role: String = "Member"
)

data class RememberedUserSession(
    val rrkMemberId: String = "",
    val fullName: String = "",
    val contact: String = "",
    val role: String = "Member",
    val pinHash: String = ""
) {
    val isValid: Boolean get() = rrkMemberId.isNotBlank() && fullName.isNotBlank()
    val hasPin: Boolean get() = pinHash.isNotBlank()
}

@Entity(tableName = "member_ideas")
data class MemberIdea(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // Agro, Trade, Tech, Service, Other
    val businessType: String = "Product", // "Product" or "Service"
    val estimatedBudget: Long = 0L,
    val description: String,
    val authorId: String,
    val authorName: String,
    val authorRole: String = "Member",
    val createdAt: Long = System.currentTimeMillis(),
    val likedByUserIds: String = "",
    val dislikedByUserIds: String = ""
) {
    fun likedUsersSet(): Set<String> =
        likedByUserIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun dislikedUsersSet(): Set<String> =
        dislikedByUserIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun likeCount(): Int = likedUsersSet().size

    fun dislikeCount(): Int = dislikedUsersSet().size

    fun isLikedBy(userKey: String): Boolean =
        userKey.isNotBlank() && likedUsersSet().contains(userKey)

    fun isDislikedBy(userKey: String): Boolean =
        userKey.isNotBlank() && dislikedUsersSet().contains(userKey)
}

@Entity(
    tableName = "idea_comments",
    indices = [Index(value = ["ideaId"])]
)
data class IdeaComment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ideaId: Int,
    val authorId: String,
    val authorName: String,
    val authorRole: String = "Member",
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class MemberIdeaWithComments(
    val idea: MemberIdea,
    val comments: List<IdeaComment>
)

@Entity(
    tableName = "payment_requests",
    indices = [
        Index(value = ["memberId"]),
        Index(value = ["status"])
    ]
)
data class PaymentRequest(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val memberId: Int,
    val memberName: String,
    val month: String,
    val paymentMethod: String, // "bKash", "Nagad", "Bank", "Cash"
    val amount: Int = 1000,
    val fine: Int = 0,
    val trxId: String,
    val paymentDate: String,
    val notes: String = "",
    val status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val createdAt: Long = System.currentTimeMillis(),
    val reviewedAt: Long? = null,
    val reviewedBy: String = "",
    val approvedDepositId: Int? = null,
    val rejectionReason: String = ""
)

data class OfficialPaymentAccounts(
    val bkash: String = DEFAULT_BKASH,
    val nagad: String = DEFAULT_NAGAD,
    val bank: String = DEFAULT_BANK
) {
    companion object {
        const val DEFAULT_BKASH = "01792-430077 (Personal · Send Money)"
        const val DEFAULT_NAGAD = "01792-430077 (Personal · Send Money)"
        const val DEFAULT_BANK = "Islami Bank Bangladesh PLC · A/C: 2050-3100-2004-812 · Kharkharian Br."
    }
}

data class AdminAlertEmailSettings(
    val adminAlertEmail: String = DEFAULT_ADMIN_EMAIL,
    val emailJsServiceId: String = "",
    val emailJsTemplateId: String = "",
    val emailJsPublicKey: String = ""
) {
    val isEmailJsConfigured: Boolean
        get() = emailJsServiceId.isNotBlank() &&
            emailJsTemplateId.isNotBlank() &&
            emailJsPublicKey.isNotBlank()

    companion object {
        const val DEFAULT_ADMIN_EMAIL = "rakibother01@gmail.com"
    }
}

data class MemberDueReminder(
    val id: String,
    val dayOfMonth: Int, // 1, 8, or 14
    val stageLabel: String,
    val memberId: Int,
    val memberName: String,
    val rrkId: String,
    val billingMonth: String,
    val capitalDue: Int,
    val accruedFine: Int,
    val totalPayable: Int,
    val message: String,
    val isTestPreview: Boolean = false
)

@Entity(tableName = "exited_members")
data class ExitedMember(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "",
    val phone: String = "",
    val resignationDate: String = "",
    val lossShareAmount: Int = 14, // ৳14 per person (3 exited members total ৳42)
    val notes: String = ""
)

@Entity(tableName = "custom_pages")
data class CustomPage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String = "",
    val iconName: String = "Article",
    val coverImageUrl: String = "",
    val content: String = "",
    val isVisible: Boolean = true,
    val displayOrder: Int = 0
)



