package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithStats
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.MainViewModel
import com.example.ui.components.AppCardBorder
import com.example.ui.components.AppCardElevation
import com.example.ui.components.AppCardShape
import com.example.ui.components.AppInputShape
import com.example.ui.components.MemberAvatar
import com.example.ui.components.StatusBadge
import com.example.ui.components.appInputTextStyle
import com.example.ui.components.appOutlinedTextFieldColors
import com.example.ui.components.appSolidButtonColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NagadBorder
import com.example.ui.theme.NagadDanger
import com.example.ui.theme.NagadLightBg
import com.example.ui.theme.NagadMainText
import com.example.ui.theme.NagadPrimary
import com.example.ui.theme.NagadSecondaryText
import com.example.ui.theme.NagadVeryLightBg
import com.example.ui.theme.NagadWhite
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.TABULAR_NUMBERS
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembersScreen(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit
) {
    val context = LocalContext.current
    val membersWithStats by viewModel.membersWithStats.collectAsStateWithLifecycle()
    val adminUsername by viewModel.adminUsername.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("All") }
    var isTableView by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredMembers = remember(membersWithStats, searchQuery, selectedStatusFilter) {
        membersWithStats.filter { stats ->
            val query = searchQuery.trim().lowercase()
            val formattedCode = "rrk-${stats.member.id.toString().padStart(3, '0')}"
            val matchesQuery = query.isEmpty() ||
                stats.member.name.lowercase().contains(query) ||
                stats.member.phone.lowercase().contains(query) ||
                stats.member.address.lowercase().contains(query) ||
                formattedCode.contains(query)

            val matchesStatus = when (selectedStatusFilter) {
                "Active" -> stats.status == MemberStatus.ACTIVE
                "Warning" -> stats.status == MemberStatus.WARNING
                "RED ALERT" -> stats.status == MemberStatus.RED_ALERT
                else -> true
            }
            matchesQuery && matchesStatus
        }
    }

    val totalInvested = remember(membersWithStats) {
        membersWithStats.sumOf { it.totalPaidContribution }
    }
    val totalDue = remember(membersWithStats) {
        membersWithStats.sumOf { it.totalDue }
    }
    val activeCount = remember(membersWithStats) {
        membersWithStats.count { it.status == MemberStatus.ACTIVE }
    }
    val alertCount = remember(membersWithStats) {
        membersWithStats.count { it.status == MemberStatus.RED_ALERT }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("members_screen")
            .padding(start = 16.dp, top = 12.dp, end = 16.dp)
    ) {
        // Top Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Investment Members",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = NagadMainText
                )
                Text(
                    text = "${membersWithStats.size} Members · ৳1,000/mo Contribution",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 11.5.sp,
                    color = NagadPrimary,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.refreshData() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh members",
                        tint = NagadPrimary
                    )
                }

                IconButton(onClick = { isTableView = !isTableView }) {
                    Icon(
                        imageVector = if (isTableView) Icons.Default.GridView else Icons.Default.List,
                        contentDescription = "Switch view",
                        tint = NagadPrimary
                    )
                }

                if (isAdmin) {
                    Button(
                        onClick = { showAddDialog = true },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("add_member_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Add",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Summary Strip (Equal 2-Column 50/50 Width & Equal Height Grid)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Max),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DirectorySummaryPill(
                label = "MEMBERS",
                value = "${membersWithStats.size} Total",
                sub = "$activeCount Active · $alertCount Alert",
                valueColor = NagadPrimary,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
            DirectorySummaryPill(
                label = "CAPITAL POOLED",
                value = "৳${formatMemberNumber(totalInvested)}",
                sub = "৳${formatMemberNumber(totalDue)} Total Due",
                valueColor = NagadMainText,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = {
                    val pdfFile = PdfReceiptGenerator.generateAllMembersSummaryPdf(
                        context = context,
                        membersWithStats = membersWithStats,
                        adminName = adminUsername
                    )
                    PdfReceiptGenerator.sharePdf(context, pdfFile, "Download All Members Summary (.pdf)")
                },
                enabled = membersWithStats.isNotEmpty(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.45f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = NagadWhite,
                    contentColor = NagadPrimary
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("all_members_summary_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = null,
                    tint = NagadPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "All Members Summary (PDF)",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = NagadPrimary,
                    maxLines = 1
                )
            }

            OutlinedButton(
                onClick = {
                    val pdfFile = PdfReceiptGenerator.generateAllMembersSummaryPdf(
                        context = context,
                        membersWithStats = membersWithStats,
                        adminName = adminUsername
                    )
                    PdfReceiptGenerator.printPdf(context, pdfFile, "RRK_All_Members_Summary")
                },
                enabled = membersWithStats.isNotEmpty(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.45f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = NagadWhite,
                    contentColor = NagadPrimary
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .height(44.dp)
                    .testTag("print_all_members_summary_pdf_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Print,
                    contentDescription = "Print All Members Summary PDF",
                    tint = NagadPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Print",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = NagadPrimary,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("member_search_input"),
            placeholder = {
                Text(
                    "Search by name, phone, address or RRK ID...",
                    color = NagadSecondaryText,
                    fontFamily = InterFontFamily,
                    fontSize = 13.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search members",
                    tint = NagadPrimary
                )
            },
            singleLine = true,
            textStyle = appInputTextStyle(13.5.sp),
            shape = AppInputShape,
            colors = appOutlinedTextFieldColors()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Status Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Active", "Warning", "RED ALERT").forEach { filter ->
                val count = when (filter) {
                    "Active" -> membersWithStats.count { it.status == MemberStatus.ACTIVE }
                    "Warning" -> membersWithStats.count { it.status == MemberStatus.WARNING }
                    "RED ALERT" -> membersWithStats.count { it.status == MemberStatus.RED_ALERT }
                    else -> membersWithStats.size
                }
                FilterChip(
                    selected = selectedStatusFilter == filter,
                    onClick = { selectedStatusFilter = filter },
                    label = {
                        Text(
                            text = "$filter ($count)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = PoppinsFontFamily,
                            color = if (selectedStatusFilter == filter) NagadPrimary else NagadSecondaryText
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NagadLightBg,
                        containerColor = NagadWhite
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedStatusFilter == filter,
                        selectedBorderColor = NagadPrimary,
                        borderColor = NagadBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.refreshData() },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (filteredMembers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No investment members match your filter",
                        fontFamily = PoppinsFontFamily,
                        color = NagadSecondaryText
                    )
                }
            } else if (isTableView) {
                Card(
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = NagadWhite),
                    border = AppCardBorder,
                    elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                    modifier = Modifier.fillMaxSize()
                ) {
                    val hScrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(hScrollState)
                    ) {
                        Row(
                            modifier = Modifier
                                .background(NagadLightBg)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ID", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(78.dp))
                            Text("NAME", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(160.dp))
                            Text("PHONE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(120.dp))
                            Text("INVESTED", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(105.dp))
                            Text("FINES", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(75.dp))
                            Text("DUE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(85.dp))
                            Text("STATUS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(110.dp))
                            Text("PROFILE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NagadSecondaryText, fontFamily = InterFontFamily, modifier = Modifier.width(80.dp))
                        }
                        HorizontalDivider(color = NagadBorder)

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(bottom = 120.dp)
                        ) {
                            items(filteredMembers, key = { it.member.id }) { stats ->
                                val code = "RRK-${stats.member.id.toString().padStart(3, '0')}"
                                Row(
                                    modifier = Modifier
                                        .clickable { onNavigateToMemberProfile(stats.member.id) }
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(code, style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 12.sp, color = NagadSecondaryText, modifier = Modifier.width(78.dp))
                                    Text(stats.member.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NagadPrimary, fontFamily = InterFontFamily, modifier = Modifier.width(160.dp))
                                    Text(stats.member.phone, style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 12.sp, color = NagadMainText, modifier = Modifier.width(120.dp))
                                    Text("৳${formatMemberNumber(stats.totalPaidContribution)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NagadPrimary, modifier = Modifier.width(105.dp))
                                    Text("৳${formatMemberNumber(stats.totalFinePaid)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 12.sp, color = NagadMainText, modifier = Modifier.width(75.dp))
                                    Text("৳${formatMemberNumber(stats.totalDue)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (stats.totalDue > 0) NagadDanger else NagadPrimary, modifier = Modifier.width(85.dp))
                                    Box(modifier = Modifier.width(110.dp)) {
                                        StatusBadge(status = stats.status)
                                    }
                                    Box(modifier = Modifier.width(80.dp)) {
                                        TextButton(onClick = { onNavigateToMemberProfile(stats.member.id) }) {
                                            Text("Open", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = NagadPrimary, fontFamily = PoppinsFontFamily)
                                        }
                                    }
                                }
                                HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    items(filteredMembers, key = { it.member.id }) { stats ->
                        MemberDirectoryCard(
                            stats = stats,
                            onClick = { onNavigateToMemberProfile(stats.member.id) }
                        )
                    }
                }
            }
        }
    }

    if (isAdmin && showAddDialog) {
        AddMemberDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, phone, joinDate, address ->
                viewModel.addMember(name = name, phone = phone, joinDate = joinDate, address = address)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun DirectorySummaryPill(
    label: String,
    value: String,
    sub: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                fontFamily = InterFontFamily,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = NagadSecondaryText
            )
            Text(
                text = value,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = sub,
                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                color = NagadSecondaryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MemberDirectoryCard(
    stats: MemberWithStats,
    onClick: () -> Unit
) {
    val member = stats.member
    val code = "RRK-${member.id.toString().padStart(3, '0')}"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("member_card_${member.id}"),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MemberAvatar(
                        name = member.name,
                        id = member.id,
                        size = 48,
                        photoUri = member.photoUri
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = member.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = NagadMainText,
                            fontFamily = InterFontFamily
                        )
                        Text(
                            text = "$code · Joined ${member.joinDate}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = NagadPrimary,
                            fontFamily = InterFontFamily
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = NagadSecondaryText
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${member.phone} · ${member.address}",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp,
                                color = NagadSecondaryText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                StatusBadge(status = stats.status)
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = NagadBorder, thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Invested", fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, fontFamily = InterFontFamily)
                    Text("৳${formatMemberNumber(stats.totalPaidContribution)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NagadPrimary)
                }
                Column {
                    Text("Fines Paid", fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, fontFamily = InterFontFamily)
                    Text("৳${formatMemberNumber(stats.totalFinePaid)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NagadMainText)
                }
                Column {
                    Text("Due", fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, fontFamily = InterFontFamily)
                    Text("৳${formatMemberNumber(stats.totalDue)}", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (stats.totalDue > 0) NagadDanger else NagadPrimary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Cycles", fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, fontFamily = InterFontFamily)
                    Text("${stats.paidMonths.size} mos", style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NagadPrimary)
                }
            }
        }
    }
}

@Composable
private fun AddMemberDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String, joinDate: String, address: String) -> Unit
) {
    val today = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var joinDate by remember { mutableStateOf(today) }
    var address by remember { mutableStateOf("Kharkharian") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NagadWhite,
        title = {
            Text(
                text = "Add Investment Member",
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                color = NagadMainText
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number *", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = joinDate,
                    onValueChange = { joinDate = it },
                    label = { Text("Join Date (YYYY-MM-DD)", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address", fontFamily = InterFontFamily) },
                    singleLine = true,
                    textStyle = appInputTextStyle(),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        name.trim(),
                        phone.trim(),
                        joinDate.trim().ifBlank { today },
                        address.trim().ifBlank { "Kharkharian" }
                    )
                },
                enabled = name.isNotBlank() && phone.isNotBlank(),
                colors = appSolidButtonColors(NagadPrimary),
                modifier = Modifier.height(48.dp)
            ) {
                Text(
                    text = "Add Member",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
            }
        }
    )
}

private fun formatMemberNumber(amount: Int): String {
    return CurrencyFormatter.formatNumber(amount)
}
