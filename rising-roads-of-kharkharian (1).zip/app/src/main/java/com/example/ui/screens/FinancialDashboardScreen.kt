package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import com.example.ai.AiTaskState
import com.example.data.repository.AppRepository
import com.example.pdf.PdfReceiptGenerator
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter

@Composable
fun FinancialDashboardScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val kpi by viewModel.financialKpi.collectAsState()
    val deposits by viewModel.deposits.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val aiSummaryState by viewModel.financialSummaryState.collectAsState()

    var showBalanceDialog by remember { mutableStateOf(false) }

    // Trend points from deposits
    val trendPoints = remember(deposits) {
        val activeMonths = AppRepository.getActiveMonths().takeLast(6)
        activeMonths.map { month ->
            val total = deposits.filter { it.month == month }.sumOf { it.amount + it.fine }.toFloat()
            Pair(month.split(" ").firstOrNull() ?: month, total)
        }
    }

    val capitalEfficiency = remember(kpi) {
        if (kpi.totalCollection > 0) {
            ((kpi.mainCapital.coerceAtLeast(0).toFloat() / kpi.totalCollection) * 100).toInt()
        } else 0
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("financial_dashboard_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Financial Dashboard",
                        style = TextStyle(
                            fontFamily = PoppinsFontFamily,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        ),
                        maxLines = 1
                    )
                    Text(
                        text = "Real-time capital & balance tracking",
                        style = TextStyle(
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText
                        ),
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            val pdfFile = PdfReceiptGenerator.generateFinancialSummaryReport(
                                context = context,
                                kpi = kpi,
                                membersCount = membersWithStats.size,
                                expensesCount = expenses.size,
                                investmentsCount = investments.size,
                                adminName = adminUsername
                            )
                            PdfReceiptGenerator.sharePdf(context, pdfFile, "Complete Financial Summary Report")
                        },
                        colors = appSolidButtonColors(NagadPrimary),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier.height(34.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Summary PDF", fontSize = 10.5.sp, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = InterFontFamily, maxLines = 1)
                    }

                    if (isAdmin) {
                        OutlinedButton(
                            onClick = { showBalanceDialog = true },
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp),
                            modifier = Modifier.height(34.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NagadMainText),
                            border = BorderStroke(1.dp, InputBorder)
                        ) {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(12.dp), tint = NagadMainText)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Balances", fontSize = 10.5.sp, color = NagadMainText, fontWeight = FontWeight.Medium, fontFamily = InterFontFamily, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            val pdfFile = PdfReceiptGenerator.generateAllMembersSummaryPdf(
                                context = context,
                                membersWithStats = membersWithStats,
                                adminName = adminUsername
                            )
                            PdfReceiptGenerator.sharePdf(context, pdfFile, "Download All Members Summary (.pdf)")
                        },
                        enabled = membersWithStats.isNotEmpty(),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("financial_all_members_pdf_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = NagadWhite,
                            contentColor = NagadPrimary
                        ),
                        border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = NagadPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "All Members Summary (PDF)",
                            fontSize = 10.5.sp,
                            color = NagadPrimary,
                            fontWeight = FontWeight.Bold,
                            fontFamily = InterFontFamily,
                            maxLines = 1
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            val pdfFile = PdfReceiptGenerator.generateFinancialSummaryReport(
                                context = context,
                                kpi = kpi,
                                membersCount = membersWithStats.size,
                                expensesCount = expenses.size,
                                investmentsCount = investments.size,
                                adminName = adminUsername
                            )
                            PdfReceiptGenerator.printPdf(context, pdfFile, "RRK_Fund_Financial_Summary")
                        },
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("financial_print_summary_pdf_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = NagadWhite,
                            contentColor = NagadPrimary
                        ),
                        border = BorderStroke(1.dp, NagadPrimary.copy(alpha = 0.4f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Print Financial Summary PDF",
                            modifier = Modifier.size(12.dp),
                            tint = NagadPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Print",
                            fontSize = 10.5.sp,
                            color = NagadPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = InterFontFamily,
                            maxLines = 1
                        )
                    }
                }

                AiSummaryButton(
                    isLoading = aiSummaryState is AiTaskState.Loading || aiSummaryState is AiTaskState.Streaming,
                    onClick = { viewModel.generateFinancialAiSummary() }
                )
            }
        }

        if (aiSummaryState !is AiTaskState.Idle) {
            item {
                AiSummaryPanel(
                    title = "Financial AI Executive Summary",
                    state = aiSummaryState,
                    onDismiss = { viewModel.clearFinancialAiSummary() },
                    onRetry = { viewModel.generateFinancialAiSummary() }
                )
            }
        }

        // 9 KPI Cards (Grid of 3 rows x 3 columns)
        item {
            Text(
                text = "Key Financial Performance Indicators",
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = NagadMainText,
                fontFamily = PoppinsFontFamily
            )
        }

        // 2-Column Grid of KPI Cards (grid-cols-2 gap-2.5)
        item {
            val runningInv = kpi.totalRunningInvestments
            val pastInv = kpi.totalClosedInvestments
            val runningCount = remember(investments) { investments.count { it.status.equals("Running", true) || it.status.equals("Active", true) } }
            val pnlVal = kpi.realizedBusinessPnl
            val pnlColor = if (pnlVal < 0) NagadDanger else if (pnlVal > 0) NagadPrimary else NagadSecondaryText
            val pnlDisplay = CurrencyFormatter.formatSignedCurrency(pnlVal)
            val grossStr = CurrencyFormatter.formatSignedCurrency(kpi.grossBusinessPnl)

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: Collection & Expenses
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Total Collection",
                        value = CurrencyFormatter.formatCurrency(kpi.totalDeposits),
                        valueColor = NagadPrimary,
                        subtitle = "Pure member deposits (excl. fines)",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Total Expenses",
                        value = CurrencyFormatter.formatCurrency(kpi.totalExpenses),
                        subtitle = "${expenses.size} expense entries",
                        titleFontSize = 11.sp,
                        valueColor = NagadDanger,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }

                // Row 2: Main Capital & Total Invested
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Main Capital",
                        value = CurrencyFormatter.formatCurrency(kpi.mainCapital.coerceAtLeast(0)),
                        valueColor = NagadPrimary,
                        subtitle = "Deposits + Fines - Expenses ± P/L",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Total Invested",
                        value = CurrencyFormatter.formatCurrency(kpi.totalInvestments),
                        valueColor = NagadPrimary,
                        subtitle = "Active: ${CurrencyFormatter.formatCurrency(runningInv)} | Closed: ${CurrencyFormatter.formatCurrency(pastInv)}",
                        titleFontSize = 11.sp,
                        subtitleFontSize = 10.5.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }

                // Row 3: Bank Balance & Cash In Hand
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Bank Balance",
                        value = CurrencyFormatter.formatCurrency(kpi.bankBalance),
                        valueColor = NagadMainText,
                        subtitle = "Corporate bank account",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Cash In Hand",
                        value = CurrencyFormatter.formatCurrency(kpi.cashInHand),
                        valueColor = NagadPrimary,
                        subtitle = "Vault cash balance",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }

                // Row 4: Fine Collection & Total Due
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Fine Collection",
                        value = CurrencyFormatter.formatCurrency(kpi.fineCollection),
                        valueColor = NagadWarning,
                        subtitle = "Official late fines",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Total Due",
                        value = CurrencyFormatter.formatCurrency(kpi.totalDue),
                        subtitle = "Outstanding receivables",
                        titleFontSize = 11.sp,
                        valueColor = if (kpi.totalDue > 0) NagadDanger else NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }

                // Row 5: Business P&L & Running Projects
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Business P&L",
                        value = pnlDisplay,
                        subtitle = "Gross $grossStr + ${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)} exited loss share",
                        titleFontSize = 11.sp,
                        subtitleFontSize = 10.5.sp,
                        valueColor = pnlColor,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                    StatCard(
                        title = "Running Projects",
                        value = "$runningCount Active",
                        valueColor = NagadPrimary,
                        subtitle = "Ongoing trade cycles",
                        titleFontSize = 11.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 104.dp)
                    )
                }
            }
        }

        // Running Investments Summary Card
        item {
            val runningInvestments = remember(investments) {
                investments.filter { it.status.equals("Active", true) || it.status.equals("Running", true) }
            }
            val totalRunningCapital = runningInvestments.sumOf { if (it.activeCapital > 0) it.activeCapital else it.amount }

            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Running Investments", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NagadMainText, fontFamily = InterFontFamily)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = NagadLightBg,
                            modifier = Modifier.wrapContentWidth()
                        ) {
                            Text(
                                text = "${runningInvestments.size} Active",
                                color = NagadPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Total Running Capital Deployed: ${CurrencyFormatter.formatCurrency(totalRunningCapital)}",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadPrimary,
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (runningInvestments.isEmpty()) {
                            "All ${investments.size} historical commercial trade cycles are closed & settled."
                        } else {
                            "${runningInvestments.size} active investment(s) currently deployed from fund capital."
                        },
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        fontFamily = InterFontFamily
                    )
                }
            }
        }

        // Capital Breakdown Calculation Card
        item {
            val grossStr = CurrencyFormatter.formatSignedCurrency(kpi.grossBusinessPnl)
            val netPnlStr = CurrencyFormatter.formatSignedCurrency(kpi.realizedBusinessPnl)
            val depositQty = deposits.size.takeIf { it > 0 } ?: 179

            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Master Receipt & Cash/Bank Reconciliation",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NagadMainText
                    )
                    Text(
                        text = "Official November 2026 Head Office reconciliation formula",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        fontFamily = InterFontFamily
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    BreakdownRow("Total Member Deposits ($depositQty qty)", CurrencyFormatter.formatCurrency(kpi.totalDeposits), color = NagadPrimary)
                    BreakdownRow("Deposit Fine (17 qty)", CurrencyFormatter.formatCurrency(kpi.fineCollection), color = NagadWarning)
                    BreakdownRow("Gross Business P/L (Profit ৳6,100 − Loss ৳6,700)", grossStr, color = if (kpi.grossBusinessPnl >= 0) NagadPrimary else NagadDanger)
                    BreakdownRow("Exited Members' Loss Share Retained (3 × ৳14)", "+${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)}", color = NagadPrimary)
                    BreakdownRow("Net Business P/L ($grossStr + ${CurrencyFormatter.formatCurrency(kpi.exitedMembersLossRecovery)})", netPnlStr, color = if (kpi.realizedBusinessPnl >= 0) NagadPrimary else NagadDanger)
                    BreakdownRow("Total Amount (Inflow Total)", CurrencyFormatter.formatCurrency(kpi.totalCollection), color = NagadPrimary)
                    BreakdownRow("Operational Expenses (${expenses.size} records)", CurrencyFormatter.formatCurrency(kpi.totalExpenses), color = NagadDanger)
                    BreakdownRow("Investment Running", CurrencyFormatter.formatCurrency(kpi.totalRunningInvestments), color = NagadSecondaryText)
                    BreakdownRow("Cost & Invest (Expenses + Running)", "-${CurrencyFormatter.formatCurrency(kpi.costAndInvest)}", color = NagadDanger)

                    HorizontalDivider(
                        color = NagadBorder,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Total Hand Cash",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = NagadMainText,
                                fontFamily = InterFontFamily
                            )
                            Text(
                                text = "Inflow Total (${CurrencyFormatter.formatCurrency(kpi.totalCollection)}) − Cost & Invest (${CurrencyFormatter.formatCurrency(kpi.costAndInvest)})",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.5.sp,
                                color = NagadSecondaryText
                            )
                        }
                        Text(
                            text = CurrencyFormatter.formatCurrency(kpi.cashInHand),
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = NagadPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NagadLightBg,
                        border = BorderStroke(1.5.dp, NagadBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Bank Total: ${CurrencyFormatter.formatCurrency(kpi.bankBalance)}",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NagadMainText
                            )
                            Text(
                                text = "Grand Total: ${CurrencyFormatter.formatCurrency(kpi.mainLiquidCapital)}",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NagadPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Capital Efficiency Ratio", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = NagadSecondaryText, fontFamily = InterFontFamily)
                        Text(
                            text = "$capitalEfficiency%",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (capitalEfficiency / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = NagadPrimary,
                        trackColor = NagadLightBg
                    )
                }
            }
        }

        // Monthly Trend Line Chart
        item {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Monthly Collection Trend",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NagadMainText
                    )
                    Text(
                        text = "Historical collection velocity (last 6 months)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        fontFamily = InterFontFamily
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    TrendLineChartComposable(points = trendPoints, lineColor = NagadPrimary)
                }
            }
        }
    }

    // Update Balances Dialog
    if (showBalanceDialog) {
        var bankInput by remember { mutableStateOf(kpi.bankBalance.toString()) }
        var reserveInput by remember { mutableStateOf(kpi.reservedAmount.toString()) }
        val derivedCashPreview = kpi.mainLiquidCapital - (bankInput.toIntOrNull() ?: kpi.bankBalance)

        AlertDialog(
            onDismissRequest = { showBalanceDialog = false },
            containerColor = NagadWhite,
            title = { Text("Update Financial Balances", fontWeight = FontWeight.Bold, fontFamily = InterFontFamily, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = bankInput,
                        onValueChange = { bankInput = it },
                        label = { Text("Bank Balance (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    OutlinedTextField(
                        value = CurrencyFormatter.formatCurrency(derivedCashPreview),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Cash In Hand (Derived: Liquid − Bank)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                    OutlinedTextField(
                        value = reserveInput,
                        onValueChange = { reserveInput = it },
                        label = { Text("Reserved Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val b = bankInput.toIntOrNull() ?: 0
                        val r = reserveInput.toIntOrNull() ?: 0
                        viewModel.updateFinancialSettings(b, r)
                        showBalanceDialog = false
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Save Balances", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBalanceDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText, fontFamily = InterFontFamily)
                }
            }
        )
    }
}

@Composable
fun BreakdownRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Medium,
            color = NagadSecondaryText,
            modifier = Modifier.weight(1f, fill = false),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            fontFamily = InterFontFamily
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.5.sp,
            color = color,
            maxLines = 1,
            softWrap = false,
            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS)
        )
    }
    HorizontalDivider(color = NagadBorder)
}
