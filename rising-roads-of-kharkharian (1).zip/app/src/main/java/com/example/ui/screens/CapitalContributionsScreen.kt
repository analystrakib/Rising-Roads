package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Deposit
import com.example.data.model.Member
import com.example.data.model.MemberStatus
import com.example.data.model.MemberWithCapitalContributions
import com.example.data.model.MemberWithStats
import com.example.data.model.PaymentRequest
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Screen that lists all 11 members and their individual capital contributions
 * using a LazyColumn layout styled with the Nagad Green & White visual design system.
 */
@Composable
fun CapitalContributionsScreen(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit,
    onPayNowClick: (() -> Unit)? = null
) {
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val adminRole by viewModel.adminRole.collectAsState()
    val membersWithContributions by viewModel.membersWithCapitalContributions.collectAsState()
    val allDeposits by viewModel.deposits.collectAsState()
    val allPaymentRequests by viewModel.paymentRequests.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val kpi by viewModel.financialKpi.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "Fully Paid", "Has Dues", "Red Alert"

    var selectedReceiptDeposit by remember { mutableStateOf<Deposit?>(null) }
    var selectedReceiptMember by remember { mutableStateOf<Member?>(null) }
    var recordDepositForMember by remember { mutableStateOf<Member?>(null) }

    // Aggregate metrics
    val totalCapitalContributed = remember(allDeposits) {
        allDeposits.sumOf { it.amount }
    }
    val totalFinesCollected = kpi.fineCollection
    val totalDueAmount = remember(membersWithStats) {
        membersWithStats.sumOf { it.totalDue }
    }
    val fullyPaidCount = remember(membersWithStats) {
        membersWithStats.count { it.pendingMonths.isEmpty() }
    }

    // Combine stats with raw contributions
    val memberContributionItems = remember(membersWithStats, membersWithContributions, searchQuery, selectedFilter) {
        membersWithStats.map { statItem ->
            val rel = membersWithContributions.find { it.member.id == statItem.member.id }
            val contributionsList = rel?.contributions ?: emptyList()
            MemberContributionUiModel(
                stats = statItem,
                contributions = contributionsList
            )
        }.filter { item ->
            val query = searchQuery.trim().lowercase()
            val matchesQuery = query.isEmpty() ||
                    item.stats.member.name.lowercase().contains(query) ||
                    item.stats.member.phone.contains(query) ||
                    "rrk-${item.stats.member.id.toString().padStart(3, '0')}".contains(query)

            val matchesFilter = when (selectedFilter) {
                "Fully Paid" -> item.stats.pendingMonths.isEmpty()
                "Has Dues" -> item.stats.totalDue > 0
                "Red Alert" -> item.stats.status == MemberStatus.RED_ALERT
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("capital_contributions_screen"),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Capital Contributions",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp,
                            color = NagadMainText
                        )
                        Text(
                            text = "All 11 Founding Investors · Capital Accounts",
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = NagadSecondaryText
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onPayNowClick != null) {
                            Surface(
                                onClick = onPayNowClick,
                                shape = RoundedCornerShape(10.dp),
                                color = NagadPrimary,
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("pay_now_header_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "+ Pay Now",
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = NagadLightBg,
                            border = BorderStroke(1.dp, NagadBorder)
                        ) {
                            Text(
                                text = "৳1,000 / mo",
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = NagadPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Summary KPI Banner
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Total Capital Raised",
                        value = "৳${totalCapitalContributed.toFormattedAmount()}",
                        subtitle = "Across all members",
                        icon = Icons.Default.AttachMoney,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Total Fines Paid",
                        value = "৳${totalFinesCollected.toFormattedAmount()}",
                        subtitle = "Late fee collection",
                        icon = Icons.Default.Warning,
                        iconBgColor = Color(0xFFFEF7E6),
                        iconColor = NagadWarning,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Fully Paid Investors",
                        value = "$fullyPaidCount / ${membersWithStats.size}",
                        subtitle = "Zero outstanding dues",
                        icon = Icons.Default.CheckCircle,
                        iconBgColor = NagadLightBg,
                        iconColor = NagadPrimary,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    StatCard(
                        title = "Outstanding Dues",
                        value = "৳${totalDueAmount.toFormattedAmount()}",
                        subtitle = "Pending capital",
                        icon = Icons.Default.HourglassBottom,
                        iconBgColor = Color(0xFFFDF0F0),
                        iconColor = NagadDanger,
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        }

        // Search and Filters
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("capital_search_input"),
                    placeholder = {
                        Text(
                            text = "Search by investor name, phone, or RRK ID...",
                            fontFamily = InterFontFamily,
                            fontSize = 13.sp,
                            color = NagadSecondaryText
                        )
                    },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = NagadPrimary) },
                    singleLine = true,
                    textStyle = appInputTextStyle(13.5.sp),
                    shape = AppInputShape,
                    colors = appOutlinedTextFieldColors()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Fully Paid", "Has Dues", "Red Alert").forEach { filter ->
                        val isSelected = selectedFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = filter },
                            label = {
                                Text(
                                    text = filter,
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) NagadPrimary else NagadSecondaryText
                                )
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NagadLightBg,
                                containerColor = NagadWhite
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) NagadPrimary else NagadBorder
                            )
                        )
                    }
                }
            }
        }

        // Section Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Investor Portfolios (${memberContributionItems.size})",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = NagadMainText
                )
                Text(
                    text = "Deadline: 15th of month",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    color = NagadSecondaryText
                )
            }
        }

        // Empty state
        if (memberContributionItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No member records match the filter criteria",
                        fontFamily = PoppinsFontFamily,
                        color = NagadSecondaryText
                    )
                }
            }
        } else {
            // LazyColumn Items for all 11 members
            items(memberContributionItems, key = { it.stats.member.id }) { item ->
                val memberRequests = remember(allPaymentRequests, item.stats.member.id) {
                    allPaymentRequests.filter { it.memberId == item.stats.member.id }
                }
                MemberCapitalContributionCard(
                    item = item,
                    paymentRequests = memberRequests,
                    adminUsername = adminUsername,
                    isAdmin = isAdmin,
                    onNavigateToProfile = { onNavigateToMemberProfile(item.stats.member.id) },
                    onRecordDeposit = { recordDepositForMember = item.stats.member },
                    onViewReceipt = { deposit ->
                        selectedReceiptDeposit = deposit
                        selectedReceiptMember = item.stats.member
                    },
                    onProofDownloaded = { msg -> viewModel.showToast(msg) }
                )
            }
        }
    }

    // Receipt Dialog
    if (selectedReceiptDeposit != null && selectedReceiptMember != null) {
        DepositReceiptDialog(
            deposit = selectedReceiptDeposit!!,
            member = selectedReceiptMember!!,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = {
                selectedReceiptDeposit = null
                selectedReceiptMember = null
            }
        )
    }

    // Quick Record Dialog for Member
    if (recordDepositForMember != null) {
        val targetMember = recordDepositForMember!!
        val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
        val day = remember { SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1 }
        val defFine = if (day > 15) 100 else 0
        var pMonth by remember { mutableStateOf("May 2025") }
        var pDate by remember { mutableStateOf(todayStr) }
        var fineVal by remember { mutableStateOf(defFine.toString()) }

        AlertDialog(
            onDismissRequest = { recordDepositForMember = null },
            containerColor = NagadWhite,
            title = {
                Text(
                    text = "Record Contribution — ${targetMember.name}",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NagadMainText
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Monthly Capital: ৳1,000",
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        color = NagadPrimary
                    )
                    OutlinedTextField(
                        value = pMonth,
                        onValueChange = { pMonth = it },
                        label = { Text("Month (e.g. May 2025)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = pDate,
                        onValueChange = { pDate = it },
                        label = { Text("Payment Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = fineVal,
                        onValueChange = { fineVal = it },
                        label = { Text("Fine Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fine = fineVal.toIntOrNull() ?: 0
                        viewModel.recordDeposit(
                            memberId = targetMember.id,
                            month = pMonth,
                            paymentDate = pDate,
                            amount = 1000,
                            fine = fine
                        ) { newId ->
                            val newDep = Deposit(
                                id = newId.toInt(),
                                memberId = targetMember.id,
                                month = pMonth,
                                paymentDate = pDate,
                                amount = 1000,
                                fine = fine
                            )
                            selectedReceiptDeposit = newDep
                            selectedReceiptMember = targetMember
                            recordDepositForMember = null
                        }
                    },
                    colors = appSolidButtonColors(NagadPrimary)
                ) {
                    Text("Save & Generate Receipt", fontFamily = InterFontFamily, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordDepositForMember = null }) {
                    Text("Cancel", fontFamily = InterFontFamily, color = NagadSecondaryText)
                }
            }
        )
    }
}

/**
 * Individual Member Capital Contribution Card.
 * Displays member details, capital contributions total, paid/unpaid months,
 * and expandable breakdown of individual capital deposits.
 */
@Composable
fun MemberCapitalContributionCard(
    item: MemberContributionUiModel,
    paymentRequests: List<PaymentRequest> = emptyList(),
    adminUsername: String = "Rakib",
    isAdmin: Boolean,
    onNavigateToProfile: () -> Unit,
    onRecordDeposit: () -> Unit,
    onViewReceipt: (Deposit) -> Unit,
    onProofDownloaded: (String) -> Unit = {}
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("capital_card_${item.stats.member.id}"),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = NagadWhite),
        border = AppCardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Avatar, Member Info, and Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MemberAvatar(name = item.stats.member.name, id = item.stats.member.id, size = 48)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.stats.member.name,
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = NagadMainText
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NagadLightBg,
                                border = BorderStroke(1.dp, NagadBorder)
                            ) {
                                Text(
                                    text = "RRK-${item.stats.member.id.toString().padStart(3, '0')}",
                                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NagadPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = NagadSecondaryText
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = item.stats.member.phone,
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp,
                                color = NagadSecondaryText
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    StatusBadge(status = item.stats.status)
                    paymentRequests.firstOrNull()?.let { latestReq ->
                        PaymentRequestStatusBadge(status = latestReq.status)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Capital Metrics Grid
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NagadLightBg,
                border = BorderStroke(1.dp, NagadBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "Capital Contributed",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NagadSecondaryText
                        )
                        Text(
                            text = "৳${item.stats.totalPaidContribution.toFormattedAmount()}",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NagadPrimary
                        )
                        Text(
                            text = "${item.contributions.size} deposits",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = NagadMainText
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Paid Months",
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NagadSecondaryText
                        )
                        Text(
                            text = "${item.stats.paidMonths.size} mos",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadPrimary
                        )
                        Text(
                            text = if (item.stats.totalFinePaid > 0) "Fine: ${CurrencyFormatter.formatCurrency(item.stats.totalFinePaid)}" else "No fines",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = if (item.stats.totalFinePaid > 0) NagadDanger else NagadSecondaryText
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Capital Due",
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NagadSecondaryText
                        )
                        Text(
                            text = if (item.stats.totalDue > 0) "৳${item.stats.totalDue.toFormattedAmount()}" else "৳0",
                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (item.stats.totalDue > 0) NagadDanger else NagadPrimary
                        )
                        Text(
                            text = if (item.stats.totalDue > 0) "${item.stats.pendingMonths.size} pending" else "Up to date",
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            color = if (item.stats.totalDue > 0) NagadDanger else NagadPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Expand / Collapse Contributions Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = NagadPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (item.contributions.isEmpty()) "No capital contributions recorded yet"
                        else "Individual Contribution Breakdown (${item.contributions.size})",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadPrimary
                    )
                }

                if (item.contributions.isNotEmpty()) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = NagadPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Expandable Breakdown List
            AnimatedVisibility(
                visible = isExpanded && (item.contributions.isNotEmpty() || paymentRequests.isNotEmpty()),
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (paymentRequests.isNotEmpty()) {
                        Text(
                            text = "Submitted Payment Requests (${paymentRequests.size})",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = NagadMainText,
                            modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                        )
                        paymentRequests.take(5).forEach { req ->
                            MemberPaymentRequestItemCard(
                                request = req,
                                memberPhone = item.stats.member.phone,
                                adminFallbackName = adminUsername,
                                showMemberIdentity = false,
                                onProofDownloaded = onProofDownloaded
                            )
                        }
                    }

                    item.contributions.forEach { contribution ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = NagadLightBg,
                            border = BorderStroke(1.dp, NagadBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = contribution.month,
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = NagadMainText
                                    )
                                    Text(
                                        text = "Paid on: ${contribution.paymentDate}" +
                                                if (contribution.fine > 0) " · Late fine: ${CurrencyFormatter.formatCurrency(contribution.fine)}" else "",
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 10.sp,
                                        color = if (contribution.fine > 0) NagadDanger else NagadSecondaryText
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = CurrencyFormatter.formatCurrency(contribution.amount + contribution.fine),
                                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = NagadPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { onViewReceipt(contribution) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Receipt,
                                            contentDescription = "View Receipt",
                                            tint = NagadPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = NagadBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onNavigateToProfile,
                    modifier = Modifier.testTag("view_profile_btn_${item.stats.member.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = NagadPrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Full Profile",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NagadPrimary
                    )
                }
            }
        }
    }
}

data class MemberContributionUiModel(
    val stats: MemberWithStats,
    val contributions: List<Deposit>
)

private fun Int.toFormattedAmount(): String {
    return CurrencyFormatter.formatNumber(this)
}
