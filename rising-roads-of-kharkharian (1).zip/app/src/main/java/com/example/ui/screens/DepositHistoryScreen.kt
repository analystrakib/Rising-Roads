package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.Deposit
import com.example.data.model.Member
import com.example.data.repository.AppRepository
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepositHistoryScreen(
    viewModel: MainViewModel,
    onNavigateToMemberProfile: (Int) -> Unit
) {
    val context = LocalContext.current
    val allDeposits by viewModel.deposits.collectAsState()
    val membersWithStats by viewModel.membersWithStats.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val adminRole by viewModel.adminRole.collectAsState()

    val activeMonths = remember { listOf("All Months") + AppRepository.getActiveMonths() }
    var searchQuery by remember { mutableStateOf("") }
    var selectedMonthFilter by remember { mutableStateOf("All Months") }
    var isMonthDropdownExpanded by remember { mutableStateOf(false) }

    var showAddDepositDialog by remember { mutableStateOf(false) }
    var selectedDepositForReceipt by remember { mutableStateOf<Deposit?>(null) }
    var selectedMemberForReceipt by remember { mutableStateOf<Member?>(null) }
    var depositToDelete by remember { mutableStateOf<Deposit?>(null) }
    var depositToEdit by remember { mutableStateOf<Deposit?>(null) }

    val membersMap = remember(membersWithStats) {
        membersWithStats.associate { it.member.id to it.member }
    }

    // Filter deposits
    val filteredDeposits = remember(allDeposits, searchQuery, selectedMonthFilter, membersMap) {
        allDeposits.filter { dep ->
            val member = membersMap[dep.memberId]
            val query = searchQuery.trim().lowercase()
            val matchesQuery = query.isEmpty() ||
                    (member?.name?.lowercase()?.contains(query) == true) ||
                    "rrk-${dep.id.toString().padStart(4, '0')}".contains(query)

            val matchesMonth = selectedMonthFilter == "All Months" || dep.month == selectedMonthFilter

            matchesQuery && matchesMonth
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NagadVeryLightBg)
            .testTag("deposit_history_screen")
            .padding(start = 16.dp, top = 16.dp, end = 16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Deposit History",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = NagadMainText
                    )
                )
                Text(
                    text = "${allDeposits.size} Total Deposits Recorded",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText
                    )
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val csvFile = viewModel.exportDepositsCsv()
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", csvFile)
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Export Deposits CSV"))
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NagadBorder)
                ) {
                    Icon(imageVector = Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp), tint = NagadPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CSV", fontSize = 12.sp, color = NagadPrimary, fontWeight = FontWeight.Bold, fontFamily = PoppinsFontFamily)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Search & Month Filter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name or receipt #...", color = NagadSecondaryText) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = NagadPrimary) },
                singleLine = true,
                textStyle = appInputTextStyle(13.5.sp),
                shape = AppInputShape,
                colors = appOutlinedTextFieldColors(),
                modifier = Modifier.weight(1f)
            )

            ExposedDropdownMenuBox(
                expanded = isMonthDropdownExpanded,
                onExpandedChange = { isMonthDropdownExpanded = !isMonthDropdownExpanded }
            ) {
                Surface(
                    shape = AppInputShape,
                    color = NagadWhite,
                    border = androidx.compose.foundation.BorderStroke(1.dp, InputBorder),
                    modifier = Modifier
                        .menuAnchor()
                        .clickable { isMonthDropdownExpanded = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedMonthFilter.replace(" Months", ""),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NagadMainText
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isMonthDropdownExpanded)
                    }
                }

                ExposedDropdownMenu(
                    expanded = isMonthDropdownExpanded,
                    onDismissRequest = { isMonthDropdownExpanded = false }
                ) {
                    activeMonths.forEach { m ->
                        DropdownMenuItem(
                            text = { Text(m, fontSize = 13.sp) },
                            onClick = {
                                selectedMonthFilter = m
                                isMonthDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Deposits List
        if (filteredDeposits.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No deposits found",
                    color = NagadSecondaryText,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            Card(
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = NagadWhite),
                border = AppCardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 12.dp, top = 12.dp, end = 12.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredDeposits, key = { it.id }) { dep ->
                        val member = membersMap[dep.memberId]
                        val rNo = "RRK-${dep.id.toString().padStart(4, '0')}"

                        Card(
                            shape = AppCardShape,
                            colors = CardDefaults.cardColors(containerColor = NagadWhite),
                            border = AppCardBorder,
                            elevation = CardDefaults.cardElevation(defaultElevation = AppCardElevation),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (member != null) {
                                        selectedDepositForReceipt = dep
                                        selectedMemberForReceipt = member
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = rNo,
                                            style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadSecondaryText
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = dep.month,
                                            fontSize = 11.5.sp,
                                            color = NagadSecondaryText,
                                            fontWeight = FontWeight.Medium,
                                            fontFamily = InterFontFamily
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = member?.name ?: "Member #${dep.memberId}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = NagadMainText,
                                        fontFamily = PoppinsFontFamily
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = "Paid on ${dep.paymentDate} · Cash: ${CurrencyFormatter.formatCurrency(dep.amount)}",
                                        style = TextStyle(fontFamily = PoppinsFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NagadSecondaryText
                                    )

                                    if (dep.fine > 0) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Late Fine: ${CurrencyFormatter.formatCurrency(dep.fine)} (Company Fund)",
                                            style = TextStyle(fontFamily = PoppinsFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NagadDanger
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = CurrencyFormatter.formatCurrency(dep.amount + dep.fine),
                                            style = TextStyle(fontFamily = PoppinsFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 16.sp,
                                            color = NagadPrimary
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = NagadLightBg,
                                            modifier = Modifier
                                                .padding(top = 4.dp)
                                                .clickable {
                                                    if (member != null) {
                                                        selectedDepositForReceipt = dep
                                                        selectedMemberForReceipt = member
                                                    }
                                                }
                                        ) {
                                            Text(
                                                text = "Receipt",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = NagadPrimary,
                                                fontFamily = PoppinsFontFamily,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Receipt Dialog
    if (selectedDepositForReceipt != null && selectedMemberForReceipt != null) {
        DepositReceiptDialog(
            deposit = selectedDepositForReceipt!!,
            member = selectedMemberForReceipt!!,
            adminName = adminUsername,
            adminRole = adminRole,
            onDismiss = {
                selectedDepositForReceipt = null
                selectedMemberForReceipt = null
            }
        )
    }

    // Delete Confirmation Dialog
    if (depositToDelete != null) {
        AlertDialog(
            onDismissRequest = { depositToDelete = null },
            title = { Text("Delete Deposit Record?", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = { Text("Are you sure you want to delete deposit RRK-${depositToDelete?.id?.toString()?.padStart(4, '0')}? This action cannot be undone.", color = NagadSecondaryText) },
            confirmButton = {
                Button(
                    onClick = {
                        depositToDelete?.id?.let { viewModel.deleteDeposit(it) }
                        depositToDelete = null
                    },
                    colors = appSolidButtonColors(RedAlert)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { depositToDelete = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Add Deposit Dialog
    if (showAddDepositDialog) {
        var selectedMemberId by remember { mutableStateOf(membersWithStats.firstOrNull()?.member?.id ?: 1) }
        val activeMonthsList = remember { AppRepository.getActiveMonths() }
        var selectedMonthInput by remember { mutableStateOf(activeMonthsList.lastOrNull() ?: "May 2025") }
        var paymentDateInput by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val day = remember { SimpleDateFormat("d", Locale.US).format(Date()).toIntOrNull() ?: 1 }
        val autoFine = if (day > 15) 100 else 0
        var fineInput by remember { mutableStateOf(autoFine.toString()) }

        val alreadyPaid = remember(selectedMemberId, selectedMonthInput, allDeposits) {
            allDeposits.any { it.memberId == selectedMemberId && it.month == selectedMonthInput }
        }

        AlertDialog(
            onDismissRequest = { showAddDepositDialog = false },
            title = { Text("Record New Deposit", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (alreadyPaid) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF2F2),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ This member has already paid for $selectedMonthInput!",
                                color = RedAlert,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    // Member selector dropdown
                    Text("Select Member:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    var memberDropdownOpen by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = memberDropdownOpen,
                        onExpandedChange = { memberDropdownOpen = !memberDropdownOpen }
                    ) {
                        val currentSelectedMember = membersMap[selectedMemberId]
                        OutlinedTextField(
                            value = currentSelectedMember?.name ?: "Select",
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = memberDropdownOpen) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = memberDropdownOpen,
                            onDismissRequest = { memberDropdownOpen = false }
                        ) {
                            membersWithStats.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text("${m.member.id}. ${m.member.name}") },
                                    onClick = {
                                        selectedMemberId = m.member.id
                                        memberDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // Month selector
                    Text("Payment Month:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NagadMainText)
                    var monthDropdownOpen by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = monthDropdownOpen,
                        onExpandedChange = { monthDropdownOpen = !monthDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = selectedMonthInput,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = appInputTextStyle(),
                            shape = AppInputShape,
                            colors = appOutlinedTextFieldColors(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthDropdownOpen) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = monthDropdownOpen,
                            onDismissRequest = { monthDropdownOpen = false }
                        ) {
                            activeMonthsList.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m) },
                                    onClick = {
                                        selectedMonthInput = m
                                        monthDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = paymentDateInput,
                        onValueChange = {
                            paymentDateInput = it
                            try {
                                val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(it)?.date ?: 1
                                if (d > 15) fineInput = "100" else fineInput = "0"
                            } catch (e: Exception) {}
                        },
                        label = { Text("Payment Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = fineInput,
                        onValueChange = { fineInput = it },
                        label = { Text("Fine (৳100 auto-added after 15th)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    val fineNum = fineInput.toIntOrNull() ?: 0
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NagadVeryLightBg,
                        border = AppCardBorder,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Payable:", fontWeight = FontWeight.Bold, color = NagadMainText)
                            Text(
                                CurrencyFormatter.formatCurrency(1000 + fineNum),
                                style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldGreen,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fine = fineInput.toIntOrNull() ?: 0
                        viewModel.recordDeposit(
                            memberId = selectedMemberId,
                            month = selectedMonthInput,
                            paymentDate = paymentDateInput,
                            amount = 1000,
                            fine = fine
                        ) { newId ->
                            val newDep = Deposit(
                                id = newId.toInt(),
                                memberId = selectedMemberId,
                                month = selectedMonthInput,
                                paymentDate = paymentDateInput,
                                amount = 1000,
                                fine = fine
                            )
                            selectedDepositForReceipt = newDep
                            selectedMemberForReceipt = membersMap[selectedMemberId]
                            showAddDepositDialog = false
                        }
                    },
                    colors = appSolidButtonColors(EmeraldGreen),
                    enabled = !alreadyPaid
                ) {
                    Text("Confirm Deposit", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDepositDialog = false }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }

    // Edit Deposit Dialog
    if (depositToEdit != null) {
        val dep = depositToEdit!!
        val mName = membersMap[dep.memberId]?.name ?: "Member #${dep.memberId}"
        var eMonth by remember { mutableStateOf(dep.month) }
        var eDate by remember { mutableStateOf(dep.paymentDate) }
        var eAmount by remember { mutableStateOf(dep.amount.toString()) }
        var eFine by remember { mutableStateOf(dep.fine.toString()) }

        AlertDialog(
            onDismissRequest = { depositToEdit = null },
            title = { Text("Edit Deposit RRK-${dep.id.toString().padStart(4, '0')}", fontWeight = FontWeight.Bold, color = NagadMainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Member: $mName", fontWeight = FontWeight.Bold, color = NagadMainText)

                    OutlinedTextField(
                        value = eMonth,
                        onValueChange = { eMonth = it },
                        label = { Text("Month (e.g. May 2025)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = eDate,
                        onValueChange = { eDate = it },
                        label = { Text("Payment Date (YYYY-MM-DD)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = eAmount,
                        onValueChange = { eAmount = it },
                        label = { Text("Base Amount (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = eFine,
                        onValueChange = { eFine = it },
                        label = { Text("Late Fine (৳)") },
                        singleLine = true,
                        textStyle = appInputTextStyle(),
                        shape = AppInputShape,
                        colors = appOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = eAmount.toIntOrNull() ?: dep.amount
                        val fn = eFine.toIntOrNull() ?: dep.fine
                        viewModel.updateDeposit(
                            dep.copy(
                                month = eMonth.trim(),
                                paymentDate = eDate.trim(),
                                amount = amt,
                                fine = fn
                            )
                        )
                        depositToEdit = null
                    },
                    colors = appSolidButtonColors(RoyalBlue)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { depositToEdit = null }) {
                    Text("Cancel", color = NagadSecondaryText)
                }
            }
        )
    }
}
