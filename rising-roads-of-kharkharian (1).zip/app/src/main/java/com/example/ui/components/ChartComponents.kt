package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class BarItem(
    val label: String,
    val value: Float,
    val color: Color = RoyalBlue
)

@Composable
fun BarChartComposable(
    items: List<BarItem>,
    modifier: Modifier = Modifier.fillMaxWidth().height(180.dp),
    valuePrefix: String = "৳"
) {
    if (items.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                "No collection data available",
                color = NagadSecondaryText,
                fontWeight = FontWeight.Medium
            )
        }
        return
    }

    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(items) {
        animProgress.snapTo(0f)
        animProgress.animateTo(1f, animationSpec = tween(700))
    }

    val maxValue = remember(items) { (items.maxOfOrNull { it.value } ?: 1000f).coerceAtLeast(100f) }
    val textColor = NagadSecondaryText

    Canvas(modifier = modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
        val totalBars = items.size
        val barSpacing = size.width / (totalBars * 2.2f)
        val barWidth = (size.width - (totalBars + 1) * barSpacing) / totalBars
        val chartHeight = size.height - 35.dp.toPx()

        // Horizontal baseline
        drawLine(
            color = NagadBorder,
            start = Offset(0f, chartHeight),
            end = Offset(size.width, chartHeight),
            strokeWidth = 1.5.dp.toPx()
        )

        items.forEachIndexed { index, item ->
            val left = barSpacing + index * (barWidth + barSpacing)
            val barHeight = (item.value / maxValue) * (chartHeight - 25.dp.toPx()) * animProgress.value
            val top = chartHeight - barHeight

            // Draw bar with gradient
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(item.color, item.color.copy(alpha = 0.7f)),
                    startY = top,
                    endY = chartHeight
                ),
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            // Draw value text above bar
            if (barHeight > 10f) {
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.parseColor("#0F172A")
                        textSize = 22f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    val displayVal = if (item.value >= 1000) "${(item.value / 1000).toInt()}k" else item.value.toInt().toString()
                    drawText(displayVal, left + barWidth / 2, top - 6.dp.toPx(), paint)
                }
            }

            // Draw X-axis label
            drawContext.canvas.nativeCanvas.apply {
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.parseColor("#334155")
                    textSize = 24f
                    textAlign = android.graphics.Paint.Align.CENTER
                    isAntiAlias = true
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                }
                drawText(item.label, left + barWidth / 2, size.height - 4.dp.toPx(), paint)
            }
        }
    }
}

data class DonutSlice(
    val label: String,
    val value: Float,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DonutChartComposable(
    slices: List<DonutSlice>,
    modifier: Modifier = Modifier.fillMaxWidth().height(180.dp),
    centerLabel: String = "Members",
    centerValue: String = ""
) {
    val total = remember(slices) { slices.sumOf { it.value.toDouble() }.toFloat().coerceAtLeast(1f) }

    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(slices) {
        animProgress.snapTo(0f)
        animProgress.animateTo(1f, animationSpec = tween(800))
    }

    Row(
        modifier = modifier.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(140.dp)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(130.dp)) {
                val strokeWidth = 24.dp.toPx()
                val radius = (size.minDimension - strokeWidth) / 2
                val centerOffset = Offset(size.width / 2, size.height / 2)
                var currentAngle = -90f

                slices.forEach { slice ->
                    val sweepAngle = (slice.value / total) * 360f * animProgress.value
                    if (sweepAngle > 0f) {
                        drawArc(
                            color = slice.color,
                            startAngle = currentAngle,
                            sweepAngle = sweepAngle - 2f, // Small gap
                            useCenter = false,
                            topLeft = Offset(centerOffset.x - radius, centerOffset.y - radius),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                    currentAngle += (slice.value / total) * 360f
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = centerValue.ifEmpty { total.toInt().toString() },
                    style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = NagadMainText
                )
                Text(
                    text = centerLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = NagadSecondaryText
                )
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            slices.forEach { slice ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(slice.color)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = slice.label,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = NagadSecondaryText,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = slice.value.toInt().toString(),
                        style = TextStyle(fontFamily = InterFontFamily, fontFeatureSettings = TABULAR_NUMBERS),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NagadMainText
                    )
                }
            }
        }
    }
}

@Composable
fun TrendLineChartComposable(
    points: List<Pair<String, Float>>,
    modifier: Modifier = Modifier.fillMaxWidth().height(160.dp),
    lineColor: Color = RoyalBlue
) {
    if (points.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                "No trend records available",
                color = NagadSecondaryText,
                fontWeight = FontWeight.Medium
            )
        }
        return
    }

    val maxVal = remember(points) { (points.maxOfOrNull { it.second } ?: 100f).coerceAtLeast(10f) }
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(points) {
        animProgress.snapTo(0f)
        animProgress.animateTo(1f, animationSpec = tween(800))
    }

    Canvas(modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        val chartHeight = size.height - 30.dp.toPx()
        val stepX = size.width / (points.size - 1).coerceAtLeast(1)

        val path = Path()
        val fillPath = Path()

        val coordinates = points.mapIndexed { index, pair ->
            val x = index * stepX
            val y = chartHeight - (pair.second / maxVal) * (chartHeight - 20.dp.toPx()) * animProgress.value
            Offset(x, y)
        }

        if (coordinates.isNotEmpty()) {
            path.moveTo(coordinates[0].x, coordinates[0].y)
            fillPath.moveTo(coordinates[0].x, chartHeight)
            fillPath.lineTo(coordinates[0].x, coordinates[0].y)

            for (i in 0 until coordinates.size - 1) {
                val p0 = coordinates[i]
                val p1 = coordinates[i + 1]
                val controlX = (p0.x + p1.x) / 2
                path.cubicTo(controlX, p0.y, controlX, p1.y, p1.x, p1.y)
                fillPath.cubicTo(controlX, p0.y, controlX, p1.y, p1.x, p1.y)
            }

            fillPath.lineTo(coordinates.last().x, chartHeight)
            fillPath.close()

            // Draw gradient area below curve
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.25f), lineColor.copy(alpha = 0.02f)),
                    startY = 0f,
                    endY = chartHeight
                )
            )

            // Draw line curve
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw points and X labels
            coordinates.forEachIndexed { index, point ->
                drawCircle(
                    color = Color.White,
                    radius = 5.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = lineColor,
                    radius = 3.dp.toPx(),
                    center = point
                )

                // Label
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.parseColor("#334155")
                        textSize = 22f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                    }
                    drawText(points[index].first, point.x, size.height - 4.dp.toPx(), paint)
                }
            }
        }
    }
}
