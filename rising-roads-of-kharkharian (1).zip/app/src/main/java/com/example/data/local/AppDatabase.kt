package com.example.data.local

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ActivityLog
import com.example.data.model.AdminUser
import com.example.data.model.AppConfig
import com.example.data.model.Deposit
import com.example.data.model.Expense
import com.example.data.model.IdeaComment
import com.example.data.model.Investment
import com.example.data.model.Member
import com.example.data.model.MemberAccount
import com.example.data.model.MemberIdea
import com.example.data.model.CustomPage
import com.example.data.model.ExitedMember
import com.example.data.model.MemberSettlement
import com.example.data.model.OfficialPaymentAccounts
import com.example.data.model.PaymentRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Member::class,
        Deposit::class,
        Expense::class,
        Investment::class,
        MemberSettlement::class,
        AdminUser::class,
        ActivityLog::class,
        AppConfig::class,
        MemberAccount::class,
        MemberIdea::class,
        IdeaComment::class,
        PaymentRequest::class,
        ExitedMember::class,
        CustomPage::class
    ],
    version = 12,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        private const val TAG = "AppDatabase"
        private const val DB_NAME = "rising_roads_database"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    val hasInvPhoto = hasColumn(db, "investments", "photoUri")
                    if (!hasInvPhoto) {
                        db.execSQL("ALTER TABLE investments ADD COLUMN photoUri TEXT NOT NULL DEFAULT ''")
                    }
                    val hasMemberPhoto = hasColumn(db, "members", "photoUri")
                    if (!hasMemberPhoto) {
                        db.execSQL("ALTER TABLE members ADD COLUMN photoUri TEXT")
                    }
                    // Clear any abnormally large Base64 blobs that could exceed SQLite CursorWindow limits
                    db.execSQL("UPDATE members SET photoUri = NULL WHERE LENGTH(photoUri) > 250000")
                    db.execSQL("UPDATE investments SET photoUri = '' WHERE LENGTH(photoUri) > 250000")
                } catch (e: Throwable) {
                    Log.e(TAG, "Migration 7->8 warning: ${e.message}", e)
                }
            }

            private fun hasColumn(db: SupportSQLiteDatabase, table: String, column: String): Boolean {
                db.query("PRAGMA table_info($table)").use { cursor ->
                    val nameIdx = cursor.getColumnIndex("name")
                    while (cursor.moveToNext()) {
                        if (nameIdx >= 0 && cursor.getString(nameIdx) == column) {
                            return true
                        }
                    }
                }
                return false
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    // Safe migration from 8 to 9
                } catch (e: Throwable) {
                    Log.e(TAG, "Migration 8->9 warning: ${e.message}", e)
                }
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS exited_members (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, resignationDate TEXT NOT NULL, lossShareAmount INTEGER NOT NULL, notes TEXT NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS custom_pages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, iconName TEXT NOT NULL, coverImageUrl TEXT NOT NULL, content TEXT NOT NULL, isVisible INTEGER NOT NULL, displayOrder INTEGER NOT NULL)")
                } catch (e: Throwable) {
                    Log.e(TAG, "Migration 9->10 warning: ${e.message}", e)
                }
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    if (!hasTableColumn(db, "investments", "paymentSource")) {
                        db.execSQL("ALTER TABLE investments ADD COLUMN paymentSource TEXT NOT NULL DEFAULT 'Cash'")
                    }
                    if (!hasTableColumn(db, "investments", "returnSource")) {
                        db.execSQL("ALTER TABLE investments ADD COLUMN returnSource TEXT NOT NULL DEFAULT ''")
                    }
                } catch (e: Throwable) {
                    Log.e(TAG, "Migration 10->11 warning: ${e.message}", e)
                }
            }

            private fun hasTableColumn(db: SupportSQLiteDatabase, table: String, column: String): Boolean {
                db.query("PRAGMA table_info($table)").use { cursor ->
                    val nameIdx = cursor.getColumnIndex("name")
                    while (cursor.moveToNext()) {
                        if (nameIdx >= 0 && cursor.getString(nameIdx) == column) {
                            return true
                        }
                    }
                }
                return false
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    if (!hasTableColumn(db, "member_ideas", "businessType")) {
                        db.execSQL("ALTER TABLE member_ideas ADD COLUMN businessType TEXT NOT NULL DEFAULT 'Product'")
                    }
                    if (!hasTableColumn(db, "member_ideas", "dislikedByUserIds")) {
                        db.execSQL("ALTER TABLE member_ideas ADD COLUMN dislikedByUserIds TEXT NOT NULL DEFAULT ''")
                    }
                } catch (e: Throwable) {
                    Log.e(TAG, "Migration 11->12 warning: ${e.message}", e)
                }
            }

            private fun hasTableColumn(db: SupportSQLiteDatabase, table: String, column: String): Boolean {
                db.query("PRAGMA table_info($table)").use { cursor ->
                    val nameIdx = cursor.getColumnIndex("name")
                    while (cursor.moveToNext()) {
                        if (nameIdx >= 0 && cursor.getString(nameIdx) == column) {
                            return true
                        }
                    }
                }
                return false
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val appContext = context.applicationContext
                try {
                    buildDatabase(appContext, scope).also { INSTANCE = it }
                } catch (e: Throwable) {
                    Log.e(TAG, "Database initialization error, resetting database: ${e.message}", e)
                    try {
                        appContext.deleteDatabase(DB_NAME)
                    } catch (delEx: Throwable) {
                        Log.e(TAG, "Failed to delete database file: ${delEx.message}")
                    }
                    buildDatabase(appContext, scope).also { INSTANCE = it }
                }
            }
        }

        private fun buildDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                DB_NAME
            )
                .addMigrations(MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12)
                .addCallback(AppDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
        }

        suspend fun populateInitialData(dao: AppDao) {
            // Clear existing before repopulating
            dao.clearMembers()
            dao.clearDeposits()
            dao.clearExpenses()
            dao.clearInvestments()
            dao.clearSettlements()
            dao.clearConfigs()
            dao.clearPaymentRequests()
            dao.clearExitedMembers()

            dao.insertExitedMembers(
                listOf(
                    ExitedMember(1, "Exited Partner A", "+880 1700-111111", "2025-05-15", 14, "Early withdrawal loss share"),
                    ExitedMember(2, "Exited Partner B", "+880 1700-222222", "2025-07-20", 14, "Mid-term withdrawal loss share"),
                    ExitedMember(3, "Exited Partner C", "+880 1700-333333", "2025-09-10", 14, "Late withdrawal loss share")
                )
            )

            // 11 Verified Active Founding Members
            val initialMembers = listOf(
                Member(1, "Mohsin Ali", "01773-313693", "2025-05-01", "Kharkharian"),
                Member(2, "Mostafizur Rahman", "01611-985331", "2025-05-01", "Kharkharian"),
                Member(3, "Jony Mia", "01332-330113", "2025-05-01", "Kharkharian"),
                Member(4, "Saiful Islam", "01955-609509", "2025-05-01", "Kharkharian"),
                Member(5, "Rakib Hossen (A)", "01792-430077", "2025-05-01", "Kharkharian"),
                Member(6, "Ropok Islam", "01649-108567", "2025-05-01", "Kharkharian"),
                Member(7, "Rakibul Islam", "01405-184559", "2025-05-01", "Kharkharian"),
                Member(8, "Sumon Mia", "01967-284173", "2025-05-01", "Kharkharian"),
                Member(9, "Hasanuzzaman", "01581-282197", "2025-05-01", "Kharkharian"),
                Member(10, "Rafiqul Islam", "01921-827138", "2025-05-01", "Kharkharian"),
                Member(11, "Jakir Hossen", "8221021306708", "2025-05-01", "Kharkharian")
            )
            dao.insertMembers(initialMembers)

            // Verified Month-by-Month Deposit Matrix:
            // Total Verified Deposits: ৳1,79,000 across 11 members | Late Fines: ৳4,200
            val initialDeposits = mutableListOf<Deposit>()

            // 2025 Base Deposits (Total: ৳77,000 across 11 members)
            fun add2025(memberId: Int, monthsCount: Int) {
                val months2025 = listOf(
                    "May 2025", "Jun 2025", "Jul 2025", "Aug 2025",
                    "Sep 2025", "Oct 2025", "Nov 2025", "Dec 2025"
                )
                for (i in 0 until monthsCount) {
                    val m = months2025[i]
                    initialDeposits.add(
                        Deposit(
                            memberId = memberId,
                            month = m,
                            paymentDate = "2025-${(i + 5).toString().padStart(2, '0')}-10",
                            amount = 1000,
                            fine = 0,
                            paymentMode = "Cash"
                        )
                    )
                }
            }

            // Member 1: MOHSIN ALI (2025: ৳7,000 | 2026: ৳11,000 | Fine: ৳300 | Total: ৳18,000)
            add2025(1, 7)
            initialDeposits.add(Deposit(memberId = 1, month = "Jan 2026", paymentDate = "2026-01-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Mar 2026", paymentDate = "2026-03-12", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Apr 2026", paymentDate = "2026-04-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "May 2026", paymentDate = "2026-05-14", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Jun 2026", paymentDate = "2026-06-12", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Aug 2026", paymentDate = "2026-08-11", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Sep 2026", paymentDate = "2026-09-14", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 1, month = "Oct 2026", paymentDate = "2026-10-18", amount = 1000, fine = 300))

            // Member 2: MOSTAFIZUR RAHMAN (2025: ৳8,000 | 2026: ৳10,000 | Fine: ৳0 | Total: ৳18,000)
            add2025(2, 8)
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct").forEachIndexed { idx, m ->
                initialDeposits.add(
                    Deposit(memberId = 2, month = "$m 2026", paymentDate = "2026-${(idx + 1).toString().padStart(2, '0')}-08", amount = 1000, fine = 0)
                )
            }

            // Member 3: JONY MIA (2025: ৳4,000 | 2026: ৳8,000 | Fine: ৳100 | Total: ৳12,000)
            add2025(3, 4)
            initialDeposits.add(Deposit(memberId = 3, month = "Mar 2026", paymentDate = "2026-03-20", amount = 3000, fine = 100))
            initialDeposits.add(Deposit(memberId = 3, month = "Apr 2026", paymentDate = "2026-04-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 3, month = "May 2026", paymentDate = "2026-05-12", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 3, month = "Jun 2026", paymentDate = "2026-06-10", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 3, month = "Sep 2026", paymentDate = "2026-09-11", amount = 1000, fine = 0))

            // Member 4: SAIFUL ISLAM (2025: ৳6,000 | 2026: ৳10,000 | Fine: ৳500 | Total: ৳16,000)
            add2025(4, 6)
            initialDeposits.add(Deposit(memberId = 4, month = "Mar 2026", paymentDate = "2026-03-25", amount = 5000, fine = 500))
            initialDeposits.add(Deposit(memberId = 4, month = "May 2026", paymentDate = "2026-05-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 4, month = "Jun 2026", paymentDate = "2026-06-12", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 4, month = "Jul 2026", paymentDate = "2026-07-10", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 4, month = "Aug 2026", paymentDate = "2026-08-14", amount = 1000, fine = 0))

            // Member 5: RAKIB HOSSEN (A) (2025: ৳8,000 | 2026: ৳10,000 | Fine: ৳400 | Total: ৳18,000)
            add2025(5, 8)
            initialDeposits.add(Deposit(memberId = 5, month = "Mar 2026", paymentDate = "2026-03-22", amount = 3000, fine = 200))
            initialDeposits.add(Deposit(memberId = 5, month = "Jun 2026", paymentDate = "2026-06-19", amount = 3000, fine = 100))
            initialDeposits.add(Deposit(memberId = 5, month = "Aug 2026", paymentDate = "2026-08-12", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 5, month = "Oct 2026", paymentDate = "2026-10-18", amount = 2000, fine = 100))

            // Member 6: ROPOK ISLAM (2025: ৳8,000 | 2026: ৳10,000 | Fine: ৳500 | Total: ৳18,000)
            add2025(6, 8)
            initialDeposits.add(Deposit(memberId = 6, month = "Feb 2026", paymentDate = "2026-02-12", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 6, month = "Mar 2026", paymentDate = "2026-03-22", amount = 2000, fine = 200))
            initialDeposits.add(Deposit(memberId = 6, month = "Apr 2026", paymentDate = "2026-04-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 6, month = "Jun 2026", paymentDate = "2026-06-14", amount = 2000, fine = 0))
            initialDeposits.add(Deposit(memberId = 6, month = "Oct 2026", paymentDate = "2026-10-25", amount = 4000, fine = 300))

            // Member 7: RAKIBUL ISLAM (2025: ৳8,000 | 2026: ৳10,000 | Fine: ৳0 | Total: ৳18,000)
            add2025(7, 8)
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct").forEachIndexed { idx, m ->
                initialDeposits.add(
                    Deposit(memberId = 7, month = "$m 2026", paymentDate = "2026-${(idx + 1).toString().padStart(2, '0')}-09", amount = 1000, fine = 0)
                )
            }

            // Member 8: SUMON MIA (2025: ৳8,000 | 2026: ৳10,000 | Fine: ৳400 | Total: ৳18,000)
            add2025(8, 8)
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct").forEachIndexed { idx, m ->
                val fineAmt = if (m == "Apr" || m == "Jul" || m == "Sep" || m == "Oct") 100 else 0
                val day = if (fineAmt > 0) "20" else "10"
                initialDeposits.add(
                    Deposit(memberId = 8, month = "$m 2026", paymentDate = "2026-${(idx + 1).toString().padStart(2, '0')}-$day", amount = 1000, fine = fineAmt)
                )
            }

            // Member 9: HASANUZZAMAN (2025: ৳5,000 | 2026: ৳10,000 | Fine: ৳100 | Total: ৳15,000)
            add2025(9, 5)
            initialDeposits.add(Deposit(memberId = 9, month = "Mar 2026", paymentDate = "2026-03-10", amount = 5000, fine = 0))
            initialDeposits.add(Deposit(memberId = 9, month = "Nov 2026", paymentDate = "2026-11-20", amount = 5000, fine = 100))

            // Member 10: RAFIQUL ISLAM (2025: ৳8,000 | 2026: ৳2,000 | Fine: ৳100 | Total: ৳10,000)
            add2025(10, 8)
            initialDeposits.add(Deposit(memberId = 10, month = "Jan 2026", paymentDate = "2026-01-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 10, month = "Apr 2026", paymentDate = "2026-04-22", amount = 1000, fine = 100))

            // Member 11: JAKIR HOSSEN (2025: ৳7,000 | 2026: ৳11,000 | Fine: ৳700 | Total: ৳18,000)
            add2025(11, 7)
            initialDeposits.add(Deposit(memberId = 11, month = "Jan 2026", paymentDate = "2026-01-11", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 11, month = "Apr 2026", paymentDate = "2026-04-12", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 11, month = "Jun 2026", paymentDate = "2026-06-10", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 11, month = "Aug 2026", paymentDate = "2026-08-11", amount = 1000, fine = 0))
            initialDeposits.add(Deposit(memberId = 11, month = "Oct 2026", paymentDate = "2026-10-24", amount = 7000, fine = 700))

            dao.insertDeposits(initialDeposits)

            // Verified Master Sheet Investments (Net Realized P/L: -৳600)
            val initialInvestments = getMasterInvestments()
            dao.insertInvestments(initialInvestments)

            // Verified 8 Master Sheet Operational Expenses Totaling ৳1,487
            val initialExpenses = getMasterExpenses()
            dao.insertExpenses(initialExpenses)

            // Default Admin User
            dao.insertAdmin(
                AdminUser(
                    username = "admin",
                    password = "rrk2025",
                    role = "Super Admin",
                    addedBy = "System",
                    addedAt = "2025-05-01"
                )
            )

            // Initial Financial Configurations: Bank ৳726, Reserve ৳4,200, 2025 Fines ৳1,100, Exited Loss Recovery +৳42
            dao.setConfig(AppConfig("bank_balance", "726"))
            dao.setConfig(AppConfig("reserved_amount", "4200"))
            dao.setConfig(AppConfig("historical_2025_fines", "1100"))
            dao.setConfig(AppConfig("exited_loss_recovery", "42"))
            dao.setConfig(AppConfig("master_sheet_audit_v3", "true"))

            // Official Payment Receiving Accounts (Editable by Admin)
            dao.setConfig(AppConfig("pay_bkash_number", OfficialPaymentAccounts.DEFAULT_BKASH))
            dao.setConfig(AppConfig("pay_nagad_number", OfficialPaymentAccounts.DEFAULT_NAGAD))
            dao.setConfig(AppConfig("pay_bank_details", OfficialPaymentAccounts.DEFAULT_BANK))

            // Initial Activity Log
            dao.insertLog(
                ActivityLog(
                    type = "settings",
                    message = "System calibrated to official November 2026 Head Office dataset (11 Members, ৳1,79,000 deposits, ৳4,200 fines, ৳1,487 expenses)",
                    username = "Rakib"
                )
            )
        }

        fun getMasterInvestments(): List<Investment> = listOf(
            Investment(
                id = 1,
                name = "Agro — Female Goat (Qty: 2)",
                type = "Agro",
                amount = 9600,
                purchasedQuantity = "Qty: 2",
                saleDate = "20 Jun 2025",
                soldQuantity = "৳5,700 + ৳1,500 + ৳7,000",
                saleRevenue = 14200,
                expenses = 0,
                profitLoss = 4600,
                activeCapital = 0,
                status = "CLOSED",
                date = "20 Jun 2025",
                supervisor = "Rupok",
                stockStatus = "Closed",
                description = "Invested ৳9,600 (20 Jun 2025) | Sold ৳14,200 (৳5,700 + ৳1,500 + ৳7,000) | Profit: +৳4,600 | Supervision: Rupok | Status: Closed"
            ),
            Investment(
                id = 2,
                name = "Stock — Cumin / Jira (Qty: 90 Kg)",
                type = "Stock",
                amount = 48620,
                purchasedQuantity = "Qty: 90 Kg",
                saleDate = "07 Dec 2025",
                soldQuantity = "90 Kg",
                saleRevenue = 48620,
                expenses = 0,
                profitLoss = 0,
                activeCapital = 0,
                status = "CLOSED",
                date = "29 Sep 2025",
                supervisor = "Rakibul",
                stockStatus = "Closed",
                description = "Invested ৳48,620 (29 Sep 2025) | Sold ৳48,620 (07 Dec 2025) | Equal: ৳0 | Supervision: Rakibul | Status: Closed"
            ),
            Investment(
                id = 3,
                name = "Stock — Cigarette Batch 1 (Qty: 50 Carton)",
                type = "Stock",
                amount = 87500,
                purchasedQuantity = "Qty: 50 Carton",
                saleDate = "29 Jan 2026",
                soldQuantity = "50 Carton",
                saleRevenue = 89000,
                expenses = 0,
                profitLoss = 1500,
                activeCapital = 0,
                status = "CLOSED",
                date = "05 Dec 2025",
                supervisor = "Rakibul",
                stockStatus = "Closed",
                description = "Invested ৳87,500 (05 Dec 2025) | Sold ৳89,000 (29 Jan 2026) | Profit: +৳1,500 | Supervision: Rakibul | Status: Closed"
            ),
            Investment(
                id = 4,
                name = "Stock — Cigarette Batch 2 (Qty: 2 Case / 100)",
                type = "Stock",
                amount = 128000,
                purchasedQuantity = "Qty: 2 Case / 100",
                saleDate = "Aug 2026",
                soldQuantity = "2 Case / 100",
                saleRevenue = 121300,
                expenses = 0,
                profitLoss = -6700,
                activeCapital = 0,
                status = "CLOSED",
                date = "18 May 2026",
                supervisor = "Rakibul",
                stockStatus = "Closed",
                description = "Invested ৳128,000 (18 May 2026) | Sold ৳121,300 (Aug 2026) | Loss: -৳6,700 | Supervision: Rakibul | Status: Closed"
            )
        )

        fun getMasterExpenses(): List<Expense> = listOf(
            Expense(
                id = 1,
                description = "Goat Rap",
                category = "Agro",
                quantity = "Tying Sets",
                amount = 200,
                date = "2025-09-10",
                paidBy = "Finance Dept",
                remarks = "Goat rope and tying materials"
            ),
            Expense(
                id = 2,
                description = "Goat Sell Cost",
                category = "Agro",
                quantity = "Haat Trip",
                amount = 60,
                date = "2025-10-14",
                paidBy = "Finance Dept",
                remarks = "Goat market selling cost"
            ),
            Expense(
                id = 3,
                description = "Amjad",
                category = "Agro",
                quantity = "Honorarium",
                amount = 300,
                date = "2025-11-12",
                paidBy = "Finance Dept",
                remarks = "Caregiver labor honorarium (Amjad)"
            ),
            Expense(
                id = 4,
                description = "Goat Husk+Food",
                category = "Agro",
                quantity = "Feed Sack",
                amount = 100,
                date = "2025-12-08",
                paidBy = "Finance Dept",
                remarks = "Goat husk and nutritional fodder"
            ),
            Expense(
                id = 5,
                description = "Bank SMS Charge",
                category = "Bank Charge",
                quantity = "Service Fee",
                amount = 37,
                date = "2026-01-10",
                paidBy = "Bank Auto Trnx",
                remarks = "Corporate bank account SMS notification charge"
            ),
            Expense(
                id = 6,
                description = "Goat Medicine",
                category = "Agro",
                quantity = "1 Course",
                amount = 90,
                date = "2026-02-18",
                paidBy = "Finance Dept",
                remarks = "Veterinary medicine for livestock"
            ),
            Expense(
                id = 7,
                description = "Jalil Mom",
                category = "Agro",
                quantity = "Caretaking",
                amount = 400,
                date = "2026-04-15",
                paidBy = "Finance Dept",
                remarks = "Livestock caretaking allowance (Jalil Mom)"
            ),
            Expense(
                id = 8,
                description = "Goat Treatment",
                category = "Agro",
                quantity = "Vet Visit",
                amount = 300,
                date = "2026-06-05",
                paidBy = "Finance Dept",
                remarks = "Veterinary doctor treatment and care"
            )
        )

        /**
         * Non-destructively audits an existing database and updates ONLY the mismatched
         * investments, operational expenses, and the 5 members' 2026 fine entries without
         * resetting user accounts, payment requests, or matching member records.
         */
        suspend fun ensureMasterSheetCalibrated(dao: AppDao) {
            if (dao.getConfig("master_sheet_audit_v3") == "true") return

            // 1. Update ONLY the 5 members whose seeded 2026 fine amounts had 2025 fines lumped in
            val expectedFineByMember = mapOf(
                2 to 0,
                7 to 0,
                9 to 100,
                10 to 100,
                11 to 700
            )
            for ((memberId, targetFine) in expectedFineByMember) {
                val memberDeps = dao.getAllDepositsSync().filter { it.memberId == memberId }
                val currentFineSum = memberDeps.sumOf { it.fine }
                if (currentFineSum != targetFine && memberDeps.isNotEmpty()) {
                    val targetDep = memberDeps.firstOrNull { it.fine > 0 } ?: memberDeps.first()
                    for (dep in memberDeps) {
                        val newFine = if (dep.id == targetDep.id) targetFine else 0
                        if (dep.fine != newFine) {
                            dao.updateDeposit(dep.copy(fine = newFine))
                        }
                    }
                }
            }

            // 2. Replace mismatched placeholder investments with the 4 verified closed historical investments
            val currentInvs = dao.getAllInvestmentsSync()
            if (currentInvs.size != 4 || currentInvs.none { it.name.startsWith("Agro — Female Goat") }) {
                dao.clearInvestments()
                dao.insertInvestments(getMasterInvestments())
            }

            // 3. Replace mismatched expense amounts/labels with the 8 verified master sheet expenses
            val currentExps = dao.getAllExpensesSync()
            if (currentExps.none { it.description == "Jalil Mom" && it.amount == 400 }) {
                dao.clearExpenses()
                dao.insertExpenses(getMasterExpenses())
            }

            dao.setConfig(AppConfig("historical_2025_fines", "1100"))
            dao.setConfig(AppConfig("exited_loss_recovery", "42"))
            dao.setConfig(AppConfig("master_sheet_audit_v3", "true"))
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                try {
                    INSTANCE?.let { populateInitialData(it.appDao()) }
                } catch (e: Throwable) {
                    Log.e("AppDatabase", "Error during onCreate populateInitialData: ${e.message}", e)
                }
            }
        }

        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
            super.onDestructiveMigration(db)
            scope.launch(Dispatchers.IO) {
                try {
                    INSTANCE?.let { populateInitialData(it.appDao()) }
                } catch (e: Throwable) {
                    Log.e("AppDatabase", "Error during onDestructiveMigration populateInitialData: ${e.message}", e)
                }
            }
        }
    }
}
